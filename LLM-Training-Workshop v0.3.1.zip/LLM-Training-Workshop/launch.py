"""LLM Training Workshop · launcher

Double-click: start the local service → open the UI in your default browser.
Zero third-party dependencies; Python standard library only.
"""
from __future__ import annotations

import os
import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

# 默认 1220（用户指定）。若该端口被占，可用环境变量 LLM_WORKSHOP_PORT 覆盖，
# 不必改代码：set LLM_WORKSHOP_PORT=1221 后再启动。
PORT = int(os.environ.get("LLM_WORKSHOP_PORT") or 1220)
HOST = "127.0.0.1"
APP_TITLE = "LLM Training Workshop"
REPO_URL = "https://github.com/HOISwsmh/LLM-Training-Workshop"


def port_busy(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.6)
        return s.connect_ex((HOST, port)) == 0


def bi(zh: str, en: str) -> None:
    """控制台提示中英双行：黑窗口不跟随界面语言，两种都显示最稳妥。"""
    print("  " + zh)
    print("  " + en)


def main() -> int:
    print("=" * 62)
    print(f"  {APP_TITLE} · LLM 训练工坊")
    print("=" * 62)
    print()
    bi("[说明] 本工具为单卡训练设计，多张显卡不合并显存。",
       "[Note] Single-GPU tool. Multiple GPUs are not combined.")
    bi("       模型规模 / 上下文 / 显存只给参考提示，是否尝试由你决定。",
       "       Model size / context / VRAM are advisory only — your call.")
    bi("       实验性工具，非生产级软件。",
       "       Experimental tool, not production-grade software.")
    print()
    # 仓库地址只打印，不自动打开：启动时不该擅自开外部网页
    bi(f"项目仓库：{REPO_URL}", f"Repository: {REPO_URL}")
    print()

    url = f"http://{HOST}:{PORT}"

    if port_busy(PORT):
        bi(f"服务已在运行，直接打开浏览器：{url}",
           f"Service already running. Opening browser: {url}")
        webbrowser.open(url)
        print()
        bi("（此窗口可以关闭，服务会继续运行。）",
           "(You may close this window; the service keeps running.)")
        time.sleep(2)
        return 0

    try:
        from app.server import serve
    except Exception as e:  # noqa: BLE001
        bi(f"[错误] 无法加载后端：{type(e).__name__}: {e}",
           f"[Error] Cannot load backend: {type(e).__name__}: {e}")
        input("  按回车退出 / Press Enter to exit...")
        return 1

    try:
        httpd = serve(HOST, PORT)
    except OSError as e:
        bi(f"[错误] 无法监听端口 {PORT}：{e}",
           f"[Error] Cannot listen on port {PORT}: {e}")
        bi("       可设置环境变量 LLM_WORKSHOP_PORT 换一个端口再启动。",
           "       Set LLM_WORKSHOP_PORT to use another port.")
        input("  按回车退出 / Press Enter to exit...")
        return 1

    bi(f"服务已启动：{url}", f"Service started: {url}")
    bi("正在打开默认浏览器…", "Opening your default browser...")
    print()
    bi("★ 训练期间请保持此黑窗口打开。",
       "* Keep this console window open while training.")
    bi("  关闭它会停止服务；已保存的断点不受影响，下次可继续训练。",
       "  Closing it stops the service; saved checkpoints are safe to resume.")
    print()

    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        bi("正在关闭服务…", "Shutting down...")
    finally:
        httpd.shutdown()
        httpd.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())

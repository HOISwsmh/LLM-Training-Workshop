# LLM 训练工坊 · 完整手册
# LLM Training Workshop · Complete Manual

**v0.1 · 公开测试版 / Public Beta**

> 本文合并了使用说明、测试指引与第三方声明，中英双语对照。
> This single document merges the user guide, testing guide and third-party notices, in Chinese and English.
>
> **许可证原文见同目录 `LICENSE.txt`（Apache-2.0）。翻译不具法律效力，以英文原文为准。**
> **The authoritative license text is `LICENSE.txt` (Apache-2.0) in this folder. Translations are for convenience only.**

---

## 目录 / Contents

| 中文 | English |
|---|---|
| [1. 这是什么](#1-这是什么--what-is-this) | What is this |
| [2. 能力边界（必读）](#2-能力边界必读--limitations-read-first) | Limitations (read first) |
| [3. 环境准备](#3-环境准备--environment-setup) | Environment setup |
| [4. 快速开始](#4-快速开始--quick-start) | Quick start |
| [5. 界面与功能](#5-界面与功能--ui--features) | UI & features |
| [6. 模型规模与自定义架构](#6-模型规模与自定义架构--model-size--custom-architecture) | Model size & custom architecture |
| [7. 语料与清洗](#7-语料与清洗--corpus--cleaning) | Corpus & cleaning |
| [7.5 使用已有文件](#75-使用已有文件--using-existing-files) | Using existing files |
| [8. 断点与备份](#8-断点与备份--checkpoints--backup) | Checkpoints & backup |
| [8.5 外部训练监控](#85-外部训练监控只读--external-training-monitor-read-only) | External training monitor |
| [8.6 升级到新版](#86-升级到新版--updating-to-a-new-version) | Updating to a new version |
| [9. 测试指引](#9-测试指引--testing-guide) | Testing guide |
| [10. 常见问题](#10-常见问题--faq) | FAQ |
| [11. 第三方与许可](#11-第三方与许可--third-party--licensing) | Third-party & licensing |
| [12. 隐私与免责](#12-隐私与免责--privacy--disclaimer) | Privacy & disclaimer |

---

## 1. 这是什么 / What is this

**中文**：让个人开发者不写代码，也能训练自己的中文小模型。提供本地语料，点几下按钮，
程序自动完成清洗、构建训练集、训练，全程可视化查看损失曲线与断点。

**English**: Train your own small Chinese language model without writing code.
Point it at local corpus files, click a few buttons, and it handles cleaning,
dataset building and training — with live loss curves and checkpoint management.

### 文件结构 / File layout

```
llm-workshop/
├── start_workshop.bat   ← 双击这个 / Double-click this
├── launch.py            ← 启动器 / Launcher
├── app/                 ← 后端 / Backend
├── web/                 ← 界面 / UI (HTML/CSS/JS)
├── engine/              ← 训练脚本 / Training scripts
├── MANUAL.md            ← 本文 / This manual
├── LICENSE.txt          ← Apache-2.0
├── projects/            ← 你的项目（自动创建）/ Your projects (auto-created)
└── logs/                ← 服务日志（自动创建）/ Service logs (auto-created)
```

### 文件都写在哪 / Where files are written

**中文**：每个项目的产物都在 `projects/<项目名>/` 内：

| 子目录 | 内容 |
|---|---|
| `data/` | 适配、清洗、打包、整合后的语料 |
| `tokenizer/` | 训练出的词表 |
| `output/model/` | **模型与断点**（默认位置，可改，见下） |
| `logs/` | 各步骤日志 |
| `tmp/` | 临时文件，**用完即删** |
| `cache/` | CUDA / HuggingFace / torch 等缓存 |

**模型输出目录可自定义**：「新建项目 → 高级参数 → 模型输出目录」。留空用项目内 `output/model`，
也可填任意路径（例如另一块盘）。模型、断点、训练日志都会写到那里，界面也按该位置读取。

**★不往系统盘乱塞东西**：程序为每个训练子进程设置了
`TMP`/`TEMP`/`CUDA_CACHE_PATH`/`HF_HOME`/`TORCH_HOME`/`TRITON_CACHE_DIR`/`XDG_CACHE_HOME`，
全部指向项目内的 `tmp/` 与 `cache/`。词表训练的大临时语料也写在项目内并在训练后删除。

实测对比：改动前往 `C:\...\Temp` 写过 **773MB** 临时语料；改动后同一流程跑完，
C 盘关键位置（Temp / NVIDIA ComputeCache / .cache）**增量仅 0.35MB**，
且那是 Windows 自身产生的空 `.tmp`，不是本程序的数据。

唯一例外：你在「备份目录」里主动指定的位置——那是你自己的选择。

**English**: Everything a project produces lives under `projects/<name>/`:
`data/` (processed corpus), `tokenizer/`, `output/model/` (**models & checkpoints**, default location, configurable),
`logs/`, `tmp/` (temporary, **deleted after use**), `cache/` (CUDA / HuggingFace / torch caches).

**The model output directory is configurable** via New Project → Advanced → Model output directory.
Leave it blank for `output/model` inside the project, or point it anywhere (e.g. another drive).
Models, checkpoints and the training log go there, and the UI reads from the same place.

**★No silent writes to the system drive**: every training subprocess gets
`TMP`/`TEMP`/`CUDA_CACHE_PATH`/`HF_HOME`/`TORCH_HOME`/`TRITON_CACHE_DIR`/`XDG_CACHE_HOME`
pointed at the project's own `tmp/` and `cache/`. The large temporary tokenizer corpus is also
written inside the project and removed afterwards.

Measured: before this change a run wrote **773MB** into `C:\...\Temp`; after it, the same flow left
only **0.35MB** of growth across Temp / NVIDIA ComputeCache / .cache — and that was empty `.tmp`
files created by Windows itself, not by this app.

The only exception is a backup directory you explicitly choose yourself.

**中文**
- 整个文件夹约 8MB，可整体拷到任何 Windows 电脑
- 界面资源已嵌入 exe，**不需要浏览器文件、不需要联网**
- 双击后弹出**独立应用窗口**（无地址栏、无标签页），用系统自带 Edge/Chrome 的应用模式实现
- 可以移动位置，但 **exe 与 engine 文件夹必须在同一层**

**English**
- The whole folder is ~8 MB and can be copied to any Windows PC
- UI assets are embedded in the exe — **no browser files, no internet needed**
- Double-clicking opens a **standalone app window** (no address bar, no tabs), using the app mode of your installed Edge/Chrome
- You may move the folder, but **the exe and `engine/` must stay in the same directory**

> **engine 里的部分脚本界面不调用**：`prepare_audio_chart.py` / `train_multimodal.py` /
> `test_multimodal.py` 为实验性多模态预留；`fetch_corpus.py`（在线下载）与 `split_qa.py`（问答切分）
> 供进阶用户手动使用。`mm_tokens.py` 必须保留——词表训练依赖它的特殊标记定义。
>
> **Some engine scripts are not called by the UI**: the audio/multimodal scripts are experimental
> placeholders; `fetch_corpus.py` (online download) and `split_qa.py` (QA splitting) are for advanced
> manual use. `mm_tokens.py` must be kept — tokenizer training depends on its special-token definitions.

---

## 2. 能力边界（必读）/ Limitations (read first)

| 项目 / Item | 支持情况 / Support |
|---|---|
| 多卡 / 多机并行<br>Multi-GPU / multi-node | **不支持 / Not supported** — 只用第一张卡，不合并显存<br>Only the first GPU is used; VRAM is not pooled |
| 最大模型 / Max model size | **≤ 7B**（取决于显存 / depends on your VRAM） |
| 最大上下文 / Max context | **≤ 8192 tokens** |
| 定位 / Positioning | **实验性工具，非生产级软件**<br>**Experimental tool, not production-grade software** |

**中文**：想训 27B、262k 上下文、8 卡集群？请用专业分布式框架
（Megatron-LM / DeepSpeed / torchtitan / nanotron）。本工具不是为此设计的。

**English**: Want 27B, 262k context, or an 8-GPU cluster? Use a dedicated distributed framework
(Megatron-LM / DeepSpeed / torchtitan / nanotron). This tool is not built for that.

### 显存对照 / VRAM reference

估算值，实际以运行时检测为准 / Estimates; actual detection at runtime prevails.

| 显存 VRAM | 舒适训练 Comfortable | 极限（batch=1，很慢）Limit (slow) |
|---|---|---|
| 8 GB | ~0.6B | ~1.2B |
| 12 GB | ~1.2B | ~2.1B |
| 16 GB | ~1.9B | ~3.0B |
| 24 GB | ~3.3B | ~4.9B |
| 32 GB | ~4.7B | ~6.8B |
| 48 GB | ~7.7B | ~10.7B |

**中文**：程序启动时自动检测显卡，**显存不足的档位直接灰掉**。显存读数取自全局，
会扣除其他程序占用的部分，不会让你第一次就 OOM。

**English**: On startup the app detects your GPU and **greys out tiers that won't fit**.
VRAM readings are system-wide (other programs' usage is subtracted), so you won't OOM on the first try.

---

## 3. 环境准备 / Environment setup

**中文**：**本程序不自带 Python 与训练库**（PyTorch 含 CUDA 约 2.9GB）。环境需你自己准备一次。
程序会自动探测本机已装的 conda / venv / 官方 Python；没找到会在「运行环境」页给出指引，也可手动指定 python.exe。

**English**: **Python and training libraries are NOT bundled** (PyTorch + CUDA is ~2.9 GB).
You set up the environment once. The app auto-detects conda / venv / official Python installs;
if none is found, the "Environment" page shows setup instructions, and you can also point it at a specific `python.exe`.

已有可用环境可跳过本节 / Skip this section if you already have a working PyTorch environment.

```bash
# 1. 安装 Python 3.10 或 3.11，勾选 Add Python to PATH
#    Install Python 3.10 or 3.11, check "Add Python to PATH"

# 2. 建虚拟环境 / Create a virtual environment
python -m venv llm-env

# 3. 激活（Windows）/ Activate (Windows)
llm-env\Scripts\activate

# 4. 装依赖 / Install dependencies
pip install torch transformers tokenizers numpy pyarrow
```

**中文**：GPU 训练需装对应 CUDA 版本的 torch，去 pytorch.org 按显卡选命令。
只有 CPU 版也能跑，但极慢，仅适合 15M 档体验。装好后到「运行环境」页点「重新检测」，显示绿色「环境就绪」即可。

**English**: For GPU training install the CUDA build of torch — pick the command for your GPU at pytorch.org.
A CPU-only build works but is extremely slow (15M tier only, for trying the flow).
After installing, click "Re-detect" on the Environment page until it shows a green "Ready".

必需依赖 / Required: `torch`, `transformers`, `tokenizers`, `numpy`
可选 / Optional: `pyarrow`（读 parquet 语料 / for parquet corpora）

---

## 4. 快速开始 / Quick start

| # | 中文 | English |
|---|---|---|
| 1 | 双击 `LLM训练工坊.exe` | Double-click `LLM训练工坊.exe` |
| 2 | 弹出独立窗口；环境未就绪会自动跳到「运行环境」页 | A standalone window opens; if the env isn't ready it jumps to the Environment page |
| 3 | 「新建项目」→ 填名字 → 添加本地语料并选类型 → 选模型规模 → 创建 | New Project → name it → add local corpus & pick its type → choose model size → create |
| 4 | 「数据处理」→ 点要执行的步骤（可只跑一段） | Data Processing → click the stage group you want (partial runs allowed) |
| 5 | 「训练中心」→ 开始训练 → 看曲线、管断点 | Training Center → start → watch curves, manage checkpoints |

> ⚠ **中文**：训练期间**不要关闭那个黑色控制台窗口**，关了服务会停。已保存的断点不会丢，重开可续。
>
> ⚠ **English**: **Do not close the black console window** while training — closing it stops the service.
> Saved checkpoints are safe; reopen and resume.

**首次建议 / First-run advice**

**中文**：模型选 **15M 或 124M**，语料先用一个小文件，上下文 512，断点间隔 100 步。
先跑通全流程（几分钟到一小时）再加量。直接上 3B + 几十 GB 语料 = 几个月。

**English**: Start with the **15M or 124M** tier, one small corpus file, context 512, checkpoint every 100 steps.
Get the whole flow working (minutes to an hour) before scaling up. Jumping straight to 3B with tens of GB
of corpus means months of waiting.

---

## 5. 界面与功能 / UI & features

| 页面 / Page | 作用 / Purpose |
|---|---|
| **我的项目**<br>My Projects | 项目卡片、进度、硬件与推荐规模<br>Project cards, progress, hardware & recommended tier |
| **新建项目**<br>New Project | 语料配置、模型规模（含自定义架构）、上下文、断点、高级参数<br>Corpus config, model size (incl. custom architecture), context, checkpoints, advanced params |
| **数据处理**<br>Data Processing | 五段进度、步骤分组单选、清洗参数表、分步日志<br>Five-stage progress, stage-group selection, cleaning params table, per-stage logs |
| **训练中心**<br>Training Center | 完成横幅、7 个实时指标、双曲线、断点管理、日志<br>Completion banner, 7 live metrics, two charts, checkpoint management, logs |
| **运行环境**<br>Environment | 环境状态、手动指定 python.exe、安装指引、路径信息<br>Env status, manual python.exe, setup guide, path info |
| **能力说明**<br>About & Limits | 能力边界、显存表、免责<br>Limitations, VRAM table, disclaimer |

### 步骤可单独执行 / Run stages selectively

**中文**：不必每次从头跑到尾。已完成的步骤不会重复执行；想重跑会询问确认；前置条件不满足的分组标灰。

**English**: You don't have to run everything each time. Completed stages are skipped;
re-running asks for confirmation; groups whose prerequisites aren't met are greyed out.

| 分组 / Group | 包含步骤 / Stages |
|---|---|
| 准备数据 / Prepare Data | 识别字段 → 清洗 / field mapping → cleaning |
| 构建训练集 / Build Dataset | 训词表 → 打包 → 整合 / tokenizer → packing → mixing |
| 数据全流程 / All Data Stages | 上述五步 / all five above |
| 仅训练 / Train Only | 训练 / training |
| 仅验证 / Test Only | 验证 / evaluation & generation test |
| 全部步骤 / Everything | 七步全跑 / all seven stages |

### 训练中心能看到什么 / What the Training Center shows

**中文**：总进度条与百分比；7 个实时指标（步数、损失、已训 token、速度、显存、预计剩余、尖刺/回滚）；
损失曲线（训练线 + 验证线）；速度与显存双轴曲线；断点表（名称、**步数**、大小、时间、「从此续训」按钮）；
训练与验证日志切换。数据每几秒自动刷新。训练完成后顶部出现绿色「训练完成」横幅，显示耗时与保存位置。

**English**: Overall progress bar and percentage; 7 live metrics (step, loss, tokens seen, throughput,
VRAM, ETA, spikes/rollbacks); loss chart with both training and validation lines; dual-axis throughput/VRAM chart;
checkpoint table (name, **step**, size, time, "resume from here"); switchable training/test logs.
Data refreshes every few seconds. On completion a green "Training complete" banner shows elapsed time and save location.

---

## 6. 模型规模与自定义架构 / Model size & custom architecture

### 9 个预设档位 / 9 preset tiers

| 档位 Tier | 参数量 Params | 约需显存 VRAM |
|---|---|---|
| 15M · 体验 Try-out | 0.015B | 2.1 GB |
| 39M · 入门 Starter | 0.039B | 2.2 GB |
| 124M · 小型 Small | 0.124B | 2.5 GB |
| 345M · 中型 Medium | 0.345B | 3.3 GB |
| 748M · 较大 Large | 0.748B | 4.8 GB |
| 1.3B · 大型 XL | 1.299B | 6.9 GB |
| 2B · 很大 2B | 1.985B | 9.5 GB |
| 3B · 高端 3B | 2.934B | 13.0 GB |
| **7B · 单卡上限 Single-GPU ceiling** | **5.802B** | **23.8 GB** |

> **中文**：显存为「权重+梯度+优化器+激活基线」静态估算，长上下文会再增加。显存不足的档位直接灰掉。
> 表中参数量按 32000 词表计；实际参数量随你设的词表大小变化（词表越大，嵌入层参数越多）。
>
> **English**: VRAM figures are static estimates (weights + grads + optimizer + activation baseline); long context adds more.
> Tiers that don't fit are greyed out. Parameter counts assume a 32,000-token vocabulary;
> the actual count varies with the vocab size you set (a larger vocab means more embedding parameters).

### 完全自定义 / Fully custom architecture

**中文**：「新建项目」→ 模型规模区 → 点「自定义模型架构」展开，勾选「启用」后可调下表各项。
**English**: New Project → model size section → expand "Custom architecture" → tick "Enable" → adjust the fields below.

| 可调项 Field | 范围 Range | 说明 Notes |
|---|---|---|
| 隐层宽度 Hidden size | 64 – 8192 | 主干维度 / backbone width |
| 层数 Layers | 1 – 80 | Transformer 块数 / number of blocks |
| 前馈中间维度 FFN intermediate | 64 – 32768 | SwiGLU 内部维度，约隐层 2.7–4 倍 / ~2.7–4× hidden |
| 每头维度 Head dim | 32 – 256 | 常用 64 或 128 / commonly 64 or 128 |
| 注意力头数 Attention heads | 1 – 128 | 留空自动 = 隐层 ÷ 每头维度 / blank = hidden ÷ head_dim |
| KV 头数 KV heads (GQA) | 1 – 128 | 留空自动取头数 1/4 / blank = heads ÷ 4 |

外加开关 / Plus a toggle：**共享输入输出词嵌入 / tie input-output embeddings**（省参数，中小模型推荐 / saves params, recommended for small–mid models）。

**三个设计要点 / Three design points**

1. **以当前档位为起点**，只改你想改的项，其余沿用预设。
   **Starts from the selected tier**; only the fields you change are overridden.
2. **实时显示参数量与预计显存**，超出可用显存当场警告，不用等开训才发现。
   **Live parameter count and VRAM estimate**, warning immediately if it exceeds available VRAM.
3. **结构合法性校验**：隐层不是头维度整数倍、头数不能被 KV 整除等会明确提示；
   词表大小始终以实际分词器为准，不受架构改动影响。
   **Structural validation**: non-divisible hidden/head_dim or heads/KV mismatches are flagged;
   vocab size always follows the actual tokenizer and is never broken by architecture edits.

> 参数量估算与引擎实际构建**实测偏差 0.000%**——界面上的数字就是真实参数量。
> Parameter estimates match the engine's actual construction with **0.000% measured deviation** — what you see is what you get.

---

## 7. 语料与清洗 / Corpus & cleaning

### 按类型自动适配 / Per-type presets

**中文**：一刀切的清洗阈值会误杀整类语料，所以每类有自己的预设。
**English**: One-size-fits-all thresholds wipe out entire corpus categories, so each type has its own preset.

| 类型 Type | 中文占比≥ CJK ≥ | 重复率≤ Repeat ≤ | 符号率≤ Symbol ≤ | 最短字数 Min chars |
|---|---|---|---|---|
| 网页正文 Web text | 0.30 | 0.50 | 0.30 | 20 |
| 百科词条 Encyclopedia | 0.35 | 0.50 | 0.28 | 20 |
| 问答对话 Q&A | 0.25 | 0.60 | 0.35 | 8 |
| 书籍文献 Books | 0.40 | 0.45 | 0.25 | 30 |
| 古籍文言 Classical | 0.50 | 0.55 | 0.25 | **8** |
| **代码 Code** | **0.00** | **0.80** | 0.55 | 20 |
| 自动识别 Auto | 0.20 | 0.60 | 0.35 | 8 |

> **中文**：这些数值来自真实项目的实测教训——代码类用通用「标准」强度会被**全部误杀**；
> 用默认 0.5 重复阈值会误杀 56%；古籍用 20 字门槛会滤掉大量正常段落。
>
> **English**: These numbers come from hard-won measurements — code corpora get **entirely wiped out**
> by generic "standard" settings; a 0.5 repetition threshold kills 56% of code;
> a 20-char minimum filters out most legitimate classical-Chinese paragraphs.

### 逐项自定义 / Per-corpus overrides

**中文**：每条语料下方点「自定义清洗参数」，可逐项调整 7 个阈值。
**English**: Under each corpus entry, expand "Custom cleaning params" to override any of 7 thresholds.

| 可调项 Field | 范围 Range |
|---|---|
| 中文字符占比下限 Min CJK ratio | 0 – 0.95 |
| 重复率上限 Max repetition | 0.10 – 0.99 |
| 符号占比上限 Max symbol ratio | 0.05 – 0.95 |
| 最短字符数 Min chars | 1 – 5000 |
| 最长字符数 Max chars | 100 – 2000000 |
| 数字占比上限 Max digit ratio | 0.10 – 0.99 |
| 单字最高占比 Max top-char ratio | 0.10 – 0.99 |

外加三个开关 / Plus three switches：**去除网址 / strip URLs**、**Unicode 规范化 / NFKC normalize**、
**去重方式 / dedup mode**（近似 approximate / 精确 exact / 关闭 off）。

1. **只覆盖你改动的项**，其余仍按类型适配。/ **Only your changed fields are overridden**; the rest still follow the type preset.
2. **每项可单独恢复预设**，也能一键全部恢复。/ **Reset per field** or reset all at once.
3. **实时风险提示**：给代码类设中文门槛 0.4 会立刻警告"可能滤掉绝大部分代码"。
   **Live risk warnings**: setting a 0.4 CJK threshold on code immediately warns that most code will be filtered out.

超出范围的值自动钳制，不会让你填出必然清空语料的配置。
Out-of-range values are clamped, so you can't configure something that empties the corpus.

### 多条语料与权重 / Multiple corpora & weights

**中文**：可添加多条语料，每条单独指定路径、类型与混合权重。支持 jsonl / json / parquet / gz，文件或文件夹皆可。
**English**: Add multiple corpus entries, each with its own path, type and mixing weight.
Supports jsonl / json / parquet / gz, either a single file or a folder.

---

## 7.5 使用已有文件 / Using existing files

**中文**：七个步骤都可以选「自己生成」或「使用已有」。已经有词表、打包好的 token 流、
或别处训到一半的模型时，不必从头再做一遍。在「新建项目」页的**使用已有文件**卡片里，
把对应步骤切到「使用已有」，填入路径，点「校验」确认可用即可。

**English**: Every one of the seven stages can either run itself or reuse a file you already have.
If you already own a tokenizer, a packed token stream, or a half-trained model from elsewhere,
you do not have to redo it. On the **New project** page, in the **Use existing files** card,
switch the stage to *Use existing*, enter the path, and click *Check*.

### 各步骤接受什么 / What each stage accepts

| 步骤 Stage | 填什么 What to provide | 必需文件 Required |
|---|---|---|
| 识别字段 Map fields | 已统一字段的 jsonl / a jsonl with unified fields | 每行含 `text` / `text` per line |
| 清洗 Clean | 已清洗的 jsonl / a cleaned jsonl | 每行含 `text` / `text` per line |
| 训练词表 Tokenizer | 词表目录 / tokenizer folder | `tokenizer.json` |
| 打包 Pack | token 流目录 / token stream folder | `tokens_train.bin` + `data_meta.json` |
| 整合 Mix | 训练集目录 / dataset folder | `tokens_train.bin` + `data_meta.json` |
| 训练 Train | 检查点或模型目录 / checkpoint or model folder | `config.json` + 权重 weights |
| 验证 Test | 模型目录 / model folder | `config.json` + 权重 weights |

### 三条重要行为 / Three behaviours worth knowing

**1. 大目录引用而不复制 / Large folders are referenced, not copied**

**中文**：token 流动辄几十 GB。导入打包/整合数据时，工坊建立**目录联接**指向原位置，
不复制、不占额外磁盘、也不改动你的原始数据。只有词表（几 MB）会复制进项目。
系统不支持联接时才退回复制，并会先检查磁盘空间。

**English**: Token streams are often tens of gigabytes. When importing packed or mixed data,
the workshop creates a **directory junction** pointing at the original location — no copy,
no extra disk usage, and your source data is never modified. Only the tokenizer (a few MB)
is copied into the project. If junctions are unavailable, it falls back to copying and checks
free space first.

**2. 词表大小必须一致 / Vocabulary size must match**

**中文**：导入的数据或模型若与配置里的「词表大小」不一致，**训练会被拒绝启动**。
这不是保守，而是必须——词表不同意味着 token 编号错位，训出来的权重是废的。
校验结果会直接告诉你应该把词表大小改成多少。

**English**: If imported data or a model disagrees with the configured vocabulary size,
**training refuses to start**. This is not caution but necessity: a different vocabulary means
token IDs are misaligned and the resulting weights are meaningless. The check tells you
which value to use.

**3. 从已有模型接着训 / Resuming from an existing model**

**中文**：训练步骤填检查点目录即可接着训。若填的是包含多个 `checkpoint-*` 的父目录，
工坊自动选步数最大的那个。目录里有 `optimizer.pt` 时连优化器状态一起恢复，步数不归零；
只有权重没有优化器时，会提示「仅继承权重」——此时学习率预热重来，loss 可能短暂上跳，属正常。

**English**: Point the Train stage at a checkpoint folder to continue from it. If you give a parent
folder containing several `checkpoint-*` entries, the highest step is picked automatically.
With `optimizer.pt` present, optimizer state is restored and the step counter continues;
with weights only, you get a *weights only* notice — warmup restarts and loss may briefly jump,
which is expected.

### 每条语料也能单独导入 / Per-corpus import too

**中文**：在语料条目里展开「已有清洗好的文件」，填入路径，该条就跳过识别与清洗，
其余语料仍按各自设置正常处理。适合手上已有干净语料、只想补一类新数据的情况。

**English**: Expand *Already-cleaned file* inside a corpus entry and give a path; that entry skips
mapping and cleaning while the others are processed normally. Useful when you already have
clean data and only want to add one new category.

### 来源会留痕 / Provenance is recorded

**中文**：导入了什么、从哪来、什么时候，都记在项目的 `state.json` 的 `imports` 字段里。
几周后回看，仍能知道这个模型是接着谁的权重训的。

**English**: What was imported, from where, and when is recorded under `imports` in the project's
`state.json`, so weeks later you can still tell whose weights a model continued from.

---

## 8. 断点与备份 / Checkpoints & backup

**中文**：「新建项目」页设初始值，训练中心可随时改（点「修改断点策略」）。
**English**: Set initial values on the New Project page; change them anytime in the Training Center ("Edit checkpoint policy").

| 项 Item | 默认 Default |
|---|---|
| 保存间隔 Save interval | 500 步 steps（预设 100/250/500/1000 或自定义 / presets or custom） |
| 本地保留 Keep local | 最近 3 个 / latest 3 |
| 备份目录 Backup dir | 空（建议另一块物理盘）/ empty (a separate physical drive recommended) |
| 备份保留 Keep backups | 最近 10 个 / latest 10 |

- **best / final 永不自动删除** / **best & final are never auto-deleted**
- 轮转自动完成，磁盘占用封顶 / Rotation is automatic; disk usage is capped
- 崩溃或重启后点「开始训练」即从最近断点续训，也可指定从某个断点续
  After a crash or reboot, "Start" resumes from the latest checkpoint; you can also pick a specific one

**中文**：间隔越小越安全（崩溃损失少），但写盘更频繁。界面会实时换算「约每多少 token 存一次」。
**English**: Shorter intervals are safer (less lost on crash) but write more often.
The UI converts your setting into "roughly every N tokens" in real time.

---

## 8.5 外部训练监控（只读）/ External training monitor (read-only)

**中文**：如果你已经在命令行启动了一个长训练（比如跑几个月的基座模型），不想重启它、
只想用图形界面看进度——用「外部监控」页。它**只读取那个训练的日志文件**，
不启动、不停止、不干预它，也不在它的目录里写任何东西。

**English**: If you already started a long training run from the command line (say a base model
that runs for months) and don't want to restart it — use the "External Monitor" page.
It **only reads that run's log files**; it never starts, stops or interferes with it,
and never writes anything into its directory.

### 怎么用 / How to use

| 字段 Field | 说明 Notes |
|---|---|
| 监控名称 Name | 随便起 / anything you like |
| 训练输出目录 Output dir | **含 `train_log.csv` 的那个目录** / the folder containing `train_log.csv` |
| 总 token 预算 Total tokens | 可选，填了才能算百分比与剩余时间 / optional, needed for % and ETA |
| 总步数 Total steps | 可选 / optional |
| 控制台日志文件 Console log | 可选，填了能看原始输出文本 / optional, shows raw console output |

**中文**：添加后每 4 秒自动刷新，能看到进度条、7 个实时指标、损失曲线（训练+验证）、
速度与显存双轴曲线、断点列表、原始日志尾部。

**English**: After adding, it refreshes every 4 seconds: progress bar, 7 live metrics,
loss chart (training + validation), dual-axis throughput/VRAM chart, checkpoint list, and raw log tail.

### 安全边界（硬性）/ Safety guarantees

| 中文 | English |
|---|---|
| 只读文件，绝不在被监控目录创建/修改/删除任何内容 | Read-only; never creates, modifies or deletes anything in the watched directory |
| 绝不终止、暂停或干预训练进程 | Never terminates, pauses or interferes with the training process |
| 注册信息只写在本程序自己的目录 | The watch list is stored only in this app's own folder |
| 断点区只列出，不提供删除或续训按钮 | Checkpoints are listed only — no delete or resume buttons |
| 移除监控只是取消查看，不动训练文件 | Removing a watch only stops watching; training files are untouched |

> **中文**：已实测验证——监控运行期间，被监控目录**零新增、零删除**，
> 断点文件的大小与时间戳完全未变，唯一变化是训练自己在追加日志。
>
> **English**: Verified in practice — while monitoring, the watched directory had
> **zero additions and zero deletions**; checkpoint sizes and timestamps were unchanged.
> The only change was the training appending to its own log.

### 暂停与继续：本工具启动的训练 / Pause & resume for runs started here

**中文**：「训练中心」页有两个按钮：

- **暂停并保存** —— 在训练输出目录写一个 `STOP_REQUESTED` 标记，
  训练在**当前步结束后**检测到它，保存断点（模型+优化器+步数）再退出。**不丢进度。**
  按钮显示「保存中…」，模型越大保存越久（3B 约十几秒）。
- **继续训练** —— 以 `--resume` 重启，自动找最新断点，步数与优化器状态全部还原。

另有**强制停止**，直接终止进程，**可能丢进度或写坏断点**，仅在暂停无效时用。

> **为什么用标记文件而不是模拟 Ctrl+C？**
> 后台启动的训练可能**没有可见控制台窗口**（`MainWindowHandle=0`），
> 跨进程附着控制台发信号不可靠。标记文件与控制台无关，跨进程稳定可用，
> 且由训练自己在安全的步边界响应，不会打断正在进行的保存。

**实测**：第 35 步暂停 → 保存 `checkpoint-35` → 状态 `paused` → 点继续 →
日志显示「从检查点续训」「优化器状态已恢复」→ 步数接续到 85，loss 继续下降，**零进度丢失**。

**English**: The Training Center has **Pause & save** (writes a `STOP_REQUESTED` marker;
the run detects it at the next step boundary, saves model + optimizer + step count, then exits —
**no progress lost**) and **Resume** (restarts with `--resume`, restoring step count and optimizer state).
**Force stop** terminates directly and may lose progress or corrupt a checkpoint — use only if pausing fails.

A marker file is used instead of simulating Ctrl+C because background runs may have **no visible
console** (`MainWindowHandle=0`), making cross-process console signals unreliable. The marker is
console-independent and handled at a safe step boundary.

**Measured**: paused at step 35 → `checkpoint-35` saved → resumed → steps continued to 85 with
optimizer state restored, **zero progress lost**.

### 想暂停外部训练 / Pausing an external run

**中文**：外部训练的暂停/继续按钮**默认禁用**（见下方"为什么"）。要暂停请自己操作：

1. 切到**启动那个训练的控制台窗口**
2. 按一次 **Ctrl + C**
3. 等它打印「收到中断，保存当前进度」并**写完断点**（约十几秒）
4. 进程退出后再关窗口

训练脚本捕获了中断信号（Python 的 `KeyboardInterrupt`），会先把**模型 + 优化器 + 步数**
完整存成断点再退出，因此**不丢进度**，随时可停，不必等整百步。

**别做**：直接点窗口 ✕、任务管理器结束进程、按 Ctrl+C 后立刻关窗口、连按多次 Ctrl+C ——
这些会强杀进程，丢掉最近断点之后的全部进度，甚至写坏断点。

**恢复**：重新运行你原来带 `--resume` 的启动命令即可，步数与优化器状态都会还原。

**English**: This page has **no pause button** (see "why" below). To pause, do it yourself:
switch to the console window that launched the training, press **Ctrl + C once**,
wait for "interrupt received, saving progress" and for the checkpoint to finish writing
(~10+ seconds), then close the window after the process exits.

The training script catches the interrupt (Python's `KeyboardInterrupt`) and saves
**model + optimizer + step count** before exiting, so **no progress is lost** — you can stop
anytime without waiting for a round-numbered step.

**Don't**: click the window's ✕, kill it in Task Manager, close the window immediately after
Ctrl+C, or press Ctrl+C repeatedly — these force-kill the process, losing everything after the
last checkpoint and possibly corrupting it.

**Resume**: re-run your original launch command with `--resume`; step count and optimizer state are restored.

> **为什么不做成按钮 / Why no button**
>
> 中文：本页的安全承诺是「只读、绝不干预外部训练」。加暂停按钮就得让本程序去控制别的进程，
> 一旦误触或判断失误，可能伤到你跑了很久的训练。手动 Ctrl+C 由你亲自确认，更可控。
>
> English: This page promises "read-only, never interferes". A pause button would require
> controlling another process — a misclick or a bad judgement could damage a run you've invested
> weeks in. Pressing Ctrl+C yourself keeps you in control.

### 活性判断 / Liveness detection

**中文**：判断"还在跑吗"依据**日志写入时间**，不看进程是否存活。
阈值按最近记录推算的实际步时动态计算（日志间隔 × 6，最低 2 分钟），
所以不会因为"还没到下一个写盘点"就误报停滞。若超阈值会显示「日志已停滞」并提示你自行确认——
**它不会替你做任何处置**。

**English**: Liveness is judged by **log write time**, not by whether a process is alive.
The threshold is derived from the measured per-step time (log interval × 6, minimum 2 minutes),
so it won't falsely flag a stall just because the next write point hasn't been reached.
If the threshold is exceeded it shows "log stalled" and asks you to check yourself —
**it takes no action on your behalf**.

---

## 8.6 升级到新版 / Updating to a new version

**中文**：两种方式，任选其一。**两种都不会动你的项目和训练数据。**

### 方式一：导入更新包（推荐）

在「运行环境」页的「导入更新包」卡片里填入新版 zip 的完整路径 → 自动校验 → 看清清单 → 点「开始更新」→ 弹窗确认 → 完成后**关闭工坊重新启动**。

校验是只读的，不写任何文件。清单会明确告诉你：当前版本 → 新版版本、替换多少个文件、多大、以及**哪些内容不会被改动**。

### 方式二：手动覆盖

用新版的 `app/`、`engine/`、`web/`、`launch.py`、`start_workshop.bat` 覆盖旧版同名文件，**保留下面这些**：

| 保留项 Keep | 作用 Purpose |
|---|---|
| `projects/` | 项目配置与训练进度 / project configs & training state |
| `watched_trainings.json` | 外部监控注册 / external watch registrations |
| `workshop_config.json` | Python 环境等设置 / interpreter & settings |
| `logs/` | 工坊自身日志（可丢，排查问题时有用）/ app logs (optional) |

⚠️ **不要整目录覆盖**，那样会连 `projects/` 一起换掉，项目就没了。
⚠️ **Do not overwrite the whole folder** — that replaces `projects/` too and your projects are gone.

### 安全机制 / Safety

- **训练运行时拒绝更新** / Updates are refused while a training run is active
- **更新前自动备份**被替换的旧文件，最多留 3 份，可在同一张卡片一键回滚
  Replaced files are backed up automatically (up to 3 kept); one-click rollback on the same card
- **写入失败自动还原**旧版 / The old version is restored automatically if writing fails
- 只替换程序文件；包内若误带 `projects/` 等用户数据，**直接忽略不覆盖**
  Only program files are replaced; user data accidentally present in the package is ignored
- 拒绝路径穿越、符号链接、非本程序包、损坏包与超大包
  Rejects path traversal, symlinks, foreign packages, corrupted and oversized archives

**中文**：旧版配置缺新版字段不会出错，新字段一律有默认值（日志语言默认中文）。
**English**: Older configs missing newer fields are fine — every new field has a default (log language defaults to Chinese).

---

## 9. 测试指引 / Testing guide

**中文**：感谢参与测试。这是实验性工具的首个公开测试版，你的反馈会直接决定下一版改什么。
**English**: Thanks for testing. This is the first public beta of an experimental tool — your feedback directly shapes the next version.

### 五分钟冒烟测试 / Five-minute smoke test

**优先完成这条路径，它覆盖核心功能。/ Do this path first; it covers the core flow.**

| # | 步骤 Step | 预期 Expected |
|---|---|---|
| 1 | 整个解压（**别只拷 exe**）/ Extract everything (**not just the exe**) | engine 与 exe 同层 / engine next to exe |
| 2 | 双击 exe / Double-click the exe | 独立窗口 / standalone window |
| 3 | 看右上角硬件 / Check the hardware chip | 显卡型号 + **可用**显存（已扣其他程序占用）/ GPU name + **available** VRAM |
| 4 | 新建项目：15M/124M、上下文 512、断点 100 步 / New project: 15M/124M, ctx 512, ckpt 100 | 「配置可行」绿字 / green "config OK" |
| 5 | 数据处理 → 数据全流程 / Data Processing → All Data Stages | 五段依次变绿 / five stages turn green |
| 6 | 训练中心 → 开始训练 / Training Center → Start | 进度动、损失降、步数增 / progress moves, loss drops, steps climb |
| 7 | 中途「停止并保存」→「继续训练」/ Stop mid-way → resume | 从断点续，步数不归零 / resumes, step count not reset |
| 8 | 等训练结束 / Wait for completion | 绿色「训练完成」横幅 / green completion banner |

### 重点验证清单 / Key verification checklist

**硬件与拦截 / Hardware & guards**（最容易出问题 / most failure-prone）
- [ ] 显卡与可用显存正确？开着占显存程序时可用量相应减少？/ GPU & available VRAM correct? Drops when other apps use VRAM?
- [ ] 显存不足的档位灰掉不可选？/ Unaffordable tiers greyed out?
- [ ] 强行选大模型给出明确拦截原因，而非直接 OOM？/ Clear rejection reason instead of a raw OOM?
- [ ] 上下文填 20000 被拦截并说明原因？/ Context 20000 rejected with explanation?
- [ ] 内存显示正常（**不是 0**）？/ RAM shown correctly (**not 0**)?

**语料与清洗 / Corpus & cleaning**
- [ ] 四种格式都能读进来？/ All four formats load?
- [ ] 类型选错时提示清洗后无数据？/ Wrong type → "no data after cleaning" warning?
- [ ] 拖动滑块，阈值与警告实时更新？/ Sliders update thresholds & warnings live?
- [ ] 「恢复预设」只恢复该项？/ Per-field reset affects only that field?
- [ ] 多条语料 + 不同权重能整合？/ Multiple corpora with weights mix successfully?

**自定义架构 / Custom architecture**
- [ ] 改宽度/层数，参数量与显存预估实时变化？/ Params & VRAM update live?
- [ ] 非法值（隐层 1000 / 每头 64）提示应为 1024？/ Invalid values flagged with a suggestion?
- [ ] 预估超出可用显存时当场警告？/ Immediate warning when over budget?

**步骤单选 / Stage selection**
- [ ] 只点「准备数据」，后续步骤保持未执行？/ Only "Prepare Data" runs; later stages untouched?
- [ ] 再点「构建训练集」接着跑，不重跑清洗？/ "Build Dataset" continues without re-cleaning?
- [ ] 数据未就绪时「仅训练」标灰？/ "Train Only" greyed out when data isn't ready?

**训练监控 / Training monitor**
- [ ] 各指标每几秒刷新？/ Metrics refresh every few seconds?
- [ ] 损失曲线有训练线与验证线两条？/ Two lines: training & validation?
- [ ] 断点表显示步数、大小、时间？/ Checkpoint table shows step, size, time?
- [ ] 「从此续训」真从该断点继续？/ "Resume from here" actually resumes there?
- [ ] 「修改断点策略」改完生效？/ Policy edits take effect?
- [ ] 断点按设定自动轮转（best/final 不删）？/ Rotation works, best/final preserved?

**稳定性 / Stability**
- [ ] 关控制台后服务停止？重开能续训？/ Closing console stops service; reopening resumes?
- [ ] 换位置或换电脑仍能运行？/ Works after moving folder or to another PC?
- [ ] 中文路径、带空格路径正常？/ Non-ASCII and spaced paths work?
- [ ] 同时训两个项目时正确提示"一次只能一个"？/ Second concurrent training properly rejected?

### 反馈模板 / Bug report template

```
【环境 / Environment】
显卡 + 显存 / GPU + VRAM:
Python 版本 / version:
torch 版本 / CUDA / torch version / CUDA:
操作系统 / OS:

【操作 / Steps】
1. ...
2. ...

【预期 / Expected】
...

【实际 / Actual】
...（报错原文最好截图 / screenshot of the error is best）

【日志 / Logs】
程序目录 logs/  → app logs
projects/<项目名 project>/logs/<步骤 stage>.log
（「运行环境」页底部有路径信息 / path info at the bottom of the Environment page）
```

**特别有价值的反馈 / Especially valuable feedback**
- 你的显卡型号 + 实际能跑通的最大档位 / Your GPU + the largest tier that actually worked
- 哪种语料格式或类型识别失败 / Which corpus format or type failed to parse
- 界面上哪里看不懂、找不到 / Anything confusing or hard to find in the UI

### 已知限制（不算 bug，不用报）/ Known limitations (not bugs)

| 中文 | English |
|---|---|
| 多卡不支持，只用第一张 | Multi-GPU unsupported; first GPU only |
| 模型上限 7B，更大需模型切分 | 7B ceiling; larger needs model sharding |
| 上下文上限 8192 | Context ceiling 8192 |
| 一次只能训一个项目 | One training job at a time |
| 小模型早期只输出标点，属正常 | Early small models emit only punctuation — normal |
| CPU 模式极慢，仅供体验 | CPU mode is extremely slow, for trying the flow only |
| 关控制台会停服务，断点不丢 | Closing console stops service; checkpoints are safe |

---

## 10. 常见问题 / FAQ

**Q：双击没反应 / 闪退？/ Nothing happens or it crashes on launch?**
中文：看同目录 `logs/`。最常见原因是 engine 文件夹没和 exe 放在一起。
EN: Check `logs/` next to the exe. The most common cause is `engine/` not sitting beside the exe.

**Q：提示"未找到可用环境"？/ "No usable environment found"?**
中文：到「运行环境」页按指引装依赖，或手动指定已有的 python.exe。需要 torch / transformers / tokenizers / numpy。
EN: Follow the setup guide on the Environment page, or point it at an existing `python.exe`. Needs torch / transformers / tokenizers / numpy.

**Q：提示显存不足？/ "Not enough VRAM"?**
中文：退出占显存的程序（本地大模型、游戏），或选更小档位。显示的是真实可用显存。
EN: Close VRAM-heavy apps (local LLMs, games) or pick a smaller tier. The figure shown is genuinely available VRAM.

**Q：某类语料清洗后没数据？/ A corpus is empty after cleaning?**
中文：先确认类型选对（代码选成"网页正文"会被全部滤掉），再把强度改为「宽松」。界面会显示该类具体阈值。
EN: First check the type (code tagged as "web text" gets fully filtered), then switch intensity to "loose". The UI shows that type's exact thresholds.

**Q：训练很慢？/ Training is slow?**
中文：正常。3B 训几十 B token 单卡要几个月；小模型几小时内能看到明显效果。
EN: Expected. 3B on tens of billions of tokens takes months on one GPU; small models show clear progress within hours.

**Q：可以同时训两个项目吗？/ Can I train two projects at once?**
中文：不行，单卡设计。EN: No — single-GPU design.

**Q：关掉窗口训练会停吗？/ Does closing the window stop training?**
中文：会。但断点已保存，重开可续。长期挂机请保持窗口开着并关闭系统自动重启。
EN: Yes. Checkpoints are saved, so you can resume. For long runs keep the window open and disable automatic OS restarts.

**Q：怎么知道训练完了？/ How do I know it finished?**
中文：训练中心顶部出现绿色「训练完成」横幅，显示耗时与保存位置，并弹提示。
EN: A green "Training complete" banner appears atop the Training Center with elapsed time and save location, plus a toast.

**Q：能换电脑用吗？/ Can I move it to another PC?**
中文：可以，整个文件夹拷过去即可，但目标电脑也要有可用的 Python 训练环境。
EN: Yes, copy the whole folder — but the target PC also needs a working Python training environment.

---

## 11. 第三方与许可 / Third-party & licensing

### 本程序自身 / This program

**中文**：自身代码以 **Apache License 2.0** 发布，原文见 `LICENSE.txt`。
界面为原创 HTML/CSS/JavaScript，图表用浏览器原生 Canvas 自绘，**不引用任何 CDN、不使用第三方前端框架或图表库**，完全离线。
后端仅用 Python 标准库（http.server / json / csv / subprocess 等），不依赖任何第三方 Web 框架。

**English**: Our own code is released under **Apache License 2.0** — see `LICENSE.txt`.
The UI is original HTML/CSS/JavaScript with charts drawn on native Canvas — **no CDNs, no third-party frontend frameworks or chart libraries**, fully offline.
The backend uses only the Python standard library (http.server / json / csv / subprocess, etc.), with no third-party web framework.

### 需你自行安装的组件 / Components you install yourself

**中文**：本程序**不打包、不再分发**任何第三方运行库。以下组件由你自行安装，其许可由你自行遵守。
**English**: This program **does not bundle or redistribute** any third-party runtime.
You install the following yourself and are responsible for their licenses.

| 组件 Component | 许可 License | 用途 Purpose |
|---|---|---|
| Python | PSF License | 解释器 / interpreter |
| PyTorch | BSD-3-Clause | 训练推理，含 CUDA 运行时 / training & inference, includes CUDA runtime |
| transformers | Apache-2.0 | 模型结构与分词封装 / model & tokenizer wrappers |
| tokenizers | Apache-2.0 | BPE 词表训练 / BPE tokenizer training |
| NumPy | BSD-3-Clause | 数值与 memmap / numerics & memmap |
| PyArrow | Apache-2.0 | 读 parquet（可选）/ parquet reading (optional) |
| huggingface_hub | Apache-2.0 | 下载辅助（默认不联网）/ download helper (offline by default) |

**NVIDIA CUDA 运行时**随 PyTorch 分发，受 NVIDIA 软件许可协议约束，GPU 训练前请自行阅读并遵守。
The **NVIDIA CUDA runtime** ships with PyTorch and is governed by NVIDIA's software license — read and comply before GPU training.

> **中文**：开发环境已扫描 53 个依赖包，未发现 GPL/AGPL 传染性许可。NumPy 为 BSD，
> 其捆绑的 libgfortran 带 GCC 运行时例外条款，不构成传染。你若自行安装其他包，需自行评估许可。
>
> **English**: We scanned 53 packages in the dev environment and found no GPL/AGPL copyleft.
> NumPy is BSD; its bundled libgfortran carries the GCC runtime exception and is not copyleft-contaminating.
> Any extra packages you install are your own responsibility to assess.

### 界面窗口 / The app window

**中文**：程序以「应用模式」调用系统已装的 Microsoft Edge 或 Google Chrome 显示界面。
**这些浏览器不被打包或再分发**，仅作为本机已安装程序被调用。若都没有，会退回系统默认浏览器，功能不受影响。

**English**: The app invokes your installed Microsoft Edge or Google Chrome in "app mode" to render the UI.
**These browsers are not bundled or redistributed** — they are simply launched as locally installed programs.
If neither exists, it falls back to your default browser with no loss of functionality.

### 语料与模型权重 / Corpora & model weights

**中文**：**本程序不包含任何语料数据或模型权重，也不提供内置下载源。** 你需自行获取语料并评估合规性。
**English**: **No corpus data or model weights are included, and no built-in download sources are provided.**
You must obtain corpora yourself and assess compliance.

| 来源类型 Source | 常见许可 Typical license | 注意 Caution |
|---|---|---|
| 维基百科 / 维基文库<br>Wikipedia / Wikisource | CC-BY-SA + GFDL | 署名与相同方式共享 / attribution & share-alike |
| 公版古籍<br>Public-domain classics | 多为无声明 / often unstated | 数字化转录是否产生新权利属法律判断 / digitization rights are a legal question |
| 网页抓取集<br>Web crawls | 各自社区许可 / community licenses | 部分授权可撤销 / some grants are revocable |
| 问答社区 / 百科<br>Q&A / encyclopedias | 常无 LICENSE / often none | 无明确授权，风险自评 / no explicit grant, assess yourself |
| 代码集<br>Code corpora | 逐文件许可含 GPL / per-file, incl. GPL | copyleft，发布前自评 / copyleft, assess before release |

> ⚠ **中文**：训练产出的权重是否受语料许可约束（尤其 CC-BY-SA 的 ShareAlike 与 GPL 的 copyleft
> 是否延伸到权重），**法律上尚无定论，业界观点相反且无法院判决**。
> 计划公开发布或商业使用前，请咨询知识产权律师。本文不构成法律意见。
>
> ⚠ **English**: Whether trained weights are bound by corpus licenses (specifically whether CC-BY-SA's
> ShareAlike or GPL copyleft extends to weights) is **legally unsettled — industry views conflict and
> there is no court ruling**. Consult an IP lawyer before public release or commercial use.
> This document is not legal advice.

---

## 12. 隐私与免责 / Privacy & disclaimer

### 隐私 / Privacy

| 中文 | English |
|---|---|
| 只监听本机地址 127.0.0.1，不对外开放端口 | Listens only on 127.0.0.1; no externally exposed port |
| 不上传任何数据，语料与模型全程留在你电脑上 | Uploads nothing; corpora and models stay on your machine |
| 默认不联网（在线下载功能已移除） | Offline by default (online download removed) |
| 会在程序目录写入：项目数据、日志、`workshop_config.json`（记录你选的 Python 路径） | Writes into the app folder: project data, logs, `workshop_config.json` (your chosen Python path) |

### 免责 / Disclaimer

**中文**：本程序是面向个人开发者的**实验性工具**，不是稳定的生产级软件。
按 Apache-2.0 第 7、8 条，作者不提供任何明示或默示担保，不对使用本程序造成的数据损失、
设备损坏、训练失败或其他后果承担责任。

训练前请自行确认：磁盘空间充足、散热良好、重要数据已备份、已关闭系统自动重启。
长时间训练可能持续数天至数月。训练结果与硬件、数据质量强相关，请自行验证。

**English**: This is an **experimental tool** for individual developers, not production-grade software.
Per sections 7 and 8 of Apache-2.0, the authors provide no warranty of any kind, express or implied,
and accept no liability for data loss, hardware damage, failed training runs, or any other consequence.

Before training, verify yourself: sufficient disk space, adequate cooling, important data backed up,
automatic OS restarts disabled. Long runs may last days to months.
Results depend heavily on your hardware and data quality — validate them yourself.

---

*v0.1 公开测试版 · 功能与界面都可能调整 · 感谢你的时间与反馈*
*v0.1 Public Beta · Features and UI may change · Thank you for your time and feedback*

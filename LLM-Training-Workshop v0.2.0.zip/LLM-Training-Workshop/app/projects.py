"""项目管理：每个训练项目一个独立目录，配置与产物都在其中。

目录结构（用户项目）：
  projects/<项目名>/
    config.json      用户选择的配置
    state.json       流水线各工位状态
    corpus/          下载的原始语料
    data/            清洗/打包/混合产物
    tokenizer/       训练出的词表
    output/          模型与检查点
    logs/            各工位日志
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PROJECTS_DIR = ROOT / "projects"

# 七个工位（去掉在线下载，语料由用户提供本地路径）
STAGES = [
    ("adapt", "识别字段", "统一字段结构，认出正文列"),
    ("clean", "清洗", "按语料类型去噪、去重、过滤"),
    ("tokenizer", "训练词表", "学习分词器"),
    ("pack", "打包", "转成 token 流"),
    ("mix", "整合", "按配比混合成最终训练集"),
    ("train", "训练", "预训练模型"),
    ("test", "验证", "困惑度与生成测试"),
]

DEFAULT_CONFIG = {
    "tier": "base",
    "arch": None,               # 自定义架构；None = 用档位预设
    "block_size": 1024,
    "batch_size": 4,
    "grad_accum": 4,
    "lr": None,                 # None = 按档位自动
    "master_dtype": "bf16",
    "max_tokens": 0,            # 0 = 按语料实际供给
    "warmup_steps": 500,
    "vocab_size": 32000,
    # 语料条目：每条一个本地路径 + 类型 + 可选权重
    # [{"path": "D:/语料/wiki", "kind": "wiki", "weight": 1.0}, ...]
    "corpus": [],
    "clean_level": "standard",  # loose / standard / strict
    # 模型输出目录：留空 = 项目内 output/model；也可指定任意位置
    "output_dir": "",
    "save_every": 500,
    "keep_checkpoints": 3,
    "backup_dir": "",
    "backup_every": 500,
    "keep_backups": 10,
    "eval_every": 500,
    "log_every": 20,
    "num_workers": 0,
    "spike_guard": True,
    # 日志语言：zh（默认，保持既有中文输出不变）/ en
    # ★与界面语言独立：界面切英文不会改动已有项目的日志语言
    "log_lang": "zh",
    # 每个工位的来源：{"tokenizer": {"mode": "import", "path": "..."}}
    # mode: "auto"（自己生成，默认） / "import"（用已有文件）
    # 语料类工位可按条覆盖：corpus[i]["clean_import"] 指向已清洗文件
    "sources": {},
}

_NAME_RE = re.compile(r"^[\w\u4e00-\u9fff][\w\u4e00-\u9fff .-]{0,48}$")


def output_dir(name: str, cfg: dict | None = None) -> Path:
    """模型输出目录。留空用项目内 output/model；否则用用户指定位置。

    ★所有读写输出的地方都必须走这个函数，避免"训练写到A、界面读B"的口径分裂。
    """
    if cfg is None:
        try:
            cfg = load(name)["config"]
        except (ValueError, OSError):
            cfg = {}
    raw = (cfg.get("output_dir") or "").strip().strip('"')
    if raw:
        return Path(raw)
    return project_dir(name) / "output" / "model"


def safe_name(name: str) -> str:
    """校验项目名，阻断路径穿越。"""
    name = (name or "").strip()
    if not _NAME_RE.match(name) or ".." in name or name in (".", ".."):
        raise ValueError("项目名只能包含中英文、数字、空格、点、下划线和连字符，且不超过 50 字")
    return name


def project_dir(name: str) -> Path:
    return PROJECTS_DIR / safe_name(name)


def _read_json(p: Path, default):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write_json(p: Path, data) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)          # 原子替换，避免断电写坏配置


def new_state() -> dict:
    return {
        "stages": {k: {"status": "pending", "progress": 0.0, "message": "",
                       "started_at": None, "finished_at": None}
                   for k, _n, _d in STAGES},
        "running": False,
        "current": None,
        "created_at": time.time(),
        "error": None,
    }


def create(name: str, config: dict | None = None) -> dict:
    d = project_dir(name)
    if d.exists():
        raise ValueError(f"项目「{name}」已存在")
    for sub in ("corpus", "data", "tokenizer", "output", "logs"):
        (d / sub).mkdir(parents=True, exist_ok=True)
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(config or {})
    cfg["name"] = name
    _write_json(d / "config.json", cfg)
    _write_json(d / "state.json", new_state())
    return {"name": name, "config": cfg, "state": new_state()}


def list_all() -> list[dict]:
    if not PROJECTS_DIR.exists():
        return []
    out = []
    for d in sorted(PROJECTS_DIR.iterdir()):
        if not d.is_dir() or d.name.startswith("_"):
            continue
        cfg = _read_json(d / "config.json", None)
        if cfg is None:
            continue
        st = _read_json(d / "state.json", new_state())
        done = sum(1 for s in st["stages"].values() if s["status"] == "done")
        out.append({
            "name": d.name,
            "tier": cfg.get("tier"),
            "block_size": cfg.get("block_size"),
            "running": st.get("running", False),
            "current": st.get("current"),
            "stages_done": done,
            "stages_total": len(STAGES),
            "created_at": st.get("created_at"),
        })
    return out


def load(name: str) -> dict:
    d = project_dir(name)
    cfg = _read_json(d / "config.json", None)
    if cfg is None:
        raise ValueError(f"项目「{name}」不存在")
    return {"name": name, "config": cfg,
            "state": _read_json(d / "state.json", new_state())}


def save_config(name: str, patch: dict) -> dict:
    d = project_dir(name)
    cfg = _read_json(d / "config.json", None)
    if cfg is None:
        raise ValueError(f"项目「{name}」不存在")
    st = _read_json(d / "state.json", new_state())
    if st.get("running"):
        raise ValueError("项目正在运行，请先停止再修改配置")
    allowed = set(DEFAULT_CONFIG) | {"name"}
    for k, v in patch.items():
        if k in allowed and k != "name":
            cfg[k] = v
    _write_json(d / "config.json", cfg)
    return cfg


def save_state(name: str, state: dict) -> None:
    _write_json(project_dir(name) / "state.json", state)


def delete(name: str) -> None:
    """删除项目：仅允许删本项目目录内的内容，且需调用方确认。"""
    import shutil  # noqa: PLC0415

    d = project_dir(name)
    if not d.exists():
        raise ValueError(f"项目「{name}」不存在")
    st = _read_json(d / "state.json", new_state())
    if st.get("running"):
        raise ValueError("项目正在运行，请先停止")
    # 双保险：确认路径确实在 projects 目录之下
    if PROJECTS_DIR.resolve() not in d.resolve().parents:
        raise ValueError("路径校验失败，拒绝删除")
    shutil.rmtree(d)

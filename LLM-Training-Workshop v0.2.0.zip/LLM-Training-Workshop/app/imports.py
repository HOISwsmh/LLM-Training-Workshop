"""导入已有产物：每个工位都能「用现成的」而不是「从头做」。

设计要点（都来自实际使用中的教训）：
  1. ★默认引用而非复制。token 流动辄几十 GB，复制一份既慢又白占一块盘。
     只有词表这种小文件才复制（几 MB，且后续步骤要就地读取）。
  2. ★导入必须校验。只认目录里真实存在的标志文件，不认"用户说它有"。
     词表不匹配会导致 token id 全错却不报错 —— 这类静默错误最危险。
  3. ★来源要留痕。导入了什么、从哪来、什么时候，都记进项目状态，
     否则几周后没人记得这个模型是接着谁的权重训的。
"""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path

# 每个工位的导入规格：标志文件用于校验，kind 决定校验方式。
# accept: 用户该填什么（目录还是文件），hint 给界面提示。
IMPORT_SPECS = {
    "adapt": {
        "label": "已识别的语料",
        "accept": "file",
        "hint": "已统一字段的 jsonl（每行含 text 字段）",
        "markers": [],
        "suffixes": (".jsonl", ".json"),
    },
    "clean": {
        "label": "已清洗的语料",
        "accept": "file",
        "hint": "清洗好的 jsonl，可跳过识别与清洗",
        "markers": [],
        "suffixes": (".jsonl", ".json"),
    },
    "tokenizer": {
        "label": "已有词表",
        "accept": "dir",
        "hint": "含 tokenizer.json 的目录（会复制到项目内）",
        "markers": ["tokenizer.json"],
        "suffixes": (),
    },
    "pack": {
        "label": "已打包的 token 流",
        "accept": "dir",
        "hint": "含 tokens_train.bin 与 data_meta.json 的目录（直接引用，不复制）",
        "markers": ["tokens_train.bin", "data_meta.json"],
        "suffixes": (),
    },
    "mix": {
        "label": "已整合的训练集",
        "accept": "dir",
        "hint": "含 tokens_train.bin 与 data_meta.json 的目录（直接引用，不复制）",
        "markers": ["tokens_train.bin", "data_meta.json"],
        "suffixes": (),
    },
    "train": {
        "label": "已有模型/断点",
        "accept": "dir",
        "hint": "检查点目录，或含 config.json 的模型目录；有 optimizer.pt 则连优化器状态一起接上",
        "markers": ["config.json"],
        "suffixes": (),
    },
    "test": {
        "label": "待验证的模型",
        "accept": "dir",
        "hint": "含 config.json 与权重的模型目录",
        "markers": ["config.json"],
        "suffixes": (),
    },
}


def _clean_path(raw: str) -> Path:
    """去掉资源管理器「复制文件地址」带来的引号与首尾空白。"""
    return Path((raw or "").strip().strip('"').strip("'"))


def _read_meta(d: Path) -> dict:
    try:
        return json.loads((d / "data_meta.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def validate(stage: str, raw: str) -> dict:
    """校验用户给的导入路径。返回 ok/problems/warnings/info。

    ★只警告不阻断的原则同样适用：能读出来就用，风险讲清楚由用户决定。
      但"路径不存在""缺标志文件"属于根本无法执行，必须拒绝。
    """
    spec = IMPORT_SPECS.get(stage)
    if spec is None:
        return {"ok": False, "problems": [f"工位 {stage} 不支持导入"],
                "warnings": [], "info": {}}
    # ★空串必须先判断：Path("") 会变成当前目录 "."，导致误判为"存在"
    if not (raw or "").strip().strip('"').strip("'"):
        return {"ok": False, "problems": ["请填写路径"], "warnings": [], "info": {}}
    p = _clean_path(raw)
    if not p.exists():
        return {"ok": False, "problems": [f"路径不存在：{p}"], "warnings": [], "info": {}}

    problems: list[str] = []
    warnings: list[str] = []
    info: dict = {"path": str(p)}

    if spec["accept"] == "file":
        if not p.is_file():
            problems.append("这里需要填一个文件，而不是文件夹")
        elif p.suffix.lower() not in spec["suffixes"]:
            problems.append(f"只支持 {'/'.join(spec['suffixes'])} 文件")
        else:
            info["size_mb"] = round(p.stat().st_size / 1024 ** 2, 2)
            if p.stat().st_size == 0:
                problems.append("文件是空的")
            else:
                # 抽首行确认结构，避免导入了根本不是语料的 jsonl
                try:
                    with p.open(encoding="utf-8") as f:
                        first = f.readline()
                    obj = json.loads(first)
                    if not isinstance(obj, dict):
                        problems.append("首行不是 JSON 对象")
                    elif "text" not in obj:
                        warnings.append("首行没有 text 字段，可能不是已统一字段的语料")
                    info["sample_keys"] = list(obj.keys())[:8]
                except (OSError, ValueError):
                    problems.append("无法按 jsonl 读取首行，文件可能损坏或不是文本")
    else:
        if not p.is_dir():
            problems.append("这里需要填一个文件夹，而不是文件")
        else:
            # train/test 允许指向父目录（内含 checkpoint-*），自动找最新的
            if stage in ("train",) and not (p / "config.json").exists():
                cks = sorted(p.glob("checkpoint-*"),
                             key=lambda x: int(x.name.split("-")[1])
                             if x.name.split("-")[1].isdigit() else -1)
                cks = [c for c in cks if (c / "config.json").exists()]
                if cks:
                    p = cks[-1]
                    info["path"] = str(p)
                    info["picked_checkpoint"] = p.name
                    warnings.append(f"已自动选用最新断点 {p.name}")
                else:
                    problems.append("目录内既没有 config.json，也没有可用的 checkpoint-*")
            else:
                for m in spec["markers"]:
                    if not (p / m).exists():
                        problems.append(f"缺少必需文件：{m}")

            if not problems:
                info["size_gb"] = round(
                    sum(f.stat().st_size for f in p.rglob("*") if f.is_file()) / 1024 ** 3, 3)
                if stage in ("pack", "mix"):
                    meta = _read_meta(p)
                    info["train_tokens"] = int(meta.get("train_tokens", 0))
                    info["val_tokens"] = int(meta.get("val_tokens", 0))
                    info["vocab_size"] = meta.get("vocab_size")
                    if info["train_tokens"] <= 0:
                        problems.append("data_meta.json 里训练 token 数为 0")
                    if not (p / "tokens_val.bin").exists():
                        warnings.append("没有验证集 tokens_val.bin，训练中的困惑度评估会被跳过")
                if stage == "tokenizer":
                    try:
                        tj = json.loads((p / "tokenizer.json").read_text(encoding="utf-8"))
                        vs = len(((tj.get("model") or {}).get("vocab") or {}))
                        if vs:
                            info["vocab_size"] = vs
                    except (OSError, ValueError):
                        warnings.append("tokenizer.json 无法解析出词表大小")
                if stage in ("train", "test"):
                    try:
                        cj = json.loads((p / "config.json").read_text(encoding="utf-8"))
                        info["vocab_size"] = cj.get("vocab_size")
                        info["hidden_size"] = cj.get("hidden_size")
                        info["num_hidden_layers"] = cj.get("num_hidden_layers")
                    except (OSError, ValueError):
                        warnings.append("config.json 无法解析")
                    st = p / "trainer_state.json"
                    if st.exists():
                        try:
                            info["global_step"] = json.loads(
                                st.read_text(encoding="utf-8")).get("global_step")
                        except (OSError, ValueError):
                            pass
                    info["has_optimizer"] = (p / "optimizer.pt").exists()
                    has_w = any((p / n).exists() for n in
                                ("model.safetensors", "pytorch_model.bin"))
                    if not has_w:
                        problems.append("目录里没有模型权重（model.safetensors 或 pytorch_model.bin）")
                    if stage == "train" and not info["has_optimizer"]:
                        warnings.append("没有 optimizer.pt：只继承权重，优化器从零开始，"
                                        "学习率预热会重来，loss 可能短暂上跳")
    return {"ok": not problems, "problems": problems, "warnings": warnings, "info": info}


def record(stage: str, raw: str, info: dict) -> dict:
    """生成来源记录，写进项目状态便于日后追溯。"""
    return {"stage": stage, "path": str(_clean_path(raw)),
            "at": time.time(), "info": info or {}}


def use_file(stage: str, raw: str, dst: Path) -> tuple[bool, str]:
    """把已有语料文件放到工位期望的位置（复制，语料通常不大且要就地读）。"""
    p = _clean_path(raw)
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        if dst.exists():
            dst.unlink()
        shutil.copy2(p, dst)
    except OSError as e:
        return False, f"复制失败：{e}"
    return True, f"已导入 {p.name}（{dst.stat().st_size / 1024 ** 2:.1f}MB）"


def use_tokenizer(raw: str, dst: Path) -> tuple[bool, str]:
    """词表复制到项目内：只有几 MB，且后续步骤频繁就地读取。"""
    p = _clean_path(raw)
    dst.mkdir(parents=True, exist_ok=True)
    copied = []
    try:
        for f in sorted(p.iterdir()):
            if f.is_file() and f.suffix in (".json", ".model", ".txt"):
                shutil.copy2(f, dst / f.name)
                copied.append(f.name)
    except OSError as e:
        return False, f"复制词表失败：{e}"
    if "tokenizer.json" not in copied:
        return False, "复制后未见 tokenizer.json"
    return True, f"已导入词表（{len(copied)} 个文件）"


def link_or_copy_dir(src: Path, dst: Path) -> tuple[bool, str, bool]:
    """让 dst 指向 src 的数据。★优先目录联接，失败才退回复制。

    返回 (ok, message, referenced)。referenced=True 表示是引用而非副本。
    Windows 上目录联接(junction)不需要管理员权限，比符号链接可用性高。
    """
    src = _clean_path(str(src))
    if dst.exists() or dst.is_symlink():
        # 已有内容：先判断是否已经指向同一处
        try:
            if dst.resolve() == src.resolve():
                return True, "已指向该目录", True
        except OSError:
            pass
        return False, f"目标位置已有内容：{dst}。请先清空或改用其它项目", False
    dst.parent.mkdir(parents=True, exist_ok=True)
    # 尝试目录联接
    try:
        import _winapi  # noqa: PLC0415  仅 Windows 有
        _winapi.CreateJunction(str(src), str(dst))
        return True, f"已引用 {src}（目录联接，未复制）", True
    except (ImportError, OSError, AttributeError):
        pass
    try:
        dst.symlink_to(src, target_is_directory=True)
        return True, f"已引用 {src}（符号链接，未复制）", True
    except (OSError, NotImplementedError):
        pass
    # 退回复制：大文件会很慢，先看清体积并如实告知
    try:
        size = sum(f.stat().st_size for f in src.rglob("*") if f.is_file())
        free = shutil.disk_usage(str(dst.parent)).free
        if free < size + 1024 ** 3:
            return False, (f"无法建立引用，需复制 {size / 1024 ** 3:.1f}GB "
                           f"但磁盘只剩 {free / 1024 ** 3:.1f}GB"), False
        shutil.copytree(src, dst)
        return True, f"已复制 {size / 1024 ** 3:.2f}GB（系统不支持目录引用）", False
    except OSError as e:
        return False, f"引用与复制均失败：{e}", False


def tokenizer_fingerprint(d: Path) -> str | None:
    """词表内容指纹。★只比大小是不够的：两个词表都是 32000，
    但 token→id 映射完全不同时，续训会把 embedding 全部错位，
    模型静默变成废权重且 loss 看起来"还能降"。必须比内容。
    """
    import hashlib  # noqa: PLC0415
    f = Path(d) / "tokenizer.json"
    if not f.exists():
        return None
    try:
        tj = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    model = tj.get("model") or {}
    vocab = model.get("vocab")
    if isinstance(vocab, dict):
        items = sorted(vocab.items(), key=lambda kv: kv[0])
        payload = json.dumps(items, ensure_ascii=False, separators=(",", ":"))
    elif isinstance(vocab, list):
        payload = json.dumps(vocab, ensure_ascii=False, separators=(",", ":"))
    else:
        # 退而用整个文件的哈希，至少能发现文件不同
        try:
            return hashlib.sha256(f.read_bytes()).hexdigest()[:16]
        except OSError:
            return None
    merges = model.get("merges") or []
    payload += "|" + json.dumps(merges, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def tokenizer_mismatch(model_dir: Path, tok_dir: Path) -> str | None:
    """续训前比对：要接的模型自带词表 vs 项目将使用的词表。"""
    a = tokenizer_fingerprint(model_dir)
    b = tokenizer_fingerprint(tok_dir)
    if a is None or b is None:
        return None                      # 拿不到指纹就不拦，交给用户判断
    if a != b:
        return ("词表内容不一致：要接续的模型用的是另一套分词器。"
                "直接续训会让所有 token 编号错位、模型权重作废。"
                f"请把「训练词表」这一步改为导入该模型自带的词表：{model_dir}")
    return None


def vocab_conflict(imported_vs, cfg_vs) -> str | None:
    """词表大小不一致必须提醒：token id 会错位，训出来的东西是废的。"""
    try:
        a, b = int(imported_vs), int(cfg_vs)
    except (TypeError, ValueError):
        return None
    if a and b and a != b:
        return (f"导入数据的词表大小是 {a}，但配置里填的是 {b}。"
                "两者必须一致，否则 token 编号错位、训练结果无意义。"
                "请把词表大小改成 " + str(a))
    return None
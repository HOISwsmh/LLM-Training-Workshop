"""导入压缩包自动更新。

★安全边界（每一条都来自"不能弄丢用户数据"这个底线）：
  1. 只替换程序文件（app/ engine/ web/ 与根级脚本、文档）。
     projects/、logs/、watched_trainings.json、workshop_config.json 一律不动。
  2. 分两步：先 inspect() 只读校验并把清单摆给用户看，用户确认后 apply() 才写盘。
     inspect 不写任何东西。
  3. 落地前把将被替换的旧文件整份备份到 .upgrade_backup/<时间戳>/，
     失败自动回滚；用户也可手动 rollback()。
  4. 训练正在运行时拒绝更新 —— 引擎文件被占用，换掉会让训练行为不可预期。
  5. 压缩包内路径严格校验：拒绝绝对路径、.. 穿越、符号链接、非白名单顶层项。
     解压炸弹防护：限制单文件大小、总解压体积与文件数。
  6. 只接受本程序的发布包：必须含 app/paths.py 且能读出 VERSION。

★所有 problems / warnings 一律返回 {k:翻译键, v:变量}，不返回中文原文。
  界面用 t() 渲染，切语言即时重译；也避免在前端维护一张中文→英文映射表。
"""
from __future__ import annotations

import json
import re
import shutil
import tempfile
import time
import zipfile
from pathlib import Path

from . import paths as PA

# 允许被替换的顶层项（其余一律忽略，绝不删除）
REPLACE_DIRS = ("app", "engine", "web")
REPLACE_FILES = (
    "launch.py", "start_workshop.bat", "requirements.txt",
    "README.md", "MANUAL.md", "LICENSE", "CONTRIBUTING.md",
    "THIRD_PARTY.md", ".gitignore",
)
# 永不触碰的用户数据
PROTECTED = ("projects", "logs", "watched_trainings.json",
             "workshop_config.json", ".upgrade_backup")

MAX_FILES = 4000
MAX_TOTAL = 400 * 1024 * 1024      # 解压后总量上限
MAX_ONE = 64 * 1024 * 1024         # 单文件上限
BACKUP_DIRNAME = ".upgrade_backup"
KEEP_BACKUPS = 3


def _p(code: str, **v) -> dict:
    """一条待翻译的提示。变量里只放数字、版本号、包内相对路径。"""
    return {"k": code, "v": v}


def _norm(name: str) -> str:
    return name.replace("\\", "/").lstrip("/")


def _safe_member(name: str) -> bool:
    """拒绝绝对路径与穿越；只允许白名单顶层项。"""
    n = _norm(name)
    if not n or n.startswith("/") or ":" in n.split("/")[0]:
        return False
    parts = [p for p in n.split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts):
        return False
    top = parts[0]
    if top in REPLACE_DIRS:
        return True
    return len(parts) == 1 and top in REPLACE_FILES


def _find_root(z: zipfile.ZipFile) -> str:
    """发布包通常有一层顶层目录；自动识别含 app/paths.py 的那一层。"""
    names = [_norm(n) for n in z.namelist()]
    if "app/paths.py" in names:
        return ""
    tops = {n.split("/")[0] for n in names if "/" in n}
    for t in sorted(tops):
        if (t + "/app/paths.py") in names:
            return t + "/"
    return ""


def _read_version(z: zipfile.ZipFile, root: str) -> str:
    try:
        src = z.read(root + "app/paths.py").decode("utf-8", errors="replace")
    except (KeyError, OSError):
        return ""
    # ★单双引号都要认：Python 里 VERSION = '0.1.4' 完全合法，
    #   只认双引号会把合法发布包误判成"读不出版本"。
    m = re.search(r"""^VERSION\s*=\s*["']([^"']+)["']""", src, re.M)
    return m.group(1) if m else ""


def _ver_key(v: str) -> tuple:
    return tuple(int(x) if x.isdigit() else 0 for x in re.split(r"[.\-+]", v)[:4])


def inspect(zip_path: str, running: bool = False) -> dict:
    """只读校验：返回版本、将替换/保留的清单与风险，不写任何文件。"""
    out = {
        "ok": False, "current": PA.VERSION, "incoming": "",
        "replace": [], "keep": list(PROTECTED[:4]), "ignored": [],
        "problems": [], "warnings": [], "file_count": 0, "total_mb": 0.0,
        "same_version": False, "downgrade": False, "running": running,
    }
    raw = (zip_path or "").strip().strip('"').strip("'")
    if not raw:
        out["problems"].append(_p("upg.noPath"))
        return out
    p = Path(raw)
    if not p.exists() or not p.is_file():
        out["problems"].append(_p("upg.notFound", p=p.name))
        return out
    if p.suffix.lower() != ".zip":
        out["problems"].append(_p("upg.notZip"))
        return out
    if running:
        out["problems"].append(_p("upg.running"))
        return out

    try:
        with zipfile.ZipFile(p) as z:
            if z.testzip() is not None:
                out["problems"].append(_p("upg.crc"))
                return out
            names = [_norm(n) for n in z.namelist()]
            root = _find_root(z)
            if not root and "app/paths.py" not in names:
                out["problems"].append(_p("upg.notOurs"))
                return out
            ver = _read_version(z, root)
            if not ver:
                out["problems"].append(_p("upg.noVer"))
                return out
            out["incoming"] = ver
            out["same_version"] = ver == PA.VERSION
            out["downgrade"] = _ver_key(ver) < _ver_key(PA.VERSION)

            infos = [i for i in z.infolist() if not i.is_dir()]
            if len(infos) > MAX_FILES:
                out["problems"].append(_p("upg.tooMany", n=len(infos), max=MAX_FILES))
                return out
            total = sum(i.file_size for i in infos)
            if total > MAX_TOTAL:
                out["problems"].append(_p("upg.tooBig"))
                return out
            out["total_mb"] = round(total / 1024 ** 2, 2)

            seen_ignored = set()
            for i in infos:
                raw_name = i.filename.replace("\\", "/")
                n = _norm(i.filename)
                rel = n[len(root):] if root and n.startswith(root) else n
                if not rel:
                    continue
                # ★穿越/绝对路径条目：整包拒绝，而不是静默跳过。
                #   正常发布包不可能出现这种条目，出现即说明包被人动过手脚，
                #   此时继续更新等于默认可疑内容，宁可让用户换一个包。
                # ★绝对路径必须在剥掉开头斜杠之前判断 —— _norm 会 lstrip("/")，
                #   拿处理后的字符串去查 startswith("/") 永远为假，等于没防。
                parts = [q for q in rel.split("/") if q not in ("", ".")]
                if (".." in parts or raw_name.startswith("/")
                        or ":" in (parts[0] if parts else "")):
                    out["problems"].append(_p("upg.traversal", f=rel))
                    return out
                if i.file_size > MAX_ONE:
                    out["problems"].append(_p("upg.oneBig", f=rel))
                    return out
                # 符号链接：zip 外部属性高 16 位为 unix mode，0xA000 表示 symlink
                mode = (i.external_attr >> 16) & 0xFFFF
                if mode and (mode & 0xF000) == 0xA000:
                    out["problems"].append(_p("upg.symlink", f=rel))
                    return out
                if not _safe_member(rel):
                    top = rel.split("/")[0]
                    if top in PROTECTED:
                        continue          # 包里若误带用户数据，直接忽略且不覆盖
                    seen_ignored.add(top)
                    continue
                out["replace"].append(rel)
            out["ignored"] = sorted(seen_ignored)
            out["file_count"] = len(out["replace"])
    except zipfile.BadZipFile:
        out["problems"].append(_p("upg.badZip"))
        return out
    except OSError as e:
        out["problems"].append(_p("upg.readFail", e=type(e).__name__))
        return out

    if not out["replace"]:
        out["problems"].append(_p("upg.empty"))
        return out
    need = ["app/paths.py", "app/server.py", "web/index.html", "engine/train_model.py"]
    lacking = [n for n in need if n not in out["replace"]]
    if lacking:
        out["problems"].append(_p("upg.incomplete", f="、".join(lacking)))
        return out
    if out["downgrade"]:
        out["warnings"].append(_p("upg.downgrade", a=out["incoming"], b=PA.VERSION))
    if out["same_version"]:
        out["warnings"].append(_p("upg.same"))
    out["ok"] = True
    return out


def _backup_root() -> Path:
    p = PA.app_root() / BACKUP_DIRNAME
    p.mkdir(parents=True, exist_ok=True)
    return p


def list_backups() -> list[dict]:
    root = PA.app_root() / BACKUP_DIRNAME
    if not root.exists():
        return []
    items = []
    for d in sorted(root.iterdir(), reverse=True):
        if not d.is_dir():
            continue
        meta = {}
        try:
            meta = json.loads((d / "meta.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass
        items.append({"id": d.name, "at": meta.get("at"),
                      "from": meta.get("from"), "to": meta.get("to"),
                      "files": meta.get("files", 0)})
    return items


def _prune_backups() -> None:
    root = PA.app_root() / BACKUP_DIRNAME
    if not root.exists():
        return
    ds = sorted([d for d in root.iterdir() if d.is_dir()], reverse=True)
    for old in ds[KEEP_BACKUPS:]:
        shutil.rmtree(old, ignore_errors=True)


def apply(zip_path: str, running: bool = False) -> dict:
    """落地更新：先备份将被替换的旧文件，再写入新文件；失败自动回滚。"""
    chk = inspect(zip_path, running)
    if not chk["ok"]:
        return {"ok": False, "problems": chk["problems"], "warnings": chk["warnings"]}

    app_root = PA.app_root()
    old_ver = PA.VERSION
    stamp = time.strftime("%Y%m%d-%H%M%S")
    bkp = _backup_root() / stamp
    bkp.mkdir(parents=True, exist_ok=True)
    replaced, backed = [], []

    # 1) 备份现有程序文件（只备份包内要替换的那些）
    try:
        for rel in chk["replace"]:
            src = app_root / rel
            if src.exists() and src.is_file():
                dst = bkp / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                backed.append(rel)
        (bkp / "meta.json").write_text(json.dumps(
            {"at": time.time(), "from": old_ver, "to": chk["incoming"],
             "files": len(backed)}, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as e:
        shutil.rmtree(bkp, ignore_errors=True)
        return {"ok": False, "problems": [_p("upg.backupFail", e=type(e).__name__)]}

    # 2) 解到临时目录再逐个替换，避免半个包写坏程序
    tmp = Path(tempfile.mkdtemp(prefix="wsupg_"))
    try:
        with zipfile.ZipFile(Path((zip_path or "").strip().strip('"'))) as z:
            root = _find_root(z)
            for rel in chk["replace"]:
                member = (root + rel) if root else rel
                info = z.getinfo(member)
                target = tmp / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as fsrc, target.open("wb") as fdst:
                    shutil.copyfileobj(fsrc, fdst, 1024 * 256)
        for rel in chk["replace"]:
            src = tmp / rel
            dst = app_root / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            # 原子替换：先写 .new 再 replace，避免写入中断留下半截文件
            tmp_dst = dst.with_suffix(dst.suffix + ".new")
            shutil.copy2(src, tmp_dst)
            tmp_dst.replace(dst)
            replaced.append(rel)
    except (OSError, zipfile.BadZipFile, KeyError) as e:
        rolled = 0
        for rel in backed:
            try:
                b = bkp / rel
                if b.exists():
                    d = app_root / rel
                    d.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(b, d)
                    rolled += 1
            except OSError:
                pass
        return {"ok": False, "problems": [_p("upg.writeFail", e=type(e).__name__)],
                "rolled_back": rolled, "backup": stamp}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        for rel in chk["replace"]:
            t = (app_root / rel).with_suffix((app_root / rel).suffix + ".new")
            if t.exists():
                try:
                    t.unlink()
                except OSError:
                    pass

    # 3) 清掉旧 .pyc，避免旧字节码被优先加载
    for sub in REPLACE_DIRS:
        shutil.rmtree(app_root / sub / "__pycache__", ignore_errors=True)

    _prune_backups()
    return {"ok": True, "from": old_ver, "to": chk["incoming"],
            "replaced": len(replaced), "backup": stamp,
            "warnings": chk["warnings"], "restart_required": True,
            "kept": chk["keep"], "ignored": chk["ignored"]}


def rollback(backup_id: str, running: bool = False) -> dict:
    """从指定备份还原程序文件。用户数据同样不动。"""
    if running:
        return {"ok": False, "problems": [_p("upg.running")]}
    bid = (backup_id or "").strip()
    if not re.fullmatch(r"[0-9]{8}-[0-9]{6}", bid):
        return {"ok": False, "problems": [_p("upg.badId")]}
    bkp = _backup_root() / bid
    if not bkp.is_dir():
        return {"ok": False, "problems": [_p("upg.noBackup", id=bid)]}
    app_root = PA.app_root()
    n = 0
    for f in sorted(bkp.rglob("*")):
        if not f.is_file() or f.name == "meta.json":
            continue
        rel = f.relative_to(bkp)
        if not _safe_member(str(rel).replace("\\", "/")):
            continue
        dst = app_root / rel
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dst)
            n += 1
        except OSError as e:
            return {"ok": False, "problems": [_p("upg.restoreFail", e=type(e).__name__)],
                    "restored": n}
    for sub in REPLACE_DIRS:
        shutil.rmtree(app_root / sub / "__pycache__", ignore_errors=True)
    return {"ok": True, "restored": n, "backup": bid, "restart_required": True}
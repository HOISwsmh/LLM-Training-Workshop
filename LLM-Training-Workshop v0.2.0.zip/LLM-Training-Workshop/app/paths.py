"""运行时路径解析 + 用户 Python 环境探测。

★范围（用户明确）：**不随包 Python 与训练库**，运行环境由用户自备。
  本模块只负责：定位程序自身资源、找到用户已装的可用环境、给出缺失指引。

三种运行形态：
  1. 源码运行：ROOT = 项目根，资源在 ROOT/web、ROOT/engine
  2. 冻结 exe：界面资源打进 exe（解包到 sys._MEIPASS）
  3. 便携发布：exe 同级放 engine/ 脚本（体积小，便于更新）

★引擎子进程绝不能用 sys.executable —— 冻结后它指向 exe 自身，
  拿它跑 .py 会递归启动 GUI。必须用探测到的用户 Python。
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

FROZEN = bool(getattr(sys, "frozen", False))

# ★程序版本：★唯一来源。界面左上角、能力说明页都从这里取，
#   发新版只改这一处，不要在 HTML/JS 里另写一份。
VERSION = "0.2.0"

# 训练所需的库（用户环境里必须有）
REQUIRED = ["torch", "transformers", "tokenizers", "numpy"]
OPTIONAL = ["pyarrow", "huggingface_hub"]

_CONFIG_NAME = "workshop_config.json"


def app_root() -> Path:
    """程序所在目录（exe 同级 或 源码项目根）。用户数据与配置放这里。"""
    if FROZEN:
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def resource_root() -> Path:
    """内置资源目录（界面）。冻结时用解包目录。"""
    if FROZEN:
        mp = getattr(sys, "_MEIPASS", None)
        if mp and (Path(mp) / "web").exists():
            return Path(mp)
    return app_root()


def web_dir() -> Path:
    return resource_root() / "web"


def engine_dir() -> Path:
    env = os.environ.get("LLM_WORKSHOP_ENGINE")
    if env and Path(env).exists():
        return Path(env)
    p = app_root() / "engine"
    if p.exists():
        return p
    return resource_root() / "engine"


def projects_dir() -> Path:
    return app_root() / "projects"


def logs_dir() -> Path:
    """日志目录。首次使用时自动创建——纯源码分发时该目录可能不存在。"""
    p = app_root() / "logs"
    try:
        p.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return p


# ---------------- 配置持久化 ----------------
def load_config() -> dict:
    p = app_root() / _CONFIG_NAME
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_config(cfg: dict) -> None:
    p = app_root() / _CONFIG_NAME
    try:
        p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def set_python(path: str) -> None:
    cfg = load_config()
    cfg["python"] = path
    save_config(cfg)


# ---------------- 环境探测 ----------------
def _probe(exe: str) -> dict | None:
    """检查某个解释器是否具备训练所需库。失败返回 None。"""
    code = (
        "import json,sys,importlib.util as u;"
        "r={'exe':sys.executable,'ver':sys.version.split()[0]};"
        "mods={};\n"
        "for m in ['torch','transformers','tokenizers','numpy','pyarrow','huggingface_hub']:\n"
        "    s=u.find_spec(m)\n"
        "    mods[m]=bool(s)\n"
        "r['mods']=mods\n"
        "try:\n"
        "    import torch\n"
        "    r['torch']=torch.__version__\n"
        "    r['cuda']=torch.cuda.is_available()\n"
        "    r['cuda_ver']=torch.version.cuda\n"
        "except Exception as e:\n"
        "    r['torch_err']=type(e).__name__\n"
        "print(json.dumps(r))"
    )
    try:
        p = subprocess.run([exe, "-c", code], capture_output=True, text=True,
                           timeout=90, encoding="utf-8", errors="replace")
        if p.returncode != 0 or not p.stdout.strip():
            return None
        line = [l for l in p.stdout.strip().splitlines() if l.startswith("{")]
        if not line:
            return None
        r = json.loads(line[-1])
        r["ok"] = all(r["mods"].get(m) for m in REQUIRED)
        return r
    except Exception:  # noqa: BLE001 探测失败不影响界面
        return None


def _candidates() -> list[str]:
    """按优先级列出可能的用户 Python。"""
    out: list[str] = []
    cfg = load_config()
    if cfg.get("python"):
        out.append(cfg["python"])
    env = os.environ.get("LLM_WORKSHOP_PYTHON")
    if env:
        out.append(env)
    if not FROZEN:
        out.append(sys.executable)

    home = Path(os.environ.get("USERPROFILE", str(Path.home())))
    # conda 常见位置
    for base in (home / "miniconda3", home / "anaconda3",
                 Path("C:/ProgramData/miniconda3"), Path("C:/ProgramData/anaconda3")):
        envs = base / "envs"
        if envs.exists():
            # 名字里带 llm/torch/train 的优先
            subs = sorted(envs.iterdir(), key=lambda p: (
                0 if any(k in p.name.lower() for k in ("llm", "torch", "train", "ai")) else 1,
                p.name))
            for s in subs:
                out.append(str(s / "python.exe"))
        out.append(str(base / "python.exe"))
    # 官方安装与 Store 版
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    prog = local / "Programs" / "Python"
    if prog.exists():
        for s in sorted(prog.iterdir(), reverse=True):
            out.append(str(s / "python.exe"))
    out += ["python", "python3", "py"]

    seen, uniq = set(), []
    for x in out:
        k = str(x).lower()
        if k in seen:
            continue
        seen.add(k)
        if x in ("python", "python3", "py") or Path(x).exists():
            uniq.append(x)
    return uniq


_CACHE: dict | None = None


def detect_env(force: bool = False) -> dict:
    """探测可用的用户 Python 环境。结果缓存，避免每次请求都启动子进程。"""
    global _CACHE
    if _CACHE is not None and not force:
        return _CACHE

    tried = []
    found = None
    for exe in _candidates():
        r = _probe(exe)
        tried.append({"exe": exe, "probed": r is not None,
                      "ok": bool(r and r.get("ok"))})
        if r and r.get("ok"):
            found = r
            break

    if found:
        _CACHE = {
            "ready": True, "python": found["exe"], "info": found,
            "tried": tried, "message": "已找到可用的训练环境",
        }
    else:
        _CACHE = {
            "ready": False, "python": None, "info": None, "tried": tried,
            "message": "未找到具备训练依赖的 Python 环境",
            "required": REQUIRED, "optional": OPTIONAL,
            "howto": [
                "安装 Python 3.10 或更高版本（建议 3.10/3.11）",
                "创建虚拟环境：python -m venv llm-env",
                "激活后安装依赖：pip install torch transformers tokenizers numpy pyarrow",
                "GPU 训练需装对应 CUDA 版本的 torch，详见 pytorch.org",
                "装好后回到本页点「重新检测」，或用「手动指定」选择 python.exe",
            ],
        }
    return _CACHE


def engine_python() -> str | None:
    """跑引擎用的解释器。未就绪时返回 None（调用方须拦截）。"""
    env = detect_env()
    return env["python"] if env["ready"] else None


def has_runtime() -> bool:
    return detect_env()["ready"]


def describe() -> dict:
    env = detect_env()
    return {
        "frozen": FROZEN,
        "app_root": str(app_root()),
        "resource_root": str(resource_root()),
        "engine_dir": str(engine_dir()),
        "engine_python": env.get("python"),
        "can_train": env["ready"],
    }

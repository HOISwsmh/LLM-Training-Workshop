"""外部训练监控（严格只读）。

用途：监控**不由本工具启动**的训练，例如用户自己在命令行跑的长任务。

★安全边界（硬性）：
  1. 本模块只读文件，绝不在被监控目录里创建/修改/删除任何东西
  2. 绝不终止、暂停或以任何方式干预训练进程
  3. 注册信息只写在本程序自己的目录里
  4. 判断"是否还在跑"依据日志写入时间，不依据进程存活
     （踩坑教训：体积不变可能只是没到写盘点，进程活着也可能已卡死）
"""
from __future__ import annotations

import csv
import json
import re
import time
from pathlib import Path

from . import paths as PA

WATCH_FILE = "watched_trainings.json"

# 日志写入间隔的宽限倍数。
# ★结束/暂停现在由日志里的 event 即时判定，不再依赖这个超时，
#   所以倍数可以收紧：2.5 倍足以容忍一次评估或存盘的抖动，
#   又能让"异常卡死"更快被发现（原来是 6 倍，最长要等几十分钟）。
STALL_MULTIPLIER = 2.5
DEFAULT_LOG_EVERY = 20
DEFAULT_STEP_SEC = 24.0


# ---------------- 注册表（写在本程序目录，不碰被监控目录） ----------------
def _load() -> list[dict]:
    p = PA.app_root() / WATCH_FILE
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save(items: list[dict]) -> None:
    p = PA.app_root() / WATCH_FILE
    try:
        p.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def list_watched() -> list[dict]:
    return _load()


def add(name: str, out_dir: str, total_tokens: float = 0,
        total_steps: int = 0, log_file: str = "") -> dict:
    """注册一个外部训练目录。只校验可读性，不写入该目录。"""
    name = (name or "").strip()
    if not name:
        raise ValueError("请填写监控名称")
    if len(name) > 50:
        raise ValueError("名称过长（最多 50 字）")
    d = Path((out_dir or "").strip().strip('"'))
    if not d.exists() or not d.is_dir():
        raise ValueError(f"目录不存在：{out_dir}")
    csv_p = d / "train_log.csv"
    if not csv_p.exists():
        raise ValueError(f"该目录下没有 train_log.csv：{d}")
    try:
        with csv_p.open(encoding="utf-8") as f:
            f.readline()
    except OSError as e:
        raise ValueError(f"无法读取日志：{e}") from e

    items = _load()
    if any(x["name"] == name for x in items):
        raise ValueError(f"名称「{name}」已存在")
    if any(Path(x["out_dir"]) == d for x in items):
        raise ValueError("该目录已在监控列表中")

    # 自动推断总步数/总token（从日志的 start 事件里取）
    info = _peek_totals(csv_p)
    item = {
        "name": name,
        "out_dir": str(d),
        "total_tokens": float(total_tokens or info.get("total_tokens") or 0),
        "total_steps": int(total_steps or info.get("total_steps") or 0),
        "log_file": (log_file or "").strip().strip('"'),
        "added_at": time.time(),
    }
    items.append(item)
    _save(items)
    return item


def remove(name: str) -> None:
    items = _load()
    kept = [x for x in items if x["name"] != name]
    if len(kept) == len(items):
        raise ValueError(f"未找到监控项「{name}」")
    _save(kept)


def _peek_totals(csv_p: Path) -> dict:
    """从 start 事件与 step 分母推断总量。只读。"""
    out = {}
    try:
        with csv_p.open(encoding="utf-8", newline="") as f:
            for r in csv.DictReader(f):
                note = r.get("note") or ""
                if r.get("phase") == "event" and "start" in note:
                    m = re.search(r"tokens=([\d.eE+]+)", note)
                    if m:
                        try:
                            out["total_tokens"] = float(m.group(1))
                        except ValueError:
                            pass
                    break
    except (OSError, ValueError):
        pass
    return out


# ---------------- 自动探测总量（只读） ----------------
def probe(out_dir: str, log_file: str = "") -> dict:
    """填了输出目录就自动推断总步数与 token 预算，省去手填。

    ★全部只读，且按可靠性排序，来源如实告知用户：
      1. 控制台日志里的 `step 3,980/640,396` —— 分母就是 max_steps，最可靠
      2. CSV 的 start 事件 —— 拿到 batch/accum/block，算出每步 token 数
      3. 断点 trainer_state.json —— 同样有这三个参数，作为退路
      4. data_meta.json 的 train_tokens —— 实际供给量（不等于预算，仅作参考）
    推断不出来就返回 0，绝不猜一个数糊上去。
    """
    d = Path((out_dir or "").strip().strip('"').strip("'"))
    out = {"ok": False, "total_steps": 0, "total_tokens": 0.0,
           "tokens_per_step": 0, "latest_step": 0, "sources": [], "problems": []}
    # ★Path("") 会变成 "."（当前目录），必须先判空再构造，
    #   否则空输入会被当成"存在但没有日志"，给出误导性提示。
    if not (out_dir or "").strip().strip('"').strip("'"):
        out["problems"].append("请填写训练输出目录")
        return out
    if not d.exists() or not d.is_dir():
        out["problems"].append(f"目录不存在：{d}")
        return out

    # ---- 1. 控制台日志：分母 = 总步数（最可靠）----
    # 未显式指定时，尝试几个常见位置，全部只读
    cands = []
    lf = (log_file or "").strip().strip('"').strip("'")
    if lf:
        cands.append(Path(lf))
    cands += [d / "train.log", d.parent / "logs" / "train.log",
              d.parent.parent / "logs" / "train_3b.log"]
    step_re = re.compile(r"step\s+([\d,]+)\s*/\s*([\d,]+)")
    for cp in cands:
        try:
            if not cp.is_file():
                continue
            # 只读尾部，避免几十 MB 日志全量读入
            with cp.open("rb") as f:
                f.seek(0, 2)
                size = f.tell()
                f.seek(max(0, size - 65536))
                tail = f.read().decode("utf-8", errors="replace")
            hits = step_re.findall(tail)
            if hits:
                cur, total = hits[-1]
                out["latest_step"] = int(cur.replace(",", ""))
                out["total_steps"] = int(total.replace(",", ""))
                out["sources"].append("console_total")
                break
        except (OSError, ValueError):
            continue

    # ---- 2. CSV：每步 token 数 + 最新步数 + 显式预算 ----
    csv_p = d / "train_log.csv"
    tps = 0
    if csv_p.is_file():
        out["ok"] = True
        try:
            with csv_p.open(encoding="utf-8", newline="") as f:
                for r in csv.DictReader(f):
                    note = r.get("note") or ""
                    if r.get("phase") == "event" and "start" in note:
                        mb = re.search(r"batch=(\d+)", note)
                        ma = re.search(r"accum=(\d+)", note)
                        mk = re.search(r"block=(\d+)", note)
                        if mb and ma and mk:
                            tps = int(mb.group(1)) * int(ma.group(1)) * int(mk.group(1))
                        mt = re.search(r"tokens=([\d.eE+]+)", note)
                        if mt:
                            try:
                                out["total_tokens"] = float(mt.group(1))
                                out["sources"].append("csv_budget")
                            except ValueError:
                                pass
                    elif r.get("phase") == "train":
                        st = int(r.get("step") or 0)
                        if st > out["latest_step"]:
                            out["latest_step"] = st
        except (OSError, ValueError):
            out["problems"].append("train_log.csv 无法解析")

    # ---- 3. 断点状态：补每步 token 数 ----
    if not tps:
        try:
            cks = sorted(
                [c for c in d.iterdir()
                 if c.is_dir() and c.name.startswith("checkpoint-")
                 and c.name.split("-")[-1].isdigit()],
                key=lambda x: int(x.name.split("-")[-1]))
            if cks:
                st = json.loads((cks[-1] / "trainer_state.json").read_text(encoding="utf-8"))
                b, a, k = st.get("batch_size"), st.get("grad_accum"), st.get("block_size")
                if b and a and k:
                    tps = int(b) * int(a) * int(k)
                    out["sources"].append("checkpoint_params")
        except (OSError, ValueError, TypeError):
            pass
    elif "csv_start" not in out["sources"]:
        out["sources"].append("csv_start")
    out["tokens_per_step"] = tps

    # ---- 4. 由总步数 × 每步 token 反推预算 ----
    if not out["total_tokens"] and out["total_steps"] and tps:
        out["total_tokens"] = float(out["total_steps"] * tps)
        out["sources"].append("derived_from_steps")

    # ---- 5. 数据供给量：仅作参考，不当预算 ----
    for meta in (d.parent / "data" / "final" / "data_meta.json",
                 d.parent.parent / "data" / "final" / "data_meta.json"):
        try:
            if meta.is_file():
                m = json.loads(meta.read_text(encoding="utf-8"))
                tt = int(m.get("train_tokens") or 0)
                if tt:
                    out["available_tokens"] = tt
                    out["sources"].append("data_meta")
                    # 完全没有任何预算线索时，用实际供给量兜底（并标注来源）
                    if not out["total_tokens"]:
                        out["total_tokens"] = float(tt)
                        out["total_steps"] = out["total_steps"] or (tt // tps if tps else 0)
                        out["sources"].append("fallback_available")
                break
        except (OSError, ValueError, TypeError):
            continue

    if not out["ok"] and not out["total_steps"]:
        out["problems"].append("该目录下没有 train_log.csv，也未找到可用的控制台日志")
    return out


# ---------------- 读取训练数据（只读） ----------------
# ★1 秒轮询下必须缓存：训练全程 CSV 会长到约 3 万行，
#   实测每次全量解析约 115ms，每秒重解析等于长期占着 CPU。
#   以 (路径, mtime, size, limit) 为键缓存解析结果 —— 日志一变键就变，
#   所以新数据点仍会在下一秒立刻出现，不会为了省 CPU 而延迟显示。
_LOG_CACHE: dict = {}
_LOG_CACHE_MAX = 12


def read_log(out_dir: str, limit: int = 1500) -> dict:
    d = Path(out_dir)
    p = d / "train_log.csv"
    try:
        stt = p.stat()
        ck = (str(p), stt.st_mtime_ns, stt.st_size, limit)
    except OSError:
        ck = None
    if ck is not None and ck in _LOG_CACHE:
        return _LOG_CACHE[ck]
    points, evals, events = [], [], []
    start_note = ""
    try:
        with p.open(encoding="utf-8", newline="") as f:
            for r in csv.DictReader(f):
                ph = r.get("phase")
                if ph == "train":
                    points.append({
                        "step": int(r.get("step") or 0),
                        "loss": _f(r.get("loss")),
                        "ppl": _f(r.get("ppl")),
                        "lr": _f(r.get("lr")),
                        "tok_s": _f(r.get("tok_s")),
                        "vram": _f(r.get("vram_gb")),
                        "tokens": int(r.get("tokens_seen") or 0),
                        "spikes": int(r.get("skipped_spikes") or 0),
                        "rollbacks": int(r.get("rollbacks") or 0),
                        "elapsed": _f(r.get("elapsed_s")),
                        "time": r.get("wall_time", ""),
                    })
                elif ph == "eval":
                    evals.append({"step": int(r.get("step") or 0),
                                  "loss": _f(r.get("loss")), "ppl": _f(r.get("ppl"))})
                elif ph == "event":
                    note = r.get("note", "")
                    if "start" in note and not start_note:
                        start_note = note
                    events.append({"step": int(r.get("step") or 0),
                                   "note": note, "time": r.get("wall_time", "")})
    except (OSError, ValueError):
        return {"points": [], "evals": [], "events": [], "latest": None,
                "start_note": "", "mtime": None, "error": "日志不可读"}

    mtime = None
    try:
        mtime = p.stat().st_mtime
    except OSError:
        pass

    full_n = len(points)
    last = points[-1] if points else None      # ★抽稀前先留住真正的最后一步
    if full_n > limit:
        stride = full_n // limit + 1
        points = points[::stride]
        # 抽稀可能把最后一点丢掉，导致步数/曲线落后于真实进度 → 补回来
        if last is not None and (not points or points[-1]["step"] != last["step"]):
            points.append(last)
    res = {"points": points, "evals": evals, "events": events[-25:],
           "latest": last, "start_note": start_note, "mtime": mtime, "count": full_n}
    if ck is not None:
        if len(_LOG_CACHE) >= _LOG_CACHE_MAX:
            _LOG_CACHE.clear()
        _LOG_CACHE[ck] = res
    return res


def _f(v):
    try:
        return float(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def checkpoints(out_dir: str) -> list[dict]:
    d = Path(out_dir)
    items = []
    if not d.exists():
        return items
    try:
        for c in sorted(d.iterdir()):
            if not c.is_dir():
                continue
            if not (c.name.startswith("checkpoint-") or c.name in ("best", "final")):
                continue
            size = 0
            try:
                size = sum(f.stat().st_size for f in c.rglob("*") if f.is_file())
            except OSError:
                pass
            step = None
            st = c / "trainer_state.json"
            if st.exists():
                try:
                    step = json.loads(st.read_text(encoding="utf-8")).get("global_step")
                except (OSError, ValueError):
                    pass
            try:
                mt = c.stat().st_mtime
            except OSError:
                mt = 0
            items.append({"name": c.name, "step": step,
                          "size_gb": round(size / 1024 ** 3, 2), "mtime": mt})
    except OSError:
        pass
    return items


def tail(path: str, lines: int = 60) -> str:
    if not path:
        return ""
    p = Path(path)
    if not p.exists() or not p.is_file():
        return ""
    try:
        with p.open(encoding="utf-8", errors="replace") as f:
            return "".join(f.readlines()[-lines:])
    except OSError:
        return ""


def supports_pause(out_dir: str) -> dict:
    """判断某个外部训练能否被安全暂停。

    ★只有引擎支持 STOP_REQUESTED 标记的训练才能暂停。
      判断依据：该输出目录旁的引擎脚本是否含标记机制 —— 但外部训练用的引擎
      路径未知，因此改为保守策略：默认不支持，除非用户显式确认过。
    """
    d = Path(out_dir)
    flag = d / "STOP_REQUESTED"
    return {
        "can_pause": False,
        "reason": ("该训练不由本工具启动，无法确认它的引擎是否支持暂停标记。"
                   "贸然写入标记可能被忽略（无效），也可能被误当成其他文件。"
                   "请用它自己的启动方式停止，或把训练迁移到本工具管理。"),
        "flag_path": str(flag),
        "flag_exists": flag.exists(),
    }


def snapshot(item: dict) -> dict:
    """汇总一个被监控训练的当前状态。全程只读。"""
    d = item["out_dir"]
    log = read_log(d)
    L = log["latest"]
    cks = checkpoints(d)

    total_tokens = float(item.get("total_tokens") or 0)
    total_steps = int(item.get("total_steps") or 0)

    # 从日志 step 行推断总步数：训练脚本打印 step N/TOTAL，但CSV没有分母，
    # 所以优先用用户填的；否则用 tokens 比例估算
    pct = None
    if L and total_tokens > 0:
        pct = min(100.0, L["tokens"] / total_tokens * 100)
    elif L and total_steps > 0:
        pct = min(100.0, L["step"] / total_steps * 100)

    eta = None
    if L and L.get("tok_s") and total_tokens > 0:
        left = total_tokens - L["tokens"]
        if left > 0:
            eta = left / L["tok_s"]

    # 活性判断：按日志写入时间，不看进程
    age = (time.time() - log["mtime"]) if log.get("mtime") else None
    # 用最近若干步的实际耗时估一个日志间隔
    step_sec = DEFAULT_STEP_SEC
    pts = log["points"]
    if len(pts) >= 2 and pts[-1].get("elapsed") and pts[0].get("elapsed"):
        ds = pts[-1]["step"] - pts[0]["step"]
        dt = pts[-1]["elapsed"] - pts[0]["elapsed"]
        if ds > 0 and dt > 0:
            step_sec = dt / ds
    gap = DEFAULT_LOG_EVERY * step_sec
    if len(pts) >= 2:
        gap = max(gap, (pts[-1]["step"] - pts[-2]["step"]) * step_sec)
    threshold = max(120.0, gap * STALL_MULTIPLIER)

    # ★状态优先看"最后一条事件"，而不是靠目录名或等超时：
    #   引擎在结束/暂停/中断时都会立刻写一条 event，所以这样判断是即时的。
    #   旧实现只要目录里有 final 就判"已完成"，但 final 可能是早期跑完留下的，
    #   之后同一目录又续训 —— 于是明明在训却显示已完成。
    evs = log.get("events") or []
    last_note = (evs[-1].get("note") or "") if evs else ""
    ended_by_event = None
    if last_note.startswith("done"):
        ended_by_event = "finished"
    elif last_note in ("paused_by_request", "keyboard_interrupt"):
        ended_by_event = "paused"
    # 事件之后若又有新的训练点，说明已经重新开跑，结束事件作废
    if ended_by_event and L and evs:
        try:
            if L.get("time") and evs[-1].get("time") and L["time"] > evs[-1]["time"]:
                ended_by_event = None
        except TypeError:
            pass

    if ended_by_event:
        state = ended_by_event
    elif age is None:
        state = "unknown"
    elif age <= threshold:
        state = "running"
    else:
        state = "stalled"

    return {
        "name": item["name"], "out_dir": d,
        "log": log, "checkpoints": cks,
        "total_tokens": total_tokens, "total_steps": total_steps,
        "percent": pct, "eta_sec": eta,
        "log_age_sec": age, "stall_threshold_sec": threshold,
        "step_sec_est": round(step_sec, 2),
        "state": state,
        "log_file": item.get("log_file") or "",
    }

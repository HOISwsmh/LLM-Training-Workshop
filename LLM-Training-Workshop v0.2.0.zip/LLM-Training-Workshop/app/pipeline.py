"""流水线调度器：把九个工位串成"自动挡"。

三条铁律（全部来自真实踩坑）：
  1. 每步产物落盘才算完成 —— 下一步只认上一步的输出文件，不认"进程退出了"
  2. 进度看文件增长/日志时间，不看进程活着 —— 曾三次误判卡死
  3. 大文件步骤先看磁盘 —— 不够就提前报错，而不是跑到一半磁盘满
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from . import imports as IM
from . import paths as PA
from . import projects as P

ROOT = PA.app_root()
ENGINE = PA.engine_dir()
# ★解释器在每次启动时动态取：用户可能中途才装好环境。
#   绝不能用 sys.executable —— 冻结后它指向 exe 自身，会递归启动 GUI。

# 语料类型：每类有自己的清洗预设与字段适配器。
# ★分类适配的必要性来自真实踩坑：
#   代码类 CJK 占比为 0，用通用"标准"强度会被全部误杀；
#   代码 4-gram 重复率中位数 0.52，用默认 0.5 阈值会误杀 56%；
#   古籍按段落切分，中位数仅 34 字，最短长度门槛必须放低。
CORPUS_KINDS = [
    {"key": "web", "name": "网页正文", "extractor": "skypile",
     "desc": "新闻、博客、论坛等长文本",
     "clean": {"min_cjk_ratio": 0.30, "max_repeat_ratio": 0.50,
               "max_symbol_ratio": 0.30, "min_chars": 20}},
    {"key": "wiki", "name": "百科词条", "extractor": "wikipedia",
     "desc": "维基百科、百度百科等结构化词条",
     "clean": {"min_cjk_ratio": 0.35, "max_repeat_ratio": 0.50,
               "max_symbol_ratio": 0.28, "min_chars": 20}},
    {"key": "qa", "name": "问答对话", "extractor": "zhihu",
     "desc": "知乎、问答社区、指令数据",
     "clean": {"min_cjk_ratio": 0.25, "max_repeat_ratio": 0.60,
               "max_symbol_ratio": 0.35, "min_chars": 8}},
    {"key": "book", "name": "书籍文献", "extractor": "wikipedia",
     "desc": "维基文库、电子书、长篇文章",
     "clean": {"min_cjk_ratio": 0.40, "max_repeat_ratio": 0.45,
               "max_symbol_ratio": 0.25, "min_chars": 30}},
    {"key": "guji", "name": "古籍文言", "extractor": "classical",
     "desc": "公版古籍，段落短、文言密度高",
     "clean": {"min_cjk_ratio": 0.50, "max_repeat_ratio": 0.55,
               "max_symbol_ratio": 0.25, "min_chars": 8}},
    {"key": "code", "name": "代码", "extractor": "codeparrot",
     "desc": "源码文件，中文占比为 0 属正常",
     "clean": {"min_cjk_ratio": 0.0, "max_repeat_ratio": 0.80,
               "max_symbol_ratio": 0.55, "min_chars": 20}},
    {"key": "auto", "name": "自动识别", "extractor": "auto",
     "desc": "结构不确定的语料，按通用规则处理",
     "clean": {"min_cjk_ratio": 0.20, "max_repeat_ratio": 0.60,
               "max_symbol_ratio": 0.35, "min_chars": 8}},
]

KIND_MAP = {k["key"]: k for k in CORPUS_KINDS}

# 清洗强度：在各类预设基础上整体收紧或放宽
CLEAN_LEVELS = {
    "loose": {"cjk_delta": -0.15, "repeat_delta": 0.15, "symbol_delta": 0.15, "chars_scale": 0.5},
    "standard": {"cjk_delta": 0.0, "repeat_delta": 0.0, "symbol_delta": 0.0, "chars_scale": 1.0},
    "strict": {"cjk_delta": 0.15, "repeat_delta": -0.10, "symbol_delta": -0.10, "chars_scale": 1.5},
}

# 可单独执行的步骤分组（用户可只跑其中一段）
STEP_GROUPS = [
    {"key": "prepare", "name": "准备数据", "stages": ["adapt", "clean"],
     "desc": "识别字段 + 清洗"},
    {"key": "build", "name": "构建训练集", "stages": ["tokenizer", "pack", "mix"],
     "desc": "训词表 + 打包 + 混合"},
    {"key": "all_data", "name": "数据全流程", "stages": ["adapt", "clean", "tokenizer", "pack", "mix"],
     "desc": "从原始语料到可训练数据"},
    {"key": "train", "name": "仅训练", "stages": ["train"],
     "desc": "用已有训练集开始/继续训练"},
    {"key": "test", "name": "仅验证", "stages": ["test"],
     "desc": "对已训好的模型做生成与困惑度测试"},
    {"key": "full", "name": "全部步骤", "stages": ["adapt", "clean", "tokenizer", "pack", "mix", "train", "test"],
     "desc": "一条流水线跑到底"},
]


# 自定义清洗参数的合法范围（防止用户填出必然清空语料的值）
CLEAN_BOUNDS = {
    "min_cjk_ratio": (0.0, 0.95),
    "max_repeat_ratio": (0.10, 0.99),
    "max_symbol_ratio": (0.05, 0.95),
    "min_chars": (1, 5000),
    "max_chars": (100, 2000000),
    "max_digit_ratio": (0.10, 0.99),
    "max_top_char_ratio": (0.10, 0.99),
}


def clean_params(kind: str, level: str, custom: dict | None = None) -> dict:
    """按语料类型 + 强度算出清洗参数；custom 中的项逐个覆盖预设。

    custom 为 None 或空 → 完全走类型预设（保持原有行为）。
    只覆盖用户明确填写的字段，其余仍按类型适配，避免"改一个就丢掉全部适配"。
    """
    base = KIND_MAP.get(kind, KIND_MAP["auto"])["clean"]
    lv = CLEAN_LEVELS.get(level, CLEAN_LEVELS["standard"])
    out = {
        "min_cjk_ratio": round(max(0.0, min(0.95, base["min_cjk_ratio"] + lv["cjk_delta"])), 3),
        "max_repeat_ratio": round(max(0.1, min(0.95, base["max_repeat_ratio"] + lv["repeat_delta"])), 3),
        "max_symbol_ratio": round(max(0.05, min(0.9, base["max_symbol_ratio"] + lv["symbol_delta"])), 3),
        "min_chars": max(4, int(base["min_chars"] * lv["chars_scale"])),
    }
    for k, v in (custom or {}).items():
        if k not in CLEAN_BOUNDS or v is None or v == "":
            continue
        lo, hi = CLEAN_BOUNDS[k]
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        f = max(lo, min(hi, f))
        out[k] = int(f) if k in ("min_chars", "max_chars") else round(f, 3)
    return out


def clean_warnings(kind: str, params: dict) -> list[str]:
    """对用户自定义值给出风险提示（不阻断，只提醒）。"""
    w = []
    if kind == "code" and params.get("min_cjk_ratio", 0) > 0.05:
        w.append("代码语料的中文占比通常为 0，中文门槛大于 0.05 可能滤掉绝大部分代码")
    if params.get("max_repeat_ratio", 1) < 0.52 and kind == "code":
        w.append("代码的 4-gram 重复率中位数约 0.52，阈值低于此值会误杀约一半样本")
    if kind == "guji" and params.get("min_chars", 0) > 20:
        w.append("古籍段落中位数约 34 字，最短门槛过高会滤掉大量正常段落")
    if params.get("min_cjk_ratio", 0) > 0.8:
        w.append("中文门槛过高，混合中英文的语料可能被大量丢弃")
    if params.get("max_symbol_ratio", 1) < 0.1:
        w.append("符号率上限过低，含公式或代码片段的文本容易被丢弃")
    mc = params.get("min_chars")
    xc = params.get("max_chars")
    if mc and xc and mc >= xc:
        w.append("最短字数不小于最长字数，会导致所有样本被丢弃")
    return w


class Runner:
    """单项目流水线执行器。同一时刻只允许一个项目在跑（单卡工具）。"""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._proc: subprocess.Popen | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.active: str | None = None
        self._only: set[str] | None = None
        self._pausing = False

    # ---------------- 状态 ----------------
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def status(self) -> dict:
        return {"running": self.is_running(), "active": self.active,
                "pausing": self._pausing}

    # ---------------- 优雅暂停 ----------------
    def pause(self, name: str) -> dict:
        """请求优雅暂停：写停止标记，让训练在步边界保存断点后自行退出。

        ★不终止进程、不发控制台信号。训练自己决定何时安全退出，
          因此不会丢进度、不会写坏断点。
        """
        if not self.is_running() or self.active != name:
            raise ValueError(f"项目「{name}」当前没有正在运行的任务")
        st = P.load(name)["state"]
        cur = st.get("current")
        if cur != "train":
            raise ValueError(f"当前在「{cur}」步骤，只有训练步骤支持暂停")
        out = P.output_dir(name)
        if not out.exists():
            raise ValueError("训练输出目录尚未创建，请稍等再试")
        flag = out / "STOP_REQUESTED"
        try:
            flag.write_text(
                f"requested_at={time.time()}\nby=LLM训练工坊\n", encoding="utf-8")
        except OSError as e:
            raise ValueError(f"无法写入暂停标记：{e}") from e
        self._pausing = True
        return {"requested": True, "flag": str(flag),
                "message": "已请求暂停。训练会在当前步结束后保存断点再退出，请稍候。"}

    def cancel_pause(self, name: str) -> dict:
        """撤销尚未被消费的暂停请求。"""
        flag = P.output_dir(name) / "STOP_REQUESTED"
        removed = False
        if flag.exists():
            try:
                flag.unlink()
                removed = True
            except OSError:
                pass
        self._pausing = False
        return {"cancelled": removed}

    # ---------------- 启动 ----------------
    def start(self, name: str, from_stage: str | None = None,
              group: str | None = None) -> None:
        """启动流水线。

        group: 只跑某一组步骤（prepare/build/all_data/train/test/full）
        from_stage: 从某个工位开始跑到最后（兼容断点续训）
        """
        with self._lock:
            if self.is_running():
                raise ValueError(f"已有项目「{self.active}」在运行。本工具为单卡设计，一次只能训练一个项目。")
            proj = P.load(name)
            st = proj["state"]
            keys = [k for k, _n, _d in P.STAGES]

            if group:
                g = next((x for x in STEP_GROUPS if x["key"] == group), None)
                if g is None:
                    raise ValueError(f"未知步骤分组：{group}")
                self._only = set(g["stages"])
                # 重置本组内未完成的工位；组外保持原状
                # paused 也要重置为 pending，才能继续训练
                for k in self._only:
                    if st["stages"][k]["status"] != "done":
                        st["stages"][k] = {"status": "pending", "progress": 0.0,
                                           "message": "", "started_at": None,
                                           "finished_at": None}
            else:
                self._only = None
                if from_stage:
                    if from_stage not in keys:
                        raise ValueError(f"未知工位：{from_stage}")
                    idx = keys.index(from_stage)
                    for k in keys[idx:]:
                        st["stages"][k] = {"status": "pending", "progress": 0.0,
                                           "message": "", "started_at": None,
                                           "finished_at": None}
            st["running"] = True
            st["error"] = None
            st["group"] = group
            P.save_state(name, st)
            self._stop.clear()
            self.active = name
            self._thread = threading.Thread(target=self._run, args=(name,), daemon=True)
            self._thread.start()

    def stop(self) -> None:
        """请求停止：终止当前子进程，保留已完成的工位。"""
        self._stop.set()
        p = self._proc
        if p and p.poll() is None:
            try:
                p.terminate()
                try:
                    p.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    p.kill()
            except OSError:
                pass

    # ---------------- 内部 ----------------
    def _set(self, name: str, key: str, **kw) -> dict:
        st = P.load(name)["state"]
        st["stages"][key].update(kw)
        if key:
            st["current"] = key
        P.save_state(name, st)
        return st

    def _run(self, name: str) -> None:
        d = P.project_dir(name)
        try:
            cfg = P.load(name)["config"]
            for key, label, _desc in P.STAGES:
                if self._only is not None and key not in self._only:
                    continue
                if self._stop.is_set():
                    self._set(name, key, status="stopped", message="用户停止")
                    break
                st = P.load(name)["state"]
                if st["stages"][key]["status"] == "done":
                    continue
                self._set(name, key, status="running", started_at=time.time(),
                          message=f"{label}中…")
                ok, msg = self._stage(name, key, cfg, d)
                if ok:
                    self._set(name, key, status="done", progress=1.0,
                              finished_at=time.time(), message=msg or "完成")
                elif msg == "__PAUSED__":
                    # 优雅暂停：断点已保存，不是失败
                    self._set(name, key, status="paused",
                              finished_at=time.time(),
                              message="已暂停并保存断点，可点「继续训练」接着跑")
                    s = P.load(name)["state"]
                    s["error"] = None
                    s["running"] = False
                    P.save_state(name, s)
                    return
                else:
                    self._set(name, key, status="failed", message=msg)
                    s = P.load(name)["state"]
                    s["error"] = f"{label}失败：{msg}"
                    s["running"] = False
                    P.save_state(name, s)
                    return
        except Exception as e:  # noqa: BLE001 任何异常都要落到状态里，不能静默
            s = P.load(name)["state"]
            s["error"] = f"{type(e).__name__}: {e}"
            s["running"] = False
            P.save_state(name, s)
        finally:
            s = P.load(name)["state"]
            s["running"] = False
            s["current"] = None
            P.save_state(name, s)
            self.active = None
            self._proc = None

    # ---------------- 子进程 ----------------
    def _exec(self, name: str, script: str, args: list[str], stage: str,
              d: Path, expect: Path | None = None,
              progress_cb=None, timeout: float | None = None) -> tuple[bool, str]:
        """运行引擎脚本；实时读输出更新进度；结束后校验产物。"""
        log = d / "logs" / f"{stage}.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        env = dict(os.environ)
        env["LLM_WORKSHOP_ROOT"] = str(d)
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUNBUFFERED"] = "1"
        env.setdefault("HF_ENDPOINT", "https://hf-mirror.com")

        # ★把临时文件与各类缓存全部收进项目目录，避免悄悄占用系统盘(C:)。
        #   CUDA_CACHE_PATH：GPU 内核编译缓存，训练必然产生，默认在 %APPDATA%\NVIDIA
        #   HF_HOME / TRANSFORMERS_CACHE：模型与数据集缓存，默认在 ~\.cache
        #   TMP/TEMP：Python tempfile 与部分库的落地位置
        cache = d / "cache"
        tmpd = d / "tmp"
        for p in (cache, tmpd, cache / "cuda", cache / "hf", cache / "torch", cache / "triton"):
            try:
                p.mkdir(parents=True, exist_ok=True)
            except OSError:
                pass
        # ★日志语言：默认 zh，引擎侧中文分支一字不改；
        #   只有显式选 en 时才走英文输出，保证既有中文日志完全不受影响。
        try:
            lg_lang = (P.load(name)["config"].get("log_lang") or "zh")
        except (ValueError, OSError):
            lg_lang = "zh"
        env["LLM_LOG_LANG"] = "en" if lg_lang == "en" else "zh"
        env["LLM_WORKSHOP_TMP"] = str(tmpd)
        env["TMP"] = str(tmpd)
        env["TEMP"] = str(tmpd)
        env["TMPDIR"] = str(tmpd)
        env["CUDA_CACHE_PATH"] = str(cache / "cuda")
        env["HF_HOME"] = str(cache / "hf")
        env["HUGGINGFACE_HUB_CACHE"] = str(cache / "hf" / "hub")
        env["TRANSFORMERS_CACHE"] = str(cache / "hf" / "transformers")
        env["TORCH_HOME"] = str(cache / "torch")
        env["TRITON_CACHE_DIR"] = str(cache / "triton")
        env["XDG_CACHE_HOME"] = str(cache)
        py = PA.engine_python()
        if not py:
            return False, ("未找到可用的 Python 训练环境。请在「环境」页按指引安装依赖，"
                           "或手动指定 python.exe 后重试")
        cmd = [py, "-u", str(ENGINE / script), *args]
        tail: list[str] = []
        t0 = time.time()
        with log.open("a", encoding="utf-8") as lf:
            lf.write(f"\n===== {stage} START {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n")
            lf.write("CMD: " + " ".join(cmd) + "\n")
            lf.flush()
            try:
                self._proc = subprocess.Popen(
                    cmd, cwd=str(d), env=env, stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                    errors="replace", bufsize=1,
                )
            except OSError as e:
                return False, f"无法启动引擎：{e}"
            proc = self._proc
            assert proc.stdout is not None
            for line in proc.stdout:
                lf.write(line)
                lf.flush()
                tail.append(line.rstrip())
                if len(tail) > 40:
                    tail.pop(0)
                if progress_cb:
                    pr, msg = progress_cb(line)
                    if pr is not None:
                        self._set(name, stage, progress=pr, message=msg or "")
                if self._stop.is_set():
                    proc.terminate()
                    return False, "用户停止"
                if timeout and time.time() - t0 > timeout:
                    proc.terminate()
                    return False, f"超时（>{timeout:.0f}秒）"
            code = proc.wait()
            lf.write(f"===== {stage} EXIT {code} =====\n")
        if self._stop.is_set():
            return False, "用户停止"
        # 131 = 优雅暂停（已保存断点），130 = Ctrl+C 中断（也已保存）
        if code in (130, 131):
            self._pausing = False
            self._paused_code = code
            return False, "__PAUSED__"
        if code != 0:
            reason = next((l for l in reversed(tail)
                           if re.search(r"Error|error|Traceback|\[!\]", l)), None)
            return False, reason or f"退出码 {code}（详见日志）"
        # 铁律1：产物必须落盘
        if expect is not None and not expect.exists():
            return False, f"脚本正常退出但产物缺失：{expect.name}"
        return True, tail[-1][:200] if tail else "完成"

    # ---------------- 导入已有产物 ----------------
    def _src(self, cfg: dict, key: str) -> dict | None:
        """取某工位的导入设置；未设为 import 则返回 None（走自己生成）。"""
        s = (cfg.get("sources") or {}).get(key) or {}
        if s.get("mode") == "import" and (s.get("path") or "").strip():
            return s
        return None

    def _mark_imported(self, name: str, key: str, raw: str, info: dict) -> None:
        """把导入来源记进状态，便于日后追溯这个模型接的是谁的权重。"""
        st = P.load(name)["state"]
        st.setdefault("imports", {})[key] = IM.record(key, raw, info)
        P.save_state(name, st)

    def _import_stage(self, name: str, key: str, cfg: dict, d: Path):
        """尝试用已有产物完成该工位。返回 (handled, ok, msg)。

        handled=False 表示该工位没设导入，调用方继续走正常生成流程。
        """
        s = self._src(cfg, key)
        if s is None:
            return False, False, ""
        raw = s["path"]
        v = IM.validate(key, raw)
        if not v["ok"]:
            return True, False, "导入失败：" + "；".join(v["problems"])
        info = v["info"]
        real = info.get("path", raw)

        if key in ("adapt", "clean"):
            # 语料类：复制到工位期望的位置，让后续步骤照常读取
            fn = "raw_0.jsonl" if key == "adapt" else "clean_0.jsonl"
            ok, msg = IM.use_file(key, real, d / "data" / fn)
            if not ok:
                return True, False, msg
            if key == "clean":
                # 合并文件供词表训练使用；单条导入时它就是全部
                merged = d / "data" / "cleaned_corpus.jsonl"
                try:
                    shutil.copy2(d / "data" / fn, merged)
                except OSError as e:
                    return True, False, f"生成合并语料失败：{e}"
            self._mark_imported(name, key, real, info)
            return True, True, "已导入：" + msg

        if key == "tokenizer":
            ok, msg = IM.use_tokenizer(real, d / "tokenizer")
            if not ok:
                return True, False, msg
            self._mark_imported(name, key, real, info)
            return True, True, msg

        if key in ("pack", "mix"):
            # ★token 流可能几十 GB：默认引用，不复制
            dst = d / "data" / ("packed_0" if key == "pack" else "final")
            ok, msg, ref = IM.link_or_copy_dir(Path(real), dst)
            if not ok:
                return True, False, msg
            wc = IM.vocab_conflict(info.get("vocab_size"), cfg.get("vocab_size"))
            if wc:
                self._set(name, key, message="⚠ " + wc)
            self._mark_imported(name, key, real, dict(info, referenced=ref))
            extra = f"，{info.get('train_tokens', 0):,} token" if info.get("train_tokens") else ""
            return True, True, msg + extra

        if key in ("train", "test"):
            # 模型类不复制：只把路径记下来，训练/验证时直接用
            self._mark_imported(name, key, real, info)
            gs = info.get("global_step")
            extra = f"，从第 {gs:,} 步接上" if gs else ""
            if key == "train" and not info.get("has_optimizer"):
                extra += "（仅继承权重）"
            return True, True, f"已选用已有模型{extra}"

        return False, False, ""

    # ---------------- 各工位 ----------------
    def _stage(self, name: str, key: str, cfg: dict, d: Path) -> tuple[bool, str]:
        # 先看该工位是否要用已有产物。train/test 例外：它们仍需真正执行，
        # 只是把模型来源换成导入路径，故在下面各自处理。
        if key not in ("train", "test"):
            handled, ok, msg = self._import_stage(name, key, cfg, d)
            if handled:
                return ok, msg
        if key == "adapt":
            return self._adapt(name, cfg, d)
        if key == "clean":
            return self._clean(name, cfg, d)
        if key == "tokenizer":
            return self._tokenizer(name, cfg, d)
        if key == "pack":
            return self._pack(name, cfg, d)
        if key == "mix":
            return self._mix(name, cfg, d)
        if key == "train":
            return self._train(name, cfg, d)
        if key == "test":
            return self._test(name, cfg, d)
        return False, f"未实现的工位 {key}"

    @staticmethod
    def _corpus_files(entry: dict) -> list[Path]:
        p = Path(entry.get("path", ""))
        if not p.exists():
            return []
        if p.is_file():
            return [p]
        return sorted(x for x in p.rglob("*")
                      if x.is_file() and x.suffix in (".jsonl", ".json", ".parquet", ".gz"))

    def _entries(self, cfg: dict) -> list[dict]:
        return [e for e in (cfg.get("corpus") or []) if (e.get("path") or "").strip()]

    def _adapt(self, name, cfg, d):
        """按语料条目分别适配：每类用自己的字段提取器，产物分开存放。"""
        entries = self._entries(cfg)
        if not entries:
            return False, "未配置语料。请在「语料」里添加本地文件或文件夹路径"
        total_mb = 0.0
        for i, e in enumerate(entries):
            if self._stop.is_set():
                return False, "用户停止"
            # 该类若直接提供已清洗文件，则无需识别字段
            if (e.get("clean_import") or "").strip():
                self._set(name, "adapt", progress=(i + 1) / len(entries),
                          message=f"第{i + 1}类将用已清洗文件")
                continue
            kind = e.get("kind", "auto")
            files = self._corpus_files(e)
            if not files:
                return False, f"语料「{e['path']}」不存在或没有 jsonl/json/parquet/gz 文件"
            ex = KIND_MAP.get(kind, KIND_MAP["auto"])["extractor"]
            out = d / "data" / f"raw_{i}.jsonl"
            args = ["--src", *[str(f) for f in files], "--dst", str(out), "--kind", ex]

            def cb(line, i=i, n=len(entries)):
                m = re.search(r"已处理\s*([\d,]+)", line)
                if m:
                    return (i + 0.5) / n, f"第{i + 1}类 已处理 {m.group(1)} 条"
                return None, None

            ok, msg = self._exec(name, "adapt_corpus.py", args, "adapt", d,
                                 expect=out, progress_cb=cb)
            if not ok:
                return False, f"第{i + 1}类（{KIND_MAP.get(kind, {}).get('name', kind)}）：{msg}"
            if out.stat().st_size == 0:
                return False, (f"第{i + 1}类适配结果为空——字段可能无法识别，"
                               "请把类型改为「自动识别」重试")
            total_mb += out.stat().st_size / 1024 ** 2
            self._set(name, "adapt", progress=(i + 1) / len(entries),
                      message=f"{i + 1}/{len(entries)} 类已识别")
        return True, f"{len(entries)} 类语料共产出 {total_mb:.1f}MB"

    def _clean(self, name, cfg, d):
        """按语料类型分别清洗：各类用各自适配的阈值，避免一刀切误杀。"""
        entries = self._entries(cfg)
        # ★每条语料可单独导入已清洗文件：该类跳过识别与清洗，其余照常处理。
        imported_idx = set()
        kept_info = []
        total_mb = 0.0
        for i, e in enumerate(entries):
            raw = (e.get("clean_import") or "").strip()
            if not raw:
                continue
            v = IM.validate("clean", raw)
            if not v["ok"]:
                return False, f"第{i + 1}类导入失败：" + "；".join(v["problems"])
            ok, msg = IM.use_file("clean", v["info"].get("path", raw),
                                  d / "data" / f"clean_{i}.jsonl")
            if not ok:
                return False, f"第{i + 1}类：{msg}"
            imported_idx.add(i)
            mb = (d / "data" / f"clean_{i}.jsonl").stat().st_size / 1024 ** 2
            total_mb += mb
            kn = KIND_MAP.get(e.get("kind", "auto"), {}).get("name", e.get("kind", "auto"))
            kept_info.append(f"{kn} {mb:.0f}MB(导入)")
            self._mark_imported(name, f"clean_{i}", raw, v["info"])
        if imported_idx and len(imported_idx) == len(entries):
            merged = d / "data" / "cleaned_corpus.jsonl"
            with merged.open("w", encoding="utf-8") as out:
                for i in range(len(entries)):
                    with (d / "data" / f"clean_{i}.jsonl").open(encoding="utf-8") as f:
                        shutil.copyfileobj(f, out, 1024 * 1024)
            self._set(name, "clean", progress=1.0, message="全部语料已导入")
            return True, f"已导入清洗语料：{'、'.join(kept_info)}"
        level = cfg.get("clean_level", "standard")
        for i, e in enumerate(entries):
            if i in imported_idx:
                continue
            if self._stop.is_set():
                return False, "用户停止"
            kind = e.get("kind", "auto")
            src = d / "data" / f"raw_{i}.jsonl"
            if not src.exists():
                return False, f"缺少第{i + 1}类的适配产物，请先执行「识别字段」"
            dst = d / "data" / f"clean_{i}.jsonl"
            # 每条语料可单独设强度；未设则用全局默认
            lv_i = e.get("clean_level") or level
            cp = clean_params(kind, lv_i, e.get("clean_custom"))
            args = ["--src", str(src), "--dst", str(dst),
                    "--min-cjk-ratio", str(cp["min_cjk_ratio"]),
                    "--max-repeat-ratio", str(cp["max_repeat_ratio"]),
                    "--max-symbol-ratio", str(cp["max_symbol_ratio"]),
                    "--min-chars", str(cp["min_chars"]),
                    "--workers", str(min(8, os.cpu_count() or 4)),
                    "--dedup", e.get("dedup") or "bloom", "--progress-every", "50000"]
            # 以下为用户可选的进阶项，仅在填写时传入
            for key, flag in (("max_chars", "--max-chars"),
                              ("max_digit_ratio", "--max-digit-ratio"),
                              ("max_top_char_ratio", "--max-top-char-ratio")):
                if key in cp:
                    args += [flag, str(cp[key])]
            if e.get("strip_urls") is False:
                args.append("--no-strip-urls")
            if e.get("nfkc") is False:
                args.append("--no-nfkc")

            def cb(line, i=i, n=len(entries)):
                m = re.search(r"已处理\s*([\d,]+)", line)
                if m:
                    return (i + 0.5) / n, f"第{i + 1}类 已清洗 {m.group(1)} 条"
                return None, None

            ok, msg = self._exec(name, "clean_data.py", args, "clean", d,
                                 expect=dst, progress_cb=cb)
            if not ok:
                return False, f"第{i + 1}类清洗失败：{msg}"
            kname = KIND_MAP.get(kind, {}).get("name", kind)
            if dst.stat().st_size == 0:
                return False, (f"「{kname}」清洗后无数据。该类阈值："
                               f"中文占比≥{cp['min_cjk_ratio']}、重复率≤{cp['max_repeat_ratio']}。"
                               "请把强度改为「宽松」，或确认语料类型选对了")
            mb = dst.stat().st_size / 1024 ** 2
            total_mb += mb
            kept_info.append(f"{kname} {mb:.0f}MB")
            self._set(name, "clean", progress=(i + 1) / len(entries),
                      message=f"{i + 1}/{len(entries)} 类已清洗")
        # 合并供后续词表训练使用
        merged = d / "data" / "cleaned_corpus.jsonl"
        with merged.open("w", encoding="utf-8") as out:
            for i in range(len(entries)):
                p = d / "data" / f"clean_{i}.jsonl"
                with p.open(encoding="utf-8") as f:
                    shutil.copyfileobj(f, out, 1024 * 1024)
        return True, f"清洗完成：{'、'.join(kept_info)}"

    def _tokenizer(self, name, cfg, d):
        src = d / "data" / "cleaned_corpus.jsonl"
        out = d / "tokenizer"
        args = ["--src", str(src), "--out-dir", str(out),
                "--vocab-size", str(int(cfg.get("vocab_size") or 32000)),
                "--sample-lines", "300000"]
        ok, msg = self._exec(name, "train_tokenizer.py", args, "tokenizer", d,
                             expect=out / "tokenizer.json")
        return (True, "词表已生成") if ok else (False, msg)

    def _pack(self, name, cfg, d):
        """按类分别打包，产物分开存放，供整合阶段按权重混合。"""
        entries = self._entries(cfg)
        tok = d / "tokenizer"
        if not (tok / "tokenizer.json").exists():
            return False, "缺少词表，请先执行「训练词表」或在该步导入已有词表"
        total_need = 0
        for i in range(len(entries)):
            p = d / "data" / f"clean_{i}.jsonl"
            if p.exists():
                total_need += p.stat().st_size
        free = shutil.disk_usage(str(d)).free
        need = total_need + 2 * 1024 ** 3
        if free < need:
            return False, (f"磁盘空间不足：约需 {need / 1024 ** 3:.1f}GB，"
                           f"剩余 {free / 1024 ** 3:.1f}GB")
        total_tok = 0
        for i, e in enumerate(entries):
            if self._stop.is_set():
                return False, "用户停止"
            src = d / "data" / f"clean_{i}.jsonl"
            if not src.exists():
                return False, f"缺少第{i + 1}类清洗产物，请先执行「清洗」"
            out = d / "data" / f"packed_{i}"
            args = ["--src", str(src), "--tokenizer", str(tok), "--out-dir", str(out),
                    "--workers", str(max(1, min(8, (os.cpu_count() or 4) - 2))),
                    "--progress-every", "50000"]

            def cb(line, i=i, n=len(entries)):
                m = re.search(r"已处理\s*([\d,]+)", line)
                if m:
                    return (i + 0.5) / n, f"第{i + 1}类 已打包 {m.group(1)} 条"
                return None, None

            ok, msg = self._exec(name, "prepare_data.py", args, "pack", d,
                                 expect=out / "data_meta.json", progress_cb=cb)
            if not ok:
                return False, f"第{i + 1}类打包失败：{msg}"
            m = json.loads((out / "data_meta.json").read_text(encoding="utf-8"))
            total_tok += int(m.get("train_tokens", 0))
            self._set(name, "pack", progress=(i + 1) / len(entries),
                      message=f"{i + 1}/{len(entries)} 类已打包")
        return True, f"打包完成，合计约 {total_tok:,} token"

    def _mix(self, name, cfg, d):
        """整合：单类直接采用；多类调用引擎按权重混合。"""
        entries = self._entries(cfg)
        final = d / "data" / "final"
        # ★打包步骤若为引用导入，final 可能已是指向别处的联接，
        #   此时绝不能再往里写，否则会污染用户的原始数据目录。
        if self._src(cfg, "pack") and (final / "data_meta.json").exists():
            meta = json.loads((final / "data_meta.json").read_text(encoding="utf-8"))
            total = int(meta.get("train_tokens", 0))
            if total <= 0:
                return False, "导入的训练集 token 为 0"
            self._set(name, "mix", progress=1.0, message=f"沿用导入数据 {total:,} token")
            return True, f"沿用已导入的训练集，{total:,} token"
        final.mkdir(parents=True, exist_ok=True)
        packs = []
        for i, e in enumerate(entries):
            p = d / "data" / f"packed_{i}"
            if (p / "data_meta.json").exists():
                packs.append((i, e, p))
        if not packs:
            return False, "没有打包产物，请先执行「打包」"

        if len(packs) == 1:
            _i, _e, p = packs[0]
            # ★单类无需混合。若 packed 目录是导入的引用，直接沿用，
            #   绝不复制几十 GB；否则建联接，失败才退回复制。
            if p.resolve() != final.resolve():
                if final.exists() and any(final.iterdir()):
                    for fn in ("tokens_train.bin", "tokens_val.bin", "data_meta.json"):
                        s = p / fn
                        if s.exists():
                            shutil.copy2(s, final / fn)
                else:
                    if final.exists():
                        final.rmdir()
                    ok, msg, _ref = IM.link_or_copy_dir(p, final)
                    if not ok:
                        return False, msg
            meta = json.loads((final / "data_meta.json").read_text(encoding="utf-8"))
            total = int(meta.get("train_tokens", 0))
            if total <= 0:
                return False, "训练集 token 为 0"
            self._set(name, "mix", progress=1.0, message=f"就绪 {total:,} token")
            return True, f"训练集 {total:,} token"

        # 多类：用户可用百分比自由指定占比（sum 不必等于100，会自动归一化）；
        # 也可用 weight 相对权重。percent 优先。
        weights = []
        for _i, e, _p in packs:
            pv = e.get("percent")
            if pv is not None and pv != "":
                try:
                    weights.append(max(0.0, float(pv)))
                    continue
                except (TypeError, ValueError):
                    pass
            weights.append(max(0.0, float(e.get("weight") or 1.0)))
        s = sum(weights)
        if s <= 0:
            weights = [1.0] * len(packs)
            s = float(len(packs))
        ratios = [w / s for w in weights]
        src_args, ratio_parts = [], []
        avail_total = 0
        for (i, e, p), r in zip(packs, ratios):
            key = f"{e.get('kind', 'auto')}{i}"
            src_args += ["--source", f"{key}={p}"]
            ratio_parts.append(f"{key}={r:.6f}")
            m = json.loads((p / "data_meta.json").read_text(encoding="utf-8"))
            avail_total += int(m.get("train_tokens", 0))
        want = int(cfg.get("max_tokens") or 0)
        target = min(want, avail_total) if want > 0 else avail_total
        args = [*src_args, "--ratio", ",".join(ratio_parts),
                "--target-tokens", str(target), "--out-dir", str(final),
                "--block-size", "1024", "--allow-insufficient"]
        ok, msg = self._exec(name, "mix_tokens.py", args, "mix", d,
                             expect=final / "data_meta.json")
        if not ok:
            return False, msg
        meta = json.loads((final / "data_meta.json").read_text(encoding="utf-8"))
        total = int(meta.get("train_tokens", 0))
        if total <= 0:
            return False, "整合后训练集为 0"
        self._set(name, "mix", progress=1.0, message=f"就绪 {total:,} token")
        return True, f"{len(packs)} 类已整合，训练集 {total:,} token"

    def _train(self, name, cfg, d):
        from . import hardware as H  # noqa: PLC0415

        hw = H.detect()
        arch = cfg.get("arch") or None
        chk = H.check_config(cfg["tier"], int(cfg["block_size"]), hw,
                             arch=arch, vocab_size=int(cfg.get("vocab_size") or 32000))
        if not chk["ok"]:
            return False, "；".join(chk["problems"])
        # ★显存不足/规模过大只警告，不阻止启动（用户明确要求）
        if chk.get("warnings"):
            self._set(name, "train",
                      message="风险提示：" + "；".join(chk["warnings"])[:300])
            log = d / "logs" / "train.log"
            try:
                log.parent.mkdir(parents=True, exist_ok=True)
                with log.open("a", encoding="utf-8") as f:
                    f.write("\n[风险提示] 以下问题不会阻止启动，由用户自行决定：\n")
                    for w in chk["warnings"]:
                        f.write("  - " + w + "\n")
            except OSError:
                pass

        # 数据目录：优先用整合产物；若用户直接导入了训练集则用它
        data_dir = d / "data" / "final"
        s_mix = self._src(cfg, "mix")
        if s_mix:
            v = IM.validate("mix", s_mix["path"])
            if not v["ok"]:
                return False, "导入的训练集不可用：" + "；".join(v["problems"])
            data_dir = Path(v["info"].get("path", s_mix["path"]))
            wc = IM.vocab_conflict(v["info"].get("vocab_size"), cfg.get("vocab_size"))
            if wc:
                return False, wc
        mp = data_dir / "data_meta.json"
        if not mp.exists():
            return False, "缺少训练集，请先执行「整合」或在该步导入已有训练集"
        meta = json.loads(mp.read_text(encoding="utf-8"))
        avail = int(meta.get("train_tokens", 0))
        want = int(cfg.get("max_tokens") or 0)
        budget = min(want, avail) if want > 0 else avail
        if budget <= 0:
            return False, "可用训练 token 为 0"

        lr = cfg.get("lr") or H.TIER_LR.get(cfg["tier"], 1e-4)
        out = P.output_dir(name, cfg)
        try:
            out.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            return False, f"无法创建输出目录 {out}：{e}"
        # 词表目录：★只跑「仅训练」时词表工位不会执行，
        #   所以这里要负责把导入的词表落地，不能假设前面已经复制过。
        tok_dir = d / "tokenizer"
        if not (tok_dir / "tokenizer.json").exists():
            s_tk = self._src(cfg, "tokenizer")
            if s_tk:
                vt = IM.validate("tokenizer", s_tk["path"])
                if not vt["ok"]:
                    return False, "导入的词表不可用：" + "；".join(vt["problems"])
                ok, msg = IM.use_tokenizer(vt["info"].get("path", s_tk["path"]), tok_dir)
                if not ok:
                    return False, msg
                self._mark_imported(name, "tokenizer", s_tk["path"], vt["info"])
            else:
                return False, "缺少词表，请先执行「训练词表」或在该步导入已有词表"
        args = ["--tier", cfg["tier"], "--data-dir", str(data_dir),
                "--tokenizer", str(tok_dir),
                "--master-dtype", cfg.get("master_dtype", "bf16"),
                "--lr", str(lr), "--block-size", str(int(cfg["block_size"])),
                "--batch-size", str(int(cfg["batch_size"])),
                "--grad-accum", str(int(cfg["grad_accum"])),
                "--max-tokens", str(budget),
                "--warmup-steps", str(int(cfg["warmup_steps"])),
                "--log-every", str(int(cfg["log_every"])),
                "--eval-every", str(int(cfg["eval_every"])),
                "--save-every", str(int(cfg["save_every"])),
                "--keep-checkpoints", str(int(cfg["keep_checkpoints"])),
                "--num-workers", str(int(cfg["num_workers"])),
                "--out-dir", str(out), "--resume"]
        # ★导入已有模型：从别处的断点/权重接着训，而不是从零开始
        s_tr = self._src(cfg, "train")
        if s_tr:
            v = IM.validate("train", s_tr["path"])
            if not v["ok"]:
                return False, "导入的模型不可用：" + "；".join(v["problems"])
            rp = v["info"].get("path", s_tr["path"])
            # ★续训前必须确认分词器一致：大小相同但内容不同会静默毁掉模型
            mm = IM.tokenizer_mismatch(Path(rp), tok_dir)
            if mm:
                return False, mm
            args += ["--resume-from", str(rp)]
            self._mark_imported(name, "train", rp, v["info"])
            note = f"[导入] 从已有模型续训：{rp}"
            if not v["info"].get("has_optimizer"):
                note += "（无优化器状态，仅继承权重）"
            try:
                lg = d / "logs" / "train.log"
                lg.parent.mkdir(parents=True, exist_ok=True)
                with lg.open("a", encoding="utf-8") as f:
                    f.write("\n" + note + "\n")
            except OSError:
                pass
        if arch:
            args += ["--arch", json.dumps(arch, ensure_ascii=False)]
        if not cfg.get("spike_guard", True):
            args.append("--no-spike-guard")
        bdir = (cfg.get("backup_dir") or "").strip()
        if bdir:
            args += ["--backup-dir", bdir,
                     "--backup-every", str(int(cfg["backup_every"])),
                     "--keep-backups", str(int(cfg["keep_backups"]))]

        def cb(line):
            m = re.search(r"^step\s+(\d+)/([\d,]+)", line)
            if m:
                cur = int(m.group(1))
                tot = int(m.group(2).replace(",", ""))
                return cur / max(tot, 1), f"第 {cur:,}/{tot:,} 步"
            return None, None

        ok, msg = self._exec(name, "train_model.py", args, "train", d,
                             expect=out / "final" / "config.json", progress_cb=cb)
        return (True, "训练完成") if ok else (False, msg)

    def _test(self, name, cfg, d):
        # 验证对象：默认本项目训出的 final；也可导入任意已有模型
        model_dir = P.output_dir(name, cfg) / "final"
        s_te = self._src(cfg, "test")
        if s_te:
            v = IM.validate("test", s_te["path"])
            if not v["ok"]:
                return False, "导入的模型不可用：" + "；".join(v["problems"])
            model_dir = Path(v["info"].get("path", s_te["path"]))
            self._mark_imported(name, "test", str(model_dir), v["info"])
        elif not (model_dir / "config.json").exists():
            # 没训完但用户导入了训练起点时，退而验证那个模型
            s_tr = self._src(cfg, "train")
            if s_tr:
                v = IM.validate("train", s_tr["path"])
                if v["ok"]:
                    model_dir = Path(v["info"].get("path", s_tr["path"]))
        if not (model_dir / "config.json").exists():
            return False, "没有可验证的模型，请先完成训练或在该步导入已有模型"
        args = ["--model-dir", str(model_dir), "--prompt", "人工智能的未来",
                "--max-new-tokens", "40", "--eval-lines", "0"]
        ok, msg = self._exec(name, "test_model.py", args, "test", d)
        return (True, f"验证完成（{model_dir.name}）") if ok else (False, msg)


RUNNER = Runner()

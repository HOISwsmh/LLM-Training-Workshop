# -*- coding: utf-8 -*-
"""prepare_audio_chart.py —— 构造「音频 → 4K 音游谱面」多模态训练数据

这是第二阶段的数据准备。把音频特征与对应谱面配对，序列化成统一的
token 流，让第一阶段的中文 LLM 能继续训练出跨模态能力。

输入（每条样本一行 jsonl）：
    {
      "audio_features": [[f0, f1, ...], ...],   # 帧 × 特征维，如 64 帧 × 128 维
      "chart": [                                 # 4K 谱面，按时间排序的音符
        {"time": 1.234, "lane": 2},              # lane 取值 1~4
        ...
      ],
      "bpm": 128.0,          # 可选，供模型学习节奏先验
      "difficulty": "Hard"   # 可选
    }

输出（train_multimodal.py 直接消费）：
    增加 chart_text 字段，即谱面的文本化表示：
        note + lane标记 + 时间  重复拼接
    文本化而非数值化，是为了直接复用第一阶段 LLM 的自回归目标——
    谱面生成就退化成"生成一段结构化文本"，不需要额外的回归头。

★所有标记从 mm_tokens 引用，源码里不写裸字面量（避免同形替换）。

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/prepare_audio_chart.py --make-demo
    python engine/prepare_audio_chart.py --src my_data.jsonl
"""
from __future__ import annotations
import os

import argparse
import json
import sys
from pathlib import Path

import numpy as np

# 同目录的 mm_tokens：所有多模态标记的唯一定义处
sys.path.insert(0, str(Path(__file__).resolve().parent))
import mm_tokens as T  # noqa: E402

ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent)
DATA_DIR = ROOT / "data"
RAW_MM = DATA_DIR / "audio_chart_raw.jsonl"
OUT_MM = DATA_DIR / "audio_chart_train.jsonl"

AUDIO_DIM = 128          # 每帧特征维度（示例用梅尔谱/Onset 强度）
AUDIO_FRAMES = 64        # 每条样本的音频帧数
LANES = T.LANES          # 4K 音游，取自 mm_tokens 保持一致


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="构造音频→4K 谱面多模态训练数据")
    ap.add_argument("--src", default=str(RAW_MM), help="原始配对数据 jsonl")
    ap.add_argument("--dst", default=str(OUT_MM), help="输出 jsonl")
    ap.add_argument("--make-demo", action="store_true",
                    help="生成合成演示数据（先验证链路，不是真谱面）")
    ap.add_argument("--demo-count", type=int, default=200)
    ap.add_argument("--frames", type=int, default=AUDIO_FRAMES)
    ap.add_argument("--audio-dim", type=int, default=AUDIO_DIM)
    ap.add_argument("--max-notes", type=int, default=512)
    ap.add_argument("--min-notes", type=int, default=8)
    ap.add_argument("--seed", type=int, default=42)
    return ap.parse_args()


def make_demo(path: Path, count: int, frames: int, dim: int, seed: int) -> None:
    """合成演示数据。

    ★重要：这里的音频与谱面是随机生成的，两者没有真实对应关系。
    它只能用来验证张量形状、投影层、loss 计算等链路是否正确，
    模型学不到任何真实的音乐→谱面映射。正式训练必须换成真实数据。
    """
    rng = np.random.default_rng(seed)
    path.parent.mkdir(parents=True, exist_ok=True)
    difficulties = ["Easy", "Normal", "Hard", "Expert"]
    with path.open("w", encoding="utf-8") as fh:
        for i in range(count):
            bpm = float(rng.integers(80, 200))
            dur = rng.uniform(10.0, 30.0)
            # 模拟 onset 强度：低频节律 + 噪声
            t = np.linspace(0, dur, frames)
            energy = np.abs(np.sin(2 * np.pi * (bpm / 60) * t)) \
                + rng.normal(0, 0.15, frames)
            feats = (np.abs(rng.normal(0, 1, (frames, dim)))
                     * energy[:, None]).astype(np.float32)

            n_notes = int(rng.integers(20, 200))
            times = np.sort(rng.uniform(0, dur, n_notes))
            # 让音符倾向于落在节拍上（演示数据的弱相关性）
            half_beat = 60.0 / bpm / 2
            times = np.unique(np.clip(
                np.round(times / half_beat) * half_beat, 0, dur))
            chart = [{"time": round(float(x), 4),
                      "lane": int(rng.integers(1, LANES + 1))} for x in times]

            fh.write(json.dumps({
                "id": f"demo_{i:06d}",
                "audio_features": feats.tolist(),
                "chart": chart,
                "bpm": round(bpm, 2),
                "difficulty": difficulties[i % len(difficulties)],
            }, ensure_ascii=False) + "\n")
    print(f"[i] 已生成合成演示数据 {count} 条 → {path}")
    print("    ★注意：音频与谱面为随机生成，无真实对应关系，只能验证链路。")


def chart_to_tokens(chart: list[dict]) -> str:
    """把谱面转成文本 token 序列。

    每个音符 = NOTE 标记 + 对应轨道标记 + 三位小数时间。
    按时间升序排列，保证序列与音乐时间轴一致。
    """
    parts = []
    for note in sorted(chart, key=lambda n: n.get("time", 0)):
        lane = note.get("lane")
        if not isinstance(lane, int) or not (1 <= lane <= LANES):
            continue
        t = float(note.get("time", 0))
        parts.append(f"{T.NOTE}{T.lane_token(lane)}{t:.3f}")
    return "".join(parts)


def validate_and_convert(src: Path, dst: Path, args) -> int:
    if not src.exists():
        print(f"[!] 找不到原始数据：{src}")
        print("    用 --make-demo 生成演示数据，或自备同格式的真实数据")
        return 1

    dst.parent.mkdir(parents=True, exist_ok=True)
    n_ok = n_bad = n_short = 0
    reasons: dict[str, int] = {}
    note_counts = []
    feat_shapes = set()
    bad_lane = 0

    with src.open("r", encoding="utf-8-sig", errors="replace") as fin, \
            dst.open("w", encoding="utf-8") as fout:
        for lineno, line in enumerate(fin, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                n_bad += 1
                reasons["json_parse_error"] = reasons.get("json_parse_error", 0) + 1
                continue

            feats = obj.get("audio_features")
            chart = obj.get("chart")
            if not isinstance(feats, list) or not feats:
                n_bad += 1
                reasons["missing_audio_features"] = \
                    reasons.get("missing_audio_features", 0) + 1
                continue
            if not isinstance(chart, list):
                n_bad += 1
                reasons["missing_chart"] = reasons.get("missing_chart", 0) + 1
                continue

            arr = np.asarray(feats, dtype=np.float32)
            if arr.ndim != 2:
                key = f"audio_shape_ndim_{arr.ndim}"
                n_bad += 1
                reasons[key] = reasons.get(key, 0) + 1
                continue
            feat_shapes.add(arr.shape)

            bad_lane += sum(1 for n in chart
                            if not (isinstance(n.get("lane"), int)
                                    and 1 <= n["lane"] <= LANES))
            text_chart = chart_to_tokens(chart)
            n_notes = text_chart.count(T.NOTE)
            if n_notes < args.min_notes:
                n_short += 1
                reasons["too_few_notes"] = reasons.get("too_few_notes", 0) + 1
                continue

            note_counts.append(n_notes)
            fout.write(json.dumps({
                "id": obj.get("id", f"line_{lineno}"),
                "audio_features": arr.tolist(),
                "audio_frames": int(arr.shape[0]),
                "audio_dim": int(arr.shape[1]),
                "chart_text": text_chart,
                "n_notes": n_notes,
                "bpm": obj.get("bpm"),
                "difficulty": obj.get("difficulty"),
            }, ensure_ascii=False) + "\n")
            n_ok += 1

    print("=" * 62)
    print(f"有效样本: {n_ok:,} | 格式错误: {n_bad:,} | 音符过少丢弃: {n_short:,}")
    if bad_lane:
        print(f"[!] ★{bad_lane:,} 个音符的 lane 不在 1~{LANES} 范围内，已被跳过。"
              f"4K 音游只有 {LANES} 条轨道。")
    if reasons:
        print("丢弃原因:")
        for k, v in sorted(reasons.items(), key=lambda x: -x[1]):
            print(f"    {k:<28} {v:>8,}")
    if note_counts:
        a = np.asarray(note_counts)
        print(f"每首音符数: 均值 {a.mean():.1f} | 中位 {np.median(a):.0f} "
              f"| 最小 {a.min()} | 最大 {a.max()}")
    if len(feat_shapes) > 1:
        print(f"[!] ★音频特征形状不统一，共 {len(feat_shapes)} 种: "
              f"{sorted(feat_shapes)[:5]}{'…' if len(feat_shapes) > 5 else ''}")
        print("    投影层需要固定输入维度，请先统一到同一形状；")
        print("    否则 train_multimodal.py 会补零对齐，可能引入噪声。")
    elif feat_shapes:
        s = next(iter(feat_shapes))
        print(f"音频特征形状: {s[0]} 帧 × {s[1]} 维（统一 ✓）")
        print(f"[i] train_multimodal.py 需配置 --audio-dim {s[1]} "
              f"--max-frames {s[0]}")
    print(f"[i] 输出: {dst}  ({dst.stat().st_size / 1024 / 1024:.1f} MB)")
    if n_ok == 0:
        print("\n[!] 没有产出任何有效样本，无法进行多模态训练。")
        return 1
    if n_ok < 10000:
        print(f"\n[!] 仅 {n_ok:,} 条配对样本。跨模态对齐通常需要数万条以上，")
        print("    当前规模只够验证链路，学不出可靠的音频→谱面映射。")
    print("=" * 62)
    return 0


def main() -> int:
    args = parse_args()
    if args.make_demo:
        make_demo(Path(args.src), args.demo_count, args.frames, args.audio_dim,
                  args.seed)
    return validate_and_convert(Path(args.src), Path(args.dst), args)


if __name__ == "__main__":
    sys.exit(main())

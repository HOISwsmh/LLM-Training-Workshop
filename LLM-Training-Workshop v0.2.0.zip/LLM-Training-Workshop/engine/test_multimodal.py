# -*- coding: utf-8 -*-
"""test_multimodal.py —— 加载多模态模型，从音频特征生成 4K 谱面

验证第二阶段（音频 → 谱面）是否真正跑通。不只生成，还做结构化解析与
数值校验：把生成的 token 序列还原成 (时间, 轨道) 音符列表，检查轨道号
是否落在 1~4、时间是否单调、能否正确闭合 chart_start/chart_end。

★所有标记从 mm_tokens 引用，源码里不写裸字面量（避免同形替换）。
  解析只看 token id 数值，不比对字符串。

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/test_multimodal.py
    python engine/test_multimodal.py --audio my_song.json
    python engine/test_multimodal.py --max-new-tokens 256
"""
from __future__ import annotations
import os

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from transformers import AutoTokenizer, LlamaForCausalLM

# 同目录：复用训练脚本的模型定义与标记模块，保证两端完全一致
sys.path.insert(0, str(Path(__file__).resolve().parent))
import mm_tokens as T  # noqa: E402
from train_multimodal import AudioChartModel  # noqa: E402

ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent)
OUT_ROOT = ROOT / "output"
DATA_DIR = ROOT / "data"


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="音频 → 4K 音游谱面 生成验证")
    ap.add_argument("--model-dir", default=None,
                    help="多模态模型目录，默认 output/<tier>_multimodal/full/final")
    ap.add_argument("--tier", default="tiny")
    ap.add_argument("--stage", default="full", choices=("align", "full"))
    ap.add_argument("--audio", default=None,
                    help="单个音频特征 json 文件；缺省则从演示数据取一条")
    ap.add_argument("--audio-dim", type=int, default=128)
    ap.add_argument("--max-frames", type=int, default=64)
    ap.add_argument("--max-new-tokens", type=int, default=128)
    ap.add_argument("--do-sample", action="store_true")
    ap.add_argument("--temperature", type=float, default=0.8)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return ap.parse_args()


def resolve_model_dir(args) -> Path | None:
    if args.model_dir:
        return Path(args.model_dir)
    base = OUT_ROOT / f"{args.tier}_multimodal" / args.stage
    for cand in (base / "final", base):
        if (cand / "config.json").exists():
            return cand
    return None


def load_audio_features(args) -> np.ndarray:
    """取一条音频特征：优先 --audio 指定文件，否则从演示数据取第一条。"""
    if args.audio:
        obj = json.loads(Path(args.audio).read_text(encoding="utf-8"))
        feats = np.asarray(obj["audio_features"], dtype=np.float32)
    else:
        demo = DATA_DIR / "audio_chart_train.jsonl"
        if not demo.exists():
            raise FileNotFoundError(
                f"未找到演示数据 {demo}，请先运行 prepare_audio_chart.py --make-demo，"
                f"或用 --audio 指定单个音频特征 json")
        with demo.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line:
                    feats = np.asarray(json.loads(line)["audio_features"],
                                       dtype=np.float32)
                    break
    # 补零/截断到定长，与训练时一致
    t, d = feats.shape
    fixed = np.zeros((args.max_frames, args.audio_dim), dtype=np.float32)
    fixed[:min(t, args.max_frames), :min(d, args.audio_dim)] = \
        feats[:args.max_frames, :args.audio_dim]
    return fixed


def build_prompt_ids(tokenizer, n_frames: int) -> list[int]:
    """构造与训练时一致的前缀：BOS + audio_bos + EMB×N + audio_eos + 提示 + chart_start。"""
    emb_id = tokenizer.convert_tokens_to_ids(T.AUDIO_EMB)
    enc = lambda s: tokenizer(s, add_special_tokens=False)["input_ids"]
    return ([tokenizer.bos_token_id] + enc(T.AUDIO_BOS) + [emb_id] * n_frames
            + enc(T.AUDIO_EOS) + enc(T.PROMPT_TEMPLATE) + enc(T.CHART_START))


@torch.no_grad()
def generate_chart(model, tokenizer, feats, args, device):
    """自回归生成谱面 token 序列。

    音频占位符的 embedding 在每步 forward 里由编码器填入，
    因此不能直接用 HF 的 generate（它不认 inputs_embeds 的动态替换），
    这里手写解码循环。
    """
    n_frames = feats.shape[0]
    prompt_ids = build_prompt_ids(tokenizer, n_frames)
    generated = list(prompt_ids)
    emb_id = tokenizer.convert_tokens_to_ids(T.AUDIO_EMB)
    chart_end_id = tokenizer.convert_tokens_to_ids(T.CHART_END)
    eos_id = tokenizer.eos_token_id

    audio_t = torch.from_numpy(feats).unsqueeze(0).to(device)   # [1, T, D]
    model.eval()
    for _ in range(args.max_new_tokens):
        ids = torch.tensor([generated], dtype=torch.long, device=device)
        ids = ids[:, -getattr(model.llm.config, "max_position_embeddings", 1024):]
        inputs_embeds = model.emb_layer(ids)
        audio_embeds = model.audio_encoder(audio_t.float()).to(inputs_embeds.dtype)
        pos = (ids == emb_id)
        frame_idx = (pos.cumsum(dim=1) - 1).clamp(min=0, max=audio_embeds.shape[1] - 1)
        gather_idx = frame_idx.unsqueeze(-1).expand(-1, -1, audio_embeds.shape[-1])
        audio_full = torch.gather(audio_embeds, 1, gather_idx)
        inputs_embeds = torch.where(pos.unsqueeze(-1), audio_full, inputs_embeds)

        logits = model.llm(inputs_embeds=inputs_embeds).logits[:, -1, :].float()
        if args.do_sample:
            probs = torch.softmax(logits / args.temperature, dim=-1)
            next_id = torch.multinomial(probs, num_samples=1).item()
        else:
            next_id = logits.argmax(-1).item()
        generated.append(next_id)
        if next_id in (chart_end_id, eos_id):
            break
    return generated[len(prompt_ids):]


def parse_chart(tokenizer, ids: list[int]) -> dict:
    """把生成的 token id 序列还原成结构化音符，并做数值校验。"""
    chart_start = tokenizer.convert_tokens_to_ids(T.CHART_START)
    chart_end = tokenizer.convert_tokens_to_ids(T.CHART_END)
    note_id = tokenizer.convert_tokens_to_ids(T.NOTE)
    lane_ids = {tokenizer.convert_tokens_to_ids(t): i + 1
                for i, t in enumerate(T.LANE_TOKENS)}
    eos = tokenizer.eos_token_id

    notes = []
    problems = []
    closed = False
    i = 0
    # 收集 note 之后、下一个 note/lane 之前的数字 token，拼成时间字符串
    while i < len(ids):
        tid = ids[i]
        if tid == chart_end:
            closed = True
            i += 1
            break
        if tid == eos:
            break
        if tid == note_id:
            i += 1
            lane = None
            if i < len(ids) and ids[i] in lane_ids:
                lane = lane_ids[ids[i]]
                i += 1
            else:
                problems.append("note 后缺少合法 lane 标记")
            # 解析时间：连续的非标记 token 解码成文本
            time_tokens = []
            while i < len(ids) and ids[i] not in (note_id, chart_end, eos) \
                    and ids[i] not in lane_ids:
                time_tokens.append(ids[i])
                i += 1
            time_str = tokenizer.decode(time_tokens).strip() if time_tokens else ""
            try:
                tval = float(time_str)
            except ValueError:
                problems.append(f"时间无法解析: {time_str!r}")
                tval = None
            notes.append({"lane": lane, "time": tval, "raw_time": time_str})
        else:
            problems.append(f"非预期 token id={tid}")
            i += 1

    return {"notes": notes, "closed": closed, "problems": problems}


def main() -> int:
    args = parse_args()
    torch.manual_seed(args.seed)
    device = torch.device(args.device)

    model_dir = resolve_model_dir(args)
    if model_dir is None or not (model_dir / "config.json").exists():
        print("[!] 找不到多模态模型。请先运行 train_multimodal.py，"
              "或用 --model-dir 指定路径")
        print(f"    已尝试：{OUT_ROOT / (args.tier + '_multimodal') / args.stage}")
        return 1
    enc_path = model_dir / "audio_encoder.pt"
    if not enc_path.exists():
        print(f"[!] {model_dir} 下没有 audio_encoder.pt，不是完整的多模态模型")
        return 1

    mm_cfg = json.loads((model_dir / "multimodal_config.json").read_text(encoding="utf-8"))
    args.audio_dim = mm_cfg.get("audio_dim", args.audio_dim)
    args.max_frames = mm_cfg.get("max_frames", args.max_frames)

    tokenizer = AutoTokenizer.from_pretrained(str(model_dir))
    # 标记完整性数值校验
    _, broken = T.verify_single_tokens(tokenizer)
    if broken:
        print(f"[!] {len(broken)} 个多模态标记非单 token，无法正确解析谱面")
        return 1

    llm = LlamaForCausalLM.from_pretrained(str(model_dir), torch_dtype=torch.bfloat16)
    model = AudioChartModel(llm, args.audio_dim, mm_cfg.get("enc_dim", 512),
                            mm_cfg.get("enc_layers", 2), args.max_frames)
    model.audio_encoder.load_state_dict(
        torch.load(enc_path, map_location="cpu", weights_only=True))
    model = model.to(device, dtype=torch.bfloat16)
    model.audio_encoder = model.audio_encoder.float()

    feats = load_audio_features(args)
    print("=" * 64)
    print(f"模型      : {model_dir}")
    print(f"阶段      : {args.stage}  | 训练步数 {mm_cfg.get('global_step', '?')}")
    print(f"音频输入  : {feats.shape[0]} 帧 × {feats.shape[1]} 维")
    print(f"参数量    : {sum(p.numel() for p in model.parameters()):,}")
    print(f"设备      : {device}")

    ids = generate_chart(model, tokenizer, feats, args, device)
    raw_text = tokenizer.decode(ids, skip_special_tokens=False)
    parsed = parse_chart(tokenizer, ids)

    print("-" * 64)
    print(f"生成 token 数: {len(ids)}")
    print(f"原始输出: {raw_text}")
    print("-" * 64)
    notes = parsed["notes"]
    print(f"解析出音符数: {len(notes)}")
    for nt in notes[:12]:
        print(f"    lane={nt['lane']} time={nt['time']}")
    if len(notes) > 12:
        print(f"    … 共 {len(notes)} 个")

    # ---- 数值校验
    print("-" * 64)
    lanes = [nt["lane"] for nt in notes if nt["lane"] is not None]
    times = [nt["time"] for nt in notes if nt["time"] is not None]
    checks = []
    checks.append(("正确闭合 chart_end", parsed["closed"]))
    checks.append((f"轨道号都在 1~{T.LANES}",
                   all(1 <= x <= T.LANES for x in lanes) if lanes else False))
    checks.append(("时间可解析", len(times) == len(notes) if notes else False))
    checks.append(("时间单调不减",
                   all(times[i] <= times[i + 1] for i in range(len(times) - 1))
                   if len(times) > 1 else True))
    for name, ok in checks:
        print(f"  {'✓' if ok else '★'} {name}")
    if parsed["problems"]:
        print(f"  ★结构问题（前 5 条）: {parsed['problems'][:5]}")

    print("-" * 64)
    n_ok = sum(1 for _, ok in checks if ok)
    if not notes:
        print("[!] 未解析出任何音符。若用合成演示数据训练，模型没学到映射属正常；")
        print("    用真实音频-谱面配对数据充分训练后应能生成有效谱面。")
    elif n_ok == len(checks) and not parsed["problems"]:
        print("✓ 链路完全跑通：音频 → 谱面生成 → 结构化解析 均正常")
    else:
        print(f"[i] 链路可运行（{n_ok}/{len(checks)} 项校验通过），"
              f"生成质量取决于训练数据与步数")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""train_multimodal.py —— 第二阶段：音频 → 4K 音游谱面

在第一阶段中文 LLM 的基础上，加入音频编码器与投影层，实现
「听音频 → 生成 4K 谱面」。

架构：
    音频特征 [B, T, audio_dim]
        └→ 音频编码器（2 层 Transformer）
        └→ 投影层（Linear → GELU → Linear）→ [B, T, hidden_size]
        └→ 替换输入序列中 AUDIO_EMB 占位符位置的 word embedding
    拼接后的 embedding [B, seq_len, hidden_size]
        └→ 冻结/微调的 LLaMA 主干
        └→ 自回归生成 chart_start + note/lane + 时间 + chart_end

★所有多模态标记一律从 mm_tokens 模块引用，源码里不写裸字面量。
  实测发现这类特殊标记的裸字面量在写入/回显环节可能被同形替换，
  导致注册的是 A、查询的是 B、encode 时被逐字符拆开。集中在 mm_tokens
  用拼接构造可彻底规避。校验也只认数值（encode 后的 token 个数）。

三个设计要点：
    1. 谱面用文本表示（note + lane + 时间），不加回归头，直接复用第一阶段
       的自回归 loss，谱面生成就变成"生成结构化文本"。
    2. 音频帧不占词表：AUDIO_EMB 只是占位符，其 embedding 在 forward 里
       被投影后的音频向量替换，vocab_size 不变。
    3. 分阶段训练（--stage）：align 只训编码器+投影层（主干冻结），
       full 解冻主干微调。跳过 align 直接 full 通常不收敛。

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/train_multimodal.py --stage align --tier tiny
    python engine/train_multimodal.py --stage full --tier 2b
"""
from __future__ import annotations
import os

import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from transformers import AutoTokenizer, LlamaForCausalLM

# 同目录的 mm_tokens：所有多模态标记的唯一定义处
sys.path.insert(0, str(Path(__file__).resolve().parent))
import mm_tokens as T  # noqa: E402

ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent)
DATA_DIR = ROOT / "data"
TOK_DIR = ROOT / "tokenizer"
OUT_ROOT = ROOT / "output"
MM_DATA = DATA_DIR / "audio_chart_train.jsonl"


# ---------------------------------------------------------------- 数据集


class AudioChartDataset(Dataset):
    """把音频特征 + 谱面文本序列化成模型输入。

    每条样本产出：
      audio       [max_frames, audio_dim]  音频帧（补零/截断到定长）
      input_ids   [S]  BOS + audio_bos + AUDIO_EMB×N + audio_eos
                       + 提示语 + chart_start + 谱面 + chart_end + EOS
      labels      [S]  音频段与提示语段置 -100（不计 loss），只监督谱面
    """

    def __init__(self, path: Path, tokenizer, audio_dim: int, max_frames: int,
                 max_seq_len: int) -> None:
        self.tokenizer = tokenizer
        self.audio_dim = audio_dim
        self.max_frames = max_frames
        self.max_seq_len = max_seq_len
        self.items: list[dict] = []

        # 用 mm_tokens 的常量查询 id，并做数值校验（不看字符串）
        self.emb_id = tokenizer.convert_tokens_to_ids(T.AUDIO_EMB)
        if self.emb_id in (None, tokenizer.unk_token_id):
            raise RuntimeError(
                f"{T.AUDIO_EMB!r} 未在分词器中注册（查得 id={self.emb_id}=unk）。"
                f"请重新运行 train_tokenizer.py")
        _, broken = T.verify_single_tokens(tokenizer)
        if broken:
            raise RuntimeError(
                f"以下多模态标记未被注册为单 token：{[n for n, _ in broken]}。"
                f"请重新运行 train_tokenizer.py")

        # 预编码固定片段，避免每条样本重复编码
        self._enc_audio_bos = self._ids(T.AUDIO_BOS)
        self._enc_audio_eos = self._ids(T.AUDIO_EOS)
        self._enc_prompt = self._ids(T.PROMPT_TEMPLATE)
        self._enc_chart_start = self._ids(T.CHART_START)
        self._enc_chart_end = self._ids(T.CHART_END)

        with path.open("r", encoding="utf-8-sig", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    self.items.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

    def _ids(self, text: str) -> list[int]:
        return self.tokenizer(text, add_special_tokens=False)["input_ids"]

    def __len__(self) -> int:
        return len(self.items)

    def _pad_frames(self, feats: np.ndarray) -> np.ndarray:
        """把不定长音频特征补零/截断到 (max_frames, audio_dim)。"""
        if feats.ndim != 2 or feats.shape[1] != self.audio_dim:
            fixed = np.zeros((self.max_frames, self.audio_dim), dtype=np.float32)
            t = min(feats.shape[0], self.max_frames) if feats.ndim == 2 else 0
            d = min(feats.shape[1], self.audio_dim) if feats.ndim == 2 else 0
            if t and d:
                fixed[:t, :d] = feats[:t, :d]
            return fixed
        if feats.shape[0] > self.max_frames:
            return feats[:self.max_frames]
        if feats.shape[0] < self.max_frames:
            pad = np.zeros((self.max_frames - feats.shape[0], self.audio_dim),
                           dtype=np.float32)
            return np.concatenate([feats, pad], axis=0)
        return feats

    def __getitem__(self, idx: int) -> dict:
        item = self.items[idx]
        feats = self._pad_frames(np.asarray(item["audio_features"], dtype=np.float32))
        n_frames = feats.shape[0]

        chart_text = item.get("chart_text", "")
        chart_ids = self._ids(chart_text)

        bos, eos = self.tokenizer.bos_token_id, self.tokenizer.eos_token_id
        prefix = ([bos] + self._enc_audio_bos + [self.emb_id] * n_frames
                  + self._enc_audio_eos + self._enc_prompt + self._enc_chart_start)
        suffix = chart_ids + self._enc_chart_end + [eos]

        input_ids = (prefix + suffix)[:self.max_seq_len]
        n_prefix = min(len(prefix), len(input_ids))
        labels = [-100] * n_prefix + input_ids[n_prefix:]

        return {
            "audio": torch.from_numpy(feats),
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


def collate(batch: list[dict], pad_id: int):
    max_len = max(b["input_ids"].shape[0] for b in batch)
    input_ids, labels, audio, mask = [], [], [], []
    for b in batch:
        n = b["input_ids"].shape[0]
        pad = max_len - n
        input_ids.append(torch.cat([b["input_ids"],
                                    torch.full((pad,), pad_id, dtype=torch.long)]))
        labels.append(torch.cat([b["labels"],
                                 torch.full((pad,), -100, dtype=torch.long)]))
        audio.append(b["audio"])
        mask.append(torch.cat([torch.ones(n, dtype=torch.long),
                               torch.zeros(pad, dtype=torch.long)]))
    return (torch.stack(input_ids), torch.stack(labels),
            torch.stack(audio), torch.stack(mask))


# ---------------------------------------------------------------- 模型


class AudioEncoder(nn.Module):
    """轻量 Transformer 编码器 + 投影到 LLM 的 hidden_size。

    参数量刻意保持小（相对 2-3B 主干可忽略）：音频→谱面的映射主要靠
    主干的序列建模能力，编码器只需把频谱压成语义向量。
    """

    def __init__(self, audio_dim: int, hidden_size: int, enc_dim: int = 512,
                 enc_layers: int = 2, enc_heads: int = 8,
                 max_frames: int = 512, dropout: float = 0.1) -> None:
        super().__init__()
        self.in_proj = nn.Linear(audio_dim, enc_dim)
        self.pos = nn.Parameter(torch.zeros(1, max_frames, enc_dim))
        nn.init.trunc_normal_(self.pos, std=0.02)
        layer = nn.TransformerEncoderLayer(
            d_model=enc_dim, nhead=enc_heads, dim_feedforward=enc_dim * 4,
            dropout=dropout, activation="gelu", batch_first=True, norm_first=True)
        # norm_first=True 时无法用 nested tensor，显式关闭以消除告警
        self.encoder = nn.TransformerEncoder(
            layer, num_layers=enc_layers, enable_nested_tensor=False)
        self.norm = nn.LayerNorm(enc_dim)
        # 两层 MLP 投影，比单层 Linear 更容易对齐两个不同的表示空间
        self.projector = nn.Sequential(
            nn.Linear(enc_dim, hidden_size), nn.GELU(),
            nn.Linear(hidden_size, hidden_size))

    def forward(self, audio: torch.Tensor) -> torch.Tensor:
        """[B, T, audio_dim] → [B, T, hidden_size]"""
        t = audio.shape[1]
        if t > self.pos.shape[1]:
            raise ValueError(
                f"音频帧数 {t} 超过编码器位置表 {self.pos.shape[1]}，"
                f"请用 --max-frames 对齐或增大 enc max_frames")
        x = self.in_proj(audio) + self.pos[:, :t, :]
        x = self.encoder(x)
        return self.projector(self.norm(x))


class AudioChartModel(nn.Module):
    """LLaMA 主干 + 音频编码器，在 embedding 层融合两个模态。"""

    def __init__(self, llm: LlamaForCausalLM, audio_dim: int,
                 enc_dim: int, enc_layers: int, max_frames: int) -> None:
        super().__init__()
        self.llm = llm
        hidden = llm.config.hidden_size
        self.audio_encoder = AudioEncoder(audio_dim, hidden, enc_dim,
                                          enc_layers, max_frames=max_frames)
        self.emb_layer = llm.get_input_embeddings()

    def forward(self, input_ids, labels, audio, attention_mask, emb_token_id: int):
        inputs_embeds = self.emb_layer(input_ids)
        # 编码器保持 float32 数值更稳，投影输出再转回主干 dtype
        audio_embeds = self.audio_encoder(audio.float()).to(inputs_embeds.dtype)

        # 把音频向量填入占位符位置。必须用函数式 scatter，不能 in-place 赋值：
        # align 阶段主干冻结时 embedding 输出是 leaf 变量，in-place 修改会触发
        # "a view of a leaf Variable ... in-place operation" 并破坏 autograd。
        pos = (input_ids == emb_token_id)                       # [B, S]
        # 每个占位符是第几帧音频：对 pos 做 cumsum；非占位符位置的值稍后被丢弃
        frame_idx = pos.cumsum(dim=1) - 1                       # [B, S]
        frame_idx = frame_idx.clamp(min=0, max=audio_embeds.shape[1] - 1)
        gather_idx = frame_idx.unsqueeze(-1).expand(
            -1, -1, audio_embeds.shape[-1])                     # [B, S, H]
        audio_full = torch.gather(audio_embeds, 1, gather_idx)  # [B, S, H]
        inputs_embeds = torch.where(pos.unsqueeze(-1), audio_full, inputs_embeds)

        return self.llm(inputs_embeds=inputs_embeds, labels=labels,
                        attention_mask=attention_mask)

    def trainable_parameters(self, stage: str):
        audio_params = list(self.audio_encoder.parameters())
        if stage == "align":
            for p in self.llm.parameters():
                p.requires_grad_(False)
            for p in audio_params:
                p.requires_grad_(True)
            return audio_params, "音频编码器 + 投影层（主干冻结）"
        for p in self.parameters():
            p.requires_grad_(True)
        return list(self.parameters()), "全部参数（主干解冻）"


# ---------------------------------------------------------------- 训练


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="音频 → 4K 音游谱面 多模态训练")
    ap.add_argument("--tier", default="tiny")
    ap.add_argument("--base-model", default=None,
                    help="第一阶段模型路径，默认 output/<tier>_model/final")
    ap.add_argument("--data", default=str(MM_DATA))
    ap.add_argument("--tokenizer", default=None, help="默认取 base-model 的分词器")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--stage", choices=("align", "full"), default="align")
    ap.add_argument("--audio-dim", type=int, default=128)
    ap.add_argument("--max-frames", type=int, default=64)
    ap.add_argument("--max-seq-len", type=int, default=1024)
    ap.add_argument("--enc-dim", type=int, default=512)
    ap.add_argument("--enc-layers", type=int, default=2)
    ap.add_argument("--batch-size", type=int, default=2)
    ap.add_argument("--grad-accum", type=int, default=8)
    ap.add_argument("--lr", type=float, default=0,
                    help="0 表示自动：align 用 3e-4，full 用 3e-5")
    ap.add_argument("--warmup-ratio", type=float, default=0.05)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--max-steps", type=int, default=0)
    ap.add_argument("--grad-clip", type=float, default=1.0)
    ap.add_argument("--weight-decay", type=float, default=0.01)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--log-every", type=int, default=10)
    ap.add_argument("--save-every", type=int, default=200)
    ap.add_argument("--limit", type=int, default=0, help="只用前 N 条样本")
    ap.add_argument("--no-checkpointing", action="store_true")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return ap.parse_args()


def resolve_base(args) -> Path | None:
    if args.base_model:
        return Path(args.base_model)
    tier_dir = OUT_ROOT / f"{args.tier}_model"
    for cand in (tier_dir / "final", tier_dir / "best"):
        if (cand / "config.json").exists():
            return cand
    cks = sorted(tier_dir.glob("checkpoint-*"),
                 key=lambda p: int(p.name.split("-")[1])) if tier_dir.exists() else []
    for cand in reversed(cks):
        if (cand / "config.json").exists():
            return cand
    return None


def main() -> int:
    args = parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = torch.device(args.device)

    if args.lr <= 0:
        args.lr = 3e-4 if args.stage == "align" else 3e-5
    if args.max_frames > 512:
        print(f"[!] --max-frames {args.max_frames} 超过编码器位置表上限 512")
        return 1

    base = resolve_base(args)
    if base is None:
        print("[!] 找不到第一阶段模型。请先运行 train_model.py，"
              "或用 --base-model 指定路径")
        return 1
    if not Path(args.data).exists():
        print(f"[!] 找不到多模态数据：{args.data}")
        print("    请先运行 prepare_audio_chart.py")
        return 1

    tok_dir = args.tokenizer or str(base)
    tokenizer = AutoTokenizer.from_pretrained(tok_dir)
    if tokenizer.pad_token_id is None:
        print("[!] 分词器缺少 pad_token")
        return 1

    # 标记完整性校验：缺失则补注册并 resize（正常情况下应为 0）
    n_added = T.ensure_registered(tokenizer)
    if n_added:
        print(f"[!] 补注册了 {n_added} 个缺失的多模态标记，词表将扩大。"
              f"模型 embedding 会相应 resize。")

    print("=" * 64)
    print(f"基础模型  : {base}")
    print(f"多模态数据: {args.data}")
    print(f"训练阶段  : {args.stage}  (lr={args.lr:.1e})")

    llm = LlamaForCausalLM.from_pretrained(str(base), torch_dtype=torch.bfloat16)
    if n_added:
        llm.resize_token_embeddings(len(tokenizer))

    try:
        dataset = AudioChartDataset(
            Path(args.data), tokenizer, args.audio_dim, args.max_frames,
            args.max_seq_len)
    except RuntimeError as e:
        print(f"[!] {e}")
        return 1
    if args.limit:
        dataset.items = dataset.items[:args.limit]
    if len(dataset) == 0:
        print("[!] 数据集为空")
        return 1
    print(f"样本数    : {len(dataset):,}")
    print(f"音频      : {args.max_frames} 帧 × {args.audio_dim} 维")
    print(f"序列长度  : {args.max_seq_len}")

    model = AudioChartModel(llm, args.audio_dim, args.enc_dim,
                            args.enc_layers, args.max_frames)
    model = model.to(device, dtype=torch.bfloat16)
    # 编码器精度保持 float32 更稳（投影层数值范围差异大）
    model.audio_encoder = model.audio_encoder.float()

    if not args.no_checkpointing:
        model.llm.gradient_checkpointing_enable(
            gradient_checkpointing_kwargs={"use_reentrant": False})
        model.llm.config.use_cache = False

    params, desc = model.trainable_parameters(args.stage)
    n_train = sum(p.numel() for p in params)
    n_total = sum(p.numel() for p in model.parameters())
    print(f"可训练    : {n_train:,} / {n_total:,} "
          f"({n_train / max(n_total, 1):.1%}) —— {desc}")
    print("-" * 64)

    loader = DataLoader(
        dataset, batch_size=args.batch_size, shuffle=True, num_workers=0,
        collate_fn=lambda b: collate(b, tokenizer.pad_token_id), drop_last=True)

    optimizer = torch.optim.AdamW(params, lr=args.lr, betas=(0.9, 0.95),
                                  weight_decay=args.weight_decay,
                                  fused=(device.type == "cuda"))
    steps_per_epoch = max(1, len(loader) // args.grad_accum)
    total_steps = steps_per_epoch * args.epochs
    if args.max_steps:
        total_steps = min(total_steps, args.max_steps)
    if total_steps == 0:
        print("[!] 样本数不足以构成一个训练步，请增加数据或减小 batch/grad-accum")
        return 1
    warmup = max(1, int(total_steps * args.warmup_ratio))

    def lr_lambda(s: int) -> float:
        if s < warmup:
            return (s + 1) / warmup
        prog = min(1.0, (s - warmup) / max(1, total_steps - warmup))
        return 0.1 + 0.9 * 0.5 * (1 + math.cos(math.pi * prog))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

    out_dir = Path(args.out_dir) if args.out_dir else \
        OUT_ROOT / f"{args.tier}_multimodal" / args.stage
    out_dir.mkdir(parents=True, exist_ok=True)

    global_step = 0
    running = 0.0
    t0 = time.time()
    model.train()
    try:
        for epoch in range(args.epochs):
            for batch_idx, (input_ids, labels, audio, mask) in enumerate(loader):
                if args.max_steps and global_step >= args.max_steps:
                    break
                input_ids = input_ids.to(device, non_blocking=True)
                labels = labels.to(device, non_blocking=True)
                audio = audio.to(device, non_blocking=True)
                mask = mask.to(device, non_blocking=True)

                with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
                    out = model(input_ids, labels, audio, mask, dataset.emb_id)
                    loss = out.loss / args.grad_accum
                loss.backward()
                running += loss.item()

                if (batch_idx + 1) % args.grad_accum == 0:
                    if args.grad_clip > 0:
                        torch.nn.utils.clip_grad_norm_(params, args.grad_clip)
                    optimizer.step()
                    scheduler.step()
                    optimizer.zero_grad(set_to_none=True)
                    global_step += 1

                    if global_step % args.log_every == 0:
                        avg = running / args.log_every
                        cur_lr = scheduler.get_last_lr()[0]
                        print(f"epoch {epoch + 1} | step {global_step:>6,}/{total_steps:,} "
                              f"| loss {avg:.4f} | ppl {math.exp(min(avg, 20)):7.2f} "
                              f"| lr {cur_lr:.2e} | {time.time() - t0:.0f}s")
                        running, t0 = 0.0, time.time()

                    if global_step % args.save_every == 0:
                        save(model, tokenizer, optimizer, global_step, out_dir, args)
            if args.max_steps and global_step >= args.max_steps:
                break
    except KeyboardInterrupt:
        print(f"\n[!] 中断，保存进度（step {global_step}）…")
        save(model, tokenizer, optimizer, global_step, out_dir, args)
        return 130

    save(model, tokenizer, optimizer, global_step, out_dir, args, final=True)
    print("-" * 64)
    print(f"[i] {args.stage} 阶段完成，共 {global_step:,} 步")
    print(f"[i] 已保存到 {out_dir}")
    if args.stage == "align":
        print(f"[i] 下一步：--stage full --base-model {out_dir / 'final'} 解冻主干微调")
    else:
        print("[i] 下一步：运行 test_multimodal.py 生成谱面验证效果")
    print("=" * 64)
    return 0


def save(model, tokenizer, optimizer, step, out_dir: Path, args,
         final: bool = False) -> None:
    """分开保存：主干走 save_pretrained，音频编码器单独存 state_dict。"""
    name = "final" if final else f"step-{step}"
    target = out_dir / name
    target.mkdir(parents=True, exist_ok=True)

    raw_llm = model.llm._orig_mod if hasattr(model.llm, "_orig_mod") else model.llm
    raw_llm.save_pretrained(str(target))
    tokenizer.save_pretrained(str(target))
    torch.save(model.audio_encoder.state_dict(), target / "audio_encoder.pt")
    torch.save(optimizer.state_dict(), target / "optimizer.pt")
    # 标记的十六进制一并存下，便于跨脚本核对（避免字面量被替换时无从追溯）
    (target / "multimodal_config.json").write_text(json.dumps({
        "stage": args.stage,
        "global_step": step,
        "tier": args.tier,
        "audio_dim": args.audio_dim,
        "max_frames": args.max_frames,
        "max_seq_len": args.max_seq_len,
        "enc_dim": args.enc_dim,
        "enc_layers": args.enc_layers,
        "lr": args.lr,
        "audio_token_ids": {
            "audio_bos": tokenizer.convert_tokens_to_ids(T.AUDIO_BOS),
            "audio_eos": tokenizer.convert_tokens_to_ids(T.AUDIO_EOS),
            "audio_emb": tokenizer.convert_tokens_to_ids(T.AUDIO_EMB),
            "chart_start": tokenizer.convert_tokens_to_ids(T.CHART_START),
            "chart_end": tokenizer.convert_tokens_to_ids(T.CHART_END),
            "note": tokenizer.convert_tokens_to_ids(T.NOTE),
        },
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"    [保存] {target}")


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""test_model.py —— 验证训练链路是否真正跑通

不只是"能生成中文"，而是做四层递进检查：
    1. 模型/分词器能否加载，参数量与档位是否对得上
    2. 在真实语料上算 loss 与困惑度（唯一能证明"学到了东西"的指标）
    3. 贪婪解码 vs 采样解码的生成结果
    4. 多模态控制符是否被完整保留（为音游谱面阶段做准备）

只看生成文本容易误判：模型输出通顺的句子不代表它学到了知识，
loss 和困惑度才反映真实水平，所以第 2 步是重点。

★多模态标记校验一律走 mm_tokens.verify_single_tokens，只认数值
  （encode 后是否恰好 1 个 token），不比对字符串——后者会被同形替换误导。

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/test_model.py
    python engine/test_model.py --tier 2b --prompt "人工智能"
"""
from __future__ import annotations

import os
import argparse
import json
import math
import sys
from pathlib import Path

import torch
from transformers import AutoTokenizer, GPT2LMHeadModel, LlamaForCausalLM

# 同目录的 mm_tokens：多模态标记的唯一定义处
sys.path.insert(0, str(Path(__file__).resolve().parent))
import mm_tokens as T  # noqa: E402

# 日志语言：默认中文，原样输出；仅当 LLM_LOG_LANG=en 时译为英文。
# ★不改动任何既有中文语句，查不到译文会退回中文，绝不丢日志。
try:
    from log_i18n import install as _install_log_lang
    _install_log_lang()
except Exception:
    pass

ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent)
OUT_ROOT = ROOT / "output"
DATA_DIR = ROOT / "data"

DEFAULT_PROMPTS = ["今天", "人工智能", "中国的首都是", "水的化学式是"]


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="加载模型并验证整条训练链路")
    ap.add_argument("--model-dir", default=None, help="默认 output/<tier>_model/final")
    ap.add_argument("--tier", default="tiny", help="model-dir 缺省时用于推断路径")
    ap.add_argument("--prompt", action="append", default=None, help="可多次指定")
    ap.add_argument("--max-new-tokens", type=int, default=64)
    ap.add_argument("--temperature", type=float, default=0.8)
    ap.add_argument("--top-p", type=float, default=0.9)
    ap.add_argument("--eval-lines", type=int, default=200,
                    help="从清洗语料取多少行算困惑度，0 跳过")
    ap.add_argument("--corpus", default=str(DATA_DIR / "cleaned_corpus.jsonl"),
                    help="困惑度评测语料 jsonl；真实语料放独立目录时必须显式指定")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    return ap.parse_args()


def resolve_model_dir(args) -> Path | None:
    """按优先级找模型：显式路径 → final → best → 最新编号检查点 → 档位目录。"""
    if args.model_dir:
        return Path(args.model_dir)
    tier_dir = OUT_ROOT / f"{args.tier}_model"
    for cand in (tier_dir / "final", tier_dir / "best"):
        if cand.exists() and (cand / "config.json").exists():
            return cand
    cks = sorted(tier_dir.glob("checkpoint-*"),
                 key=lambda p: int(p.name.split("-")[1])) if tier_dir.exists() else []
    for cand in reversed(cks):
        if (cand / "config.json").exists():
            return cand
    if tier_dir.exists() and (tier_dir / "config.json").exists():
        return tier_dir
    return None


def load_model(model_dir: Path, device: str):
    config = json.loads((model_dir / "config.json").read_text(encoding="utf-8"))
    arch = config.get("architectures", [""])[0]
    cls = GPT2LMHeadModel if arch.startswith("GPT2") else LlamaForCausalLM
    model = cls.from_pretrained(str(model_dir), torch_dtype=torch.bfloat16)
    model = model.to(device).eval()
    return model, arch


@torch.no_grad()
def measure_perplexity(model, tokenizer, device: str, lines: int,
                       corpus: Path | None = None) -> dict:
    """在真实语料上算困惑度——判断模型是否学到东西的核心指标。"""
    src = Path(corpus) if corpus else DATA_DIR / "cleaned_corpus.jsonl"
    if lines <= 0 or not src.exists():
        return {}

    block = getattr(model.config, "max_position_embeddings", 1024)
    texts, total_loss, total_tok = [], 0.0, 0
    with src.open("r", encoding="utf-8-sig", errors="replace") as fh:
        for line in fh:
            if len(texts) >= lines:
                break
            try:
                t = json.loads(line).get("text")
            except json.JSONDecodeError:
                continue
            if isinstance(t, str) and t.strip():
                texts.append(t.strip())

    for i in range(0, len(texts), 8):
        batch = texts[i:i + 8]
        enc = tokenizer(batch, return_tensors="pt", truncation=True,
                        max_length=block, padding=True)
        enc = {k: v.to(device) for k, v in enc.items()}
        ids = enc["input_ids"]
        mask = enc.get("attention_mask")
        # ★padding 位必须从 loss 里剔除：否则模型被要求预测 PAD，
        #   这些位置贡献巨额虚假 loss（实测 pad 占比 32% 时 ppl 虚高 10 倍），
        #   且与 train_model.py 的打包式 val_loss 口径不一致、无法对比。
        labels = ids.clone()
        if mask is not None:
            labels[mask == 0] = -100
        with torch.autocast(device_type=device, dtype=torch.bfloat16):
            loss = model(ids, attention_mask=mask, labels=labels).loss
        # HF 的 loss 已按非 -100 位置数取均值，故权重用真实 token 数
        n_tok = int(mask.sum().item()) if mask is not None else ids.numel()
        total_loss += loss.item() * n_tok
        total_tok += n_tok

    if total_tok == 0:
        return {}
    avg = total_loss / total_tok
    return {"samples": len(texts), "tokens": total_tok,
            "loss": avg, "ppl": math.exp(min(avg, 20))}


@torch.no_grad()
def generate(model, tokenizer, prompt: str, args, device: str, **kw) -> str:
    enc = tokenizer(prompt, return_tensors="pt").to(device)
    out = model.generate(
        **enc,
        max_new_tokens=args.max_new_tokens,
        pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,
        eos_token_id=tokenizer.eos_token_id,
        **kw,
    )
    new = out[0][enc["input_ids"].shape[1]:]
    return tokenizer.decode(new, skip_special_tokens=False)


def main() -> int:
    args = parse_args()
    model_dir = resolve_model_dir(args)
    if model_dir is None:
        print("[!] 找不到模型。请先运行 train_model.py，或用 --model-dir 指定路径")
        print(f"    已尝试：{OUT_ROOT / (args.tier + '_model')} 下的 "
              f"final / best / checkpoint-*")
        return 1
    if not (model_dir / "config.json").exists():
        print(f"[!] {model_dir} 下没有 config.json，不是有效的模型目录")
        return 1

    print("=" * 64)
    print(f"模型目录: {model_dir}")
    tokenizer = AutoTokenizer.from_pretrained(str(model_dir))
    model, arch = load_model(model_dir, args.device)
    n = sum(p.numel() for p in model.parameters())
    print(f"架构    : {arch}")
    print(f"参数量  : {n:,} = {n / 1e9:.3f}B")
    print(f"设备    : {args.device}"
          + (f" | 显存占用 {torch.cuda.memory_allocated() / 1024 ** 3:.2f} GB"
             if args.device == "cuda" else ""))
    print(f"上下文  : {getattr(model.config, 'max_position_embeddings', '?')}")
    print(f"词表    : {tokenizer.vocab_size:,}")

    # ---- 1. 困惑度（最有信息量的一项）
    ppl = measure_perplexity(model, tokenizer, args.device, args.eval_lines, args.corpus)
    print("-" * 64)
    print(f"评测语料: {args.corpus}")
    if ppl:
        print(f"语料困惑度: loss {ppl['loss']:.4f} | ppl {ppl['ppl']:.2f} "
              f"| 基于 {ppl['samples']} 条 / {ppl['tokens']:,} token")
        if ppl["ppl"] > 1e4:
            print("  → 困惑度极高，模型基本没学到东西（可能只训了很少步数）")
        elif ppl["ppl"] > 100:
            print("  → 模型在学习但仍处早期，2B 级预训练完成后通常应低于 20")
        else:
            print("  → 困惑度处于合理区间")
    else:
        print("语料困惑度: 跳过（未找到 data/cleaned_corpus.jsonl 或 --eval-lines 0）")

    # ---- 2. 生成
    prompts = args.prompt or DEFAULT_PROMPTS
    print("-" * 64)
    for prompt in prompts:
        greedy = generate(model, tokenizer, prompt, args, args.device, do_sample=False)
        print(f"提示: {prompt}")
        print(f"  贪婪: {greedy}")
        sampled = generate(model, tokenizer, prompt, args, args.device,
                           do_sample=True, temperature=args.temperature,
                           top_p=args.top_p)
        print(f"  采样(T={args.temperature}): {sampled}")
        print()

    # ---- 3. 多模态控制符完整性（数值校验，不看字符串）
    good, broken = T.verify_single_tokens(tokenizer)
    print("-" * 64)
    if good or broken:
        total = len(good) + len(broken)
        print(f"多模态控制符: {len(good)}/{total} 个保持单 token")
        if broken:
            print(f"  ★被拆碎（索引, encode长度）: "
                  f"{[(T.MULTIMODAL_SPECIAL.index(m), l) for m, l in broken]}")
            print("  进入音频→谱面阶段前，这些标记必须是单 token，请重训分词器。")
        else:
            print("  ✓ 全部完好，可进入第二阶段多模态训练")
    else:
        print("多模态控制符: 未注册（当前为纯文本模型，属正常）")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    sys.exit(main())

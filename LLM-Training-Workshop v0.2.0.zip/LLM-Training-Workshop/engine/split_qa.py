# -*- coding: utf-8 -*-
"""split_qa.py —— 从通用网页语料中切分问答型页面

★为什么需要：
    独立的中文问答开源语料规模很小（已核实：Zhihu-KOL ≈0.84B token、
    MNBVC 论坛 ≈1.0B，合计不足 2B），撑不起 60B 方案里 15% 的问答配额（9B）。
    但 SkyPile 网页语料里本身含大量问答型页面——本地实测 427,358 条中，
    含问答特征词的占 22.9%，强特征文档的字符占比 20.0%。
    从同源切分，不引入新的数据来源，也不新增授权风险面。

★这是启发式切分，不是精确分类：
    SkyPile 唯一字段 text、无 URL/来源标记，只能靠正文特征判断。
    切出的"问答型"包含教程、经验帖、问题解决类文章，不全是知乎式深度问答。
    对预训练而言这个粒度够用（目的是文体多样性，不是构造 QA 对）。

判据（三档，可调）：
    strong  命中 >= --strong-hits 个特征词，或 命中 >=1 且问号 >= --strong-qmarks
    weak    命中 >= 1 个特征词
    none    未命中

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    # 先只统计不写出，看占比
    python engine/split_qa.py \
        --src data\\mix\\clean_web.jsonl --stats-only
    # 实际切分
    python engine/split_qa.py \
        --src ...\\clean_web.jsonl \
        --dst-qa ...\\clean_web_qa.jsonl \
        --dst-web ...\\clean_web_pure.jsonl
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from collections import Counter
from pathlib import Path

# 问答型正文特征词。覆盖提问、回答、经验分享、教程步骤等语体。
QA_WORDS = [
    "怎么办", "如何", "为什么", "是什么", "有哪些", "怎么样", "能不能",
    "可以吗", "求问", "请问", "答主", "题主", "楼主", "回答", "答案",
    "解决方法", "教程", "步骤如下", "怎么做", "怎样", "是否", "哪些",
    "什么原因", "如何处理", "解决方案", "经验", "注意事项",
]
QA_RE = re.compile("|".join(re.escape(w) for w in QA_WORDS))
QMARK_RE = re.compile(r"[?？]")


def parse_args(argv=None):
    ap = argparse.ArgumentParser(
        description="从网页语料切分问答型页面（启发式）",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--src", required=True, help="输入 jsonl（清洗后的网页语料）")
    ap.add_argument("--dst-qa", default=None, help="问答型输出 jsonl")
    ap.add_argument("--dst-web", default=None, help="非问答型输出 jsonl")
    ap.add_argument("--mode", choices=("strong", "weak"), default="strong",
                    help="strong 更严格、纯度高；weak 召回多但混入教程类")
    ap.add_argument("--strong-hits", type=int, default=3,
                    help="strong 模式下命中多少个特征词即判定")
    ap.add_argument("--strong-qmarks", type=int, default=2,
                    help="strong 模式下命中>=1词时，问号达到此数也判定")
    ap.add_argument("--limit", type=int, default=0, help="只处理前 N 条，0 为全量")
    ap.add_argument("--stats-only", action="store_true", help="只统计占比，不写出")
    ap.add_argument("--progress-every", type=int, default=500000)
    return ap.parse_args(argv)


def classify(text: str, args) -> str:
    hits = len(QA_RE.findall(text))
    if hits == 0:
        return "none"
    if args.mode == "weak":
        return "weak"
    qm = len(QMARK_RE.findall(text))
    if hits >= args.strong_hits or (hits >= 1 and qm >= args.strong_qmarks):
        return "strong"
    return "weak"


def main(argv=None) -> int:
    args = parse_args(argv)
    src = Path(args.src)
    if not src.exists():
        print(f"[!] 找不到输入：{src}")
        return 1

    if not args.stats_only and not (args.dst_qa and args.dst_web):
        print("[!] 非 --stats-only 模式必须同时指定 --dst-qa 与 --dst-web")
        return 1

    stat = Counter()
    chars = Counter()
    hit_dist = Counter()
    t0 = time.time()

    fqa = fweb = None
    if not args.stats_only:
        for p in (args.dst_qa, args.dst_web):
            Path(p).parent.mkdir(parents=True, exist_ok=True)
        fqa = open(args.dst_qa, "w", encoding="utf-8", newline="\n")
        fweb = open(args.dst_web, "w", encoding="utf-8", newline="\n")

    try:
        with src.open("r", encoding="utf-8-sig", errors="replace") as fin:
            for line in fin:
                line = line.strip()
                if not line:
                    continue
                try:
                    o = json.loads(line)
                except (json.JSONDecodeError, ValueError):
                    stat["bad_json"] += 1
                    continue
                t = o.get("text")
                if not isinstance(t, str) or not t.strip():
                    stat["no_text"] += 1
                    continue

                stat["read"] += 1
                chars["all"] += len(t)
                kind = classify(t, args)
                stat[kind] += 1
                chars[kind] += len(t)
                hit_dist[min(len(QA_RE.findall(t)), 10)] += 1

                is_qa = (kind == "strong") if args.mode == "strong" else (kind != "none")
                if is_qa:
                    stat["out_qa"] += 1
                    chars["out_qa"] += len(t)
                else:
                    stat["out_web"] += 1
                    chars["out_web"] += len(t)

                if fqa is not None:
                    (fqa if is_qa else fweb).write(
                        json.dumps(o, ensure_ascii=False) + "\n")

                if args.progress_every and stat["read"] % args.progress_every == 0:
                    print(f"    ... 已处理 {stat['read']:,} 条")
                if args.limit and stat["read"] >= args.limit:
                    break
    finally:
        if fqa:
            fqa.close()
        if fweb:
            fweb.close()

    n = max(stat["read"], 1)
    ca = max(chars["all"], 1)
    el = time.time() - t0

    print("\n" + "=" * 68)
    print(f"输入: {src}")
    print(f"模式: {args.mode}  (strong_hits={args.strong_hits}, "
          f"strong_qmarks={args.strong_qmarks})")
    print("-" * 68)
    print(f"读取条数      : {stat['read']:,}")
    print(f"  强问答特征  : {stat['strong']:,}  ({stat['strong']/n:.2%})")
    print(f"  弱问答特征  : {stat['weak']:,}  ({stat['weak']/n:.2%})")
    print(f"  无特征      : {stat['none']:,}  ({stat['none']/n:.2%})")
    print(f"坏 JSON       : {stat['bad_json']:,}")
    print(f"无 text 字段  : {stat['no_text']:,}")
    print("-" * 68)
    print("★ 字符占比（token 量近似正比于字符数，比条数更有参考价值）")
    print(f"  强特征字符占比 : {chars['strong']/ca:.2%}")
    print(f"  弱特征字符占比 : {chars['weak']/ca:.2%}")
    print("-" * 68)
    print(f"切分结果（mode={args.mode}）")
    print(f"  → 问答型 : {stat['out_qa']:,} 条  字符占比 {chars['out_qa']/ca:.2%}")
    print(f"  → 纯网页 : {stat['out_web']:,} 条  字符占比 {chars['out_web']/ca:.2%}")
    print("-" * 68)
    print("特征词命中数分布（10 表示 >=10）：")
    for k in sorted(hit_dist):
        bar = "#" * int(hit_dist[k] / n * 50)
        print(f"  {k:>2} 个: {hit_dist[k]:>9,}  {bar}")
    print("-" * 68)
    if args.stats_only:
        print("[i] --stats-only：未写出任何文件")
    else:
        for label, p in (("问答型", args.dst_qa), ("纯网页", args.dst_web)):
            pp = Path(p)
            print(f"[i] {label}: {pp}  ({pp.stat().st_size/1024**2:.1f} MB)")
    print(f"[i] 耗时 {el:.1f}s，{stat['read']/max(el,1e-6):,.0f} 条/秒")
    if stat["no_text"] > 0:
        print(f"\n[!] ★有 {stat['no_text']:,} 条无 text 字段——"
              f"请先用 adapt_corpus.py 做字段适配")
    print("=" * 68)
    return 0


if __name__ == "__main__":
    sys.exit(main())

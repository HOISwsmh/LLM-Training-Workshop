# -*- coding: utf-8 -*-
"""fetch_corpus.py —— 语料下载器（走 hf-mirror，支持最小片试跑与批量）

设计要点：
  - 默认走 hf-mirror.com（实测 huggingface.co 直连不可达）
  - 支持 --smallest N：自动挑每类最小的 N 个分片，用于低成本验证链路
  - 断点续传由 huggingface_hub 负责（.cache/huggingface 元数据）
  - 下载后校验字节数与远端元信息一致
  - 禁用 xet 加速（实测部分仓库 xet 端点 404）

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    # 各类取最小 1 片，验证链路（约 1GB）
    python engine/fetch_corpus.py --smallest 1
    # 列出各类分片清单与体积，不下载
    python engine/fetch_corpus.py --list
    # 指定类别批量下载
    python engine/fetch_corpus.py --only code --count 82
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")

# ★跟随项目目录，不写死绝对路径：项目改名/移动后无需改代码
CORPUS_ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent) / "corpus"

# name: (repo_id, 文件后缀过滤, 子目录前缀过滤, 本地目录名)
SOURCES = {
    "web":   ("Skywork/SkyPile-150B", ".jsonl", "data/", "skypile"),
    "wiki":  ("wikimedia/wikipedia", ".parquet", "20231101.zh/", "wiki"),
    "source": ("wikimedia/wikisource", ".parquet", "20231201.zh/", "wikisource"),
    "guji":  ("buddhist-nlp/daizhige", ".parquet", "data/train-", "daizhige"),
    "code":  ("codeparrot/codeparrot-clean", ".gz", "file-", "code"),
    "qa":    ("wangrui6/Zhihu-KOL", ".parquet", "data/", "zhihu"),
    "baike": ("lars1234/baidu-baike-dataset", ".json", "563w", "baike"),
}


def parse_args(argv=None):
    ap = argparse.ArgumentParser(
        description="语料下载（hf-mirror，支持最小片试跑）",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--only", default=None, choices=sorted(SOURCES),
                    help="只处理某一类，缺省处理全部")
    ap.add_argument("--smallest", type=int, default=0,
                    help="每类取最小的 N 个分片（试跑用），0 表示不启用")
    ap.add_argument("--count", type=int, default=0,
                    help="每类取前 N 个分片（按文件名排序），0 表示全部")
    ap.add_argument("--list", action="store_true", help="只列清单与体积，不下载")
    ap.add_argument("--root", default=str(CORPUS_ROOT), help="下载根目录")
    ap.add_argument("--retries", type=int, default=4,
                    help="单个文件失败重试次数（挂机下载建议 >=4）")
    return ap.parse_args(argv)


def list_shards(api, name: str):
    repo, suf, prefix, local = SOURCES[name]
    info = api.repo_info(repo, repo_type="dataset", files_metadata=True)
    out = []
    for s in info.siblings:
        fn = s.rfilename
        if suf and not fn.endswith(suf):
            continue
        if prefix and not fn.startswith(prefix):
            continue
        out.append((fn, s.size or 0))
    return repo, local, sorted(out, key=lambda x: x[0])


def main(argv=None) -> int:
    args = parse_args(argv)
    from huggingface_hub import HfApi, hf_hub_download
    api = HfApi()
    root = Path(args.root)
    names = [args.only] if args.only else list(SOURCES)

    plan = {}
    print("=" * 76)
    print(f"镜像: {os.environ['HF_ENDPOINT']}   根目录: {root}")
    print("=" * 76)
    for name in names:
        try:
            repo, local, shards = list_shards(api, name)
        except Exception as e:                       # noqa: BLE001
            print(f"[!] {name}: 清单获取失败 {type(e).__name__}: {str(e)[:120]}")
            continue
        if not shards:
            print(f"[!] {name}: 未匹配到任何分片（检查后缀/前缀过滤）")
            continue
        total = sum(sz for _, sz in shards)
        print(f"\n[{name}] {repo}")
        print(f"  分片 {len(shards)} 个，合计 {total / 1024 ** 3:.2f} GB")
        sel = shards
        if args.smallest > 0:
            sel = sorted(shards, key=lambda x: x[1])[:args.smallest]
        elif args.count > 0:
            sel = shards[:args.count]
        sel_total = sum(sz for _, sz in sel)
        print(f"  本次选取 {len(sel)} 个，{sel_total / 1024 ** 3:.3f} GB")
        for fn, sz in sel[:5]:
            print(f"    {fn}  {sz / 1024 ** 2:.1f} MB")
        if len(sel) > 5:
            print(f"    … 其余 {len(sel) - 5} 个")
        plan[name] = (repo, local, sel)

    if args.list:
        print("\n[i] --list：仅列清单，未下载")
        return 0
    if not plan:
        print("\n[!] 没有任何可下载项")
        return 1

    grand = sum(sum(sz for _, sz in sel) for _, _, sel in plan.values())
    print("\n" + "=" * 76)
    print(f"开始下载，合计 {grand / 1024 ** 3:.2f} GB")
    print("=" * 76)

    ok = fail = skip = 0
    failed_items = []
    t0 = time.time()
    done_bytes = 0      # 仅本次实际传输的字节（跳过的不计入速率）
    skip_bytes = 0
    for name, (repo, local, sel) in plan.items():
        dest = root / local
        dest.mkdir(parents=True, exist_ok=True)
        for fn, expect in sel:
            # ★跳过已完成：按远端字节数校验，支持中断后续跑不重下
            local_f = dest / fn
            if local_f.exists() and expect and local_f.stat().st_size == expect:
                skip += 1
                skip_bytes += expect
                continue
            got = None
            for attempt in range(1, args.retries + 1):
                t1 = time.time()
                try:
                    p = hf_hub_download(repo_id=repo, filename=fn,
                                        repo_type="dataset", local_dir=str(dest))
                    got = Path(p).stat().st_size
                    el = time.time() - t1
                    rate = got / 1024 ** 2 / max(el, 1e-6)
                    if expect and got != expect:
                        print(f"  [!] {name}/{Path(fn).name} 字节不符："
                              f"{got:,} vs 期望 {expect:,}（第{attempt}次）", flush=True)
                        got = None
                    else:
                        print(f"  [OK] {name}/{Path(fn).name}  "
                              f"{got / 1024 ** 2:.1f} MB  {el:.0f}s  {rate:.2f} MB/s", flush=True)
                        ok += 1
                        done_bytes += got
                        break
                except Exception as e:               # noqa: BLE001
                    print(f"  [重试{attempt}/{args.retries}] {name}/{Path(fn).name} "
                          f"{type(e).__name__}: {str(e)[:120]}", flush=True)
                    got = None
                if attempt < args.retries:
                    time.sleep(min(30, 5 * attempt))
            if got is None:
                fail += 1
                failed_items.append(f"{name}/{fn}")
            # 进度小结
            tot_all = grand
            if tot_all and (ok + fail) % 10 == 0 and (ok + fail) > 0:
                el = time.time() - t0
                pct = (done_bytes + skip_bytes) / tot_all * 100
                rate = done_bytes / 1024 ** 2 / max(el, 1e-6)
                eta = (tot_all - done_bytes - skip_bytes) / 1024 ** 2 / max(rate, 1e-6) / 3600
                print(f"  --- 进度 {pct:.1f}%  已完成{ok} 失败{fail} 跳过{skip}  "
                      f"均速{rate:.2f} MB/s  预计剩余{eta:.1f}h ---", flush=True)

    el = time.time() - t0
    print("\n" + "=" * 76)
    print(f"成功 {ok} 个，失败 {fail} 个，跳过（已完成）{skip} 个")
    print(f"本次传输 {done_bytes / 1024 ** 3:.2f} GB，总耗时 {el / 3600:.2f} 小时")
    if done_bytes and el > 1:
        print(f"平均速率 {done_bytes / 1024 ** 2 / el:.2f} MB/s")
    if failed_items:
        print("\n[!] 以下文件最终失败，可重跑本命令自动续传：")
        for x in failed_items[:20]:
            print(f"    {x}")
        if len(failed_items) > 20:
            print(f"    … 其余 {len(failed_items) - 20} 个")
    print("=" * 76)
    return 0 if fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())

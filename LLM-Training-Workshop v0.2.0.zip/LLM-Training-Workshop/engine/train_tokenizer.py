# -*- coding: utf-8 -*-
"""train_tokenizer.py —— 训练 2-3B 中文 LLM 的 BPE 分词器

设计要点（针对 2B 预训练 + 后续音频→4K 音游谱面多模态）：
    1. 词表 32000 起（2B 以下）/ 49152（3B），512 的玩具词表会让序列长度爆炸
    2. ByteLevel 预分词，中文按字节兜底，永不 OOV
    3. 多模态控制符（音频/谱面/note/lane）作为 additional_special_tokens
       注册，保证不被 BPE 拆碎，后续接音频编码器时复用同一套词表
    4. 大语料按 --sample-lines 抽样训练：BPE 的 merge 统计不需要全量数据
    5. ★训练后校验实际词表是否达标。实测发现语料多样性不足时，
       BpeTrainer(vocab_size=32000) 可能只产出几千个 token，此时必须报警
    6. 用 PreTrainedTokenizerFast 包装保存，使 AutoTokenizer 可直接加载

★所有特殊标记从 mm_tokens 引用，源码里不写裸字面量。实测这类 "<|...|>"
  标记的裸字面量在写入/回显环节可能被同形替换，导致注册的与查询的不一致。

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/train_tokenizer.py
    python engine/train_tokenizer.py --vocab-size 49152
"""
from __future__ import annotations

import os
import argparse
import json
import sys
import tempfile
import time
from pathlib import Path

from tokenizers import Tokenizer
from tokenizers.decoders import ByteLevel as ByteLevelDecoder
from tokenizers.models import BPE
from tokenizers.pre_tokenizers import ByteLevel
from tokenizers.trainers import BpeTrainer
from transformers import PreTrainedTokenizerFast

# 同目录的 mm_tokens：所有特殊标记的唯一定义处
sys.path.insert(0, str(Path(__file__).resolve().parent))
import mm_tokens as T  # noqa: E402

# 日志语言：默认中文，原样输出；仅当 LLM_LOG_LANG=en 时译为英文。
# ★不改动任何既有中文语句，查不到译文会退回中文，绝不丢日志。
try:
    from log_i18n import install as _install_log_lang
    _install_log_lang()
except Exception:
    pass

ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent)
SRC = ROOT / "data" / "cleaned_corpus.jsonl"
OUT_DIR = ROOT / "tokenizer"

# 从 mm_tokens 取，不在本文件写裸字面量
BASE_SPECIAL = T.BASE_SPECIAL
MULTIMODAL_SPECIAL = T.MULTIMODAL_SPECIAL
TEST_TEXTS = ["今天天气真好", "人工智能语言模型", "hello world 中英混排"]


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="训练 2-3B 中文 LLM 的 BPE 分词器",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--src", default=str(SRC))
    ap.add_argument("--out-dir", default=str(OUT_DIR))
    ap.add_argument("--vocab-size", type=int, default=32000,
                    help="目标词表；3B 档建议 49152")
    ap.add_argument("--sample-lines", type=int, default=3_000_000,
                    help="参与 BPE 训练的最大行数，0 表示全量")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--no-multimodal", action="store_true",
                    help="不注册音频/谱面控制符（纯文本实验时用）")
    return ap.parse_args()


def build_train_file(src: Path, sample_lines: int, seed: int) -> tuple[Path, int, int]:
    """流式把 jsonl 的 text 落成纯文本文件；行数超限时做确定性等距抽样。

    等距抽样而非顺序截断：避免只训练语料开头的某一种文体。
    每个窗口内再用固定种子做随机偏移，避免抽样恰好落在某种周期性排版上。
    """
    total = sum(1 for _ in src.open("r", encoding="utf-8-sig", errors="replace"))
    if total == 0:
        raise RuntimeError(f"{src} 为空，请先运行 clean_data.py")

    take_all = sample_lines <= 0 or total <= sample_lines
    if take_all:
        stride, want = 1, total
    else:
        stride = max(1, total // sample_lines)
        want = sample_lines

    import random
    rng = random.Random(seed)
    # ★临时语料放在项目内，不写系统盘（C:\...\Temp）。
    #   语料大时这个文件可达数百 MB~数 GB，写系统盘会悄悄吃掉 C 盘空间。
    #   优先用 LLM_WORKSHOP_TMP（调度器指向项目内 tmp/），其次输出目录同级。
    tmp_root = os.environ.get("LLM_WORKSHOP_TMP")
    if tmp_root:
        base = Path(tmp_root)
    else:
        base = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path.cwd()) / "tmp"
    try:
        base.mkdir(parents=True, exist_ok=True)
        probe = base / ".write_test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
    except OSError:
        base = Path(tempfile.gettempdir())   # 兜底：项目目录不可写时才用系统临时目录
    tmp = base / "bpe_train_corpus.txt"
    print(f"[i] 临时语料目录 {base}")
    picked = 0
    with src.open("r", encoding="utf-8-sig", errors="replace") as fin, \
            tmp.open("w", encoding="utf-8", newline="\n") as fout:
        # 预先算出要取哪些行号，循环里只做集合判断
        wanted: set[int] = set()
        if not take_all:
            for w in range(want):
                base = w * stride
                if base >= total:
                    break
                offset = rng.randrange(stride) if stride > 1 else 0
                wanted.add(min(base + offset, total - 1))

        for i, line in enumerate(fin):
            if not take_all and i not in wanted:
                continue
            line = line.strip()
            if not line:
                continue
            try:
                text = json.loads(line).get("text")
            except (json.JSONDecodeError, AttributeError):
                continue
            if not isinstance(text, str) or not text.strip():
                continue
            fout.write(text.replace("\n", " ").strip() + "\n")
            picked += 1
    return tmp, total, picked


def main() -> int:
    args = parse_args()
    src, out_dir = Path(args.src), Path(args.out_dir)
    if not src.exists():
        print(f"[!] 找不到清洗后的语料：{src}")
        print("    请先运行 clean_data.py 生成 data/cleaned_corpus.jsonl")
        return 1

    out_dir.mkdir(parents=True, exist_ok=True)
    special = BASE_SPECIAL + ([] if args.no_multimodal else MULTIMODAL_SPECIAL)

    tmp, total, picked = build_train_file(src, args.sample_lines, args.seed)
    size_mb = tmp.stat().st_size / 1024 / 1024
    print(f"[i] 语料总行数 {total:,}，本次参与训练 {picked:,} 行（{size_mb:.1f} MB）")
    print(f"[i] 目标词表 {args.vocab_size:,}，特殊符 {len(special)} 个")

    tokenizer = Tokenizer(BPE(unk_token=T.BASE_SPECIAL[1]))   # [UNK]
    tokenizer.pre_tokenizer = ByteLevel()
    tokenizer.decoder = ByteLevelDecoder()

    trainer = BpeTrainer(
        vocab_size=args.vocab_size,
        special_tokens=special,
        show_progress=True,
        initial_alphabet=ByteLevel.alphabet(),
    )

    t0 = time.time()
    tokenizer.train([str(tmp)], trainer)
    print(f"[i] BPE 训练耗时 {time.time() - t0:.1f}s")
    tmp.unlink(missing_ok=True)

    # ---- ★关键校验：语料多样性不足时实际词表会远低于目标
    actual = tokenizer.get_vocab_size()
    if actual < args.vocab_size * 0.9:
        print(f"\n[!] 实际词表 {actual:,} 远低于目标 {args.vocab_size:,}"
              f"（仅 {actual / args.vocab_size:.0%}）")
        print("    原因：BPE 的 merge 数量受语料多样性上限约束，")
        print("    语料太少或重复度高时无法凑够目标词表。")
        print("    处理：补充语料后重训，或把 --vocab-size 降到接近实际值。")
        print("    注意：词表偏小会让中文被拆成更多字节，序列变长、训练变慢。\n")

    fast = PreTrainedTokenizerFast(
        tokenizer_object=tokenizer,
        unk_token=T.BASE_SPECIAL[1], pad_token=T.BASE_SPECIAL[0],
        bos_token=T.BASE_SPECIAL[2], eos_token=T.BASE_SPECIAL[3],
        mask_token=T.BASE_SPECIAL[4],
        additional_special_tokens=([] if args.no_multimodal else MULTIMODAL_SPECIAL),
    )
    fast.save_pretrained(str(out_dir))

    back = PreTrainedTokenizerFast.from_pretrained(str(out_dir))
    print(f"[i] 已保存：{out_dir}")
    print(f"[i] 回读词表大小：{back.vocab_size:,}")
    print("[i] 特殊符 id：" + ", ".join(
        f"{s}={back.convert_tokens_to_ids(s)}" for s in special))

    # ---- 多模态标记完整性：只认数值（encode 后必须是 1 个 token）
    if not args.no_multimodal:
        good, broken = T.verify_single_tokens(back)
        print(f"[i] 多模态标记校验：完好 {len(good)} / 拆碎 {len(broken)}")
        if broken:
            print(f"    ★被拆碎（名称, encode长度）：{broken}")
            print("    这些标记是第二阶段多模态训练必需的，请检查 mm_tokens 与重训。")

    print("\n" + "=" * 60)
    for text in TEST_TEXTS:
        enc = back(text, add_special_tokens=False)
        ids = enc["input_ids"]
        decoded = back.decode(ids)
        # ByteLevel 预分词会在句首产生一个代表空格的 Ġ，decode 后带前导空格，
        # 这是正常行为而非还原错误，因此比较时去掉首尾空白
        ok = decoded.strip() == text.strip()
        print(f"文本: {text}")
        print(f"  tokens ({len(ids)}): {back.convert_ids_to_tokens(ids)[:12]}")
        print(f"  ids: {ids[:12]}")
        print(f"  还原: {decoded!r}  {'✓' if ok else '★还原不一致'}")
    print("=" * 60)

    # 中文压缩率：直接影响后续训练成本。
    # ByteLevel 会给每条文本加一个前导 Ġ（代表空格），统计时必须剔除，
    # 否则短样本的压缩率会被明显高估。
    samples = [
        "中文语言模型预训练需要先完成数据清洗与分词器训练两个步骤。",
        "今天天气真好，我们一起去公园散步聊天。",
        "深度神经网络通过大量参数拟合数据中的复杂模式。",
    ]
    ratios = []
    for s in samples:
        toks = back.convert_ids_to_tokens(
            back(s, add_special_tokens=False)["input_ids"])
        if toks and toks[0] == "Ġ":
            toks = toks[1:]
        ratios.append(len(toks) / len(s))
    ratio = sum(ratios) / len(ratios)
    print(f"[i] 中文压缩率：{ratio:.2f} token/字（已剔除 ByteLevel 前导空格）")
    if ratio > 1.5:
        print(f"    ★偏高。当前词表 {back.vocab_size:,} 对中文太小，")
        print("    2B 级预训练建议 --vocab-size 32000 以上，否则序列变长、成本上升。")
    elif ratio > 0.9:
        print(f"    处于可用区间。词表 {back.vocab_size:,}，正式训练可考虑更大词表。")
    else:
        print(f"    良好。词表 {back.vocab_size:,} 对中文压缩充分。")
    return 0


if __name__ == "__main__":
    sys.exit(main())

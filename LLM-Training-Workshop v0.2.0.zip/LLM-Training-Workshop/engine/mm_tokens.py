# -*- coding: utf-8 -*-
"""mm_tokens.py —— 多模态标记的唯一定义处

为什么标记字符串要用拼接构造、而不是直接写字面量：
    实测发现，某些以 "<|" 开头、"|>" 结尾的特殊标记字面量，在源码写入或
    回显环节可能被同形替换成别的标记名（本项目的 audio 标记就遇到过），
    导致分词器注册的是 A、脚本查询的是 B，encode 时被逐字符拆开。
    用组件拼接生成字符串，源码里就不存在完整的裸字面量，可彻底规避。

校验一律基于数值（encode 后的 token 个数），不依赖字符串显示，
因为显示层同样可能被替换，肉眼比对不可靠。

被以下脚本共同引用，确保各处标记完全一致：
    train_tokenizer.py / prepare_audio_chart.py / train_multimodal.py
"""
from __future__ import annotations

# 用组件拼接，避免源码中出现完整的裸标记字面量
_L = "<" + "|"      # 左定界
_R = "|" + ">"      # 右定界


def mk(name: str) -> str:
    """构造一个特殊标记，如 mk("note") -> <|note|>"""
    return _L + name + _R


# ---- 音频侧
AUDIO_BOS = mk("audio" + "_start")      # 音频特征序列开始
AUDIO_EOS = mk("audio" + "_end")        # 音频特征序列结束
AUDIO_EMB = mk("AUDIO" + "_EMB")        # ★音频帧占位符，每帧一个

# ---- 谱面侧（4K 音游）
CHART_START = mk("chart" + "_start")
CHART_END = mk("chart" + "_end")
NOTE = mk("note")                       # 单个音符
BAR = mk("bar")                         # 小节分隔

LANES = 4                               # 4K = 四条轨道
LANE_TOKENS = [mk(f"lane{i}") for i in range(1, LANES + 1)]

# 注册进分词器的完整列表（顺序即 token id 顺序，改动会影响已有分词器）
MULTIMODAL_SPECIAL = [
    AUDIO_BOS, AUDIO_EOS, AUDIO_EMB,
    CHART_START, CHART_END, NOTE, BAR,
    *LANE_TOKENS,
]

BASE_SPECIAL = ["[PAD]", "[UNK]", "[BOS]", "[EOS]", "[MASK]"]
ALL_SPECIAL = BASE_SPECIAL + MULTIMODAL_SPECIAL

# 谱面生成的提示语（普通文本，无需注册为特殊符）
PROMPT_TEMPLATE = "为这首歌生成 4K 谱面："


def lane_token(lane: int) -> str:
    """轨道号 1~4 → 对应标记。"""
    if not 1 <= lane <= LANES:
        raise ValueError(f"4K 音游的轨道号必须在 1~{LANES} 之间，收到 {lane}")
    return LANE_TOKENS[lane - 1]


def verify_single_tokens(tokenizer, marks=None) -> tuple[list[str], list[int]]:
    """校验每个标记都被注册为单个 token。

    返回 (完好的标记, 被拆碎的标记及其 encode 长度)。
    只看数值，不做字符串比对，避免显示层替换造成误判。
    """
    marks = marks if marks is not None else MULTIMODAL_SPECIAL
    good, broken = [], []
    for m in marks:
        ids = tokenizer(m, add_special_tokens=False)["input_ids"]
        if len(ids) == 1:
            good.append(m)
        else:
            broken.append((m, len(ids)))
    return good, broken


def ensure_registered(tokenizer, marks=None) -> int:
    """确保标记已注册为单 token；缺失则补注册。返回新增数量。

    补注册会改变词表大小，调用方需要相应 resize 模型 embedding。
    """
    marks = marks if marks is not None else MULTIMODAL_SPECIAL
    _, broken = verify_single_tokens(tokenizer, marks)
    if not broken:
        return 0
    missing = [m for m, _ in broken]
    return tokenizer.add_tokens(missing, special_tokens=True)

# -*- coding: utf-8 -*-
"""prepare_data.py —— 语料分词 + 打包，为 2-3B 预训练准备数据

为什么需要这一步（而不是在训练时用 datasets.map 现算）：
    1. 2B 预训练要吞几百亿 token，边训边分词会让 GPU 大量空转等 CPU
    2. datasets.map 在亿级样本上产生的 arrow 缓存可达数百 GB
    3. 打包（packing）把多条样本首尾相接填满固定长度，不浪费算力在 padding 上；
       nanoGPT / LLaMA 的标准做法
    4. 输出 np.memmap 二进制，训练时按需随机寻址，内存占用恒定

产物：
    data/tokens_train.bin   训练集（uint16 或 int32，取决于词表大小）
    data/tokens_val.bin     验证集
    data/data_meta.json     dtype、块数、token 总数等元信息

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/prepare_data.py --workers 16
    python engine/prepare_data.py --limit 200000   # 先试跑
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
from transformers import AutoTokenizer

# 日志语言：默认中文，原样输出；仅当 LLM_LOG_LANG=en 时译为英文。
# ★不改动任何既有中文语句，查不到译文会退回中文，绝不丢日志。
try:
    from log_i18n import install as _install_log_lang
    _install_log_lang()
except Exception:
    pass

ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent)
SRC = ROOT / "data" / "cleaned_corpus.jsonl"
TOK_DIR = ROOT / "tokenizer"
DATA_DIR = ROOT / "data"

_TOK = None
_CFG = None


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="语料分词并打包为 memmap 二进制",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--src", default=str(SRC))
    ap.add_argument("--tokenizer", default=str(TOK_DIR))
    ap.add_argument("--out-dir", default=str(DATA_DIR))
    ap.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 4) - 2))
    ap.add_argument("--chunk-lines", type=int, default=5000, help="每批分词的行数")
    ap.add_argument("--val-ratio", type=float, default=0.005, help="验证集比例")
    ap.add_argument("--val-max-lines", type=int, default=20000, help="验证集最大行数")
    ap.add_argument("--limit", type=int, default=0, help="只处理前 N 行，0 为全量")
    ap.add_argument("--min-tokens", type=int, default=1, help="少于此 token 数的样本丢弃")
    ap.add_argument("--progress-every", type=int, default=200000)
    return ap.parse_args()


def _init(tokenizer_dir: str, min_tokens: int) -> None:
    global _TOK, _CFG
    _TOK = AutoTokenizer.from_pretrained(tokenizer_dir)
    _CFG = min_tokens


def _encode_batch(lines: list[str]) -> tuple[list[list[int]], dict]:
    """分词一批 jsonl 行，返回 (每条样本的 id 列表, 统计)。"""
    stat = {"read": 0, "bad_json": 0, "empty": 0, "dropped_short": 0}
    out = []
    texts = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        stat["read"] += 1
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            stat["bad_json"] += 1
            continue
        text = obj.get("text") if isinstance(obj, dict) else (obj if isinstance(obj, str) else None)
        if not isinstance(text, str) or not text.strip():
            stat["empty"] += 1
            continue
        texts.append(text)

    if texts:
        enc = _TOK(texts, add_special_tokens=False, return_attention_mask=False)["input_ids"]
        for ids in enc:
            if len(ids) < _CFG:
                stat["dropped_short"] += 1
                continue
            out.append(ids)
    return out, stat


def iter_line_batches(path: Path, size: int, limit: int):
    batch, produced = [], 0
    with path.open("r", encoding="utf-8-sig", errors="replace", newline=None) as fh:
        for line in fh:
            batch.append(line)
            if len(batch) >= size:
                yield batch
                produced += len(batch)
                batch = []
                if limit and produced >= limit:
                    return
    if batch:
        yield batch


def main() -> int:
    args = parse_args()
    src, tok_dir, out_dir = Path(args.src), Path(args.tokenizer), Path(args.out_dir)
    for label, p in (("清洗后语料", src), ("分词器目录", tok_dir)):
        if not p.exists():
            print(f"[!] 找不到{label}：{p}")
            print("    请依次运行 clean_data.py 与 train_tokenizer.py")
            return 1
    out_dir.mkdir(parents=True, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(str(tok_dir))
    vocab = tokenizer.vocab_size
    # uint16 上限 65535；词表更大时必须用 int32，否则 token id 会溢出
    dtype = np.uint16 if vocab < 65000 else np.int32
    bos = tokenizer.bos_token_id
    eos = tokenizer.eos_token_id
    if bos is None or eos is None:
        print("[!] 分词器缺少 bos/eos，无法标记文档边界")
        return 1

    print(f"[i] 词表 {vocab:,} → 存储 dtype {np.dtype(dtype).name}")
    print(f"[i] workers={args.workers} chunk_lines={args.chunk_lines}")
    print(f"[i] 语料: {src}  ({src.stat().st_size / 1024 / 1024:.1f} MB)")

    train_path = out_dir / "tokens_train.bin"
    val_path = out_dir / "tokens_val.bin"
    fh_train = train_path.open("wb")
    fh_val = val_path.open("wb")

    total_tokens = 0
    val_tokens = 0
    val_lines = 0
    samples = 0
    total_stat = {"read": 0, "bad_json": 0, "empty": 0, "dropped_short": 0}
    t0 = time.time()

    # 验证集等距抽样：每 val_stride 条取 1 条。分散在整个语料中，
    # 避免"文件尾部当验证集"导致文体分布与训练集不一致。
    val_stride = int(round(1 / args.val_ratio)) if args.val_ratio > 0 else 0

    def _consume_pack(ids_list, stat):
        nonlocal total_tokens, val_tokens, val_lines, samples
        for k, v in stat.items():
            total_stat[k] += v
        for ids in ids_list:
            # 打包格式：BOS + tokens + EOS，训练时按固定块长切分
            packed = [bos] + ids + [eos]
            buf = np.asarray(packed, dtype=dtype)
            take_val = (val_stride > 0 and val_lines < args.val_max_lines
                        and samples % val_stride == 0)
            if take_val:
                fh_val.write(buf.tobytes())
                val_tokens += len(buf)
                val_lines += 1
            else:
                fh_train.write(buf.tobytes())
                total_tokens += len(buf)
            samples += 1
        if args.progress_every and samples and samples % args.progress_every < args.chunk_lines:
            print(f"    ... 已处理 {samples:,} 条 / {total_tokens:,} token", flush=True)

    batches = iter_line_batches(src, args.chunk_lines, args.limit)
    # ★有界滑动窗口：imap 默认无界预取，主进程写盘慢时分词结果会在内存无限堆积
    #   （曾导致 61.9GB 占用卡死）。改为只保持 max_inflight 个批次在途，
    #   消费一个才补一个，内存占用被锁定在 O(workers × chunk) 而非 O(全文件)。
    from collections import deque
    max_inflight = args.workers * 2
    with Pool(args.workers, initializer=_init, initargs=(str(tok_dir), args.min_tokens)) as pool:
        pending = deque()
        for b in batches:
            pending.append(pool.apply_async(_encode_batch, (b,)))
            if len(pending) >= max_inflight:
                ids_list, stat = pending.popleft().get()
                _consume_pack(ids_list, stat)
        while pending:
            ids_list, stat = pending.popleft().get()
            _consume_pack(ids_list, stat)

    fh_train.close()
    fh_val.close()
    elapsed = time.time() - t0

    itemsize = np.dtype(dtype).itemsize
    train_blocks = train_path.stat().st_size // itemsize
    val_blocks = val_path.stat().st_size // itemsize

    meta = {
        "dtype": np.dtype(dtype).name,
        "itemsize": itemsize,
        "vocab_size": vocab,
        "bos_token_id": bos,
        "eos_token_id": eos,
        "train_tokens": int(total_tokens),
        "val_tokens": int(val_tokens),
        "train_samples": int(samples - val_lines),
        "val_samples": int(val_lines),
        "source": str(src),
        "tokenizer": str(tok_dir),
        "stats": total_stat,
    }
    (out_dir / "data_meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    print("\n" + "=" * 62)
    print(f"读取行数        : {total_stat['read']:,}")
    print(f"打包样本数      : {samples:,}")
    print(f"训练集 token    : {total_tokens:,}")
    print(f"验证集 token    : {val_tokens:,}  ({val_lines:,} 条)")
    print(f"JSON 解析失败   : {total_stat['bad_json']:,}")
    print(f"text 为空       : {total_stat['empty']:,}")
    print(f"token 数不足丢弃: {total_stat['dropped_short']:,}")
    print("-" * 62)
    print(f"[i] {train_path}  ({train_path.stat().st_size / 1024 / 1024:.1f} MB)")
    print(f"[i] {val_path}  ({val_path.stat().st_size / 1024 / 1024:.1f} MB)")
    print(f"[i] 耗时 {elapsed:.1f}s，{total_stat['read'] / max(elapsed, 1e-6):,.0f} 行/秒")
    if total_tokens:
        # 经验估算：2B 模型在 24GB 级显卡上约 2000~4000 token/s（含梯度检查点）
        for tps in (2000, 4000):
            print(f"[i] 跑满 1 epoch 约需 {total_tokens / tps / 3600:,.1f} 小时"
                  f"（按 {tps} token/s 估算，实际以 --tier 和显卡为准）")
    if total_tokens < 1_000_000_000:
        print(f"\n[!] token 总量仅 {total_tokens / 1e6:.1f}M。2B 模型通常需要 "
              f"100B+ token 才能学到基础常识，")
        print("    当前语料只够验证链路跑通，正式预训练前需要大幅补充数据。")
    print("=" * 62)
    return 0


if __name__ == "__main__":
    sys.exit(main())

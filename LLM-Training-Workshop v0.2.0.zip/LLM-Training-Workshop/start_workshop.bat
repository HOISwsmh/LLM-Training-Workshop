@echo off
chcp 65001 >nul
title LLM Training Workshop
cd /d "%~dp0"

rem ============================================================
rem  Launcher: prefer a bundled runtime, otherwise system Python.
rem  Training deps (torch etc.) are provided by the user;
rem  the app auto-detects an installed environment.
rem ============================================================

set PYTHONIOENCODING=utf-8
set PYTHONUNBUFFERED=1

if exist "%~dp0runtime\python.exe" (
  "%~dp0runtime\python.exe" "%~dp0launch.py"
  goto :done
)

where python >nul 2>nul
if %errorlevel%==0 (
  python "%~dp0launch.py"
  goto :done
)

where py >nul 2>nul
if %errorlevel%==0 (
  py "%~dp0launch.py"
  goto :done
)

echo.
echo   [Note] Python was not found.
echo   Install Python 3.10+ (check "Add Python to PATH"), then run this again.
echo.
pause

:done
if errorlevel 1 (
  echo.
  echo   Startup failed. Please report the message above.
  pause
)

# LLM Training Workshop

**Train your own small Chinese language model — without writing code.**

Point it at local text files, click a few buttons, and it handles field mapping, cleaning,
tokenizer training, packing, mixing and pre-training — with live loss curves, throughput,
VRAM usage and checkpoint management.

Single GPU. Runs in your browser. Fully offline. No telemetry, no uploads.

> **Status: experimental (v0.1).** Built for individual developers who want to *understand*
> and *own* a model, not to compete with commercial LLMs. Expect rough edges.

[中文说明 / Chinese manual](MANUAL.md) · [License](LICENSE) · [Third-party notices](THIRD_PARTY.md)

---

## Why this exists

Pre-training an LLM is usually gated behind a wall of scripts, flags and silent failure modes:
a wrong field name drops your entire dataset without an error, a generic cleaning threshold
wipes out all code samples, an oversized config OOMs on the first step.

This project turns that pipeline into a UI, and bakes in defaults learned the hard way on a
real 3B run. The value is not "the strongest model" — it is that **you can run the whole thing
yourself, watch it learn, and keep the weights**.

---

## Features

**Data pipeline, runnable in parts**
- Local corpora: `jsonl` / `json` / `parquet` / `gz`, single file or folder
- Multiple corpora per project, each with its own type, cleaning strength and mix share
- Per-type cleaning presets (web / encyclopedia / Q&A / books / classical / code / auto)
- Every threshold individually overridable, with live risk warnings
- Run only the stages you need: prepare data → build dataset → train → test

**Model configuration**
- 9 presets from 15M to 7B
- Fully custom architecture: hidden size, layers, FFN width, head dim, attention heads, KV heads
- **No hard limits.** Model size, context length and VRAM are advisory — you decide whether to try
- Live parameter count and VRAM estimate as you type

**Training**
- Live progress: step, loss, tokens seen, throughput, VRAM, ETA, spikes/rollbacks
- Loss chart (train + validation) and dual-axis throughput/VRAM chart, drawn on native canvas
- **Pause & save** — finishes the current step, writes a checkpoint, then exits. No progress lost
- **Resume** — restores step count and optimizer state from the latest checkpoint
- Automatic checkpoint rotation; `best` / `final` are never deleted
- Optional backup to a second physical drive

**Environment & monitoring**
- Auto-detects an installed Python environment (conda / venv / official), or point it at one
- **Read-only monitor** for runs started elsewhere — charts and checkpoints without touching them
- Dark / light theme, Chinese / English UI

**Disk hygiene**
- Every project keeps its own `data/`, `tokenizer/`, `output/`, `logs/`, `tmp/`, `cache/`
- Temp files and all caches (CUDA / HF / torch / triton) are redirected **inside the project**
- Model output directory is configurable — put weights on another drive if you like

---

## Requirements

This repo ships **no Python runtime and no model weights**. You provide the environment once.

- Windows 10/11 (Linux/macOS work from source; the `.bat` launcher is Windows-only)
- Python 3.10+
- An NVIDIA GPU with a recent driver for GPU training (RTX 20-series or newer)
- Disk space: roughly 2× your corpus size for intermediates, plus ~5.5 GB per 3B checkpoint

```bash
python -m venv llm-env
llm-env\Scripts\activate          # Windows
pip install -r requirements.txt
```

For GPU training, install the CUDA build of PyTorch for your card — see
[pytorch.org](https://pytorch.org/get-started/locally/). A CPU-only build works but is very slow.

---

## Quick start

```bash
git clone https://github.com/<your-name>/llm-training-workshop.git
cd llm-training-workshop
```

Then **double-click `start_workshop.bat`**, or:

```bash
python launch.py
```

Your browser opens at `http://127.0.0.1:8765`.

1. **New Project** → name it → add a local corpus and pick its type → choose a model size
2. **Data** → run *All data stages*
3. **Training** → *Start training* → watch the loss curve
4. Try *Pause & save*, then *Resume* — the step count continues, it does not reset

> **First run: use the 15M or 124M preset with one small file and context 512.**
> The whole flow finishes in minutes. A 3B run on tens of billions of tokens takes months.

Keep the console window open while training — closing it stops the service.
Checkpoints are safe; reopen and resume.

---

## Capability boundaries

| Item | Support |
|---|---|
| Multi-GPU / multi-node | **Not supported.** Only the first GPU is used; VRAM is not pooled |
| Model size | No hard limit. Reference comfort zone ~7B on a single card |
| Context length | No hard limit. Verified up to 8192; beyond that may be slow or OOM |
| Concurrent runs | One at a time (single-GPU design) |

Want 27B, 262k context, or an 8-GPU cluster? Use a dedicated distributed framework
(Megatron-LM, DeepSpeed, torchtitan, nanotron). This is not that tool.

### Model size by VRAM (estimates, not limits)

| VRAM | Comfortable | Limit (batch=1, slow) |
|---|---|---|
| 8 GB | ~0.6B | ~1.2B |
| 12 GB | ~1.2B | ~2.1B |
| 16 GB | ~1.9B | ~3.0B |
| 24 GB | ~3.3B | ~4.9B |
| 32 GB | ~4.7B | ~6.8B |
| 48 GB | ~7.7B | ~10.7B |

---

## Where files go

```
llm-training-workshop/
├── start_workshop.bat     launcher (Windows)
├── launch.py              launcher (any platform)
├── app/                   backend — stdlib only
├── web/                   UI — vanilla HTML/CSS/JS
├── engine/                training scripts
├── projects/<name>/       your data, tokenizer, model, logs, tmp, cache
└── logs/                  service log
```

Nothing is written outside the project except a backup directory you explicitly choose.
Temporary files are deleted after use. See [MANUAL.md](MANUAL.md) for measured details.

---

## Design notes

**Zero-dependency UI and backend.** The server uses only the Python standard library
(`http.server`, `json`, `csv`, `subprocess`). Charts are drawn on native canvas. No CDN,
no web framework, no chart library — it works with the network unplugged.

**Advisory, not paternalistic.** Insufficient VRAM produces a warning, not a blocked button.
The tool tells you what will probably happen and lets you decide.

**Per-type cleaning matters.** A single global threshold destroys whole categories: code has
0% CJK characters, and its median 4-gram repetition is ~0.52, so a 0.5 cutoff discards half of it.
Classical Chinese paragraphs have a median of ~34 characters, so a 20-character minimum drops
many valid samples. Presets encode these measurements; every value stays overridable.

**Pause is a marker file, not a signal.** A background run may have no console window, and
attaching to another process's console is unreliable. The trainer checks for `STOP_REQUESTED`
at each step boundary, saves, and exits — so an in-flight save is never interrupted.

**Liveness is measured, not assumed.** "Is it still running?" is judged by log write time with
a threshold derived from the observed per-step duration — not by whether a process exists.

---

## Privacy

- Binds to `127.0.0.1` only; no externally exposed port
- Uploads nothing; corpora and weights stay on your machine
- Offline by default (no built-in download sources)
- Writes only inside the project folder plus a config file recording your chosen Python path

---

## License and data

Code: **Apache-2.0** — see [LICENSE](LICENSE).

**No corpus and no model weights are included.** You obtain the data and assess its license
yourself. Whether trained weights inherit corpus licenses (CC-BY-SA share-alike, GPL copyleft)
is legally unsettled — consult an IP lawyer before publishing or commercialising a model.
See [THIRD_PARTY.md](THIRD_PARTY.md).

---

## Contributing

Issues and PRs welcome — see [CONTRIBUTING.md](CONTRIBUTING.md).
The most useful reports include your GPU model and the largest preset that actually worked.

---

*Experimental tool. Results depend heavily on your hardware and data quality. Validate them yourself.*

# Third-party components and licensing

The code in this repository is released under the **Apache License 2.0** (see `LICENSE`).

This project **does not bundle or redistribute** any third-party runtime, corpus or model
weights. You install the dependencies yourself and are responsible for their licenses.
The list below is provided so you know what obligations apply.

---

## Components you install

| Component | License | Purpose |
|---|---|---|
| Python | PSF License | Interpreter |
| PyTorch | BSD-3-Clause | Training and inference; ships the NVIDIA CUDA runtime |
| transformers | Apache-2.0 | Model definitions and tokenizer wrappers |
| tokenizers | Apache-2.0 | BPE tokenizer training |
| NumPy | BSD-3-Clause | Numerics and memmap dataset access |
| PyArrow | Apache-2.0 | Reading `.parquet` corpora (optional) |
| huggingface_hub | Apache-2.0 | Optional download helper; not called by the UI |

The **NVIDIA CUDA runtime** ships with PyTorch and is governed by NVIDIA's software license
agreement. Read and comply with it before running GPU training.

A scan of the development environment (53 installed packages) found **no GPL/AGPL copyleft
dependencies**. NumPy is BSD; its bundled `libgfortran` carries the GCC runtime exception and
does not impose copyleft on this project. Any additional packages you install are your own
responsibility to assess.

---

## What this project itself uses

- **Backend**: Python standard library only — `http.server`, `json`, `csv`, `subprocess`,
  `pathlib`, `threading`, `ctypes`. No third-party web framework.
- **Frontend**: original HTML / CSS / JavaScript. Charts are drawn with the browser's native
  Canvas API. **No CDN, no frontend framework, no chart library.** Fully offline.
- **Hardware detection**: reads `nvidia-smi` (a tool already installed with your NVIDIA driver)
  and Windows memory APIs via `ctypes`. Nothing is bundled.

---

## Corpora and model weights

**No corpus data and no model weights are included, and no download sources are built in.**

You must obtain training data yourself and evaluate its license. Common sources differ widely:

| Source type | Typical license | Caution |
|---|---|---|
| Wikipedia / Wikisource | CC-BY-SA + GFDL | Attribution and share-alike obligations |
| Public-domain classics | Often unstated | Whether digitisation creates new rights is a legal question |
| Web crawls | Various community licenses | Some grants are revocable |
| Q&A sites / encyclopedias | Often no LICENSE file | No explicit grant; assess the risk yourself |
| Code corpora | Per-file licenses, may include GPL | Copyleft may apply; assess before releasing anything |

**Whether trained weights are bound by corpus licenses** — specifically whether CC-BY-SA's
ShareAlike or GPL copyleft extends to model weights — **is legally unsettled**. Industry views
conflict and there is no controlling court decision.

If you intend to publish or commercialise a trained model, **consult an intellectual-property
lawyer**. This document provides technical facts and common practice, **not legal advice**.

---

## Disclaimer

This is an **experimental tool** for individual developers, not production-grade software.

Per sections 7 and 8 of the Apache-2.0 license, the authors provide no warranty of any kind,
express or implied, and accept no liability for data loss, hardware damage, failed training
runs, or any other consequence of using this software.

Before training, verify for yourself: sufficient disk space, adequate cooling, important data
backed up, and automatic OS restarts disabled. Long runs may last days to months.

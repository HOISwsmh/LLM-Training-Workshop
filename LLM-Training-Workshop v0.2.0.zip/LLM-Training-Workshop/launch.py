"""LLM Training Workshop · launcher

Double-click: start the local service → open the UI in your default browser.
Zero third-party dependencies; Python standard library only.
"""
from __future__ import annotations

import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

PORT = 8765
HOST = "127.0.0.1"
APP_TITLE = "LLM Training Workshop"


def port_busy(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.6)
        return s.connect_ex((HOST, port)) == 0


def main() -> int:
    print("=" * 58)
    print(f"  {APP_TITLE}")
    print("=" * 58)
    print()
    print("  [Note] Single-GPU tool. Multiple GPUs are not combined.")
    print("         Model size / context length / VRAM are advisory only —")
    print("         you decide whether to try a risky configuration.")
    print("         Experimental tool, not production-grade software.")
    print()

    url = f"http://{HOST}:{PORT}"

    if port_busy(PORT):
        print(f"  Service already running. Opening browser: {url}")
        webbrowser.open(url)
        print()
        print("  (You may close this window; the service keeps running.)")
        time.sleep(2)
        return 0

    try:
        from app.server import serve
    except Exception as e:  # noqa: BLE001
        print(f"  [Error] Cannot load backend: {type(e).__name__}: {e}")
        input("  Press Enter to exit...")
        return 1

    try:
        httpd = serve(HOST, PORT)
    except OSError as e:
        print(f"  [Error] Cannot listen on port {PORT}: {e}")
        input("  Press Enter to exit...")
        return 1

    print(f"  Service started: {url}")
    print("  Opening your default browser...")
    print()
    print("  * Keep this console window open while training.")
    print("    Closing it stops the service; saved checkpoints are safe")
    print("    and you can resume next time.")
    print()

    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  Shutting down...")
    finally:
        httpd.shutdown()
        httpd.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Contributing

Thanks for considering a contribution. This is a small experimental project, so the process
is lightweight — but a few things make review much faster.

---

## Reporting a bug

Please include:

```
Environment
  GPU model + VRAM:
  Python version:
  torch version / CUDA version:
  OS:

Steps
  1. ...
  2. ...

Expected
  ...

Actual
  ...  (a screenshot of the error helps a lot)

Logs
  logs/                                 service log
  projects/<name>/logs/<stage>.log      per-stage log
```

**Especially valuable reports**
- Your GPU model and the largest preset that actually completed — this builds the compatibility table
- A corpus format or type that failed to parse (a 3-line sample is enough)
- Anything in the UI you could not find or understand

---

## Known limitations (not bugs)

Please don't file these — they are deliberate design boundaries:

- Multi-GPU is unsupported; only the first GPU is used and VRAM is not pooled
- One training run at a time
- Small models emit only punctuation early in training — that is normal, not a broken model
- CPU mode is extremely slow; it exists to try the flow, not to train seriously
- Closing the console window stops the service (checkpoints survive; reopen and resume)

---

## Development setup

```bash
git clone https://github.com/<your-name>/llm-training-workshop.git
cd llm-training-workshop
python -m venv llm-env
llm-env\Scripts\activate
pip install -r requirements.txt
python launch.py
```

The backend and UI need no third-party packages; `requirements.txt` is only for the training
engine. You can therefore work on the UI without installing PyTorch.

**Layout**

| Path | Role |
|---|---|
| `app/server.py` | HTTP routes, static files |
| `app/pipeline.py` | Stage scheduler, subprocess handling, pause/resume |
| `app/hardware.py` | GPU/RAM detection, VRAM estimates, config checks |
| `app/projects.py` | Project config and state, output-directory resolution |
| `app/watch.py` | Read-only monitor for external runs |
| `app/paths.py` | Path resolution and Python environment detection |
| `web/` | UI; `i18n.js` holds every string in both languages |
| `engine/` | Training scripts, invoked as subprocesses |

---

## Guidelines

**Keep the zero-dependency property.** The backend uses only the standard library and the UI
only vanilla HTML/CSS/JS with native canvas. Please don't add a web framework, a chart library
or a CDN link.

**Keep both languages in sync.** Every user-facing string goes through `t('key')` in JS or
`data-i18n` in markup, with entries in **both** `zh` and `en` in `web/i18n.js`. A key present in
only one language is a bug.

**Don't write outside the project.** Temp files and caches must stay under the project's
`tmp/` and `cache/`. If you add a subprocess, pass the same environment redirects that
`pipeline.py` already sets.

**Warn, don't block.** Exceeding VRAM, model size or context length should produce a warning,
not a disabled control. Only genuinely unrunnable input (unknown preset, non-positive context)
should be rejected.

**Never touch a run you don't own.** The external monitor is read-only by contract. Don't add
pause/stop controls for runs started elsewhere.

**Measure before claiming.** If you change a VRAM estimate, throughput figure or cleaning
threshold, verify it against a real run and say so in the PR. Estimates that were never
measured should be labelled as estimates.

---

## Testing your change

There is no CI yet, so please check manually:

1. `python -c "import ast,pathlib; [ast.parse(p.read_text(encoding='utf-8')) for p in pathlib.Path('app').glob('*.py')]"` — syntax
2. Start the app, create a project with the **15M preset**, one small corpus file, context 512
3. Run *All data stages*, then *Start training*
4. Try *Pause & save* → confirm a checkpoint appears → *Resume* → confirm the step count continues
5. Toggle dark/light and Chinese/English; check for untranslated strings
6. Confirm nothing new appeared in your system temp directory

Mention in the PR which of these you ran and on what hardware.

---

## Commit style

Short imperative subject, optional body explaining *why*:

```
Fix VRAM estimate for untied embeddings

The previous formula counted the embedding matrix once regardless of
tie_word_embeddings, under-reporting untied models by vocab*hidden params.
```

---

## License

By contributing, you agree your contributions are licensed under the Apache-2.0 license that
covers this project.

"""在系统文件管理器中打开项目相关目录。

★安全边界：这不是「打开任意路径」的通用接口。
  只接受 (项目名, 位置键) 两个参数，真实路径由后端自己算出来：
    model      → 模型输出目录（含 best/final/checkpoint-*）
    best       → 最佳模型
    final      → 最终模型
    tokenizer  → 词表
    data       → 训练集
    downloads  → 该项目的下载目录
    logs       → 工位日志
    project    → 项目根
  用户无法传入任意路径，因此不存在被诱导打开系统目录的可能。

★只打开目录，不打开文件、不执行任何程序。
★目录不存在时如实报错，不静默创建（避免凭空造出空目录误导用户）。
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path
from urllib.parse import unquote, urlparse

from . import projects as P

IS_WIN = sys.platform == "win32"
NO_WINDOW = 0x08000000 if IS_WIN else 0

# ★一次点击 = 一个窗口：
#   目录已经开着 → 把那个窗口切到前台（不再新开，也不是「点了没反应」）；
#   没开着     → 新开一个。
#   之前用「30 秒内忽略重复请求」的做法，用户第二次点会毫无动静，体验更差。
#   这里改为真正找到已有窗口并激活，所以不需要任何时间窗。
_LOCK = threading.Lock()          # 串行化，避免连点时并发开出两个

# 允许的位置键 → 说明（说明仅用于错误提示，不参与路径拼接）
SPOTS = ("model", "best", "final", "tokenizer", "data", "downloads", "logs", "project")


def _p(code: str, **v) -> dict:
    return {"k": code, "v": v}


def resolve(name: str, spot: str) -> Path:
    """把 (项目名, 位置键) 解析成真实目录。项目名走 P.safe_name 校验。"""
    key = (spot or "").strip().lower()
    if key not in SPOTS:
        raise ValueError(f"未知位置：{spot}")
    d = P.project_dir(name)          # 内含项目名合法性校验
    if not d.exists():
        raise ValueError(f"项目「{name}」不存在")
    if key == "project":
        return d
    if key == "model":
        return P.output_dir(name)
    if key in ("best", "final"):
        return P.output_dir(name) / key
    if key == "data":
        return d / "data" / "final"
    return d / key


def _norm_path(p: str) -> str:
    """统一成可比较的绝对路径（Windows 忽略大小写与分隔符差异）。"""
    s = (p or "").strip().strip('"')
    if not s:
        return ""
    try:
        s = str(Path(s).resolve())
    except (OSError, RuntimeError, ValueError):
        s = s.replace("/", os.sep)
    s = s.rstrip("\\/")
    return s.lower() if IS_WIN else s


def _url_to_path(url: str) -> str:
    """资源管理器给的 LocationURL（file:///E:/x）→ 本地路径。

    特殊文件夹（此电脑/回收站等）给的是 shell:::{GUID}，不是路径，返回空串。
    """
    u = (url or "").strip()
    if not u or not u.lower().startswith("file:"):
        return ""
    try:
        parsed = urlparse(u)
        path = unquote(parsed.path or "")
    except ValueError:
        return ""
    if IS_WIN and path.startswith("/") and len(path) > 2 and path[2] == ":":
        path = path[1:]                      # /E:/x → E:/x
    return path.replace("/", os.sep) if IS_WIN else path


# ★纯 ASCII：Windows PowerShell 5.1 读非 ASCII 脚本需要 BOM，
#   这里不带任何中文，避免编码问题；结果用 | 分隔便于解析。
_PS_FIND = r"""
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -Namespace W -Name U -MemberDefinition @'
[DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
[DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr p);
[DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool c);
[DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
'@
# 目标路径通过环境变量传入：-Command 之后的参数会被 PowerShell 当作命令执行，
# $args[0] 取不到值（实测 WANT=[] 且报 CommandNotFoundException）。
$want = [string]$env:LW_REVEAL_TARGET
if (-not $want) { Write-Output 'NONE'; exit 0 }
$shell = New-Object -ComObject Shell.Application
foreach ($w in $shell.Windows()) {
  $url = ''
  try { $url = [string]$w.LocationURL } catch { continue }
  if (-not $url.StartsWith('file:')) { continue }
  $p = ''
  try { $p = [string]$w.Document.Folder.Self.Path } catch { }
  if (-not $p) { continue }
  if ($p.TrimEnd('\').ToLower() -ne $want) { continue }
  $h = [IntPtr]0
  try { $h = [IntPtr][int64]$w.HWND } catch { continue }
  if ($h -eq [IntPtr]::Zero) { continue }
  if ([W.U]::IsIconic($h)) { [void][W.U]::ShowWindow($h, 9) }
  # 后台进程直接 SetForegroundWindow 常被系统忽略（只闪任务栏），
  # 先把输入队列挂到当前前台线程上再切，成功率更高。
  $fg = [W.U]::GetForegroundWindow()
  $ft = [W.U]::GetWindowThreadProcessId($fg, [IntPtr]::Zero)
  $ct = [W.U]::GetCurrentThreadId()
  $attached = $false
  if ($ft -ne 0 -and $ft -ne $ct) { $attached = [W.U]::AttachThreadInput($ct, $ft, $true) }
  [void][W.U]::ShowWindow($h, 5)
  $ok = [W.U]::SetForegroundWindow($h)
  if ($attached) { [void][W.U]::AttachThreadInput($ct, $ft, $false) }
  Write-Output ('FOUND|' + $h.ToInt64() + '|' + $ok)
  exit 0
}
Write-Output 'NONE'
exit 0
"""


def _any_explorer_window() -> bool:
    """有没有任何资源管理器窗口。没有就不必启动 PowerShell（省几百毫秒）。"""
    if not IS_WIN:
        return True
    try:
        import ctypes
        u = ctypes.windll.user32
        for cls in ("CabinetWClass", "ExploreWClass"):
            if u.FindWindowW(cls, None):
                return True
        return False
    except Exception:  # noqa: BLE001
        return True                      # 判断不了就走完整流程，宁可慢不可漏


def _focus_existing(target: Path) -> bool:
    """找到已打开该目录的窗口并切到前台；找到返回 True。"""
    if not IS_WIN or not _any_explorer_window():
        return False
    ps = shutil.which("powershell") or shutil.which("pwsh")
    if not ps:
        return False                     # 没有 PowerShell 就退回普通打开
    want = _norm_path(str(target))
    try:
        env = dict(os.environ, LW_REVEAL_TARGET=want)
        r = subprocess.run(
            [ps, "-NoProfile", "-NonInteractive", "-Command", _PS_FIND],
            capture_output=True, text=True, timeout=12,
            encoding="utf-8", errors="replace",
            creationflags=NO_WINDOW, env=env)
    except (OSError, subprocess.SubprocessError):
        return False
    return (r.stdout or "").strip().startswith("FOUND|")


def open_dir(name: str, spot: str) -> dict:
    """在文件管理器中打开目录。返回 {ok, path} 或 {ok:False, problems}。

    ★一次点击只对应一个窗口：已开着就切过去（reused=True），没开才新开。
    """
    try:
        target = resolve(name, spot)
    except ValueError as e:
        return {"ok": False, "problems": [_p("rv.badTarget", e=str(e))]}

    if not target.exists() or not target.is_dir():
        return {"ok": False, "problems": [_p("rv.missing", p=str(target))],
                "path": str(target)}

    # 串行化：连点时不让两个请求同时走到「没找到 → 新开」而开出两个窗口
    with _LOCK:
        if _focus_existing(target):
            return {"ok": True, "path": str(target), "reused": True}
        try:
            if IS_WIN:
                # os.startfile 只打开文件夹窗口，不执行其中内容
                os.startfile(str(target))          # noqa: S606
            elif sys.platform == "darwin":
                subprocess.run(["open", str(target)], check=False, timeout=15)
            else:
                subprocess.run(["xdg-open", str(target)], check=False, timeout=15,
                               creationflags=NO_WINDOW)
        except Exception as e:  # noqa: BLE001
            return {"ok": False, "problems": [_p("rv.fail", e=type(e).__name__)],
                    "path": str(target)}
    return {"ok": True, "path": str(target)}
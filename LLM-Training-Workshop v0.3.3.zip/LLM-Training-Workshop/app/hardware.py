"""硬件自检与规模推荐。

设计原则（来自真实项目的踩坑经验）：
  宁可劝退，不让用户第一次就 OOM。

显存公式与档位表直接复用引擎中已实测校准的实现，不另写一套，
避免"界面说能跑、实际跑不动"的口径分裂。
"""
from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

ENGINE_DIR = Path(__file__).resolve().parent.parent / "engine"

# 能力说明：单卡工具。
# ★模型规模与上下文长度**不设硬上限**——只给参考值与风险提示，
#   由用户自己决定是否尝试。显存不足同样只警告，不阻止启动。
LIMITS = {
    "multi_gpu": False,
    "multi_node": False,
    "advisory_model_b": 7.0,      # 参考：单卡舒适区，非上限
    "advisory_context": 8192,     # 参考：实测验证过的范围，非上限
    "notice": (
        "本工具为单卡训练设计，不支持多卡/多机并行（多张卡只用第一张，不合并显存）。"
        "模型规模、上下文长度与显存需求**不设强制上限**：超出参考范围时只提示风险，"
        "是否尝试由你决定。它是面向个人开发者的实验性工具，请自行核对数据与许可。"
    ),
}

# 各档位实测参数量（meta 设备逐档实测，名称里的数字即真实量级）
TIER_PARAMS = {
    "nano": 852_864,           # 128×3×384 + 2048词表：秒级冒烟测试
    "tiny": 14_947_200,        # 384×6×1408 + 8192词表
    "base": 123_685_632,       # 768×12×2944 + 32000词表
    "0.5b": 495_171_840,       # 1280×18×5504
    "1.5b": 1_499_682_816,     # 2048×21×9408（heads32/kv8 可整除）
    "3b": 2_934_213_120,       # 2560×32×9472 + 32000词表（与真实 3B 模型一致）
    "7b": 7_009_996_800,       # 4096×32×12032，完整注意力（非GQA）
    # ---- 旧档位：保留兼容，不进界面推荐列表 ----
    "small": 38_900_000,
    "mid": 345_300_000,
    "large": 747_600_000,
    "xl": 1_299_000_000,
    "2b": 1_985_000_000,
    "5.8b": 5_802_037_248,
}

TIER_LABEL = {
    "nano": "1M · 冒烟测试",
    "tiny": "15M · 体验",
    "base": "124M · 小型",
    "0.5b": "0.5B · 入门",
    "1.5b": "1.5B · 进阶",
    "3b": "3B · 高端",
    "7b": "7B · 单卡上限",
    "small": "39M · 入门（旧）",
    "mid": "345M · 中型（旧）",
    "large": "748M · 较大（旧）",
    "xl": "1.3B · 大型（旧）",
    "2b": "2B · 很大（旧）",
    "5.8b": "5.8B（旧）",
}

# 各档位的架构定义（与引擎 TIERS 一致），供界面自定义时作为起点。
# kv_groups=1 表示完整注意力；缺省沿用 GQA（每 4 个查询头共享 1 组 KV）。
TIER_ARCH = {
    "nano": {"hidden_size": 128, "num_hidden_layers": 3, "intermediate_size": 384},
    "tiny": {"hidden_size": 384, "num_hidden_layers": 6, "intermediate_size": 1408},
    "base": {"hidden_size": 768, "num_hidden_layers": 12, "intermediate_size": 2944},
    "0.5b": {"hidden_size": 1280, "num_hidden_layers": 18, "intermediate_size": 5504},
    "1.5b": {"hidden_size": 2048, "num_hidden_layers": 21, "intermediate_size": 9408},
    "3b": {"hidden_size": 2560, "num_hidden_layers": 32, "intermediate_size": 9472},
    "7b": {"hidden_size": 4096, "num_hidden_layers": 32, "intermediate_size": 12032,
           "kv_groups": 1},
    "small": {"hidden_size": 512, "num_hidden_layers": 8, "intermediate_size": 1408},
    "mid": {"hidden_size": 1024, "num_hidden_layers": 16, "intermediate_size": 5504},
    "large": {"hidden_size": 1536, "num_hidden_layers": 16, "intermediate_size": 8192},
    "xl": {"hidden_size": 2048, "num_hidden_layers": 24, "intermediate_size": 6656},
    "2b": {"hidden_size": 2560, "num_hidden_layers": 24, "intermediate_size": 8192},
    "5.8b": {"hidden_size": 4096, "num_hidden_layers": 32, "intermediate_size": 11008},
}

# 各档位词表（与引擎 TIERS 一致）：参数量估算要用真实词表，否则小档偏差很大
TIER_VOCAB = {
    # ★3B 用 32000：49152 是早期脚本的推荐值，与用户定版（32000）不符，
    #   曾造成「3B 词表比 7B 还大」的困惑。现全档统一口径、随规模单调不减。
    "nano": 2048, "tiny": 8192, "base": 32000, "0.5b": 32000,
    "1.5b": 32000, "3b": 32000, "7b": 32000,
    "small": 32000, "mid": 32000, "large": 32000, "xl": 32000,
    "2b": 32000, "5.8b": 32000,
}

# 兼容别名：旧档位名不进界面推荐列表，只保证旧配置/脚本仍可用。
TIER_ALIASES = {"small", "mid", "large", "xl", "2b", "5.8b"}

# 各档位默认训练参数（上下文/微批/梯度累积），切档时同步到界面。
# ★设计口径（三项都随规模单调）：
#   上下文随规模递增：128→512→1024→2048→2048→4096→8192。
#     社区主预训练多为 4096（Qwen2.5 主阶段），更大模型给更长上下文更贴合实际使用；
#     7B 给 8192（>3B 的 4096），激活贵就用微批 1 + 累积 8 补回。
#   微批：玩具档 2 起步，中段统一 4，7B 收到 1（大模型激活贵，单卡放不下更多样本）。
#   每步 token（上下文×微批×累积）随规模递增：256→4K→16K→32K→32K→64K→64K，
#     大模型需要更大的有效批量才训得稳。
#   3B 的 4096×4×4=65536 token/步 是用户实测定版，原样保留。
#   冒烟档故意用极小值，保证几分钟跑完全链路。
#   词表不随规模递增：社区同系列全尺寸共用一套词表（Qwen2.5 全系 151643、
#   LLaMA3 全系 128256），这里玩具档用小词表省嵌入，124M 起统一 32000。
TIER_TRAIN = {
    "nano": {"block_size": 128, "batch_size": 2, "grad_accum": 1},
    "tiny": {"block_size": 512, "batch_size": 4, "grad_accum": 2},
    "base": {"block_size": 1024, "batch_size": 4, "grad_accum": 4},
    "0.5b": {"block_size": 2048, "batch_size": 4, "grad_accum": 4},
    "1.5b": {"block_size": 2048, "batch_size": 4, "grad_accum": 4},
    "3b": {"block_size": 4096, "batch_size": 4, "grad_accum": 4},
    "7b": {"block_size": 8192, "batch_size": 1, "grad_accum": 8},
}

# 学习率经验值（原项目扫描实测：3B 用 3e-5，小模型可用更大）
# ★这些是 Adafactor 口径下的实测/沿用值，不要按"Adafactor 需 1e-2"的通则改：
#   原项目总纲与 trainer_state 均记录 3B 在 Adafactor 下用 3e-5，1e-2/1e-3 会炸。
TIER_LR = {
    "nano": 1e-3, "tiny": 1e-3, "base": 3e-4,
    "0.5b": 1e-4, "1.5b": 4e-5, "3b": 3e-5, "7b": 2e-5,
    # 旧档位沿用原值
    "small": 1e-3, "mid": 1e-4, "large": 6e-5, "xl": 4e-5,
    "2b": 3e-5, "5.8b": 2e-5,
}


def arch_params(arch: dict, vocab_size: int = 32000, tier: str | None = None) -> dict:
    """按自定义架构估算参数量与结构合法性。

    与引擎 build_config 的口径保持一致：
      heads = hidden // head_dim（或用户指定），kv_heads = heads // kv_groups（或用户指定）
      参数量 = embedding(tie 时只算一份) + layers × (attn + mlp + 2×norm) + 末端 norm
    ★KV 分组跟随档位：7B 是完整注意力（kv_groups=1），一律 heads//4 会把
      7B 自定义架构算成 ~6.2B，与引擎实际 7.01B 不符（审计指出）。
    """
    h = int(arch.get("hidden_size") or 2560)
    L = int(arch.get("num_hidden_layers") or 32)
    inter = int(arch.get("intermediate_size") or 9472)
    hd = int(arch.get("head_dim") or 64)
    heads = int(arch.get("num_attention_heads") or max(h // hd, 1))
    kv_div = int(arch.get("kv_groups") or (TIER_ARCH.get(tier, {}).get("kv_groups", 4) if tier else 4))
    kv_raw = int(arch.get("num_key_value_heads") or max(heads // max(kv_div, 1), 1))
    kv = max(1, min(kv_raw, heads))
    while heads % kv != 0 and kv > 1:
        kv -= 1
    tie = bool(arch.get("tie_embeddings", True))

    q = h * heads * hd
    k = h * kv * hd
    v = h * kv * hd
    o = heads * hd * h
    attn = q + k + v + o
    mlp = h * inter * 3          # SwiGLU: gate / up / down
    norms = 2 * h
    per_layer = attn + mlp + norms
    emb = vocab_size * h
    total = emb * (1 if tie else 2) + L * per_layer + h

    # 结构提示：只提醒，不拦截。KV 头数会被引擎自动下调到能整除的值。
    problems = []
    if h % hd != 0 and not arch.get("num_attention_heads"):
        problems.append(f"隐层宽度 {h} 不是每头维度 {hd} 的整数倍，"
                        f"实际头数会取整为 {heads}（可改用 {round(h / hd) * hd} 更整齐）")
    if arch.get("num_key_value_heads") and heads % kv_raw != 0:
        problems.append(f"查询头数 {heads} 不能被 KV 头数 {kv_raw} 整除，"
                        f"已自动下调为 {kv}")
    if h < 64 or L < 1 or inter < 64:
        problems.append("隐层宽度/层数/中间维度取值很小，模型容量会非常有限")
    return {"params": total, "params_b": round(total / 1e9, 3),
            "heads": heads, "kv_heads": kv, "head_dim": hd,
            "hidden_size": h, "num_hidden_layers": L, "intermediate_size": inter,
            "tie_embeddings": tie, "problems": problems}


def estimate_vram(n_params: int, master_dtype: str = "bf16",
                  checkpointing: bool = True, optimizer: str = "adafactor",
                  batch_size: int = 0, block_size: int = 0,
                  hidden_size: int = 0, num_layers: int = 0,
                  vocab_size: int = 32000) -> dict:
    """静态显存估算（权重+梯度+优化器+激活），单位 GB。

    公式与引擎 train_model.estimate_memory 完全一致（原项目实测校准），
    在此独立实现是为了让界面侧不必加载 torch —— 否则打包体积会暴涨到 GB 级。
    ★两边口径必须保持一致，改这里也要同步改引擎。

    激活项随 batch/block/结构变化；缺结构参数时退回保守基线（兼容旧调用）。
    """
    wbytes = 4 if master_dtype == "fp32" else 2
    weights = n_params * wbytes / 1024 ** 3
    grads = n_params * wbytes / 1024 ** 3
    if optimizer == "adamw":
        opt_state = n_params * (4 + 4) / 1024 ** 3
    else:
        opt_state = n_params * 0.031 / 1024 ** 3
    if batch_size > 0 and block_size > 0 and hidden_size > 0 and num_layers > 0:
        # k 由 3B 定版实测反解校准（详见引擎 estimate_memory 注释），两边必须一致
        k = 5.0 if checkpointing else 15.0
        act = num_layers * batch_size * block_size * hidden_size * k / 1024 ** 3
        # ★用真实词表：写死 32000 会让大词表低估激活，与前端卡片口径分裂
        act += batch_size * block_size * max(int(vocab_size or 32000), 1) * 6 / 1024 ** 3
        act = max(act, 0.3)
    else:
        act = 2.0 if checkpointing else 8.0
    return {"weights": weights, "grads": grads, "opt": opt_state,
            "act": act, "total": weights + grads + opt_state + act}


def _global_vram() -> tuple[float, float] | None:
    """用 nvidia-smi 读全局显存。

    ★踩坑记录：Windows WDDM 下 torch.cuda.mem_get_info() 在**独立查询进程**里
    只反映自己的上下文，会把别的进程（如正在训练的任务）占用的显存报成空闲。
    实测本机：训练占 22.5GB 时，进程内读数仍报空闲 30.6GB，全局实为 9.0GB。
    照虚报值推荐档位必然 OOM，因此优先采用全局读数。
    """
    import subprocess  # noqa: PLC0415

    try:
        r = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.free,memory.total",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=10,
        )
        if r.returncode != 0 or not r.stdout.strip():
            return None
        free_s, total_s = r.stdout.strip().splitlines()[0].split(",")
        return float(free_s.strip()) / 1024, float(total_s.strip()) / 1024
    except Exception:  # noqa: BLE001 没有 nvidia-smi 时退回 torch 读数
        return None


def _smi_detail() -> dict:
    """读显卡型号、数量、算力、驱动版本（轻量，不加载 torch）。"""
    import subprocess  # noqa: PLC0415

    try:
        r = subprocess.run(
            ["nvidia-smi",
             "--query-gpu=name,compute_cap,driver_version",
             "--format=csv,noheader"],
            capture_output=True, text=True, timeout=10,
        )
        if r.returncode != 0 or not r.stdout.strip():
            return {}
        lines = [l for l in r.stdout.strip().splitlines() if l.strip()]
        first = [x.strip() for x in lines[0].split(",")]
        return {"name": first[0], "cc": first[1] if len(first) > 1 else None,
                "driver": first[2] if len(first) > 2 else None,
                "count": len(lines)}
    except Exception:  # noqa: BLE001
        return {}


def detect() -> dict:
    """检测本机硬件。无显卡时降级为 CPU 模式而非崩溃。"""
    info = {
        "ok": True,
        "gpu": None,
        "gpu_count": 0,
        "vram_total_gb": 0.0,
        "vram_free_gb": 0.0,
        "compute_capability": None,
        "cuda_available": False,
        "torch_version": None,
        "cuda_version": None,
        "cpu_count": os.cpu_count() or 1,
        "ram_total_gb": 0.0,
        "ram_free_gb": 0.0,
        "disks": [],
        "warnings": [],
        "limits": LIMITS,
    }

    # 内存：优先 Windows API，失败则退回多种备选，绝不静默留 0
    ram_err = None
    if sys.platform == "win32":
        try:
            import ctypes
            from ctypes import wintypes

            class MS(ctypes.Structure):
                _fields_ = [
                    ("dwLength", wintypes.DWORD),
                    ("dwMemoryLoad", wintypes.DWORD),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            # 显式声明签名，避免冻结环境下默认 int 返回值截断指针
            fn = ctypes.windll.kernel32.GlobalMemoryStatusEx
            fn.argtypes = [ctypes.POINTER(MS)]
            fn.restype = wintypes.BOOL
            if fn(ctypes.byref(m)):
                info["ram_total_gb"] = round(m.ullTotalPhys / 1024 ** 3, 1)
                info["ram_free_gb"] = round(m.ullAvailPhys / 1024 ** 3, 1)
                info["ram_load"] = int(m.dwMemoryLoad)
            else:
                ram_err = f"GlobalMemoryStatusEx 返回 False (err={ctypes.GetLastError()})"
        except Exception as e:  # noqa: BLE001
            ram_err = f"{type(e).__name__}: {e}"

    # 备选1：psutil（若用户环境里有）
    if not info["ram_total_gb"]:
        try:
            import psutil  # noqa: PLC0415
            vm = psutil.virtual_memory()
            info["ram_total_gb"] = round(vm.total / 1024 ** 3, 1)
            info["ram_free_gb"] = round(vm.available / 1024 ** 3, 1)
            ram_err = None
        except Exception:  # noqa: BLE001
            pass

    # 备选2：wmic/PowerShell 读物理内存（不依赖任何第三方库）
    if not info["ram_total_gb"] and sys.platform == "win32":
        try:
            import subprocess
            r = subprocess.run(
                ["powershell.exe", "-NoProfile", "-Command",
                 "$o=Get-CimInstance Win32_OperatingSystem;"
                 "\"$($o.TotalVisibleMemorySize) $($o.FreePhysicalMemory)\""],
                capture_output=True, text=True, timeout=20,
            )
            parts = (r.stdout or "").split()
            if len(parts) >= 2:
                tot_kb, free_kb = float(parts[0]), float(parts[1])
                info["ram_total_gb"] = round(tot_kb / 1024 ** 2, 1)
                info["ram_free_gb"] = round(free_kb / 1024 ** 2, 1)
                ram_err = None
        except Exception:  # noqa: BLE001
            pass

    if not info["ram_total_gb"]:
        info["ram_error"] = ram_err or "内存检测不可用"
        info["warnings"].append("内存信息读取失败，不影响训练；显存与磁盘数据仍准确。")

    # ★扫全部存在的盘符（A–Z），不再写死 C–F：语料/项目在 G: 及以后的盘
    #   时旧实现界面缺磁盘信息、预检参考失真（审计指出）。
    for letter in "CDEFGHIJKLMNOPQRSTUVWXYZAB":
        root = letter + ":"
        if not Path(root + "\\").exists():
            continue
        try:
            t, _u, f = shutil.disk_usage(root + "\\")
            info["disks"].append({
                "drive": root,
                "total_gb": round(t / 1024 ** 3, 1),
                "free_gb": round(f / 1024 ** 3, 1),
            })
        except OSError:
            continue

    # GPU：只用 nvidia-smi，不 import torch。
    # ★启动器要能打包成小体积 exe；import torch 会把约 2GB 的 CUDA 库拖进包里。
    #   torch 只在引擎子进程中使用，界面侧无需加载。
    g = _global_vram()
    smi = _smi_detail()
    if g:
        g_free, g_total = g
        info["cuda_available"] = True
        info["vram_source"] = "nvidia-smi"
        info["vram_free_gb"] = round(g_free, 2)
        info["vram_total_gb"] = round(g_total, 2)
        info["gpu"] = smi.get("name") or "NVIDIA GPU"
        info["gpu_count"] = smi.get("count", 1)
        info["compute_capability"] = smi.get("cc")
        info["driver"] = smi.get("driver")
        busy = g_total - g_free
        if busy > 2.0:
            info["warnings"].append(
                f"显卡已被其他程序占用约 {busy:.1f}GB"
                "（可能是本地模型、游戏或另一个训练任务）。"
                "推荐规模按总显存计算；开训前体检会再核对当前剩余显存。"
            )
        if info["gpu_count"] > 1:
            info["warnings"].append(
                f"检测到 {info['gpu_count']} 张显卡，但本工具只使用第 1 张，不会合并多卡显存。"
            )
        cc = smi.get("cc")
        if cc:
            try:
                if int(cc.split(".")[0]) < 7:
                    info["warnings"].append(
                        "显卡算力过低（需 RTX 20 系及以上），可能无法运行 GPU 训练。"
                    )
            except (ValueError, IndexError):
                pass
        # ★nvidia-smi 可用 ≠ 当前 PyTorch 能用 CUDA：装了 CPU 版 torch 时
        #   驱动正常但训练仍走 CPU。用已探测到的环境信息核对，不一致就告警
        #   （审计指出）。不在此 import torch（避免拖大界面侧体积）。
        try:
            from . import paths as _PA  # noqa: PLC0415
            env = _PA.detect_env()
            ei = env.get("info") or {}
            if env.get("ready") and ei.get("cuda") is False:
                info["warnings"].append(
                    "检测到 NVIDIA 显卡，但当前训练环境的 PyTorch 是 CPU 版"
                    "（torch.cuda 不可用），实际会走 CPU、极慢。"
                    "请安装对应 CUDA 版本的 torch 后重试。"
                )
        except Exception:  # noqa: BLE001 探测失败不影响硬件展示
            pass
    else:
        info["warnings"].append(
            "未检测到可用的 NVIDIA 显卡，将使用 CPU 模式（极慢，仅供体验 15M 档）。"
        )

    return info


def recommend(hw: dict) -> dict:
    """按**总显存**给出参考建议。**不禁用任何档位**，超出预算只标注风险。

    ★口径取舍（用户明确要求）：推荐规模看这张卡"有多大"，而不是"此刻剩多少"。
      剩余显存随其他程序波动，若按它推荐，开个游戏推荐就缩档，关掉又跳回来，
      建议会来回跳。总显存是硬件固有属性，推荐才稳定。
      "此刻能不能跑"由开训前体检（check_config）按剩余显存另行警告，两层不混。
    """
    cuda = hw.get("cuda_available")
    # 预留 1.5GB 给桌面/系统占用
    budget = (hw.get("vram_total_gb") or 0.0) - 1.5 if cuda else 0.0
    tiers = []
    best = None
    for name, n in TIER_PARAMS.items():
        # ★别名不进推荐列表：7b 与 5.8b 是同一档位，
        #   都列出来界面上会出现两张一模一样的卡片。旧名仅供兼容调用。
        if name in TIER_ALIASES:
            continue
        # ★按该档自己的训练预设计算（与前端卡片同口径）：
        #   旧版用固定基线（batch=1/block=1024），7B 会低估成 ~28GB，
        #   而卡片按 8192×1 算是 ~33GB，推荐标记与卡片风险态会互相矛盾。
        tp = TIER_TRAIN.get(name, {})
        _a = TIER_ARCH.get(name, {})
        mem = estimate_vram(n, batch_size=tp.get("batch_size", 1),
                            block_size=tp.get("block_size", 1024),
                            hidden_size=_a.get("hidden_size", 0),
                            num_layers=_a.get("num_hidden_layers", 0))
        need = round(mem["total"], 2)
        fits = cuda and need <= budget
        tiers.append({
            "tier": name,
            "label": TIER_LABEL[name],
            "params": n,
            "params_b": round(n / 1e9, 3),
            "vram_need_gb": need,
            "fits": fits,
            "lr": TIER_LR[name],
            "arch": TIER_ARCH.get(name, {}),
            "reason": None if fits else (
                "需要 CUDA 显卡" if not cuda
                else f"约需 {need}GB 显存，超出总显存参考预算 {max(budget, 0):.1f}GB"
            ),
        })
        if fits:
            best = name
    return {
        "budget_gb": round(max(budget, 0.0), 2),
        "budget_basis": "total",
        "tiers": tiers,
        "recommended": best,
        "cpu_only": not cuda,
    }


def check_config(tier: str, block_size: int, hw: dict,
                 arch: dict | None = None, vocab_size: int = 32000,
                 batch_size: int = 0, master_dtype: str = "bf16") -> dict:
    """开训前体检：**只提示风险，不强制拦截**。

    ★设计取舍（用户明确要求）：显存不足、模型过大、上下文过长都只警告，
      是否尝试由用户决定。唯一真正拒绝的是"根本无法执行"的输入错误
      （未知档位、上下文不是正整数）。
    """
    problems, warnings, notes = [], [], []
    if tier not in TIER_PARAMS:
        problems.append(f"未知的模型规模：{tier}")
        return {"ok": False, "problems": problems, "warnings": warnings,
                "notes": notes}

    if not isinstance(block_size, int) or block_size < 1:
        problems.append("上下文长度必须是正整数")
        return {"ok": False, "problems": problems, "warnings": warnings,
                "notes": notes}
    if block_size < 64:
        warnings.append(f"上下文 {block_size} 很短，样本会被切得很碎，通常建议 ≥256")
    elif block_size > LIMITS["advisory_context"]:
        warnings.append(
            f"上下文 {block_size} 超出已验证范围（{LIMITS['advisory_context']}）。"
            "本工具未内置 FlashAttention 与序列并行，注意力显存随长度平方增长，"
            "可能非常慢或直接 OOM。可以尝试，风险自负。"
        )

    if arch:
        info = arch_params(arch, vocab_size, tier=tier)
        warnings += info["problems"]
        n = info["params"]
        h_dim, n_layer = info["hidden_size"], info["num_hidden_layers"]
        notes.append(
            f"自定义架构：{info['hidden_size']} 宽 × {info['num_hidden_layers']} 层，"
            f"{info['heads']} 头（KV {info['kv_heads']}），约 {info['params_b']}B 参数"
        )
    else:
        n = TIER_PARAMS[tier]
        _a = TIER_ARCH[tier]
        h_dim, n_layer = _a["hidden_size"], _a["num_hidden_layers"]
    # ★留 1% 容差：7B 档实测 7.010B，裸比较 7.01>7.0 会让自家顶配档
    #   永远挂着"超出参考值"的警告，属浮点舍入误报。
    if n / 1e9 > LIMITS["advisory_model_b"] * 1.01:
        warnings.append(
            f"模型约 {n / 1e9:.2f}B，超出单卡舒适区参考值 {LIMITS['advisory_model_b']}B。"
            "本工具不做模型切分，参数必须完整放进一张卡。可以尝试，风险自负。"
        )

    # 传入真实批量/精度/结构：激活与权重显存随它们变化，不能再用固定基线
    mem = estimate_vram(n, master_dtype=master_dtype,
                        batch_size=batch_size or 1, block_size=block_size,
                        hidden_size=h_dim, num_layers=n_layer,
                        vocab_size=vocab_size)
    need = mem["total"]
    budget = None
    if hw.get("cuda_available"):
        budget = max((hw.get("vram_free_gb") or 0) - 1.5, 0)
        if need > budget:
            warnings.append(
                f"预计需要约 {need:.1f}GB 显存，当前可用约 {budget:.1f}GB，**可能 OOM**。"
                "可先退出占显存的程序（本地模型/游戏）、减小批大小或上下文；"
                "也可以直接尝试——是否启动由你决定。"
            )
        elif need > budget * 0.85:
            warnings.append("显存较紧张，建议关闭其他占用显存的程序。")
    else:
        warnings.append("未检测到可用显卡，将走 CPU，速度会非常慢（建议仅用小档位体验流程）。")

    if block_size >= 4096:
        notes.append("长上下文会增加显存与耗时（实测 4096 比 1024 慢约 15%）。")

    return {"ok": not problems, "problems": problems, "warnings": warnings,
            "notes": notes, "vram_need_gb": round(need, 2),
            "budget_gb": round(budget, 2) if budget is not None else None,
            "over_budget": bool(budget is not None and need > budget)}

"""链接下载：用户粘贴 URL → 下载到项目内，供后续工位直接引用。

★为什么不用 engine/fetch_corpus.py：
  那个脚本只认预置的 HF 数据集仓库、且依赖 huggingface_hub（训练环境才有）。
  这里要的是「任意直链」，且工坊后端保持零第三方依赖，所以用标准库实现。
  两者互补：仓库分片下载仍用 fetch_corpus.py，单文件直链用本模块。

★安全边界：
  1. 只允许 http/https；拒绝 file://、ftp:// 等本地或未知协议。
  2. 拒绝指向本机/内网的地址（SSRF）：localhost、127.*、10.*、192.168.*、
     172.16-31.*、169.254.*、::1 等一律拒绝。工坊自己就跑在本机，
     不校验的话一个 URL 就能让它去读自己的接口甚至内网服务。
  3. 文件名只取 URL 路径末段并做严格清洗，禁止路径穿越；
     落盘目录固定在项目 downloads/ 内，绝不写到项目外。
  4. 先 inspect() 只读探测（HEAD/Range），把来源、体积、类型摆给用户看，
     用户确认后才 start()。不静默下载。
  5. 体积上限可设；超限拒绝，避免一个链接把磁盘写满。
  6. 下载写 .part 临时文件，完成才改名；中断可续传（Range）。

★所有提示返回 {k, v} 翻译键，界面按当前语言渲染。
"""
from __future__ import annotations

import ipaddress
import json
import os
import re
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from . import projects as P

IS_WIN = sys.platform == "win32"

UA = "LLM-Training-Workshop/0.3 (+local personal training tool)"
MAX_BYTES_DEFAULT = 200 * 1024 ** 3      # 单文件默认上限 200GB
CONNECT_TIMEOUT = 20
CHUNK = 1024 * 512
ALLOWED_SCHEMES = ("http", "https")

_JOBS: dict[str, dict] = {}
_LOCK = threading.Lock()


def _p(code: str, **v) -> dict:
    return {"k": code, "v": v}


def _is_private(host: str) -> bool:
    """本机/内网判定：先解析 DNS，再逐个 IP 判断，避免域名绕过。"""
    h = (host or "").strip().lower().rstrip(".")
    if not h:
        return True
    if h in ("localhost", "localhost.localdomain", "metadata",
             "metadata.google.internal"):
        return True
    try:
        infos = socket.getaddrinfo(h, None)
    except OSError:
        # 解析不了就当作不可信，交给后续请求自己报错
        return True
    for info in infos:
        addr = info[4][0]
        try:
            ip = ipaddress.ip_address(addr.split("%")[0])
        except ValueError:
            return True
        if (ip.is_private or ip.is_loopback or ip.is_link_local
                or ip.is_reserved or ip.is_multicast or ip.is_unspecified):
            return True
    return False


def check_url(url: str) -> tuple[str, list[dict]]:
    """返回 (规范化 URL, 问题列表)。空列表表示通过。"""
    raw = (url or "").strip().strip('"').strip("'")
    if not raw:
        return "", [_p("dl.noUrl")]
    try:
        u = urllib.parse.urlsplit(raw)
    except ValueError:
        return "", [_p("dl.badUrl")]
    if u.scheme.lower() not in ALLOWED_SCHEMES:
        return "", [_p("dl.scheme", s=u.scheme or "?")]
    if not u.hostname:
        return "", [_p("dl.badUrl")]
    if _is_private(u.hostname):
        return "", [_p("dl.private", h=u.hostname)]
    return urllib.parse.urlunsplit(u), []


def safe_name(url: str, fallback: str = "download.bin") -> str:
    """从 URL 取文件名并清洗；任何穿越/非法字符都剔掉。"""
    path = urllib.parse.urlsplit(url).path
    name = urllib.parse.unquote(path.rsplit("/", 1)[-1] or "")
    name = name.split("?")[0].split("#")[0]
    name = re.sub(r"[^A-Za-z0-9._\-\u4e00-\u9fff]", "_", name)
    name = name.lstrip(".") or fallback
    if len(name) > 120:
        stem, dot, ext = name.rpartition(".")
        name = (stem[:100] + dot + ext[:16]) if dot else name[:120]
    return name or fallback


def downloads_dir(project: str, dest: str = "") -> Path:
    """落盘目录。dest 非空时用用户指定位置，否则按项目/公共目录兜底。

    ★为什么允许无项目：用户的真实顺序常常是「先下语料，再建项目」，
      强制先建项目会把他卡在第一步。
    ★自定义位置的边界：必须是绝对路径；拒绝系统关键目录。
      用户主动选自己的盘/文件夹是正当需求（语料动辄几十 GB，
      不该被迫塞进程序目录），但不能让他一个手误写坏系统。
    """
    raw = (dest or "").strip().strip('"').strip("'")
    if raw:
        d = Path(raw)
        if not d.is_absolute():
            raise ValueError("保存位置必须是完整路径（例如 D:\\corpus）")
        bad = _forbidden_dest(d)
        if bad:
            raise ValueError(bad)
    else:
        name = (project or "").strip()
        base = P.project_dir(name) if name else (P.PROJECTS_DIR.parent / "downloads")
        d = base / "downloads" if name else base
    d.mkdir(parents=True, exist_ok=True)
    return d


def _forbidden_dest(d: Path) -> str:
    """拒绝把下载直接落进系统关键目录（返回原因，空串表示允许）。

    只拦「目录本身或其上层是系统目录」的情况；用户自己的
    D:\\corpus、E:\\data 之类一律放行。
    """
    try:
        rd = d.resolve()
    except OSError:
        return "保存位置无法解析，请检查路径"
    parts = [p.lower() for p in rd.parts]
    if IS_WIN:
        sysroot = Path(os.environ.get("SystemRoot") or r"C:\Windows").resolve()
        try:
            rd.relative_to(sysroot)
            return "不能保存到 Windows 系统目录内，请换一个位置"
        except ValueError:
            pass
        for guard in ("program files", "program files (x86)", "programdata",
                      "$recycle.bin", "system volume information"):
            if guard in parts:
                return f"不能保存到系统保护目录（{guard}）内，请换一个位置"
        # 盘根（如 D:\）本身允许，但 Windows 盘根下的系统目录已被上面拦住
    else:
        for guard in ("/etc", "/usr", "/bin", "/sbin", "/sys", "/proc", "/dev", "/boot"):
            if str(rd) == guard or str(rd).startswith(guard + "/"):
                return f"不能保存到系统目录（{guard}）内，请换一个位置"
    return ""


def _req(url: str, extra: dict | None = None):
    headers = {"User-Agent": UA, "Accept": "*/*"}
    if extra:
        headers.update(extra)
    r = urllib.request.Request(url, headers=headers)
    # 显式禁用代理自动探测带来的意外行为？保持默认（用户可能需要代理访问）
    return r


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    """★SSRF 重定向防护：每一跳都重新校验目标，拒绝跳转到内网/本机。

    旧实现只在 check_url 查一次 DNS，urlopen 默认跟随 302 不复查，公网 URL
    可被重定向到 localhost/内网/云元数据（审计指出）。这里逐跳拦截。
    """

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        nu = urllib.parse.urlsplit(newurl)
        if nu.scheme.lower() not in ALLOWED_SCHEMES:
            raise urllib.error.URLError(f"重定向到不允许的协议：{nu.scheme}")
        if not nu.hostname or _is_private(nu.hostname):
            raise urllib.error.URLError(f"重定向到内网/本机被拒绝：{nu.hostname}")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


# 带重定向校验的 opener；所有下载请求统一走它，不用默认 urlopen。
_SAFE_OPENER = urllib.request.build_opener(_SafeRedirect)


def _open(req, timeout=CONNECT_TIMEOUT):
    return _SAFE_OPENER.open(req, timeout=timeout)


def inspect(url: str, project: str, dest: str = "") -> dict:
    """只读探测：不下载正文，只取来源信息供用户确认。"""
    out = {"ok": False, "url": "", "host": "", "name": "", "size": None,
           "size_text": "", "type": "", "resumable": False,
           "problems": [], "warnings": [], "exists": False, "local_size": 0,
           "dir": "", "path": ""}
    norm, probs = check_url(url)
    if probs:
        out["problems"] = probs
        return out
    out["url"] = norm
    u = urllib.parse.urlsplit(norm)
    out["host"] = u.hostname or ""
    out["name"] = safe_name(norm)

    # 自定义位置非法时立刻拒绝，不要等下载才报错
    try:
        base = downloads_dir(project, dest)
    except (ValueError, OSError) as e:
        out["problems"].append(_p("dl.badDest", e=str(e)))
        return out
    out["dir"] = str(base)
    target = base / out["name"]
    out["path"] = str(target)
    out["exists"] = target.exists()
    out["local_size"] = target.stat().st_size if target.exists() else 0

    size, ctype, accept_ranges = None, "", ""
    try:
        # 用 Range: bytes=0-0 代替 HEAD：很多站点不支持 HEAD，
        # 但只要支持 Range 就能从 Content-Range 拿到总长度。
        r = _req(norm, {"Range": "bytes=0-0"})
        with _open(r) as resp:
            ctype = resp.headers.get("Content-Type", "") or ""
            accept_ranges = resp.headers.get("Accept-Ranges", "") or ""
            cr = resp.headers.get("Content-Range", "") or ""
            m = re.search(r"/(\d+)\s*$", cr)
            if m:
                size = int(m.group(1))
                out["resumable"] = True
            elif resp.status == 200:
                cl = resp.headers.get("Content-Length")
                if cl and cl.isdigit():
                    size = int(cl)
            if "bytes" in accept_ranges:
                out["resumable"] = True
            resp.read(1)
    except urllib.error.HTTPError as e:
        if e.code == 416:      # Range 不满足：文件可能为空，退回普通 GET 头
            try:
                with _open(_req(norm)) as resp:
                    cl = resp.headers.get("Content-Length")
                    size = int(cl) if cl and cl.isdigit() else None
                    ctype = resp.headers.get("Content-Type", "") or ""
                    resp.read(1)
            except Exception as e2:  # noqa: BLE001
                out["problems"].append(_p("dl.httpErr", c=str(getattr(e2, "code", "") or type(e2).__name__)))
                return out
        else:
            out["problems"].append(_p("dl.httpErr", c=str(e.code)))
            return out
    except Exception as e:  # noqa: BLE001
        out["problems"].append(_p("dl.netErr", e=type(e).__name__))
        return out

    out["size"] = size
    out["type"] = ctype
    if size is not None:
        out["size_text"] = _human(size)
        if size > MAX_BYTES_DEFAULT:
            out["problems"].append(_p("dl.tooBig", a=_human(size), b=_human(MAX_BYTES_DEFAULT)))
            return out
        if size == 0:
            out["warnings"].append(_p("dl.zero"))
    else:
        out["warnings"].append(_p("dl.unknownSize"))

    # 网页而非文件：多半是用户贴了页面地址而不是下载直链
    if ctype.startswith("text/html"):
        out["warnings"].append(_p("dl.html"))
    if out["exists"] and out["local_size"] and size and out["local_size"] == size:
        out["warnings"].append(_p("dl.same"))
    out["ok"] = True
    return out


def _human(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024.0
    return f"{n:.1f} TB"


def start(url: str, project: str, job_id: str | None = None,
          dest: str = "") -> dict:
    """开始下载（后台线程）。返回 job 快照；进度用 status() 查。"""
    chk = inspect(url, project, dest)
    if not chk["ok"]:
        return {"ok": False, "problems": chk["problems"]}
    jid = job_id or f"dl{int(time.time() * 1000)}"
    # 用探测阶段已校验过的路径，避免二次解析出现口径分歧
    target = Path(chk["path"])
    job = {
        "id": jid, "url": chk["url"], "name": chk["name"],
        "path": str(target), "total": chk["size"], "done": 0,
        "state": "running", "started": time.time(), "speed": 0.0,
        "problems": [], "resumable": chk["resumable"],
    }
    with _LOCK:
        # 同一目标已有在跑的任务就不重复开
        for j in _JOBS.values():
            if j["path"] == job["path"] and j["state"] == "running":
                return {"ok": True, "job": j, "reused": True}
        _JOBS[jid] = job
    threading.Thread(target=_run, args=(jid,), daemon=True).start()
    return {"ok": True, "job": _public(job)}


def _public(j: dict) -> dict:
    out = {k: j.get(k) for k in ("id", "url", "name", "path", "total", "done",
                                 "state", "speed", "problems", "resumable")}
    out["percent"] = round(j["done"] / j["total"] * 100, 1) if j.get("total") else None
    out["done_text"] = _human(j.get("done") or 0)
    out["total_text"] = _human(j["total"]) if j.get("total") else ""
    left = (j["total"] - j["done"]) if j.get("total") else None
    out["eta_sec"] = int(left / j["speed"]) if (left and j.get("speed")) else None
    return out


def _run(jid: str) -> None:
    with _LOCK:
        j = _JOBS.get(jid)
    if not j:
        return
    target = Path(j["path"])
    part = target.with_suffix(target.suffix + ".part")
    try:
        have = part.stat().st_size if part.exists() else 0
        headers = {}
        if have and j.get("resumable"):
            headers["Range"] = f"bytes={have}-"
        mode = "ab" if (have and j.get("resumable")) else "wb"
        if mode == "wb":
            have = 0
        j["done"] = have
        with _open(_req(j["url"], headers)) as resp:
            # 服务端忽略 Range 时会返回 200 全量，这时必须从头写
            if have and resp.status == 200:
                mode, have, j["done"] = "wb", 0, 0
            with part.open(mode) as f:
                last_t, last_b = time.time(), have
                while True:
                    with _LOCK:
                        if j.get("cancel"):
                            j["state"] = "cancelled"
                            return
                    buf = resp.read(CHUNK)
                    if not buf:
                        break
                    f.write(buf)
                    j["done"] += len(buf)
                    if j.get("total") and j["done"] > j["total"]:
                        j["state"] = "error"
                        j["problems"] = [_p("dl.exceed")]
                        return
                    if j["done"] > MAX_BYTES_DEFAULT:
                        j["state"] = "error"
                        j["problems"] = [_p("dl.tooBigRun", b=_human(MAX_BYTES_DEFAULT))]
                        return
                    now = time.time()
                    if now - last_t >= 0.5:
                        j["speed"] = (j["done"] - last_b) / (now - last_t)
                        last_t, last_b = now, j["done"]
        # 完成：校验体积再改名
        got = part.stat().st_size
        if j.get("total") and got != j["total"]:
            j["state"] = "error"
            j["problems"] = [_p("dl.sizeMismatch", a=_human(got), b=_human(j["total"]))]
            return
        part.replace(target)
        j["state"] = "done"
        j["speed"] = 0.0
        j["finished"] = time.time()
    except urllib.error.HTTPError as e:
        j["state"] = "error"
        j["problems"] = [_p("dl.httpErr", c=str(e.code))]
    except Exception as e:  # noqa: BLE001
        j["state"] = "error"
        j["problems"] = [_p("dl.netErr", e=type(e).__name__)]


def status(job_id: str = "") -> dict:
    with _LOCK:
        if job_id:
            j = _JOBS.get(job_id)
            return {"ok": bool(j), "job": _public(j) if j else None}
        items = [_public(j) for j in _JOBS.values()]
    items.sort(key=lambda x: x["id"], reverse=True)
    return {"ok": True, "items": items[:20]}


def cancel(job_id: str) -> dict:
    with _LOCK:
        j = _JOBS.get(job_id)
        if not j:
            return {"ok": False, "problems": [_p("dl.noJob")]}
        if j["state"] != "running":
            return {"ok": False, "problems": [_p("dl.notRunning")]}
        j["cancel"] = True
    return {"ok": True}


def list_files(project: str, dest: str = "") -> dict:
    try:
        d = downloads_dir(project, dest)
    except (ValueError, OSError) as e:
        return {"ok": False, "dir": "", "items": [],
                "problems": [_p("dl.badDest", e=str(e))]}
    items = []
    try:
        for p in sorted(d.iterdir(), key=lambda x: x.stat().st_mtime, reverse=True):
            if not p.is_file():
                continue
            st = p.stat()
            items.append({"name": p.name, "path": str(p), "size": st.st_size,
                          "size_text": _human(st.st_size), "mtime": st.st_mtime,
                          "partial": p.name.endswith(".part")})
    except OSError:
        pass
    return {"ok": True, "dir": str(d), "items": items}
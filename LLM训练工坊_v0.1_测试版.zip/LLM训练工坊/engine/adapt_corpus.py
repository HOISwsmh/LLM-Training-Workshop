# -*- coding: utf-8 -*-
"""adapt_corpus.py —— 多源语料字段适配层（把各类原始格式统一成 {"text": ...}）

★为什么必须有这一步（实测确认的坑）：
    clean_data.py 只认 obj["text"]。对没有 text 字段的记录，它会当作
    "多模态样本"原样透传（--keep-non-text 默认 True），清洗报告里计入
    "非文本记录透传"并算作保留；但 prepare_data.py 取不到 text，会当空
    样本丢弃。结果是：清洗看起来一切正常，最终 token 数为零。
    代码源的 content/code、问答源的 INSTRUCTION+RESPONSE 都会踩这个坑。

支持的输入格式：
    .jsonl / .json      逐行 JSON（也兼容单个大 JSON 数组，流式解析）
    .jsonl.gz / .gz     gzip 压缩的逐行 JSON
    .parquet            列式存储（需 pyarrow，已装）

支持的源类型（--kind）：
    skypile      text 直取
    wikipedia    text 直取，可选 --with-title 拼 title
    baike        title + summary + sections[].content 展平
    codeparrot   content -> text
    githubcode   code -> text（github-code-clean 用 code 列）
    zhihu        INSTRUCTION + "\n" + RESPONSE
    mnbvc_qa     中文键 问 + "\n" + 答
    mnbvc        text 直取（MNBVC 通用子集）
    classical    content -> text（gujilab 古籍）
    parallel     classical + "\n" + modern（古文今译平行语料）
    auto         按字段自动推断

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/adapt_corpus.py --kind codeparrot \
        --src corpus\\code\\*.jsonl.gz --dst data\\mix\\raw_code.jsonl
    python engine/adapt_corpus.py --kind zhihu \
        --src corpus\\qa\\*.parquet --dst ...\\raw_qa.jsonl
    python engine/adapt_corpus.py --kind auto --src ... --dst ... --probe
"""
from __future__ import annotations

import argparse
import glob
import gzip
import json
import sys
import time
from collections import Counter
from pathlib import Path


# ---------------------------------------------------------------- 提取器


def _s(v) -> str:
    """安全转字符串：None/非字符串一律返回空串。"""
    return v if isinstance(v, str) else ""


def ex_skypile(o: dict, args) -> str:
    return _s(o.get("text"))


def ex_wikipedia(o: dict, args) -> str:
    t = _s(o.get("text"))
    if args.with_title:
        title = _s(o.get("title"))
        if title and t:
            return title + "\n" + t
    return t


def ex_baike(o: dict, args) -> str:
    """百度百科：title + summary + sections[{title, content}] 展平。"""
    parts = []
    title = _s(o.get("title"))
    if title:
        parts.append(title)
    summary = _s(o.get("summary"))
    if summary:
        parts.append(summary)
    secs = o.get("sections")
    if isinstance(secs, list):
        for sec in secs:
            if isinstance(sec, dict):
                st = _s(sec.get("title"))
                sc = _s(sec.get("content"))
                if st and sc:
                    parts.append(st + "\n" + sc)
                elif sc:
                    parts.append(sc)
            elif isinstance(sec, str) and sec.strip():
                parts.append(sec)
    return "\n".join(parts)


def ex_codeparrot(o: dict, args) -> str:
    return _s(o.get("content"))


def ex_githubcode(o: dict, args) -> str:
    # github-code 用 content，github-code-clean 用 code
    return _s(o.get("code")) or _s(o.get("content"))


def ex_zhihu(o: dict, args) -> str:
    q = _s(o.get("INSTRUCTION")) or _s(o.get("instruction"))
    a = _s(o.get("RESPONSE")) or _s(o.get("response"))
    if q and a:
        return q + "\n" + a
    return a or q


def ex_mnbvc_qa(o: dict, args) -> str:
    """MNBVC 问答子集用中文键。"""
    q = _s(o.get("问")) or _s(o.get("问题"))
    a = _s(o.get("答")) or _s(o.get("回答"))
    if q and a:
        return q + "\n" + a
    return a or q or _s(o.get("text"))


def ex_mnbvc(o: dict, args) -> str:
    return _s(o.get("text"))


def ex_classical(o: dict, args) -> str:
    return _s(o.get("content")) or _s(o.get("text"))


def ex_parallel(o: dict, args) -> str:
    c = _s(o.get("classical"))
    m = _s(o.get("modern"))
    if c and m:
        return c + "\n" + m
    return c or m


def ex_auto(o: dict, args) -> str:
    """按字段优先级自动推断。"""
    for fn in (ex_skypile, ex_codeparrot, ex_githubcode,
               ex_zhihu, ex_mnbvc_qa, ex_classical, ex_parallel):
        t = fn(o, args)
        if t.strip():
            return t
    if "sections" in o or "summary" in o:
        return ex_baike(o, args)
    return ""


EXTRACTORS = {
    "skypile": ex_skypile, "wikipedia": ex_wikipedia, "baike": ex_baike,
    "codeparrot": ex_codeparrot, "githubcode": ex_githubcode,
    "zhihu": ex_zhihu, "mnbvc_qa": ex_mnbvc_qa, "mnbvc": ex_mnbvc,
    "classical": ex_classical, "parallel": ex_parallel, "auto": ex_auto,
}


# ---------------------------------------------------------------- 读取器


def iter_jsonl(path: Path):
    """逐行 JSON。兼容 gzip。坏行跳过并计数。"""
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8-sig", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                o = json.loads(line)
            except (json.JSONDecodeError, ValueError):
                yield None
                continue
            if isinstance(o, dict):
                yield o
            elif isinstance(o, str):
                yield {"text": o}
            else:
                yield None


def iter_json_array(path: Path, chunk_chars: int = 4 * 1024 * 1024):
    """流式解析大 JSON 数组（如百度百科 16.8GB 单文件）。

    不整体 json.load，避免内存爆掉。用括号深度扫描切出每个顶层对象。
    字符串内的括号与转义正确跳过。
    """
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8-sig", errors="replace") as fh:
        buf = ""
        depth = 0
        in_str = False
        esc = False
        started = False
        while True:
            chunk = fh.read(chunk_chars)
            if not chunk:
                break
            for ch in chunk:
                if not started:
                    # 跳过数组起始的 [ 与空白；也兼容逐行 JSON
                    if ch == "[":
                        started = True
                    elif ch in " \t\r\n,":
                        continue
                    else:
                        # 不是数组，回退为逐行模式
                        fh.close()
                        yield from iter_jsonl(path)
                        return
                    continue
                if in_str:
                    buf += ch
                    if esc:
                        esc = False
                    elif ch == "\\":
                        esc = True
                    elif ch == '"':
                        in_str = False
                    continue
                if ch == '"':
                    in_str = True
                    buf += ch
                elif ch == "{":
                    depth += 1
                    buf += ch
                elif ch == "}":
                    depth -= 1
                    buf += ch
                    if depth == 0:
                        try:
                            o = json.loads(buf)
                            yield o if isinstance(o, dict) else None
                        except (json.JSONDecodeError, ValueError):
                            yield None
                        buf = ""
                elif depth > 0:
                    buf += ch
                # depth==0 时的 , ] 空白直接忽略


def iter_parquet(path: Path, batch_rows: int = 2000):
    """流式读 parquet，按 batch 转 dict，内存恒定。"""
    import pyarrow.parquet as pq
    pf = pq.ParquetFile(str(path))
    for batch in pf.iter_batches(batch_size=batch_rows):
        for row in batch.to_pylist():
            yield row


def iter_records(path: Path):
    suf = path.suffix.lower()
    if suf == ".parquet":
        yield from iter_parquet(path)
    elif suf in (".jsonl", ".gz", ".json"):
        # .json 可能是大数组，先探首字符
        if suf == ".json":
            opener = open
            with opener(path, "rt", encoding="utf-8-sig", errors="replace") as fh:
                head = fh.read(64).lstrip()
            if head.startswith("["):
                yield from iter_json_array(path)
                return
        yield from iter_jsonl(path)
    else:
        raise ValueError(f"不支持的格式：{path.name}")


# ---------------------------------------------------------------- 主流程


def expand_src(patterns: list[str]) -> list[Path]:
    out: list[Path] = []
    for p in patterns:
        hits = sorted(glob.glob(p))
        if hits:
            out.extend(Path(h) for h in hits)
        else:
            pp = Path(p)
            if pp.exists():
                out.append(pp)
    # 去重保序
    seen, uniq = set(), []
    for p in out:
        k = str(p.resolve())
        if k not in seen:
            seen.add(k)
            uniq.append(p)
    return uniq


def parse_args(argv=None):
    ap = argparse.ArgumentParser(
        description="多源语料字段适配：统一成 {\"text\": ...} 的 jsonl",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--src", nargs="+", required=True,
                    help="输入文件或通配符，可多个（jsonl/json/jsonl.gz/parquet）")
    ap.add_argument("--dst", required=True, help="输出 jsonl")
    ap.add_argument("--kind", choices=sorted(EXTRACTORS), default="auto")
    ap.add_argument("--with-title", action="store_true",
                    help="wikipedia 类把 title 拼在正文前")
    ap.add_argument("--min-chars", type=int, default=1,
                    help="提取后短于此字符数的丢弃")
    ap.add_argument("--limit", type=int, default=0, help="每文件最多处理 N 条，0 为全量")
    ap.add_argument("--keep-fields", default="",
                    help="额外保留的字段，逗号分隔（如 license,language）")
    ap.add_argument("--probe", action="store_true",
                    help="只探测前若干条的字段结构，不写出")
    ap.add_argument("--probe-n", type=int, default=3)
    ap.add_argument("--progress-every", type=int, default=200000)
    return ap.parse_args(argv)


def probe(files: list[Path], args) -> int:
    for p in files:
        print("=" * 66)
        print(f"文件: {p.name}  ({p.stat().st_size / 1024 ** 2:.1f} MB)")
        n = 0
        try:
            for o in iter_records(p):
                if o is None:
                    print("  [坏行]")
                    continue
                print(f"  字段: {list(o.keys())}")
                t = EXTRACTORS[args.kind](o, args)
                print(f"  提取长度: {len(t)} 字符")
                print(f"  预览: {t[:120]!r}")
                n += 1
                if n >= args.probe_n:
                    break
        except Exception as e:                       # noqa: BLE001
            print(f"  [读取失败] {type(e).__name__}: {e}")
        if n == 0:
            print("  [!] 未读到任何记录")
    return 0


def main(argv=None) -> int:
    args = parse_args(argv)
    files = expand_src(args.src)
    if not files:
        print(f"[!] 没有匹配到任何输入文件：{args.src}")
        return 1

    if args.probe:
        return probe(files, args)

    dst = Path(args.dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    keep = [k.strip() for k in args.keep_fields.split(",") if k.strip()]
    extract = EXTRACTORS[args.kind]

    stat = Counter()
    per_file = []
    t0 = time.time()

    with dst.open("w", encoding="utf-8", newline="\n") as fout:
        for p in files:
            f_read = f_ok = 0
            try:
                for o in iter_records(p):
                    stat["read"] += 1
                    f_read += 1
                    if o is None:
                        stat["bad_record"] += 1
                        continue
                    text = extract(o, args)
                    if not isinstance(text, str) or not text.strip():
                        stat["empty_extract"] += 1
                        continue
                    if len(text) < args.min_chars:
                        stat["too_short"] += 1
                        continue
                    rec = {"text": text}
                    for k in keep:
                        if k in o:
                            rec[k] = o[k]
                    fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
                    stat["written"] += 1
                    f_ok += 1
                    if args.progress_every and stat["written"] % args.progress_every == 0:
                        print(f"    ... 已写出 {stat['written']:,} 条")
                    if args.limit and f_read >= args.limit:
                        break
            except Exception as e:                   # noqa: BLE001
                print(f"[!] {p.name} 读取中断：{type(e).__name__}: {e}")
                stat["file_error"] += 1
            per_file.append((p.name, f_read, f_ok))

    elapsed = time.time() - t0
    print("\n" + "=" * 66)
    print(f"源类型: {args.kind}   文件数: {len(files)}")
    for name, r, w in per_file:
        print(f"  {name:<44} 读{r:>9,} → 写{w:>9,}")
    print("-" * 66)
    print(f"读取记录    : {stat['read']:,}")
    print(f"写出记录    : {stat['written']:,}")
    print(f"坏记录      : {stat['bad_record']:,}")
    print(f"提取为空    : {stat['empty_extract']:,}")
    print(f"过短丢弃    : {stat['too_short']:,}")
    print(f"文件级错误  : {stat['file_error']:,}")
    lost = stat["read"] - stat["written"]
    if lost > 0:
        print(f"\n[!] ★有 {lost:,} 条未能写出（占 {lost / max(stat['read'], 1):.2%}）")
        print("    若 empty_extract 占多数，说明 --kind 选错或字段名不符，")
        print("    请用 --probe 查看真实字段后重跑。")
    else:
        print("\n[i] ✓ 全部记录成功转换，无静默丢失")
    size_mb = dst.stat().st_size / 1024 ** 2
    print(f"[i] 输出: {dst}  ({size_mb:.1f} MB)")
    print(f"[i] 耗时 {elapsed:.1f}s")
    print("=" * 66)
    return 0 if stat["written"] > 0 else 1


if __name__ == "__main__":
    sys.exit(main())

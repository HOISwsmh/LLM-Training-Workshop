# -*- coding: utf-8 -*-
"""mix_tokens.py —— 按 token 配比混合多类已打包语料

★为什么不能按文件体积配比：
    各类的压缩率与字节密度都不同（中文 3 字节/字符、代码约 1.05；
    实测压缩率 网页 0.588 / 百科 0.714 / 代码 0.659 / 问答 0.712）。
    按体积 50:20:15:15 混合，得到的 token 配比会严重偏离目标。
    本脚本一律以【token 数】为准。

★为什么要交错而不是首尾拼接：
    简单 concatenation 会让模型先学完一类再学下一类，破坏 i.i.d. 假设，
    造成灾难性遗忘。本脚本按 block 粒度轮转来源，保证局部多样性。

输入：各类 prepare_data.py 产出的 tokens_*.bin + data_meta.json
输出：混合后的 tokens_train.bin / tokens_val.bin / data_meta.json

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/mix_tokens.py \
        --source web=data\\mix\\web \
        --source wiki=data\\mix\\wiki \
        --source code=data\\mix\\code \
        --source qa=data\\mix\\qa \
        --ratio web=0.55,wiki=0.13,code=0.20,qa=0.12 \
        --target-tokens 60e9 --out-dir data\\final
    # 先看各类供给与缺口，不写出：
    python ... --dry-run
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np


def parse_size(s: str) -> int:
    """支持 60e9 / 60B / 2.5e9 / 1000000 等写法。"""
    s = s.strip().upper().replace("_", "")
    mult = 1.0
    if s.endswith("T"):
        mult, s = 1e12, s[:-1]
    elif s.endswith("B"):
        mult, s = 1e9, s[:-1]
    elif s.endswith("M"):
        mult, s = 1e6, s[:-1]
    elif s.endswith("K"):
        mult, s = 1e3, s[:-1]
    return int(float(s) * mult)


def parse_args(argv=None):
    ap = argparse.ArgumentParser(
        description="按 token 配比交错混合多类已打包语料",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--source", action="append", required=True, metavar="NAME=DIR",
                    help="类别名=数据目录（含 tokens_train.bin 与 data_meta.json），可多次")
    ap.add_argument("--ratio", required=True,
                    help="目标配比，如 web=0.55,wiki=0.13,code=0.20,qa=0.12")
    ap.add_argument("--target-tokens", default="60e9",
                    help="混合后训练集总 token 目标，支持 60e9/60B 写法")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--block-size", type=int, default=1024,
                    help="交错粒度：每多少个 token 轮换一次来源")
    ap.add_argument("--val-tokens", type=int, default=2_000_000,
                    help="验证集总 token 目标，按同一配比从各类 val 取")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--dry-run", action="store_true", help="只报告供给与缺口，不写出")
    ap.add_argument("--allow-insufficient", action="store_true",
                    help="某类不足时按实际量混合并重新归一化配比，而非报错")
    return ap.parse_args(argv)


def load_source(name: str, d: Path) -> dict:
    meta_p = d / "data_meta.json"
    train_p = d / "tokens_train.bin"
    if not meta_p.exists() or not train_p.exists():
        raise FileNotFoundError(f"{name}: {d} 下缺 data_meta.json 或 tokens_train.bin")
    meta = json.loads(meta_p.read_text(encoding="utf-8"))
    dtype = np.dtype(meta["dtype"])
    train = np.memmap(str(train_p), dtype=dtype, mode="r")
    val_p = d / "tokens_val.bin"
    val = np.memmap(str(val_p), dtype=dtype, mode="r") if val_p.exists() else None
    return {"name": name, "dir": d, "meta": meta, "dtype": dtype,
            "train": train, "val": val,
            "n_train": len(train), "n_val": len(val) if val is not None else 0}


def plan_sources(sources: dict, ratio: dict, target: int, allow_short: bool):
    """计算各类应取多少 token，处理供给不足。"""
    plan = {}
    short = {}
    for name, r in ratio.items():
        want = int(target * r)
        have = sources[name]["n_train"]
        take = min(want, have)
        plan[name] = take
        if take < want:
            short[name] = (want, have)

    if short and not allow_short:
        return plan, short, False

    if short and allow_short:
        # 按实际可取量重新归一化，尽量逼近目标总量
        total_have = sum(plan.values())
        if total_have < target:
            print(f"[!] 总供给 {total_have:,} < 目标 {target:,}，"
                  f"按实际供给混合（总量 {total_have:,}）")
    return plan, short, True


def interleave_indices(plan: dict, block: int, rng) -> list[tuple[str, int, int]]:
    """生成 (来源名, 起始偏移, 长度) 的交错序列。

    按各类剩余量加权轮转，保证整体比例接近目标且局部混合均匀。
    """
    remain = {k: v for k, v in plan.items() if v > 0}
    offsets = {k: 0 for k in remain}
    seq = []
    total = sum(remain.values())
    if total == 0:
        return seq

    # 用最大余额法决定每轮取谁，避免小类被大类淹没
    credit = {k: 0.0 for k in remain}
    while remain:
        tot = sum(remain.values())
        for k in list(remain):
            credit[k] += block * remain[k] / tot
        # 本轮挑信用最高者
        k = max(credit, key=lambda x: credit[x])
        n = min(block, remain[k])
        seq.append((k, offsets[k], n))
        offsets[k] += n
        remain[k] -= n
        credit[k] -= n
        if remain[k] <= 0:
            del remain[k]
            del credit[k]
    return seq


def write_mix(sources: dict, plan: dict, seq, out_path: Path, dtype) -> int:
    """按交错序列写出混合 bin。"""
    written = 0
    with out_path.open("wb") as fh:
        for name, off, n in seq:
            arr = sources[name]["train"][off:off + n]
            fh.write(np.asarray(arr, dtype=dtype).tobytes())
            written += n
    return written


def main(argv=None) -> int:
    args = parse_args(argv)
    target = parse_size(args.target_tokens)

    sources = {}
    for item in args.source:
        if "=" not in item:
            print(f"[!] --source 格式应为 NAME=DIR，收到：{item}")
            return 1
        name, d = item.split("=", 1)
        sources[name.strip()] = load_source(name.strip(), Path(d.strip()))

    ratio = {}
    for kv in args.ratio.split(","):
        if "=" not in kv:
            print(f"[!] --ratio 格式应为 name=frac，收到：{kv}")
            return 1
        k, v = kv.split("=", 1)
        ratio[k.strip()] = float(v)

    missing = set(ratio) - set(sources)
    if missing:
        print(f"[!] 配比里有未提供数据的类别：{sorted(missing)}")
        return 1
    s = sum(ratio.values())
    if abs(s - 1.0) > 1e-6:
        print(f"[i] 配比之和 {s:.6f} ≠ 1，自动归一化")
        ratio = {k: v / s for k, v in ratio.items()}

    # dtype 一致性检查
    dtypes = {v["dtype"].name for v in sources.values()}
    if len(dtypes) > 1:
        print(f"[!] 各类 dtype 不一致：{dtypes}，无法混合。请用同一分词器打包。")
        return 1
    dtype = next(iter(sources.values()))["dtype"]
    vocabs = {v["meta"].get("vocab_size") for v in sources.values()}
    if len(vocabs) > 1:
        print(f"[!] 各类 vocab_size 不一致：{vocabs}，必须用同一分词器。")
        return 1

    print("=" * 74)
    print(f"目标总量 {target:,} token   交错粒度 {args.block_size}   dtype {dtype.name}")
    print("-" * 74)
    print(f"{'类别':<10}{'目标占比':>9}{'目标token':>15}{'实际供给':>15}{'可取':>15}{'状态':>8}")

    plan, short, ok = plan_sources(sources, ratio, target, args.allow_insufficient)
    for name, r in ratio.items():
        want = int(target * r)
        have = sources[name]["n_train"]
        take = plan[name]
        flag = "OK" if take >= want else "不足"
        print(f"{name:<10}{r:>8.1%}{want:>15,}{have:>15,}{take:>15,}{flag:>8}")

    if short and not ok:
        print("-" * 74)
        print("[!] 以下类别供给不足：")
        for name, (want, have) in short.items():
            print(f"    {name}: 需 {want:,}，仅有 {have:,}（缺 {want - have:,}）")
        print("\n    处置：补下载该类语料，或降低其配比，")
        print("    或加 --allow-insufficient 按实际供给混合（总量会低于目标）。")
        print("=" * 74)
        return 2

    actual_total = sum(plan.values())
    print("-" * 74)
    print(f"{'合计':<10}{'100.0%':>9}{target:>15,}"
          f"{sum(v['n_train'] for v in sources.values()):>15,}{actual_total:>15,}")
    print("\n实际混合配比：")
    for name in ratio:
        print(f"    {name:<10} {plan[name] / max(actual_total, 1):>7.2%}  "
              f"({plan[name]:,} token)")

    if args.dry_run:
        print("\n[i] --dry-run：仅报告，未写出任何文件")
        print("=" * 74)
        return 0

    if not args.out_dir:
        print("[!] 非 dry-run 模式必须指定 --out-dir")
        return 1
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(args.seed)
    t0 = time.time()

    seq = interleave_indices(plan, args.block_size, rng)
    print(f"\n[i] 交错块数 {len(seq):,}，开始写出…")
    train_path = out_dir / "tokens_train.bin"
    written = write_mix(sources, plan, seq, train_path, dtype)

    # 验证集：按同配比从各类 val 取，同样交错
    val_plan = {}
    for name, r in ratio.items():
        want = int(args.val_tokens * r)
        val_plan[name] = min(want, sources[name]["n_val"])
    val_seq = interleave_indices(val_plan, args.block_size, rng)
    val_path = out_dir / "tokens_val.bin"
    val_written = 0
    with val_path.open("wb") as fh:
        for name, off, n in val_seq:
            arr = sources[name]["val"][off:off + n]
            fh.write(np.asarray(arr, dtype=dtype).tobytes())
            val_written += n

    meta = {
        "dtype": dtype.name,
        "itemsize": dtype.itemsize,
        "vocab_size": next(iter(sources.values()))["meta"].get("vocab_size"),
        "train_tokens": int(written),
        "val_tokens": int(val_written),
        "target_tokens": int(target),
        "block_size": args.block_size,
        "ratio_target": ratio,
        "ratio_actual": {k: plan[k] / max(actual_total, 1) for k in ratio},
        "per_source_tokens": {k: int(v) for k, v in plan.items()},
        "sources": {k: str(v["dir"]) for k, v in sources.items()},
        "seed": args.seed,
    }
    (out_dir / "data_meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    el = time.time() - t0
    print("-" * 74)
    print(f"[i] {train_path}  ({train_path.stat().st_size / 1024 ** 3:.2f} GB, {written:,} token)")
    print(f"[i] {val_path}  ({val_path.stat().st_size / 1024 ** 2:.1f} MB, {val_written:,} token)")
    print(f"[i] 耗时 {el:.1f}s")
    if written != actual_total:
        print(f"[!] ★写出 {written:,} 与计划 {actual_total:,} 不符，请检查")
        return 1
    print("[i] ✓ 写出量与计划一致")
    print("=" * 74)
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""HTTP 服务：只用 Python 标准库，零第三方依赖。

设计取舍：不引入 FastAPI/Flask，避免为做界面而安装一堆包、
也避免破坏用户已有的训练环境。路由手写，够用且完全离线。
"""
from __future__ import annotations

import csv
import json
import mimetypes
import re
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import download as DL
from . import hardware as H
from . import imports as IM
from . import paths as PA
from . import pipeline as PL
from . import projects as P
from . import reveal as RV
from . import sysstat as SS
from . import upgrade as UP
from . import watch as W

ROOT = PA.app_root()
WEB = PA.web_dir()


def _json_bytes(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8")


# ★与外部监控同样的缓存策略：1 秒轮询下不能每次全量解析。
#   实测训练全程约 3 万行时单次解析 62ms，每秒重解析等于长期占 CPU。
#   以 (路径, mtime, size, limit) 为键；日志一变键就变，新点仍会在下一秒出现。
_TRAIN_CACHE: dict = {}
_TRAIN_CACHE_MAX = 12


def read_train_log(project: str, limit: int = 6000) -> dict:
    """读训练 CSV，供前端画曲线。输出目录可能是用户自定义位置。"""
    p = P.output_dir(project) / "train_log.csv"
    if not p.exists():
        return {"points": [], "evals": [], "events": [], "latest": None}
    try:
        stt = p.stat()
        ck = (str(p), stt.st_mtime_ns, stt.st_size, limit)
    except OSError:
        ck = None
    if ck is not None and ck in _TRAIN_CACHE:
        return _TRAIN_CACHE[ck]
    points, evals, events = [], [], []
    try:
        with p.open(encoding="utf-8", newline="") as f:
            for r in csv.DictReader(f):
                ph = r.get("phase")
                if ph == "train":
                    points.append({
                        "step": int(r["step"] or 0),
                        "loss": float(r["loss"]) if r.get("loss") else None,
                        "ppl": float(r["ppl"]) if r.get("ppl") else None,
                        "lr": float(r["lr"]) if r.get("lr") else None,
                        "tok_s": float(r["tok_s"]) if r.get("tok_s") else None,
                        "vram": float(r["vram_gb"]) if r.get("vram_gb") else None,
                        "tokens": int(r["tokens_seen"] or 0),
                        "spikes": int(r["skipped_spikes"] or 0),
                        "rollbacks": int(r["rollbacks"] or 0),
                    })
                elif ph == "eval":
                    evals.append({"step": int(r["step"] or 0),
                                  "loss": float(r["loss"]) if r.get("loss") else None,
                                  "ppl": float(r["ppl"]) if r.get("ppl") else None})
                elif ph == "event":
                    events.append({"step": int(r["step"] or 0),
                                   "note": r.get("note", ""),
                                   "time": r.get("wall_time", "")})
    except (OSError, ValueError):
        pass
    full_n = len(points)
    last = points[-1] if points else None      # ★抽稀前先留住真正的最后一步
    if full_n > limit:
        step = full_n // limit + 1
        points = points[::step]
        # 抽稀可能把最后一点丢掉，导致步数与曲线落后于真实进度 → 补回来
        if last is not None and (not points or points[-1]["step"] != last["step"]):
            points.append(last)
    res = {"points": points, "evals": evals, "events": events[-20:],
           "latest": last, "count": full_n}
    if ck is not None:
        if len(_TRAIN_CACHE) >= _TRAIN_CACHE_MAX:
            _TRAIN_CACHE.clear()
        _TRAIN_CACHE[ck] = res
    return res


def list_checkpoints(project: str) -> dict:
    out = P.output_dir(project)
    items = []
    if out.exists():
        for c in sorted(out.iterdir()):
            if not c.is_dir():
                continue
            size = sum(f.stat().st_size for f in c.rglob("*") if f.is_file())
            st = c / "trainer_state.json"
            gstep = None
            if st.exists():
                try:
                    gstep = json.loads(st.read_text(encoding="utf-8")).get("global_step")
                except ValueError:
                    pass
            items.append({"name": c.name, "size_gb": round(size / 1024 ** 3, 2),
                          "step": gstep, "mtime": c.stat().st_mtime})
    cfg = P.load(project)["config"]
    backups = []
    bdir = (cfg.get("backup_dir") or "").strip()
    if bdir:
        b = Path(bdir) / out.name
        if b.exists():
            backups = [x.name for x in sorted(b.iterdir()) if x.is_dir()]
    return {"checkpoints": items, "backups": backups, "backup_dir": bdir}


def tail_log(project: str, stage: str, lines: int = 80) -> str:
    if not re.fullmatch(r"[a-z_]+", stage or ""):
        return ""
    p = P.project_dir(project) / "logs" / f"{stage}.log"
    if not p.exists():
        return ""
    try:
        with p.open(encoding="utf-8", errors="replace") as f:
            return "".join(f.readlines()[-lines:])
    except OSError:
        return ""


class Handler(BaseHTTPRequestHandler):
    server_version = "LLMWorkshop/1.0"

    def log_message(self, *a):  # 静音默认访问日志
        pass

    # ---------- 工具 ----------
    def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _ok(self, obj):
        self._send(200, _json_bytes({"ok": True, "data": obj}))

    def _err(self, msg: str, code: int = 400):
        self._send(code, _json_bytes({"ok": False, "error": str(msg)}))

    # ---------- 请求来源与体积防护 ----------
    # ★只监听 127.0.0.1 挡不住「网页驱动本地服务」：
    #   浏览器对 text/plain 的跨站 POST 视为简单请求、不做 preflight，
    #   任意网站都能让工坊起训练、写文件；DNS rebinding 还能绕过本机限制。
    #   这里三道一起上：Host 白名单 + Origin 校验 + 请求体上限。
    MAX_BODY = 1024 * 1024          # 1MB：配置/路径类请求远小于此

    def _host_ok(self) -> bool:
        """Host 必须是本机回环，挡 DNS rebinding（外部域名解析到 127.0.0.1）。"""
        host = (self.headers.get("Host") or "").strip().lower()
        if not host:
            return False
        name = host.rsplit(":", 1)[0] if not host.startswith("[") else host.split("]")[0] + "]"
        return name in ("127.0.0.1", "localhost", "[::1]", "::1")

    def _origin_ok(self) -> bool:
        """有 Origin 就必须是本机；没有 Origin 放行（命令行/脚本调用不带）。"""
        origin = (self.headers.get("Origin") or "").strip()
        if not origin or origin == "null":
            return origin != "null"     # file:// 页面的 Origin 是 null，拒绝
        try:
            u = urlparse(origin)
        except ValueError:
            return False
        if u.scheme not in ("http", "https"):
            return False
        return (u.hostname or "").lower() in ("127.0.0.1", "localhost", "::1")

    def _guard(self) -> bool:
        """统一门禁。不通过时已回 403，调用方直接 return。"""
        if not self._host_ok():
            self._err("拒绝访问：Host 不是本机地址", 403)
            return False
        if not self._origin_ok():
            self._err("拒绝访问：请求来源不是本工坊页面", 403)
            return False
        return True

    def _body(self) -> dict:
        raw_len = self.headers.get("Content-Length") or "0"
        try:
            n = int(raw_len)
        except ValueError:
            raise ValueError("请求长度不合法")
        if n < 0:
            raise ValueError("请求长度不合法")
        if n > self.MAX_BODY:
            raise ValueError("请求内容过大（上限 1MB）")
        if not n:
            return {}
        data = self.rfile.read(n)
        try:
            obj = json.loads(data.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}
        # 顶层必须是对象：数组/标量会让后续 .get() 抛异常
        return obj if isinstance(obj, dict) else {}

    # ---------- GET ----------
    def do_GET(self):  # noqa: N802
        if not self._guard():
            return
        u = urlparse(self.path)
        q = parse_qs(u.query)
        path = u.path
        try:
            if path in ("/", "/index.html"):
                f = WEB / "index.html"
                if not f.exists():
                    return self._send(500, b"web/index.html missing", "text/plain")
                return self._send(200, f.read_bytes(), "text/html; charset=utf-8")

            if path.startswith("/static/"):
                rel = path[len("/static/"):]
                if ".." in rel or rel.startswith("/"):
                    return self._err("bad path", 403)
                f = (WEB / rel).resolve()
                if WEB.resolve() not in f.parents or not f.is_file():
                    return self._err("not found", 404)
                ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
                if ctype.startswith("text/") or ctype in ("application/javascript",):
                    ctype += "; charset=utf-8"
                return self._send(200, f.read_bytes(), ctype)

            if path == "/api/hardware":
                hw = H.detect()
                return self._ok({"hardware": hw, "recommend": H.recommend(hw)})

            # ---- 顶栏小监控：CPU / 内存 / 显卡 占用与温度 ----
            # ★只读采样：CPU/内存走系统调用（各约 0.03ms），
            #   显卡读数按 1 秒 TTL 缓存，避免每次轮询都起子进程。
            if path == "/api/sysstat":
                return self._ok(SS.snapshot())

            if path == "/api/env":
                force = (q.get("force") or ["0"])[0] == "1"
                env = PA.detect_env(force=force)
                return self._ok({"env": env, "runtime": PA.describe()})

            # ---- 训练监控（只读，不干预任何训练） ----
            # 同时列出工坊自己的项目与用户登记的外部训练，按输出目录去重。
            if path == "/api/watch/list":
                items = W.list_all_runs()
                return self._ok({"items": [W.snapshot(x) for x in items]})

            if path == "/api/watch/one":
                name = (q.get("name") or [""])[0]
                it = next((x for x in W.list_all_runs() if x["name"] == name), None)
                if it is None:
                    return self._err("未找到该监控项")
                snap = W.snapshot(it)
                snap["tail"] = W.tail(it.get("log_file") or "", 80)
                return self._ok(snap)

            if path == "/api/watch/probe":
                # 填完输出目录即自动推断总步数/预算。只读，不注册、不写任何文件。
                return self._ok(W.probe((q.get("dir") or [""])[0],
                                        (q.get("log") or [""])[0]))

            if path == "/api/meta":
                return self._ok({
                    # 版本号唯一来源在 paths.VERSION，界面据此显示
                    "version": PA.VERSION,
                    "stages": [{"key": k, "name": n, "desc": d} for k, n, d in P.STAGES],
                    "kinds": PL.CORPUS_KINDS,
                    "groups": PL.STEP_GROUPS,
                    "levels": [
                        {"key": "loose", "name": "宽松", "desc": "保留更多，噪声也更多"},
                        {"key": "standard", "name": "标准", "desc": "推荐，按类型适配"},
                        {"key": "strict", "name": "严格", "desc": "只留高质量，可能损失较多"},
                    ],
                    "clean_bounds": PL.CLEAN_BOUNDS,
                    "clean_fields": [
                        {"key": "min_cjk_ratio", "name": "中文字符占比下限", "step": 0.05,
                         "hint": "低于此值的样本丢弃。代码类应设 0"},
                        {"key": "max_repeat_ratio", "name": "重复率上限", "step": 0.05,
                         "hint": "4-gram 重复率超过此值丢弃。代码类建议 ≥0.8"},
                        {"key": "max_symbol_ratio", "name": "符号占比上限", "step": 0.05,
                         "hint": "标点符号过多视为噪声"},
                        {"key": "min_chars", "name": "最短字符数", "step": 1,
                         "hint": "短于此值丢弃。古籍段落短，建议 8"},
                        {"key": "max_chars", "name": "最长字符数", "step": 1000,
                         "hint": "超长样本截断或丢弃，留空用默认"},
                        {"key": "max_digit_ratio", "name": "数字占比上限", "step": 0.05,
                         "hint": "纯数字表格类内容的过滤，留空用默认"},
                        {"key": "max_top_char_ratio", "name": "单字最高占比", "step": 0.05,
                         "hint": "某个字反复出现的刷屏文本，留空用默认"},
                    ],
                    "limits": H.LIMITS,
                    "tier_labels": H.TIER_LABEL,
                    "tier_lr": H.TIER_LR,
                    "tier_arch": H.TIER_ARCH,
                    "tier_vocab": H.TIER_VOCAB,
                    # ★不设上限：min 仅防止 0/负数导致无法建模，max 一律不限
                    "arch_fields": [
                        {"key": "hidden_size", "name": "隐层宽度", "step": 64, "min": 1,
                         "hint": "模型主干维度，越大越强也越吃显存。不限上限"},
                        {"key": "num_hidden_layers", "name": "层数", "step": 1, "min": 1,
                         "hint": "Transformer 块数量，决定深度。不限上限"},
                        {"key": "intermediate_size", "name": "前馈中间维度", "step": 64, "min": 1,
                         "hint": "SwiGLU 内部维度，通常约为隐层的 2.7–4 倍。不限上限"},
                        {"key": "head_dim", "name": "每头维度", "step": 32, "min": 1,
                         "hint": "常用 64 或 128。不限上限"},
                        {"key": "num_attention_heads", "name": "注意力头数", "step": 1, "min": 1,
                         "hint": "留空则自动 = 隐层宽度 ÷ 每头维度。不限上限"},
                        {"key": "num_key_value_heads", "name": "KV 头数（GQA）", "step": 1, "min": 1,
                         "hint": "留空自动取头数的 1/4；不能整除时自动下调"},
                    ],
                    "defaults": P.DEFAULT_CONFIG,
                    # 每个工位的导入规格：界面据此显示「自己生成／使用已有」
                    "import_specs": IM.IMPORT_SPECS,
                })

            if path == "/api/clean_preview":
                kind = (q.get("kind") or ["auto"])[0]
                level = (q.get("level") or ["standard"])[0]
                custom = {}
                raw = (q.get("custom") or [""])[0]
                if raw:
                    try:
                        custom = json.loads(raw)
                    except ValueError:
                        custom = {}
                params = PL.clean_params(kind, level, custom)
                return self._ok({"kind": kind, "level": level, "params": params,
                                 "warnings": PL.clean_warnings(kind, params)})

            if path == "/api/probe":
                p = Path((q.get("path") or [""])[0])
                if not p.exists():
                    return self._err("路径不存在")
                files = ([p] if p.is_file() else
                         sorted(x for x in p.rglob("*")
                                if x.is_file() and x.suffix in (".jsonl", ".json", ".parquet", ".gz")))
                if not files:
                    return self._err("该路径下没有 jsonl/json/parquet/gz 文件")
                size = sum(f.stat().st_size for f in files)
                return self._ok({"files": len(files), "size_gb": round(size / 1024 ** 3, 3),
                                 "sample": [f.name for f in files[:5]]})

            if path == "/api/projects":
                return self._ok({"projects": P.list_all(), "runner": PL.RUNNER.status()})

            if path == "/api/project":
                name = (q.get("name") or [""])[0]
                proj = P.load(name)
                # 附带训练集实际 token 数，供界面算进度与剩余时间
                mp = P.project_dir(name) / "data" / "final" / "data_meta.json"
                total = 0
                if mp.exists():
                    try:
                        total = int(json.loads(mp.read_text(encoding="utf-8")).get("train_tokens", 0))
                    except (ValueError, OSError):
                        total = 0
                proj["total_tokens"] = total
                proj["output_dir"] = str(P.output_dir(name, proj["config"]))
                proj["project_dir"] = str(P.project_dir(name))
                return self._ok(proj)

            if path == "/api/trainlog":
                name = (q.get("name") or [""])[0]
                return self._ok(read_train_log(name))

            if path == "/api/checkpoints":
                name = (q.get("name") or [""])[0]
                return self._ok(list_checkpoints(name))

            if path == "/api/log":
                name = (q.get("name") or [""])[0]
                stage = (q.get("stage") or [""])[0]
                return self._ok({"text": tail_log(name, stage)})

            return self._err("not found", 404)
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            return self._err(f"{type(e).__name__}: {e}", 500)

    # ---------- POST ----------
    def do_POST(self):  # noqa: N802
        if not self._guard():
            return
        u = urlparse(self.path)
        path = u.path
        try:
            b = self._body()
        except ValueError as e:
            return self._err(str(e), 413)
        try:
            # ---- 链接下载 ----
            # ★两段式：inspect 只读探测（不取正文），用户确认后才 start。
            #   协议/内网/体积/文件名校验不变；dest 允许用户自选保存位置，
            #   但必须是绝对路径且不能落在系统关键目录内。
            if path == "/api/download/inspect":
                return self._ok(DL.inspect(b.get("url", ""), b.get("project", ""),
                                           b.get("dest", "")))

            if path == "/api/download/start":
                return self._ok(DL.start(b.get("url", ""), b.get("project", ""),
                                         dest=b.get("dest", "")))

            if path == "/api/download/status":
                return self._ok(DL.status(b.get("id", "")))

            if path == "/api/download/cancel":
                return self._ok(DL.cancel(b.get("id", "")))

            if path == "/api/download/files":
                return self._ok(DL.list_files(b.get("project", ""), b.get("dest", "")))

            # ---- 在文件管理器中打开项目目录 ----
            # ★只接受 (项目名, 位置键)，真实路径由后端算，不接受任意路径。
            if path == "/api/reveal":
                return self._ok(RV.open_dir(b.get("name", ""), b.get("spot", "")))

            if path == "/api/projects/create":
                return self._ok(P.create(b.get("name", ""), b.get("config")))

            if path == "/api/projects/config":
                return self._ok(P.save_config(b.get("name", ""), b.get("config") or {}))

            if path == "/api/projects/delete":
                P.delete(b.get("name", ""))
                return self._ok({"deleted": b.get("name")})

            if path == "/api/check":
                hw = H.detect()
                # 只在字段缺失时兜底；0 是非法输入，必须原样交给校验函数拒绝
                bs = b.get("block_size")
                bs = 1024 if bs is None else int(bs)
                vs = b.get("vocab_size")
                vs = 32000 if vs is None else int(vs)
                bz = b.get("batch_size")
                bz = 1 if bz is None else int(bz)
                return self._ok(H.check_config(
                    b.get("tier", "base"), bs, hw,
                    arch=b.get("arch") or None, vocab_size=vs,
                    batch_size=bz))

            if path == "/api/import/check":
                # 校验用户填的导入路径：只读，不复制不改动任何东西
                return self._ok(IM.validate(b.get("stage", ""), b.get("path", "")))

            # ---------- 导入更新包 ----------
            # ★两段式：inspect 只读校验并把清单给用户看，apply 才写盘。
            #   训练在跑时一律拒绝：引擎文件被占用，换掉会让训练行为不可预期。
            if path == "/api/upgrade/inspect":
                return self._ok(UP.inspect(b.get("path", ""),
                                           running=PL.RUNNER.is_running()))

            # ★失败也走 _ok 返回结构化 problems（{k,v}），前端按当前语言渲染。
            #   若用 _err 拼中文字符串，切到英文时这几条就翻不了。
            if path == "/api/upgrade/apply":
                return self._ok(UP.apply(b.get("path", ""),
                                         running=PL.RUNNER.is_running()))

            if path == "/api/upgrade/backups":
                return self._ok({"items": UP.list_backups()})

            if path == "/api/upgrade/rollback":
                return self._ok(UP.rollback(b.get("id", ""),
                                            running=PL.RUNNER.is_running()))

            if path == "/api/run/start":
                # stages = 用户勾选的工位组合（优先于 group）
                PL.RUNNER.start(b.get("name", ""), b.get("from_stage"),
                                b.get("group"), stages=b.get("stages"))
                return self._ok(PL.RUNNER.status())

            if path == "/api/run/reset":
                # 重跑指定步骤：把状态清回 pending
                name = b.get("name", "")
                proj = P.load(name)
                st = proj["state"]
                if st.get("running"):
                    return self._err("项目正在运行，请先停止")
                keys = b.get("stages") or [k for k, _n, _d in P.STAGES]
                for k in keys:
                    if k in st["stages"]:
                        st["stages"][k] = {"status": "pending", "progress": 0.0,
                                           "message": "", "started_at": None,
                                           "finished_at": None}
                st["error"] = None
                P.save_state(name, st)
                return self._ok(st)

            if path == "/api/run/stop":
                PL.RUNNER.stop()
                return self._ok({"stopping": True})

            if path == "/api/run/pause":
                return self._ok(PL.RUNNER.pause(b.get("name", "")))

            if path == "/api/run/unpause":
                return self._ok(PL.RUNNER.cancel_pause(b.get("name", "")))

            if path == "/api/watch/add":
                return self._ok(W.add(
                    b.get("name", ""), b.get("out_dir", ""),
                    float(b.get("total_tokens") or 0),
                    int(b.get("total_steps") or 0),
                    b.get("log_file", "")))

            if path == "/api/watch/remove":
                W.remove(b.get("name", ""))
                return self._ok({"removed": b.get("name")})

            if path == "/api/env/set":
                raw = (b.get("python") or "").strip().strip('"')
                if not raw:
                    return self._err("请填写 python.exe 的完整路径")
                p = Path(raw)
                if not p.exists() or p.name.lower() not in ("python.exe", "python3.exe", "python"):
                    return self._err("路径不存在或不是 python 可执行文件")
                PA.set_python(str(p))
                env = PA.detect_env(force=True)
                if not env["ready"]:
                    return self._err("该环境缺少训练依赖（需要 torch/transformers/tokenizers/numpy），"
                                     "请先在其中安装后重试")
                return self._ok(env)

            return self._err("not found", 404)
        except ValueError as e:
            return self._err(str(e), 400)
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            return self._err(f"{type(e).__name__}: {e}", 500)


def serve(host: str = "127.0.0.1", port: int = 1220) -> ThreadingHTTPServer:
    httpd = ThreadingHTTPServer((host, port), Handler)
    return httpd

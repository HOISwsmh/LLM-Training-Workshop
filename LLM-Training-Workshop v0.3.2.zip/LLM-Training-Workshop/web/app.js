/* LLM Training Workshop — front-end logic.
   Zero dependencies; charts drawn on native canvas. Bilingual via i18n.js. */
'use strict';

const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));

const S = {
  meta: null, hw: null, rec: null,
  projects: [], current: null, proj: null, runner: null, env: null,
  form: { tier: null, clean: 'standard', save: 500, spike: true, corpus: [],
          arch: {}, archOpen: false, archOn: false, tie: true, logLang: 'zh',
          dlOpen: false },
  timer: null, dataLogStage: 'clean', trainLogStage: 'train',
  watchName: null, watchSnap: null, lastDone: false,
};

const DATA_STAGES = ['adapt', 'clean', 'tokenizer', 'pack', 'mix'];
const MIX_COLORS = ['#22d3ee', '#a78bfa', '#34d399', '#fbbf24', '#f87171', '#60a5fa', '#f472b6', '#4ade80'];

/* ---------------- net & ui helpers ---------------- */
/* ★错误也要能翻译：右下角红色提示以前直接抛英文
   （fetch 失败是浏览器原生的 "Failed to fetch"，兜底是 "request failed"，
     500 则是 "TypeError: ..."），中文界面看着突兀、英文界面也没走词典。
   这里统一把失败包成 Error，并挂上 {k,vars} 文案来源，
   toast 取 err.desc 渲染，于是切语言时红框也会跟着变。 */
function apiError(key, vars) {
  const e = new Error(key);
  e.desc = { k: key, vars: vars || null };
  return e;
}

// 取错误的可翻译来源：有 desc 用它，否则退回原始消息（渲染时仍过 sv）
function errDesc(e) {
  if (e && e.desc) return e.desc;
  return txRaw((e && e.message) || String(e == null ? '' : e));
}

async function api(path, body) {
  const opt = body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {};
  let r;
  try {
    r = await fetch(path, opt);
  } catch (e) {
    // 服务没起来 / 黑窗口被关 / 端口变了：浏览器只给英文原生消息
    const m = String((e && e.message) || '');
    throw apiError(/abort|timeout/i.test(m) ? 'net.timeout' : 'net.offline');
  }
  let j;
  try {
    j = await r.json();
  } catch (e) {
    throw apiError('net.badReply');
  }
  if (!j.ok) {
    const raw = j.error || '';
    // 后端未捕获异常形如 "ValueError: xxx"；剥掉类型名后原文仍可查词典
    const mm = /^([A-Za-z_][\w.]*(?:Error|Exception)):\s*([\s\S]*)$/.exec(raw);
    if (mm) throw apiError('net.serverError', { e: mm[2] || mm[1] });
    if (!raw) throw apiError('net.failed');
    const e = new Error(raw);
    e.desc = { raw };            // 后端中文原文 → 渲染时过 sv() 查词典
    throw e;
  }
  return j.data;
}

/* ---------------- 可实时重译的文案 ----------------
   ★问题：弹窗/横幅过去存的是"生成那一刻的字符串"，切语言后仍是旧语言。
   ★做法：存"文案来源"（键+变量，或后端原文），渲染时才按当前语言求值；
     切语言时把所有在显示的提示、确认框、横幅重新渲染一遍。
   变量值若是后端中文（如显存不足理由），求值时再过一次 sv()，
   这样整句连同其中的动态部分都会跟着语言变。 */
const LIVE = new Set();

// 文案来源：{k, vars} 走词典；{raw} 是后端原文；{parts:[...]} 用于拼接
function tx(k, vars) { return { k, vars: vars || null }; }
function txRaw(s) { return { raw: s == null ? '' : String(s) }; }
function txJoin(parts) { return { parts }; }

function txRender(d) {
  if (d == null) return '';
  if (typeof d === 'string') return sv(d);
  if (d.parts) return d.parts.map(txRender).join('');
  if (d.raw != null) return sv(d.raw);
  if (d.k) {
    // ★后端提示用 {k, v}，前端包装用 {k, vars}：两种都要认。
    //   只认 vars 会让后端提示的占位符填不上，界面露出 {p} 这类原文。
    const src = d.vars || d.v || {};
    const vars = {};
    Object.keys(src).forEach((key) => {
      const v = src[key];
      // 变量里的后端中文也要翻，数字/项目名原样保留
      vars[key] = (v && typeof v === 'object') ? txRender(v)
        : (typeof v === 'string' ? sv(v) : v);
    });
    return t(d.k, vars);
  }
  return '';
}

function liveAdd(el, desc, apply) {
  const item = { el, desc, apply };
  LIVE.add(item);
  return item;
}
function liveDrop(item) { if (item) LIVE.delete(item); }

// 切换语言时重译所有在显示的内容
function retranslateLive() {
  Array.from(LIVE).forEach((item) => {
    if (!item.el || !item.el.isConnected) { LIVE.delete(item); return; }
    item.apply(txRender(item.desc));
  });
}

function toast(msg, kind) {
  const el = document.createElement('div');
  el.className = 'toast ' + (kind || '');
  const desc = (msg && typeof msg === 'object') ? msg : txRaw(msg);
  el.textContent = txRender(desc);
  $('#toast').appendChild(el);
  const item = liveAdd(el, desc, (s) => { el.textContent = s; });
  setTimeout(() => {
    el.style.opacity = '0';
    setTimeout(() => { el.remove(); liveDrop(item); }, 300);
  }, 4600);
}

let _modalItem = null;
function confirmBox(title, text, extraHTML) {
  return new Promise((res) => {
    const dTitle = (title && typeof title === 'object') ? title : txRaw(title);
    const dText = (text && typeof text === 'object') ? text : txRaw(text);
    const paint = () => {
      $('#mTitle').textContent = txRender(dTitle);
      $('#mText').textContent = txRender(dText);
    };
    paint();
    $('#mExtra').innerHTML = extraHTML || '';
    $('#modal').classList.add('on');
    liveDrop(_modalItem);
    _modalItem = liveAdd($('#modal'), dText, paint);
    const done = (v) => {
      $('#modal').classList.remove('on');
      $('#mOk').onclick = null; $('#mCancel').onclick = null;
      liveDrop(_modalItem); _modalItem = null;
      res(v);
    };
    $('#mOk').onclick = () => done(true);
    $('#mCancel').onclick = () => done(false);
  });
}

const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const fmt = {
  n: (v) => (v == null ? '—' : Number(v).toLocaleString('en-US')),
  f: (v, d = 2) => (v == null ? '—' : Number(v).toFixed(d)),
  tok: (v) => {
    if (v == null) return '—';
    if (v >= 1e9) return (v / 1e9).toFixed(2) + 'B';
    if (v >= 1e6) return (v / 1e6).toFixed(1) + 'M';
    if (v >= 1e3) return (v / 1e3).toFixed(1) + 'K';
    return String(v);
  },
  /* 参数量单位：K/M/B/T/P 自动进位。
     ★与 token 计数不同，参数量要能一路显示到 P（千万亿）——
       自定义架构不设上限，用户真能填出天文数字，不能显示成 1e+21。 */
  params: (v) => {
    if (v == null || !isFinite(v)) return '—';
    const n = Number(v);
    if (n < 0) return '—';
    // 先按量级落到某一档，再看舍入后是否「够半格」需要升到上一级。
    // ★这样做是为了让显示与档位名一致：0.495B 按 M 显示是 495M，
    //   跟名字「0.5B」对不上；而 852,864 就该老老实实显示 853K，
    //   不能因为 0.85 接近 1 就跳成 0.85M（那反而看不出是百万以下）。
    const units = [[1e15, 'P'], [1e12, 'T'], [1e9, 'B'], [1e6, 'M'], [1e3, 'K'], [1, '']];
    let idx = units.length - 1;
    for (let i = 0; i < units.length; i++) {
      if (n >= units[i][0]) { idx = i; break; }
    }
    const fmtAt = (i) => {
      const x = n / units[i][0];
      const d = x >= 100 ? 0 : (x >= 10 ? 1 : 2);
      return parseFloat(x.toFixed(d));
    };
    let val = fmtAt(idx);
    // ★只在「本级四舍五入后正好等于 1000」时升一级（999,999 → 1M）。
    //   不做「够半格就升级」：那会把 852,864 变成 0.85M、999 变成 1K，
    //   反而看不出真实量级。0.5B 档由下面的整档对齐单独处理。
    if (idx > 0 && val >= 1000) { idx -= 1; val = fmtAt(idx); }
    return String(val) + units[idx][1];
  },
  eta: (sec) => {
    if (!sec || sec < 0 || !isFinite(sec)) return '—';
    if (sec < 3600) return Math.round(sec / 60) + ' ' + t('unit.min');
    if (sec < 86400) return (sec / 3600).toFixed(1) + ' ' + t('unit.hour');
    return (sec / 86400).toFixed(1) + ' ' + t('unit.day');
  },
  dur: (sec) => {
    if (!sec || sec < 0) return '—';
    if (sec < 60) return Math.round(sec) + ' ' + t('unit.sec');
    if (sec < 3600) return (sec / 60).toFixed(1) + ' ' + t('unit.min');
    if (sec < 86400) return (sec / 3600).toFixed(1) + ' ' + t('unit.hour');
    return (sec / 86400).toFixed(1) + ' ' + t('unit.day');
  },
};

const stageName = (k) => t('stage.' + k);
const kindName = (k) => t('kind.' + k);
const levelName = (k) => t('level.' + k);
const groupName = (k) => t('group.' + k);

/* ---------------- 后端直出文案的翻译 ----------------
   后端返回的描述/提示/工位消息是中文。中文界面原样显示；
   英文界面查表翻译，查不到就保留中文（绝不显示空白或键名）。 */
const SV = {
  '请求长度不合法': 'Invalid request length',
  '请求内容过大（上限 1MB）': 'Request too large (1MB limit)',
  '请填写训练输出目录': 'Enter the training output directory',
  'train_log.csv 无法解析': 'train_log.csv could not be parsed',
  '该目录下没有 train_log.csv，也未找到可用的控制台日志':
    'No train_log.csv in that directory, and no usable console log was found',
  '显存较紧张，建议关闭其他占用显存的程序。': 'VRAM is tight; consider closing other programs that use it.',
  '内存检测不可用': 'Memory detection unavailable',
  // ---- 后端直出的错误提示（固定串）----
  '请至少选择一个要执行的步骤': 'Select at least one step to run',
  '项目正在运行，请先停止再修改配置': 'The project is running — stop it before editing the config',
  '项目正在运行，请先停止': 'The project is running — stop it first',
  '路径校验失败，拒绝删除': 'Path check failed; deletion refused',
  '项目名只能包含中英文、数字、空格、点、下划线和连字符，且不超过 50 字':
    'Project names may contain letters, CJK characters, digits, spaces, dots, underscores and hyphens, up to 50 characters',
  '请填写监控名称': 'Enter a label for the run',
  '名称过长（最多 50 字）': 'Label too long (50 characters max)',
  '该目录已在监控列表中': 'That directory is already being watched',
  '训练输出目录尚未创建，请稍等再试': 'The training output folder does not exist yet — try again shortly',
  '保存位置必须是完整路径（例如 D:\\corpus）': 'Save location must be a full path (e.g. D:\\corpus)',
  // 语料类型描述
  '新闻、博客、论坛等长文本': 'Long-form news, blogs and forums',
  '维基百科、百度百科等结构化词条': 'Structured encyclopedia entries',
  '知乎、问答社区、指令数据': 'Q&A communities and instruction data',
  '维基文库、电子书、长篇文章': 'Wikisource, ebooks and long articles',
  '公版古籍，段落短、文言密度高': 'Public-domain classics; short paragraphs',
  '源码文件，中文占比为 0 属正常': 'Source code; zero CJK ratio is normal',
  '结构不确定的语料，按通用规则处理': 'Unknown structure; generic rules applied',
  // 分组描述
  '识别字段 + 清洗': 'Map fields + clean',
  '训词表 + 打包 + 混合': 'Tokenizer + pack + mix',
  '从原始语料到可训练数据': 'Raw corpus to trainable data',
  '用已有训练集开始/继续训练': 'Start or resume with an existing dataset',
  '对已训好的模型做生成与困惑度测试': 'Generation and perplexity test on a trained model',
  '一条流水线跑到底': 'Run the whole pipeline end to end',
  // 清洗强度描述
  '保留更多，噪声也更多': 'Keeps more, including more noise',
  '推荐，按类型适配': 'Recommended; per-type presets',
  '只留高质量，可能损失较多': 'High quality only; may drop a lot',
  // 清洗字段名
  '中文字符占比下限': 'Min CJK ratio',
  '重复率上限': 'Max repeat ratio',
  '符号占比上限': 'Max symbol ratio',
  '最短字符数': 'Min characters',
  '最长字符数': 'Max characters',
  '数字占比上限': 'Max digit ratio',
  '单字最高占比': 'Max single-char ratio',
  // 清洗字段提示
  '低于此值的样本丢弃。代码类应设 0': 'Drop samples below this. Use 0 for code',
  '4-gram 重复率超过此值丢弃。代码类建议 ≥0.8': 'Drop above this 4-gram repeat rate. Use >=0.8 for code',
  '标点符号过多视为噪声': 'Too much punctuation counts as noise',
  '短于此值丢弃。古籍段落短，建议 8': 'Drop shorter samples. Classics are short; 8 works',
  '超长样本截断或丢弃，留空用默认': 'Trim or drop overlong samples; empty = default',
  '纯数字表格类内容的过滤，留空用默认': 'Filters numeric tables; empty = default',
  '某个字反复出现的刷屏文本，留空用默认': 'Catches spam repeating one character; empty = default',
  // 架构字段名
  '隐层宽度': 'Hidden size',
  '层数': 'Layers',
  '前馈中间维度': 'FFN intermediate size',
  '每头维度': 'Head dimension',
  '注意力头数': 'Attention heads',
  'KV 头数（GQA）': 'KV heads (GQA)',
  // 导入规格
  '已识别的语料': 'Mapped corpus',
  '已清洗的语料': 'Cleaned corpus',
  '已有词表': 'Existing tokenizer',
  '已打包的 token 流': 'Packed token stream',
  '已整合的训练集': 'Mixed dataset',
  '已有模型/断点': 'Existing model / checkpoint',
  '待验证的模型': 'Model to evaluate',
  '已统一字段的 jsonl（每行含 text 字段）': 'jsonl with unified fields (text per line)',
  '清洗好的 jsonl，可跳过识别与清洗': 'Cleaned jsonl; skips mapping and cleaning',
  '含 tokenizer.json 的目录（会复制到项目内）': 'Folder with tokenizer.json (copied into the project)',
  '含 tokens_train.bin 与 data_meta.json 的目录（直接引用，不复制）':
    'Folder with tokens_train.bin and data_meta.json (referenced, not copied)',
  '检查点目录，或含 config.json 的模型目录；有 optimizer.pt 则连优化器状态一起接上':
    'A checkpoint folder, or a model folder with config.json; optimizer state is restored if optimizer.pt exists',
  '含 config.json 与权重的模型目录': 'Model folder with config.json and weights',
  // 常见工位消息
  '训练中…': 'Training...',
  '训练完成': 'Training finished',
  '词表已生成': 'Tokenizer created',
  '清洗完成': 'Cleaning finished',
  '用户停止': 'Stopped by user',
  '已暂停并保存断点，可点「继续训练」接着跑':
    'Paused and checkpoint saved; click Resume to continue',
  // 硬件警告与档位理由（后端直出）
  '需要 CUDA 显卡': 'A CUDA GPU is required',
  '未检测到可用的 NVIDIA 显卡，将使用 CPU 模式（极慢，仅供体验 15M 档）。':
    'No usable NVIDIA GPU detected; falling back to CPU mode (very slow, only fit for the 15M tier).',
  '显卡算力过低（需 RTX 20 系及以上），可能无法运行 GPU 训练。':
    'GPU compute capability is too low (RTX 20 series or newer required); GPU training may not run.',
  '内存检测不可用': 'Memory detection unavailable',
  // 配置校验：上下文与模型规模
  '上下文长度必须是正整数': 'Context length must be a positive integer',
  '显存较紧张，建议关闭其他占用显存的程序。':
    'VRAM is tight; consider closing other programs that use the GPU.',
  '未检测到可用显卡，将走 CPU，速度会非常慢（建议仅用小档位体验流程）。':
    'No usable GPU detected; CPU mode will be very slow (use a small tier just to try the workflow).',
  '长上下文会增加显存与耗时（实测 4096 比 1024 慢约 15%）。':
    'Longer context costs more VRAM and time (measured: 4096 is about 15% slower than 1024).',
  // 导入校验
  '请填写路径': 'Enter a path',
  '这里需要填一个文件，而不是文件夹': 'A file is required here, not a folder',
  '这里需要填一个文件夹，而不是文件': 'A folder is required here, not a file',
  '文件是空的': 'The file is empty',
  '首行不是 JSON 对象': 'The first line is not a JSON object',
  '首行没有 text 字段，可能不是已统一字段的语料':
    'The first line has no text field; this may not be a mapped corpus',
  '无法按 jsonl 读取首行，文件可能损坏或不是文本':
    'Could not read the first line as jsonl; the file may be corrupt or not text',
  '目录内既没有 config.json，也没有可用的 checkpoint-*':
    'The folder has neither config.json nor a usable checkpoint-*',
  '没有验证集 tokens_val.bin，训练中的困惑度评估会被跳过':
    'No tokens_val.bin; perplexity evaluation during training will be skipped',
  'tokenizer.json 无法解析出词表大小': 'Could not read the vocab size from tokenizer.json',
  'config.json 无法解析': 'Could not parse config.json',
  '目录里没有模型权重（model.safetensors 或 pytorch_model.bin）':
    'No model weights in the folder (model.safetensors or pytorch_model.bin)',
  '没有 optimizer.pt：只继承权重，优化器从零开始，学习率预热会重来，loss 可能短暂上跳':
    'No optimizer.pt: only weights are inherited, the optimizer starts fresh and warmup restarts, so loss may briefly jump',
  'data_meta.json 里训练 token 数为 0': 'data_meta.json reports zero training tokens',
  // 架构字段提示（界面通常走 i18n 键，这里兜底覆盖后端直出的情况）
  '模型主干维度，越大越强也越吃显存。不限上限':
    'Backbone width; larger is stronger and costs more VRAM. No upper limit.',
  'Transformer 块数量，决定深度。不限上限': 'Number of transformer blocks. No upper limit.',
  'SwiGLU 内部维度，通常约为隐层的 2.7–4 倍。不限上限':
    'SwiGLU inner dimension, usually 2.7-4x the hidden size. No upper limit.',
  '常用 64 或 128。不限上限': 'Commonly 64 or 128. No upper limit.',
  '留空则自动 = 隐层宽度 ÷ 每头维度。不限上限':
    'Leave empty to use hidden size / head dimension. No upper limit.',
  '留空自动取头数的 1/4；不能整除时自动下调':
    'Leave empty to use a quarter of the heads; lowered automatically if it does not divide evenly.',
  // 清洗风险提示
  '中文门槛过高，混合中英文的语料可能被大量丢弃':
    'The CJK threshold is high; mixed Chinese/English text may be dropped in bulk.',
  '代码的 4-gram 重复率中位数约 0.52，阈值低于此值会误杀约一半样本':
    'Code has a median 4-gram repeat rate near 0.52; a lower threshold would discard about half the samples.',
  '代码语料的中文占比通常为 0，中文门槛大于 0.05 可能滤掉绝大部分代码':
    'Code usually has zero CJK ratio; a threshold above 0.05 may filter out most of it.',
  '古籍段落中位数约 34 字，最短门槛过高会滤掉大量正常段落':
    'Classical paragraphs average about 34 characters; a high minimum would drop many valid ones.',
  '符号率上限过低，含公式或代码片段的文本容易被丢弃':
    'The symbol-ratio cap is low; text with formulas or code snippets is easily dropped.',
  '最短字数不小于最长字数，会导致所有样本被丢弃':
    'The minimum length is not below the maximum, so every sample would be dropped.',
  '隐层宽度/层数/中间维度取值很小，模型容量会非常有限':
    'Hidden size / layers / intermediate size are very small; model capacity will be limited.',
  // 硬件与内存
  '内存信息读取失败，不影响训练；显存与磁盘数据仍准确。':
    'Could not read memory info; training is unaffected and VRAM/disk figures are still accurate.',
  // 项目与运行状态
  '名称过长（最多 50 字）': 'Name is too long (50 characters max)',
  '项目名只能包含中英文、数字、空格、点、下划线和连字符，且不超过 50 字':
    'Project names may contain letters, Chinese characters, digits, spaces, dots, underscores and hyphens, up to 50 characters.',
  '项目正在运行，请先停止': 'The project is running; stop it first',
  '项目正在运行，请先停止再修改配置': 'The project is running; stop it before changing the configuration',
  '训练输出目录尚未创建，请稍等再试': 'The training output folder does not exist yet; try again shortly',
  '路径校验失败，拒绝删除': 'Path validation failed; deletion refused',
  '路径不存在': 'Path does not exist',
  '未找到该监控项': 'Monitor entry not found',
  '该目录已在监控列表中': 'This folder is already being monitored',
  '该路径下没有 jsonl/json/parquet/gz 文件': 'No jsonl/json/parquet/gz files under this path',
  '请填写监控名称': 'Enter a monitor name',
  '请填写 python.exe 的完整路径': 'Enter the full path to python.exe',
  '路径不存在或不是 python 可执行文件': 'The path does not exist or is not a python executable',
  '该环境缺少训练依赖（需要 torch/transformers/tokenizers/numpy），请先在其中安装后重试':
    'This environment lacks training dependencies (torch/transformers/tokenizers/numpy); install them and retry',
  '已请求暂停。训练会在当前步结束后保存断点再退出，请稍候。':
    'Pause requested. Training will save a checkpoint after the current step and then exit; please wait.',
  '本工具为单卡训练设计，不支持多卡/多机并行（多张卡只用第一张，不合并显存）。模型规模、上下文长度与显存需求**不设强制上限**：超出参考范围时只提示风险，是否尝试由你决定。它是面向个人开发者的实验性工具，请自行核对数据与许可。':
    'Built for single-GPU training; no multi-GPU or multi-node support (only the first GPU is used, VRAM is not pooled). Model size, context length and VRAM needs have no hard limits: going beyond the reference range only raises a warning, and the choice is yours. This is an experimental tool for individual developers; verify your data and licences yourself.',
};

// 后端消息里的中文工位名 → 工位 key，便于在英文提示中显示为英文工位名
const STAGE_BY_ZH = {
  '识别字段': 'adapt', '清洗': 'clean', '训练词表': 'tokenizer',
  '打包': 'pack', '整合': 'mix', '训练': 'train', '验证': 'test',
};

// 档位标签：后端返回中文，界面按当前语言取对应文案
const tierLabel = (k, fallback) => {
  const key = 'tierLabel.' + k;
  const v = t(key);
  return v === key ? (fallback || k) : v;
};

// 中文界面直接返回；英文界面查表，未收录保留中文
const sv = (s) => {
  if (!s) return s;
  // ★兼容结构化文案：后端 {k,v} 提示、前端 {k,vars}/{raw} 包装都从这里过。
  //   不加这层，调用点直接把对象丢进来就会显示成 [object Object]。
  //   txRender 内部对字符串又调回 sv，但此处只处理对象，不会无限递归。
  if (typeof s === 'object') return txRender(s);
  if (PREF.lang !== 'en') return s;
  if (SV[s] != null) return SV[s];
  // 带变量的消息：按中文句式匹配后回填数字
  const patterns = [
    // ---- 硬件体检直出的中文提示（带变量，必须逐条对齐原文）----
    [/^隐层宽度 (.+?) 不是每头维度 (.+?) 的整数倍，实际头数会取整为 (.+?)（可改用 (.+?) 更整齐）$/,
      (m) => `Hidden size ${m[1]} is not a multiple of head dim ${m[2]}; heads will be rounded to ${m[3]} (use ${m[4]} for a clean fit)`],
    [/^查询头数 (.+?) 不能被 KV 头数 (.+?) 整除，已自动下调为 (.+)$/,
      (m) => `Query heads ${m[1]} is not divisible by KV heads ${m[2]}; lowered to ${m[3]}`],
    [/^显卡已被其他程序占用约 (.+?)GB（可能是本地模型、游戏或另一个训练任务）。推荐规模按总显存计算；开训前体检会再核对当前剩余显存。$/,
      (m) => `About ${m[1]}GB of VRAM is already used by other programs (a local model, a game, or another training run). Recommendations use total VRAM; the pre-training check re-checks what is actually free.`],
    [/^检测到 (.+?) 张显卡，但本工具只使用第 1 张，不会合并多卡显存。$/,
      (m) => `Detected ${m[1]} GPUs, but this tool uses only the first one and does not pool VRAM.`],
    [/^上下文 (.+?) 很短，样本会被切得很碎，通常建议 ≥256$/,
      (m) => `Context ${m[1]} is very short and will chop samples into tiny pieces; ≥256 is usually advised`],
    [/^上下文 (.+?) 超出已验证范围（(.+?)）。本工具未内置 FlashAttention 与序列并行，注意力显存随长度平方增长，可能非常慢或直接 OOM。可以尝试，风险自负。$/,
      (m) => `Context ${m[1]} exceeds the validated range (${m[2]}). There is no built-in FlashAttention or sequence parallelism, and attention memory grows with the square of length — it may be very slow or OOM outright. You can try it at your own risk.`],
    [/^自定义架构：(.+?) 宽 × (.+?) 层，(.+?) 头（KV (.+?)），约 (.+?)B 参数$/,
      (m) => `Custom architecture: ${m[1]} wide × ${m[2]} layers, ${m[3]} heads (KV ${m[4]}), about ${m[5]}B params`],
    [/^模型约 (.+?)B，超出单卡舒适区参考值 (.+?)B。本工具不做模型切分，参数必须完整放进一张卡。可以尝试，风险自负。$/,
      (m) => `Model is about ${m[1]}B, beyond the single-GPU comfort reference of ${m[2]}B. This tool does not shard models — all parameters must fit on one card. You can try it at your own risk.`],
    [/^预计需要约 (.+?)GB 显存，当前可用约 (.+?)GB，\*\*可能 OOM\*\*。可先退出占显存的程序（本地模型\/游戏）、减小批大小或上下文；也可以直接尝试——是否启动由你决定。$/,
      (m) => `Estimated need is about ${m[1]}GB VRAM with only ${m[2]}GB free — **OOM is possible**. Close VRAM-heavy programs (local models/games), or reduce batch size or context; you can also just try it — the choice is yours.`],
    // ---- 后端直出的错误提示（带变量）----
    [/^项目「(.+?)」当前没有正在运行的任务$/, (m) => `Project "${m[1]}" has no running task`],
    [/^当前在「(.+?)」步骤，只有训练步骤支持暂停$/, (m) => `Currently at "${m[1]}"; only the training step can be paused`],
    [/^无法写入暂停标记：(.+)$/, (m) => `Could not write the pause flag: ${m[1]}`],
    [/^已有项目「(.+?)」在运行。本工具为单卡设计，一次只能训练一个项目。$/,
      (m) => `Project "${m[1]}" is already running. This is a single-GPU tool — only one project at a time.`],
    [/^未知步骤分组：(.+)$/, (m) => `Unknown step group: ${m[1]}`],
    [/^未知工位：(.+)$/, (m) => `Unknown stage: ${m[1]}`],
    [/^未知位置：(.+)$/, (m) => `Unknown location: ${m[1]}`],
    [/^项目「(.+?)」已存在$/, (m) => `Project "${m[1]}" already exists`],
    [/^项目「(.+?)」不存在$/, (m) => `Project "${m[1]}" does not exist`],
    [/^目录不存在：(.+)$/, (m) => `Directory not found: ${m[1]}`],
    [/^该目录下没有 train_log\.csv：(.+)$/, (m) => `No train_log.csv in that directory: ${m[1]}`],
    [/^无法读取日志：(.+)$/, (m) => `Could not read the log: ${m[1]}`],
    [/^名称「(.+?)」已存在$/, (m) => `Label "${m[1]}" already exists`],
    [/^未找到监控项「(.+?)」$/, (m) => `Watched run "${m[1]}" not found`],
    [/^未找到该监控项$/, () => 'Watched run not found'],
    // 显卡被其他程序占用
    [/^显卡已被其他程序占用约 ([\d.]+)GB（可能是本地模型、游戏或另一个训练任务）。推荐规模按总显存计算；开训前体检会再核对当前剩余显存。$/,
      (m) => `About ${m[1]}GB of VRAM is in use by other programs (a local model, a game, or another training job). The recommendation is based on total VRAM; the pre-flight check re-checks what is currently free.`],
    // 多卡提示
    [/^检测到 (\d+) 张显卡，但本工具只使用第 1 张，不会合并多卡显存。$/,
      (m) => `${m[1]} GPUs detected, but this tool only uses the first one; VRAM is not pooled.`],
    // 档位显存不足理由
    [/^约需 ([\d.]+)GB 显存，超出总显存参考预算 ([\d.]+)GB$/,
      (m) => `Needs about ${m[1]}GB VRAM, above the total-VRAM reference budget of ${m[2]}GB`],
    // 架构预估超限
    [/^预计需要约 ([\d.]+)GB 显存，当前可用约 ([\d.]+)GB，\*\*可能 OOM\*\*。$/,
      (m) => `Estimated ${m[1]}GB VRAM needed vs about ${m[2]}GB available — OOM is likely.`],
    [/^未检测到可用显卡，将走 CPU，速度会非常慢（建议仅用小档位体验流程）。$/,
      () => 'No usable GPU detected; CPU mode will be very slow (use a small tier just to try the workflow).'],
    // 配置校验：未知档位 / 上下文过短或超范围
    [/^未知的模型规模：(.+)$/, (m) => `Unknown model tier: ${m[1]}`],
    [/^上下文 (\d+) 很短，样本会被切得很碎，通常建议 ≥256$/,
      (m) => `A context of ${m[1]} is very short and will chop samples finely; 256 or more is usually better`],
    [/^上下文 (\d+) 超出已验证范围（(\d+)）。本工具未内置 FlashAttention 与序列并行，注意力显存随长度平方增长，可能非常慢或直接 OOM。可以尝试，风险自负。$/,
      (m) => `A context of ${m[1]} is beyond the verified range (${m[2]}). There is no FlashAttention or sequence parallelism here, and attention memory grows with the square of length, so it may be very slow or OOM. You can still try, at your own risk.`],
    // 自定义架构摘要
    [/^自定义架构：(\d+) 宽 × (\d+) 层，(\d+) 头（KV (\d+)），约 ([\d.]+)B 参数$/,
      (m) => `Custom architecture: ${m[1]} wide x ${m[2]} layers, ${m[3]} heads (KV ${m[4]}), about ${m[5]}B params`],
    // 模型超舒适区
    [/^模型约 ([\d.]+)B，超出单卡舒适区参考值 ([\d.]+)B。本工具不做模型切分，参数必须完整放进一张卡。可以尝试，风险自负。$/,
      (m) => `The model is about ${m[1]}B, above the single-GPU comfort reference of ${m[2]}B. There is no model sharding here, so all parameters must fit on one card. You can still try, at your own risk.`],
    // 显存不足补充建议
    [/^可先退出占显存的程序（本地模型\/游戏）、减小批大小或上下文；也可以直接尝试——是否启动由你决定。$/,
      () => 'You can close programs using VRAM (a local model or a game), lower the batch size or context, or just go ahead — starting is your call.'],
    // ★后端会把「可能 OOM」和上面那条建议拼成一句返回，需整句匹配
    [/^预计需要约 ([\d.]+)GB 显存，当前可用约 ([\d.]+)GB，\*\*可能 OOM\*\*。可先退出占显存的程序（本地模型\/游戏）、减小批大小或上下文；也可以直接尝试——是否启动由你决定。$/,
      (m) => `Estimated ${m[1]}GB VRAM needed vs about ${m[2]}GB available — OOM is likely. You can close programs using VRAM (a local model or a game), lower the batch size or context, or just go ahead — starting is your call.`],
    // 导入自动选断点
    [/^已自动选用最新断点 (.+)$/, (m) => `Automatically picked the latest checkpoint: ${m[1]}`],
    // 缺少必需文件 / 路径不存在
    [/^缺少必需文件：(.+)$/, (m) => `Missing required file: ${m[1]}`],
    [/^路径不存在：(.+)$/, (m) => `Path does not exist: ${m[1]}`],
    [/^只支持 (.+) 文件$/, (m) => `Only ${m[1]} files are supported`],
    // 项目名相关（含中文书名号包裹的名字）
    [/^项目「(.+)」不存在$/, (m) => `Project "${m[1]}" does not exist`],
    [/^项目「(.+)」已存在$/, (m) => `Project "${m[1]}" already exists`],
    [/^名称「(.+)」已存在$/, (m) => `The name "${m[1]}" already exists`],
    [/^项目「(.+)」当前没有正在运行的任务$/, (m) => `Project "${m[1]}" has no running task right now`],
    [/^已有项目「(.+)」在运行。本工具为单卡设计，一次只能训练一个项目。$/,
      (m) => `Project "${m[1]}" is already running. This tool is single-GPU, so only one project can train at a time.`],
    [/^当前在「(.+)」步骤，只有训练步骤支持暂停$/,
      (m) => `Currently at the "${stageName(STAGE_BY_ZH[m[1]] || m[1])}" stage; only the training stage can be paused`],
    [/^未找到监控项「(.+)」$/, (m) => `Monitor entry "${m[1]}" not found`],
    [/^未知工位：(.+)$/, (m) => `Unknown stage: ${m[1]}`],
    [/^未知步骤分组：(.+)$/, (m) => `Unknown step group: ${m[1]}`],
    [/^目录不存在：(.+)$/, (m) => `Folder does not exist: ${m[1]}`],
    [/^该目录下没有 train_log.csv：(.+)$/, (m) => `No train_log.csv in this folder: ${m[1]}`],
    [/^无法写入暂停标记：(.+)$/, (m) => `Could not write the pause flag: ${m[1]}`],
    [/^无法读取日志：(.+)$/, (m) => `Could not read the log: ${m[1]}`],
    [/^无法创建输出目录 (.+)：(.+)$/, (m) => `Could not create output folder ${m[1]}: ${m[2]}`],
    // 架构合法性提示
    [/^查询头数 (\d+) 不能被 KV 头数 (\d+) 整除，已自动下调为 (\d+)$/,
      (m) => `${m[1]} query heads are not divisible by ${m[2]} KV heads; lowered automatically to ${m[3]}`],
    [/^隐层宽度 (\d+) 不是每头维度 (\d+) 的整数倍，实际头数会取整为 (\d+)（可改用 (\d+) 更整齐）$/,
      (m) => `Hidden size ${m[1]} is not a multiple of head dimension ${m[2]}; head count rounds to ${m[3]} (using ${m[4]} would divide evenly)`],
    // 语料探测与导入结果
    [/^(.+) (\d+)MB\(导入\)$/, (m) => `${m[1]} ${m[2]}MB (imported)`],
    [/^第(\d+)类将用已清洗文件$/, (m) => `Entry ${m[1]} will use the cleaned file`],
    // 磁盘与引用
    [/^磁盘空间不足：约需 ([\d.]+)GB，剩余 ([\d.]+)GB$/,
      (m) => `Not enough disk space: about ${m[1]}GB needed, ${m[2]}GB free`],
    [/^已引用 (.+)（目录联接，未复制）$/, (m) => `Referencing ${m[1]} (directory junction, not copied)`],
    [/^已引用 (.+)（符号链接，未复制）$/, (m) => `Referencing ${m[1]} (symlink, not copied)`],
    [/^已复制 ([\d.]+)GB（系统不支持目录引用）$/, (m) => `Copied ${m[1]}GB (the system does not support directory references)`],
    [/^已指向该目录$/, () => 'Already pointing at this folder'],
    // 词表不一致（严重错误，必须让用户看懂）
    [/^词表内容不一致：要接续的模型用的是另一套分词器。直接续训会让所有 token 编号错位、模型权重作废。请把「训练词表」这一步改为导入该模型自带的词表：(.+)$/,
      (m) => `Tokenizer mismatch: the model you are resuming uses a different tokenizer. Continuing would misalign every token id and ruin the weights. Set the Tokenizer stage to import the model's own tokenizer: ${m[1]}`],
    [/^导入数据的词表大小是 (\d+)，但配置里填的是 (\d+)。两者必须一致，否则 token 编号错位、训练结果无意义。请把词表大小改成 (\d+)$/,
      (m) => `The imported data uses a vocab of ${m[1]} but the configuration says ${m[2]}. They must match, otherwise token ids are misaligned and training is meaningless. Set the vocab size to ${m[3]}`],
    [/^(\d+) 类语料共产出 ([\d.]+)MB$/, (m) => `${m[1]} corpus type(s), ${m[2]}MB produced`],
    [/^打包完成，合计约 ([\d,]+) token$/, (m) => `Packed about ${m[1]} tokens in total`],
    [/^训练集 ([\d,]+) token$/, (m) => `Dataset: ${m[1]} tokens`],
    [/^(\d+) 类已整合，训练集 ([\d,]+) token$/, (m) => `${m[1]} sources mixed, ${m[2]} tokens`],
    [/^就绪 ([\d,]+) token$/, (m) => `Ready: ${m[1]} tokens`],
    [/^沿用已导入的训练集，([\d,]+) token$/, (m) => `Using imported dataset, ${m[1]} tokens`],
    [/^沿用导入数据 ([\d,]+) token$/, (m) => `Using imported data: ${m[1]} tokens`],
    [/^第 ([\d,]+)\/([\d,]+) 步$/, (m) => `Step ${m[1]}/${m[2]}`],
    [/^(\d+)\/(\d+) 类已识别$/, (m) => `${m[1]}/${m[2]} types mapped`],
    [/^(\d+)\/(\d+) 类已清洗$/, (m) => `${m[1]}/${m[2]} types cleaned`],
    [/^(\d+)\/(\d+) 类已打包$/, (m) => `${m[1]}/${m[2]} types packed`],
    [/^验证完成（(.+)）$/, (m) => `Evaluation finished (${m[1]})`],
    [/^验证完成$/, () => 'Evaluation finished'],
    [/^已导入词表（(\d+) 个文件）$/, (m) => `Tokenizer imported (${m[1]} files)`],
    [/^已导入清洗语料：(.+)$/, (m) => `Cleaned corpus imported: ${m[1]}`],
    [/^已导入：(.+)$/, (m) => `Imported: ${m[1]}`],
    [/^已选用已有模型，从第 ([\d,]+) 步接上$/, (m) => `Existing model selected, resuming at step ${m[1]}`],
    [/^已选用已有模型$/, () => 'Existing model selected'],
    [/^全部语料已导入$/, () => 'All corpus entries imported'],
    [/^风险提示：(.+)$/, (m) => `Risk notice: ${m[1]}`],
  ];
  for (const [re, fn] of patterns) {
    const m = String(s).match(re);
    if (m) return fn(m);
  }
  return s;
};

/* ---------------- app ---------------- */
const App = {
  // 进入数据/训练页时若没选项目，自动挑一个：优先正在跑的，其次最近创建的
  async ensureCurrent() {
    if (S.current) return S.current;
    try {
      const d = await api('/api/projects');
      S.projects = d.projects; S.runner = d.runner;
      const list = d.projects || [];
      if (!list.length) return null;
      const running = (d.runner && d.runner.active)
        ? list.find((x) => x.name === d.runner.active) : null;
      const pick = running || list.find((x) => x.running)
        || list.slice().sort((a, b) => (b.created_at || 0) - (a.created_at || 0))[0];
      if (pick) { S.current = pick.name; S.lastDone = false; }
    } catch (e) { /* 拿不到列表就保持未选中，由各页显示空态 */ }
    return S.current;
  },

  // 点项目卡片时按进度决定去哪一页
  landingView(st) {
    if (!st || !st.stages) return 'data';
    if (st.running && st.current === 'train') return 'train';
    const s = st.stages;
    if (s.train && ['running', 'paused', 'done'].includes(s.train.status)) return 'train';
    if (s.mix && s.mix.status === 'done') return 'train';   // 数据就绪，具备训练条件
    return 'data';
  },

  async go(v) {
    $$('nav button').forEach((b) => b.classList.toggle('on', b.dataset.view === v));
    $$('.view').forEach((s) => s.classList.toggle('on', s.id === 'v-' + v));
    if (v === 'home') App.loadProjects();
    if (v === 'data') { await App.ensureCurrent(); App.renderPicker('data'); App.refreshData(); }
    if (v === 'train') { await App.ensureCurrent(); App.renderPicker('train'); App.refreshTrain(); }
    if (v === 'watch') App.refreshWatch();
    if (v === 'env') App.refreshEnv();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    // 视图刚显示，此刻才量得到画布尺寸 → 补画之前跳过的图
    requestAnimationFrame(() => Chart.flush());
  },

  // 页内项目下拉：随时切换，标注正在运行的那个
  renderPicker(which) {
    const box = $(which === 'train' ? '#trainPicker' : '#dataPicker');
    if (!box) return;
    const list = S.projects || [];
    if (!list.length) { box.innerHTML = ''; return; }
    const act = S.runner && S.runner.active;
    box.innerHTML = `<label>${t('pick.label')}</label>
      <select data-pick="${which}">${list.map((p) => {
        const run = p.name === act || p.running;
        return `<option value="${esc(p.name)}" ${p.name === S.current ? 'selected' : ''}>`
          + `${esc(p.name)}${run ? ' · ' + t('pick.running') : ''}</option>`;
      }).join('')}</select>`;
    const sel = box.querySelector('select');
    if (sel) {
      sel.onchange = async () => {
        S.current = sel.value; S.lastDone = false;
        if (which === 'train') await App.refreshTrain(); else await App.refreshData();
        requestAnimationFrame(() => Chart.flush());
      };
    }
  },

  rerenderAll() {
    // ★切换语言零位移的第二道保障：以视口内第一个可见区块为锚点。
    //   即使某些说明文字行数变化导致总高度变了，也能把该区块拉回原来的
    //   屏幕位置，用户看到的内容不会突然跳走。
    const anchor = App.pickAnchor();
    const restore = () => App.keepAnchor(anchor);
    applyLang();
    if (S.meta) {
      $('#limitNotice').innerHTML = '<b>' + t('about.limits') + '：</b>' + esc(sv(S.meta.limits.notice));
      App.paintVersion();          // 版本号的悬停说明也要跟随语言
      App.renderLimits(); App.renderAboutText(); App.renderCleanLevels();
      App.renderCorpus(); App.renderMixPreview(); App.renderArch(); App.renderImports();
    }
    if (S.rec) { App.renderTiers(); App.renderHwDetail(); }
    // ★顶栏小监控必须一起重绘：否则切语言后它仍显示旧语言。
    //   详情面板若正开着，也一并按新语言重建。
    App.paintMonitor();
    const _pop = $('#hwMonPop');
    if (_pop) { delete _pop.dataset.built; App.paintMonPop(); }
    // ★在显示的弹窗/确认框/校验横幅立即按新语言重译，
    //   不必等它自己消失或下次触发。
    retranslateLive();
    App.loadProjects();
    const cur = $$('nav button').find((b) => b.classList.contains('on'));
    const v = cur ? cur.dataset.view : 'home';
    if (v === 'data') App.refreshData();
    if (v === 'train') App.refreshTrain();
    if (v === 'watch') App.refreshWatch();
    if (v === 'env') App.refreshEnv();
    // ★更新面板是动态生成的，applyLang 管不到，必须显式重绘才能跟随语言
    App.paintUpgrade(); App.renderUpgBackups();
    // ★项目选择器同理：它的「当前项目 / 运行中」由 JS 生成，
    //   此前只在切页时绘制，切语言后一直停在旧语言（用户实测截图）。
    App.renderPicker('data'); App.renderPicker('train');
    updateSaveHint(); updateTokensHint(); App.syncVocabUI();
    App.renderDl();
    App.renderStepPick(S.proj && S.proj.state);
    // 同步重绘后先校正一次，异步刷新完成后再校正一次
    restore();
    requestAnimationFrame(restore);
    setTimeout(restore, 260);
  },

  // 取当前视口内最靠上的可见区块作为锚点
  pickAnchor() {
    const hdr = document.querySelector('header');
    const top = (hdr ? hdr.getBoundingClientRect().height : 0) + 8;
    const view = $$('.view').find((s) => s.classList.contains('on'));
    if (!view) return null;
    const blocks = Array.from(view.querySelectorAll('.card, .banner'));
    for (const el of blocks) {
      const r = el.getBoundingClientRect();
      if (r.bottom > top && r.height > 0) return { el, offset: r.top };
    }
    return null;
  },

  // 把锚点拉回原来的屏幕位置（只在确实偏移时才滚，避免无谓抖动）
  keepAnchor(a) {
    if (!a || !a.el || !a.el.isConnected) return;
    const now = a.el.getBoundingClientRect().top;
    const delta = now - a.offset;
    if (Math.abs(delta) < 2) return;
    const max = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
    const y = Math.min(max, Math.max(0, window.scrollY + delta));
    if (Math.abs(y - window.scrollY) >= 1) window.scrollTo({ top: y, behavior: 'auto' });
  },

  async loadMeta() {
    S.meta = await api('/api/meta');
    $('#limitNotice').innerHTML = '<b>' + t('about.limits') + '：</b>' + esc(sv(S.meta.limits.notice));
    App.paintVersion();
    App.renderLimits(); App.renderAboutText(); App.renderCleanLevels();
    if (!S.form.corpus.length) App.addCorpus();
    App.renderImports();
    // ★首屏必须渲染一次架构折叠按钮：它的文字由 JS 生成，
    //   而此前 loadMeta 不调用 renderArch，按钮就一直是空窄条，
    //   要等用户点一下才出现文字（用户实测的 bug）。
    App.renderArch();
  },

  // 左上角版本号。数值只来自后端 paths.VERSION，这里不写死，
  // 拿不到就留空（CSS 里 :empty 会隐藏，不会显示一个空壳标签）。
  paintVersion() {
    const el = $('#appVersion');
    if (el) {
      const v = (S.meta && S.meta.version) || '';
      el.textContent = v ? 'v' + v : '';
      if (v) el.title = t('hdr.version') + ' v' + v;
    }
    // 品牌名为稳定布局做了定宽截断，这里补上完整名称的悬停提示，信息不丢失
    const brand = document.querySelector('.brand-line > span:first-child');
    if (brand) brand.title = t('app.name');
  },

  renderLimits() {
    const L = S.meta.limits;
    $('#aboutLimits').innerHTML = `<table><tbody>
      <tr><td style="width:190px;color:var(--txt3)">${t('about.multiGpu')}</td>
        <td><span class="tag fail">${t('about.notSupported')}</span> ${t('about.multiGpuVal')}</td></tr>
      <tr><td style="color:var(--txt3)">${t('about.modelSize')}</td>
        <td><span class="tag idle">${t('about.advisory')}</span> ${t('about.modelSizeVal', { v: L.advisory_model_b })}</td></tr>
      <tr><td style="color:var(--txt3)">${t('about.ctx')}</td>
        <td><span class="tag idle">${t('about.advisory')}</span> ${t('about.ctxVal', { v: L.advisory_context })}</td></tr>
      <tr><td style="color:var(--txt3)">${t('about.vramGuard')}</td>
        <td><span class="tag idle">${t('about.advisory')}</span> ${t('about.vramGuardVal')}</td></tr>
      <tr><td style="color:var(--txt3)">${t('about.position')}</td><td>${t('about.positionVal')}</td></tr>
    </tbody></table>
    <div class="banner" style="margin:18px 0 0"><span class="bi">⚠</span><div>${esc(sv(L.notice))}</div></div>`;
  },

  renderAboutText() {
    $('#aboutText').innerHTML = ['p1', 'p2', 'p3', 'p4', 'p5']
      .map((k) => '<p>· ' + t('about.' + k) + '</p>').join('');
  },

  /* ---------------- 顶栏小监控：CPU / 内存 / 显卡 ----------------
     ★纯展示：不绑 click，不绑 keydown 动作，cursor 为 default。
       详情只由 CSS 的 :hover / :focus-visible 展开，点它不会发生任何事。
     ★结构建一次、之后原地改文字与条宽：数值每秒变化，
       重建 DOM 会让悬停中的详情面板闪断。 */
  monBar(seg, pct) {
    if (!seg) return;
    let bar = seg.querySelector('.bar');
    if (!bar) { bar = document.createElement('span'); bar.className = 'bar'; seg.appendChild(bar); }
    const p = pct == null ? 0 : Math.max(0, Math.min(100, pct));
    const w = p.toFixed(1) + '%';
    if (bar.style.width !== w) bar.style.width = w;
    const cls = 'mon-seg' + (p >= 90 ? ' hot' : (p >= 75 ? ' warn' : ''));
    if (seg.className !== cls) seg.className = cls;
  },

  monSet(id, txt, pct, title) {
    const seg = $('#' + id);
    if (!seg) return;
    const b = seg.querySelector('b');
    if (b && b.textContent !== txt) b.textContent = txt;
    App.monBar(seg, pct);
    if (title && seg.title !== title) seg.title = title;
  },

  paintMonitor() {
    const box = $('#hwMon');
    if (!box) return;
    const s = S.stat;
    const dot = $('#hwMonDot');
    if (!s) {
      App.monSet('monCpu', '—', null); App.monSet('monMem', '—', null); App.monSet('monGpu', '—', null);
      if (dot) dot.className = 'dot off';
      return;
    }
    const c = s.cpu || {}, m = s.mem || {}, g = s.gpu || {};
    const pc = (v) => v == null ? '—' : Math.round(v) + '%';
    App.monSet('monCpu', pc(c.percent), c.percent,
      t('hw.monCpuTitle', { v: c.percent == null ? '—' : fmt.f(c.percent, 1) }));
    App.monSet('monMem', pc(m.percent), m.percent,
      t('hw.monMemTitle', { a: m.used_gb == null ? '—' : fmt.f(m.used_gb, 1), b: fmt.f(m.total_gb, 1) }));
    if (g.present) {
      App.monSet('monGpu', pc(g.util), g.util,
        t('hw.monGpuTitle', { v: g.util == null ? '—' : Math.round(g.util), c: g.temp_c == null ? '—' : Math.round(g.temp_c) }));
    } else {
      App.monSet('monGpu', t('hw.noGpuShort'), null, t('hw.cpuMode'));
    }
    // 状态点取三者中最紧的一项：显存吃紧或温度过高就变色
    let lvl = '';
    const hot = (g.temp_c != null && g.temp_c >= 85) || (c.percent != null && c.percent >= 95);
    const warn = (m.percent != null && m.percent >= 85)
      || (g.mem_percent != null && g.mem_percent >= 90)
      || (g.temp_c != null && g.temp_c >= 78);
    if (hot) lvl = ' hot'; else if (warn) lvl = ' warn';
    if (dot && dot.className !== 'dot' + lvl) dot.className = 'dot' + lvl;
    App.paintMonPop();
  },

  // 详情面板：只在悬停/聚焦时才重绘内容，平时不构建 DOM
  paintMonPop() {
    const pop = $('#hwMonPop');
    const box = $('#hwMon');
    if (!pop || !box) return;
    const open = box.matches(':hover') || box.matches(':focus-within');
    if (!open && !pop.dataset.built) return;
    const s = S.stat;
    if (!s) { pop.innerHTML = `<div class="mp-foot">${t('hw.detecting')}</div>`; return; }
    const c = s.cpu || {}, m = s.mem || {}, g = s.gpu || {};
    const row = (k, v, cls) => `<div class="mp-row"><span class="mp-k">${esc(k)}</span>`
      + `<span class="mp-v${cls ? ' ' + cls : ''}">${esc(v)}</span></div>`;
    const na = t('hw.tempNa');
    const pct = (v) => v == null ? '—' : fmt.f(v, 1) + '%';
    const tempCls = (v) => v == null ? 'na' : (v >= 85 ? 'hot' : (v >= 78 ? 'warn' : ''));

    let h = '<div class="mp-blk">'
      + `<div class="mp-h cpu"><span class="mp-ic">▣</span>${t('hw.cpuBlock')}</div>`
      + `<div class="mp-name" title="${esc(c.name || '')}">${esc(c.name || t('hw.unknown'))}</div>`
      + '<div class="mp-grid">'
      + row(t('hw.usage'), pct(c.percent))
      + row(t('hw.cores'), c.cores == null ? '—' : String(c.cores))
      + row(t('hw.baseClock'), c.base_mhz == null ? '—' : (c.base_mhz / 1000).toFixed(2) + ' GHz')
      + row(t('hw.temp'), c.temp_c == null ? na : fmt.f(c.temp_c, 1) + ' °C', tempCls(c.temp_c))
      + '</div></div>';

    h += '<div class="mp-blk">'
      + `<div class="mp-h mem"><span class="mp-ic">▤</span>${t('hw.memBlock')}</div>`
      + '<div class="mp-grid">'
      + row(t('hw.usage'), pct(m.percent))
      + row(t('hw.used'), m.used_gb == null ? '—' : fmt.f(m.used_gb, 1) + ' GB')
      + row(t('hw.free'), m.free_gb == null ? '—' : fmt.f(m.free_gb, 1) + ' GB')
      + row(t('hw.total'), m.total_gb == null ? '—' : fmt.f(m.total_gb, 1) + ' GB')
      + '</div></div>';

    h += '<div class="mp-blk">'
      + `<div class="mp-h gpu"><span class="mp-ic">▦</span>${t('hw.gpuBlock')}</div>`;
    if (g.present) {
      h += `<div class="mp-name" title="${esc(g.name || '')}">${esc(g.name || t('hw.unknown'))}</div>`
        + '<div class="mp-grid">'
        + row(t('hw.usage'), pct(g.util))
        + row(t('hw.temp'), g.temp_c == null ? na : fmt.f(g.temp_c, 1) + ' °C', tempCls(g.temp_c))
        + row(t('hw.vramUsed'), g.mem_used_gb == null ? '—' : fmt.f(g.mem_used_gb, 1) + ' GB')
        + row(t('hw.vramTotal'), g.mem_total_gb == null ? '—' : fmt.f(g.mem_total_gb, 1) + ' GB')
        + row(t('hw.vramPct'), pct(g.mem_percent))
        + row(t('hw.power'), g.power_w == null ? na
          : fmt.f(g.power_w, 0) + (g.power_limit_w ? ' / ' + fmt.f(g.power_limit_w, 0) : '') + ' W')
        + row(t('hw.fan'), g.fan_percent == null ? na : Math.round(g.fan_percent) + '%')
        + row(t('hw.clock'), g.clock_mhz == null ? na : Math.round(g.clock_mhz) + ' MHz')
        + '</div>';
      if (g.count > 1) h += `<div class="mp-foot">${t('hw.multiGpu', { n: g.count })}</div>`;
    } else {
      h += `<div class="mp-foot">${t('hw.cpuMode')}</div>`;
    }
    h += '</div>';
    h += `<div class="mp-foot">${t('hw.monFoot')}`
      + (c.temp_state === 'unavailable' ? ' ' + t('hw.tempWhy') : '') + '</div>';
    if (pop.innerHTML !== h) pop.innerHTML = h;
    pop.dataset.built = '1';
  },

  async loadStat() {
    if (S._statBusy) return;
    S._statBusy = true;
    try {
      S.stat = await api('/api/sysstat');
      App.paintMonitor();
    } catch (e) { /* 采样失败保留上次数值，不打扰用户 */ }
    S._statBusy = false;
  },

  async loadHardware() {
    const d = await api('/api/hardware');
    S.hw = d.hardware; S.rec = d.recommend;
    App.renderHwDetail(); App.renderTiers();
  },

  renderHwDetail() {
    if (!S.hw) return;
    const h = S.hw;
    const box = $('#hwDetail');
    // ★结构只建一次，之后原地改文字：硬件每 5 秒刷新一次，
    //   若每次重建 DOM，悬停提示会闪丢、数字会跳。
    if (!box.querySelector('.metrics')) {
      box.innerHTML = `
      <div class="metrics">
        <div class="metric c1"><div class="mk" id="hwMkGpu"></div>
          <div class="mv" id="hwMvGpu" style="font-size:15px"></div></div>
        <div class="metric c2"><div class="mk" id="hwMkVram"></div>
          <div class="mv" id="hwMvVram"></div></div>
        <div class="metric c3"><div class="mk" id="hwMkRam"></div>
          <div class="mv" id="hwMvRam"></div></div>
        <div class="metric c4"><div class="mk" id="hwMkRec"></div>
          <div class="mv" id="hwMvRec" style="font-size:17px"></div></div>
      </div>
      <div id="hwWarns"></div>
      <div class="hint" id="hwDisk" style="margin-top:14px"></div>`;
    }
    const set = (id, html) => { const e = $('#' + id); if (e && e.innerHTML !== html) e.innerHTML = html; };
    // ★截断的格子一律写 title：格子窄、型号长时显示省略号，悬停看全称。
    const setT = (id, html, title) => {
      const e = $('#' + id);
      if (!e) return;
      if (e.innerHTML !== html) e.innerHTML = html;
      const ti = title || e.textContent || '';
      if (e.title !== ti) e.title = ti;
    };
    // 可用/上限：无显卡时显存显示 0.0 / 0.0 GB，标签注明走 CPU
    set('hwMkGpu', t('home.gpu'));
    setT('hwMvGpu', h.gpu ? esc(h.gpu.replace('NVIDIA ', '')) : t('home.noGpu'),
      h.gpu || t('home.noGpu'));
    set('hwMkVram', h.cuda_available ? t('home.vram') : t('home.vramCpu'));
    set('hwMvVram', `${fmt.f(h.vram_free_gb, 1)}<span class="mu"> / ${fmt.f(h.vram_total_gb, 1)} GB</span>`);
    set('hwMkRam', t('home.ram'));
    set('hwMvRam', `${fmt.f(h.ram_free_gb, 1)}<span class="mu"> / ${fmt.f(h.ram_total_gb, 1)} GB</span>`);
    set('hwMkRec', t('home.rec'));
    set('hwMvRec', S.rec && S.rec.recommended ? esc(tierLabel(S.rec.recommended, S.meta.tier_labels[S.rec.recommended])) : t('home.cpuOnly'));
    const _warnHtml = (h.warnings || []).map((w) => `<div class="banner" style="margin:16px 0 0"><span class="bi">⚠</span><div>${esc(sv(w))}</div>`).join('');
    set('hwWarns', _warnHtml);
    const _diskHtml = `${t('home.disk')}: ${h.disks.map((d) => `${d.drive} ${d.free_gb}GB`).join(' | ')} ${t('home.cpuCores')} ${h.cpu_count}${h.driver ? ' ' + t('home.driver') + ' ' + esc(h.driver) : ''}`;
    set('hwDisk', _diskHtml);
  },

  renderTiers() {
    if (!S.rec) return;
    const box = $('#tierList');
    // ★结构只建一次（含点击委托），之后原地改文字与类名：
    //   硬件每 5 秒刷新会重算推荐，若每次重建 DOM，悬停与选中态会闪丢。
    if (!box.querySelector('.tier')) {
      box.innerHTML = S.rec.tiers.map((x) => `
      <div class="tier" data-tier="${x.tier}">
        <div class="tn"></div><div class="tp"></div><div class="tv"></div>
        <span class="badge"></span>
      </div>`).join('');
      box.onclick = (ev) => {
        const el = ev.target.closest('.tier');
        if (!el) return;
        const x = S.rec.tiers.find((y) => y.tier === el.dataset.tier);
        S.form.tier = el.dataset.tier;
        // ★换档位时把词表输入框同步到该档默认值（除非用户手动改过）：
        //   不同档位词表不同（1M=2048、15M=8192、3B=49152），
        //   留着上一档的值会让自定义面板的参数量与卡片对不上。
        if (!S.form.vocabTouched) {
          const tv = (S.meta && S.meta.tier_vocab) || {};
          const ve = $('#fVocab');
          if (ve && tv[S.form.tier]) ve.value = tv[S.form.tier];
          App.syncVocabUI();
        }
        // ★传文案来源而非成品字符串：切语言时整句连同显存理由一起重译
        if (x && !x.fits) {
          toast(tx('tier.riskToast', { r: x.reason ? txRaw(x.reason) : tx('tier.risk') }), 'err');
        }
        App.renderTiers(); App.renderArch();
        $('#tierWarn').textContent = '';
      };
    }
    // ★显存按「当前训练参数」算：批大小/上下文/精度一改，卡片跟着变。
    //   后端下发的 vram_need_gb 是固定基线口径，只做兜底与推荐排序用。
    const budget = S.rec.budget_gb || 0;
    let bestFit = null;
    S.rec.tiers.forEach((x) => {
      const el = box.querySelector(`.tier[data-tier="${x.tier}"]`);
      if (!el) return;
      const on = S.form.tier === x.tier;
      const need = App.tierVram(x.tier);
      const fits = !S.rec.cpu_only && need <= budget;
      if (fits) bestFit = x.tier;
      // 推荐标记改按当前参数判定，否则会出现「推荐」却显示风险
      const isRec = x.tier === (S.rec.recommended || '') && fits;
      el.className = `tier ${on ? 'on' : ''} ${fits ? '' : 'risk'}`;
      const set = (sel, txt) => { const e = el.querySelector(sel); if (e && e.textContent !== txt) e.textContent = txt; };
      set('.tn', tierLabel(x.tier, x.label));
      // ★卡片标题已是量级名（如「0.5B · 入门」），第二行给精确值，
      //   两者互补：标题好认、精确值可核对。495M 就是 0.495B 的真实参数量。
      //   当前档若启用了自定义架构，参数量也跟随自定义结构。
      const params = (S.form.archOn && on) ? App.archEstimate().params : x.params;
      set('.tp', fmt.params(params));
      const tv = el.querySelector('.tv');
      const txt = '~' + need + ' GB';
      if (tv && tv.textContent !== txt) tv.textContent = txt;
      if (tv) tv.title = t('tier.vramBasis', { b: App.trainParams().batch, s: App.trainParams().block, d: App.trainParams().dtype });
      const badge = el.querySelector('.badge');
      const bCls = `badge ${fits ? (isRec ? 'rec' : 'ok') : 'no'}`;
      const bTxt = fits ? (isRec ? t('tier.rec') : t('tier.ok')) : t('tier.risk');
      if (badge.className !== bCls) badge.className = bCls;
      if (badge.textContent !== bTxt) badge.textContent = bTxt;
    });
    if (!S.form.tier && bestFit) { S.form.tier = bestFit; App.renderTiers(); return; }
    const warn = S.rec.cpu_only ? t('tier.cpuWarn')
      : t('tier.liveNote', { b: App.trainParams().batch, s: App.trainParams().block, d: App.trainParams().dtype });
    const wEl = $('#tierWarn');
    if (wEl.innerHTML !== warn) wEl.innerHTML = warn;
  },

  /* ---------------- custom architecture ---------------- */
  archBase() {
    const k = S.form.tier || 'base';
    return (S.meta.tier_arch || {})[k] || { hidden_size: 768, num_hidden_layers: 12, intermediate_size: 2944 };
  },

  archEffective() {
    const base = App.archBase(), a = {};
    ['hidden_size', 'num_hidden_layers', 'intermediate_size', 'head_dim',
      'num_attention_heads', 'num_key_value_heads'].forEach((k) => {
      const v = S.form.arch[k];
      a[k] = (v == null || v === '') ? base[k] : v;
    });
    a.tie_embeddings = S.form.tie;
    return a;
  },

  /* 当前生效的训练参数：显存估算要用真实值，不能再拿固定基线糊弄。
     批大小/上下文/精度直接决定激活与权重占用；梯度累积不增加峰值显存
     （它是串行跑多个微批再累加），所以只影响每步 token 数，不进显存公式。 */
  trainParams() {
    const num = (sel, dft) => {
      const el = $(sel);
      const v = el ? parseInt(el.value, 10) : NaN;
      return isFinite(v) && v > 0 ? v : dft;
    };
    const dt = $('#fDtype');
    return {
      batch: num('#fBatch', 4),
      block: num('#fCtx', 1024),
      accum: num('#fAccum', 4),
      dtype: (dt && dt.value) === 'fp32' ? 'fp32' : 'bf16',
    };
  },

  archEstimate() {
    const a = App.archEffective();
    const h = +a.hidden_size || 768, L = +a.num_hidden_layers || 12;
    const inter = +a.intermediate_size || 2944, hd = +a.head_dim || 64;
    const heads = +a.num_attention_heads || Math.max(Math.floor(h / hd), 1);
    // ★KV 分组跟随档位：7B 档是完整注意力（kv_groups=1），
    //   一律按 heads/4 算会把 7B 算成 6.2B，与卡片上的 7.01B 对不上。
    const base = App.archBase();
    const kvDiv = +base.kv_groups || 4;
    let kv = +a.num_key_value_heads || Math.max(Math.floor(heads / kvDiv), 1);
    const kvRaw = kv;
    kv = Math.max(1, Math.min(kv, heads));
    while (heads % kv !== 0 && kv > 1) kv -= 1;
    // ★词表跟随档位默认值：1M 档是 2048、15M 档 8192、3B 档 49152，
    //   写死 32000 会让小档的面板数字远大于卡片（1M 档差 3.8M 参数）。
    //   用户手动改过词表输入框时以输入框为准。
    const vocab = App.effectiveVocab();
    const attn = h * heads * hd + 2 * h * kv * hd + heads * hd * h;
    const total = vocab * h * (a.tie_embeddings ? 1 : 2) + L * (attn + h * inter * 3 + 2 * h) + h;
    const probs = [];
    if (!a.num_attention_heads && h % hd !== 0) probs.push(`${h} % ${hd} != 0 → heads=${heads}`);
    if (a.num_key_value_heads && heads % kvRaw !== 0) probs.push(`heads ${heads} % kv ${kvRaw} != 0 → kv=${kv}`);
    // 显存：与引擎 estimate_memory / 后端 estimate_vram 同一套公式与系数
    const tp = App.trainParams();
    const mem = App.vramBreakdown(total, L, h, vocab, tp);
    return { params: total, b: total / 1e9, heads, kv, vram: mem.total, probs,
      vocab, batch: tp.batch, block: tp.block, accum: tp.accum, dtype: tp.dtype,
      weights: mem.weights, grads: mem.grads, opt: mem.opt, act: mem.act };
  },

  /* 显存分解：卡片与自定义面板共用，保证两处永远一致。
     ★系数与引擎 estimate_memory 同源（3B 定版实测反解 k≈4.6，取 5.0 留余量）。
     ★梯度累积不进公式：它串行跑多个微批再累加，不抬高峰值显存，
       只影响每步 token 数；把它算进显存会虚高好几倍。 */
  vramBreakdown(total, layers, hidden, vocab, tp) {
    const wb = tp.dtype === 'fp32' ? 4 : 2;
    const weights = total * wb / 1024 ** 3;
    const grads = total * wb / 1024 ** 3;
    const opt = total * 0.031 / 1024 ** 3;          // Adafactor（本工具默认）
    const act = Math.max(0.3,
      layers * tp.batch * tp.block * hidden * 5.0 / 1024 ** 3
      + tp.batch * tp.block * vocab * 6 / 1024 ** 3);
    return { weights, grads, opt, act,
      total: +(weights + grads + opt + act).toFixed(2) };
  },

  /* 某个档位在「当前训练参数」下的显存。
     卡片上的 ~X GB 以前来自后端的固定基线，不随批大小/上下文/精度变化；
     现在按真实参数算，与自定义面板同源。 */
  tierVram(tier) {
    const tv = (S.meta && S.meta.tier_vocab) || {};
    const ta = (S.meta && S.meta.tier_arch) || {};
    const a = ta[tier];
    const x = (S.rec && S.rec.tiers || []).find((y) => y.tier === tier);
    if (!a || !x) return x ? x.vram_need_gb : 0;
    const vocab = S.form.vocabTouched ? App.effectiveVocab() : (tv[tier] || 32000);
    // 未启用自定义架构时，卡片按该档预设结构算；启用了则只有当前档跟着自定义走
    let h = +a.hidden_size, L = +a.num_hidden_layers, inter = +a.intermediate_size;
    let hd = 64, kvDiv = +a.kv_groups || 4, tie = true;
    if (S.form.archOn && S.form.tier === tier) {
      const e = App.archEffective();
      h = +e.hidden_size || h; L = +e.num_hidden_layers || L; inter = +e.intermediate_size || inter;
      hd = +e.head_dim || 64; tie = e.tie_embeddings !== false;
      const heads = +e.num_attention_heads || Math.max(Math.floor(h / hd), 1);
      let kv = +e.num_key_value_heads || Math.max(Math.floor(heads / kvDiv), 1);
      kv = Math.max(1, Math.min(kv, heads));
      while (heads % kv !== 0 && kv > 1) kv -= 1;
      const attn = h * heads * hd + 2 * h * kv * hd + heads * hd * h;
      const total = vocab * h * (tie ? 1 : 2) + L * (attn + h * inter * 3 + 2 * h) + h;
      return App.vramBreakdown(total, L, h, vocab, App.trainParams()).total;
    }
    const heads = Math.max(Math.floor(h / hd), 1);
    let kv = Math.max(Math.floor(heads / kvDiv), 1);
    kv = Math.max(1, Math.min(kv, heads));
    while (heads % kv !== 0 && kv > 1) kv -= 1;
    const attn = h * heads * hd + 2 * h * kv * hd + heads * hd * h;
    const total = vocab * h * (tie ? 1 : 2) + L * (attn + h * inter * 3 + 2 * h) + h;
    return App.vramBreakdown(total, L, h, vocab, App.trainParams()).total;
  },

  /* 词表取值：用户动过输入框就用它，否则用当前档位的默认词表。
     ★不能直接读输入框：切换档位时输入框可能还留着上一档的值，
       那会让面板参数量与卡片对不上（本次 bug 的根因）。 */
  effectiveVocab() {
    const el = $('#fVocab');
    const tierVocab = (S.meta && S.meta.tier_vocab) || {};
    const dft = tierVocab[S.form.tier] || 32000;
    if (!el) return dft;
    const v = parseInt(el.value, 10);
    if (!isFinite(v) || v <= 0) return dft;
    return S.form.vocabTouched ? v : dft;
  },

  /* ---------------- 打开模型目录 ----------------
     ★只传位置键，真实路径由后端算，前端不拼路径。 */
  async reveal(spot, name) {
    const proj = name || S.current;
    if (!proj) { toast(tx('rv.needProject'), 'err'); return; }
    // ★一次点击 = 一个窗口，由后端保证：已开着就切到前台，没开才新开。
    //   这里不再做时间节流——那会让第二次点击毫无反应，反而更像坏了。
    //   只挡「同一位置的请求还在飞」时重复提交，避免并发开出两个窗口。
    const key = proj + '|' + spot;
    S._revealPending = S._revealPending || new Set();
    if (S._revealPending.has(key)) return;
    S._revealPending.add(key);
    try {
      const d = await api('/api/reveal', { name: proj, spot });
      if (!d.ok) {
        toast(txJoin((d.problems || []).map((m) => ({ raw: App.upgMsg(m) }))), 'err');
        return;
      }
      // 复用已有窗口时如实说明，避免用户以为又开了一个
      toast(tx(d.reused ? 'rv.reused' : 'rv.opened'), 'ok');
    } catch (e) { toast(errDesc(e), 'err'); }
    finally { S._revealPending.delete(key); }
  },

  // 外部训练不由工坊管理，没有项目键可用；这里只复制路径并提示，
  // 不提供“打开任意路径”的能力，避免把后端变成通用文件浏览器。
  async revealExternal() {
    const s = S.watchSnap;
    if (!s || !s.out_dir) { toast(tx('rv.needProject'), 'err'); return; }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(s.out_dir);
        toast(tx('rv.copied'), 'ok');
        return;
      }
    } catch (e) { /*  clipboard 不可用时退回提示 */ }
    toast(tx('rv.copyManually', { p: s.out_dir }), 'err');
  },

  /* ---------------- 步骤多选 ----------------
     ★用户可勾选任意工位组合；执行顺序由后端按标准顺序重排，
       避免先打包后训词表这种必然失败的顺序。 */
  renderStepPick(st) {
    const box = $('#stepPick');
    if (!box || !S.meta) return;
    const keys = S.meta.stages.map((s) => s.key);
    S.picked = S.picked || new Set();
    if (!box.querySelector('.sp-grid')) {
      box.innerHTML = `<div class="sp-grid">` + S.meta.stages.map((s) => `
        <label class="sp-item" data-k="${s.key}">
          <input type="checkbox" data-sp="${s.key}">
          <span class="sp-tx"><b>${esc(stageName(s.key))}</b><i>${esc(sv(s.desc))}</i></span>
          <span class="sp-st" data-spst="${s.key}"></span>
        </label>`).join('') + `</div>
        <div class="btn-row" style="margin-top:12px">
          <button class="btn sm" id="spAll">${t('sp.all')}</button>
          <button class="btn sm" id="spData">${t('sp.dataOnly')}</button>
          <button class="btn sm" id="spNone">${t('sp.none')}</button>
          <button class="btn primary sm" id="spRun">${t('sp.run')}</button>
        </div>
        <div class="hint" id="spHint" style="margin-top:10px"></div>
        <div class="hint sp-busy" id="spBusy" style="margin-top:8px;display:none"></div>`;
      box.addEventListener('change', (ev) => {
        const cb = ev.target.closest('input[data-sp]');
        if (!cb) return;
        if (cb.checked) S.picked.add(cb.dataset.sp); else S.picked.delete(cb.dataset.sp);
        App.paintStepPick();
      });
      const pick = (arr) => {
        S.picked = new Set(arr);
        box.querySelectorAll('input[data-sp]').forEach((c) => { c.checked = S.picked.has(c.dataset.sp); });
        App.paintStepPick();
      };
      $('#spAll').onclick = () => pick(keys);
      $('#spData').onclick = () => pick(DATA_STAGES);
      $('#spNone').onclick = () => pick([]);
      $('#spRun').onclick = () => App.runPicked();
    }
    // 状态与语言原地更新
    keys.forEach((k) => {
      const item = box.querySelector(`.sp-item[data-k="${k}"]`);
      if (!item) return;
      const tx1 = item.querySelector('.sp-tx');
      const b = tx1.querySelector('b'), i = tx1.querySelector('i');
      const nm = stageName(k);
      if (b.textContent !== nm) b.textContent = nm;
      const meta = S.meta.stages.find((x) => x.key === k);
      const ds = sv(meta.desc);
      if (i.textContent !== ds) i.textContent = ds;
      const s = (st && st.stages && st.stages[k]) || { status: 'pending' };
      const badge = item.querySelector('.sp-st');
      const cls = 'sp-st ' + s.status;
      if (badge.className !== cls) badge.className = cls;
      const lbl = t('sp.st.' + (s.status || 'pending'));
      if (badge.textContent !== lbl) badge.textContent = lbl;
    });
    ['spAll', 'spData', 'spNone', 'spRun'].forEach((id) => {
      const el = $('#' + id);
      const key = { spAll: 'sp.all', spData: 'sp.dataOnly', spNone: 'sp.none', spRun: 'sp.run' }[id];
      if (el && el.textContent !== t(key)) el.textContent = t(key);
    });
    App.paintStepPick();
  },

  // 工位依赖：key → 必须先有产物的前置工位。
  // ★依据后端各工位实际的前置检查，不是凭空设定：
  //   clean 要 adapt 的 raw；tokenizer 要 clean 的合并语料；
  //   pack 要词表；mix 要打包产物；train 要训练集；test 要模型。
  STEP_DEPS: {
    clean: ['adapt'], tokenizer: ['clean'], pack: ['tokenizer'],
    mix: ['pack'], train: ['mix'], test: ['train'],
  },

  // 返回「被勾选但前置未满足」的清单：[{key, missing:[...]}]
  stepGaps() {
    const st = (S.proj && S.proj.state && S.proj.state.stages) || {};
    const picked = S.picked || new Set();
    const gaps = [];
    picked.forEach((k) => {
      const need = (App.STEP_DEPS[k] || []).filter((d) => {
        // 前置已 done 视为满足；前置也被勾选则本次会先跑，同样满足
        const done = st[d] && st[d].status === 'done';
        return !done && !picked.has(d);
      });
      if (need.length) gaps.push({ key: k, missing: need });
    });
    return gaps;
  },

  paintStepPick() {
    const box = $('#stepPick');
    if (!box) return;
    const n = (S.picked || new Set()).size;
    const hint = $('#spHint');
    const gaps = App.stepGaps();
    if (hint) {
      const names = (S.meta ? S.meta.stages : []).filter((s) => S.picked.has(s.key))
        .map((s) => stageName(s.key));
      let txt = n ? t('sp.picked', { n, s: names.join(' → ') }) : t('sp.pickHint');
      if (gaps.length) {
        const g = gaps.map((x) => t('sp.gapItem', {
          a: stageName(x.key), b: x.missing.map(stageName).join('、'),
        })).join('；');
        txt += ' ⚠ ' + t('sp.gap', { g });
      }
      hint.textContent = txt;
      hint.title = txt;
      hint.classList.toggle('sp-warn', gaps.length > 0);
    }
    // 缺前置时给出「补上前置」按钮，一键把依赖加进勾选
    let fix = $('#spFix');
    if (gaps.length) {
      if (!fix) {
        fix = document.createElement('button');
        fix.id = 'spFix'; fix.className = 'btn sm';
        const row = $('#spRun') && $('#spRun').parentNode;
        if (row) row.insertBefore(fix, $('#spRun'));
      }
      fix.textContent = t('sp.fix');
      fix.onclick = () => {
        App.stepGaps().forEach((x) => x.missing.forEach((m) => S.picked.add(m)));
        box.querySelectorAll('input[data-sp]').forEach((c) => { c.checked = S.picked.has(c.dataset.sp); });
        App.paintStepPick();
      };
      fix.style.display = '';
    } else if (fix) { fix.style.display = 'none'; }
    const run = $('#spRun');
    if (run) run.disabled = !n || !!(S.runner && S.runner.running);
    // ★单卡工具全局只跑一个项目：禁用按钮时必须说清「是谁在跑」，
    //   否则用户看着自己项目明明空闲却点不动，无从判断。
    const busy = $('#spBusy');
    if (busy) {
      const r = S.runner || {};
      if (r.running && r.active) {
        const other = r.active !== S.current;
        // ★工位要取「在跑的那个项目」的：S.proj 是当前查看的项目，
        //   跨项目时它通常空闲，用它的 current 只会退化成笼统的「运行中」。
        const cur = other
          ? (((S.projects || []).find((x) => x.name === r.active) || {}).current || '')
          : ((S.proj && S.proj.state && S.proj.state.current) || '');
        busy.style.display = '';
        busy.textContent = other
          ? t('sp.busyOther', { a: r.active, s: cur ? stageName(cur) : t('home.running') })
          : t('sp.busySelf', { s: cur ? stageName(cur) : t('home.running') });
      } else {
        busy.style.display = 'none';
        busy.textContent = '';
      }
    }
  },

  async runPicked() {
    if (!S.current) { toast(tx('common.noProject'), 'err'); return; }
    const keys = (S.meta ? S.meta.stages : []).filter((s) => S.picked.has(s.key)).map((s) => s.key);
    if (!keys.length) { toast(tx('sp.nonePicked'), 'err'); return; }
    const names = keys.map(stageName).join(' → ');
    const gaps = App.stepGaps();
    let extra = `<div class="hint" style="margin-top:10px">${esc(t('sp.confirmNote'))}</div>`;
    if (gaps.length) {
      const g = gaps.map((x) => t('sp.gapItem', {
        a: stageName(x.key), b: x.missing.map(stageName).join('、'),
      })).join('；');
      extra += `<div class="imp-warn" style="margin-top:8px">⚠ ${esc(t('sp.gapRun', { g }))}</div>`;
    }
    if (!(await confirmBox(tx('sp.confirmTitle'), tx('sp.confirmText', { s: names }), extra))) return;
    try {
      await api('/api/run/start', { name: S.current, stages: keys });
      toast(tx('sp.started'), 'ok');
      await App.refreshData();
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  /* ---------------- 链接下载 ----------------
     ★两段式：先只读探测（不取正文），把来源/体积/类型摆出来，
       用户点「下载」才真正开始。绝不静默下载任意外部内容。
     ★整合在「使用已有文件」卡片里：下载完可直接填进语料路径，
       不必再单开一个页面来回切。 */
  dlToggle() {
    S.form.dlOpen = !S.form.dlOpen;
    App.renderDl();
  },

  renderDl() {
    const tgl = $('#btnDlToggle'), box = $('#dlPanel');
    if (!tgl || !box) return;
    tgl.classList.toggle('on', !!S.form.dlOpen);
    tgl.innerHTML = (S.form.dlOpen ? '▾ ' : '▸ ') + t('dl.title');
    if (!S.form.dlOpen) { box.innerHTML = ''; box.dataset.lang = ''; return; }
    // ★骨架文案（标签/按钮/说明）由 JS 生成，切语言必须重建，
    //   否则面板已存在时会直接 return，标签永远停在旧语言。
    //   重建前留住已输入的链接，重建后回填，用户不会丢输入。
    if (box.querySelector('#dlUrl') && box.dataset.lang === PREF.lang) {
      App.paintDlResult(); App.paintDlFiles(); App.paintDlJobs(); return;
    }
    const keepUrl = box.querySelector('#dlUrl') ? box.querySelector('#dlUrl').value : '';
    box.dataset.lang = PREF.lang;
    box.innerHTML = `<div class="clean-adv">
      <div class="ca-title">${t('dl.head')}<span>${t('dl.sub')}</span></div>
      <div class="field">
        <label>${t('dl.url')}</label>
        <div style="display:flex;gap:8px">
          <input type="text" id="dlUrl" placeholder="${esc(t('dl.urlPh'))}">
          <button class="btn sm" id="btnDlCheck" style="flex:none">${t('dl.check')}</button>
        </div>
        <div class="hint">${t('dl.urlHint')}</div>
      </div>
      <div class="field">
        <label>${t('dl.dest')}</label>
        <input type="text" id="dlDest" placeholder="${esc(t('dl.destPh'))}">
        <div class="hint">${t('dl.destHint')}</div>
      </div>
      <div id="dlResult"></div>
      <div class="btn-row" style="margin-top:12px">
        <button class="btn primary" id="btnDlStart" disabled>${t('dl.start')}</button>
      </div>
      <div id="dlJobs"></div>
      <div id="dlFiles"></div>
    </div>`;
    $('#btnDlCheck').onclick = () => App.dlInspect();
    $('#btnDlStart').onclick = () => App.dlStart();
    $('#dlUrl').onkeydown = (ev) => {
      if (ev.key === 'Enter') { ev.preventDefault(); App.dlInspect(); }
    };
    $('#dlUrl').oninput = () => {
      // 改了链接就作废上次探测结果，避免拿着旧信息去下载新地址
      S.dl = null; $('#dlResult').innerHTML = ''; $('#btnDlStart').disabled = true;
    };
    // 切语言重建后回填原输入，并按新语言重画探测结果
    if (keepUrl) $('#dlUrl').value = keepUrl;
    App.paintDlResult();
    App.paintDlJobs(); App.paintDlFiles();
  },

  dlProject() {
    // ★允许为空：用户的真实顺序常是「先下语料再建项目」。
    //   为空时后端落到程序内公共 downloads/，同样不越界。
    return S.current || ($('#fName') && $('#fName').value.trim()) || '';
  },

  async dlInspect() {
    const url = ($('#dlUrl').value || '').trim();
    const box = $('#dlResult');
    const proj = App.dlProject();
    S.dl = null; $('#btnDlStart').disabled = true;
    if (!url) { box.innerHTML = `<div class="imp-bad">✕ ${esc(t('dl.noUrl'))}</div>`; return; }
    box.innerHTML = `<div class="hint">${t('common.detecting')}</div>`;
    try {
      const dest = (($('#dlDest') && $('#dlDest').value) || '').trim();
      const r = await api('/api/download/inspect', { url, project: proj, dest });
      if ((($('#dlUrl').value || '').trim()) !== url) return;
      S.dl = r; S.dl._url = url; S.dl._proj = proj; S.dl._dest = dest;
      App.paintDlResult();
    } catch (e) {
      S.dl = { ok: false, problems: [{ k: 'dl.netErr', v: { e: e.message } }] };
      App.paintDlResult();
    }
  },

  paintDlResult() {
    const box = $('#dlResult'), r = S.dl;
    if (!box) return;
    const btn = $('#btnDlStart');
    if (!r) { box.innerHTML = ''; if (btn) btn.disabled = true; return; }
    if (btn) btn.disabled = !r.ok;
    if (!r.ok) {
      box.innerHTML = (r.problems || []).map((m) =>
        `<div class="imp-bad">✕ ${esc(App.upgMsg(m))}</div>`).join('');
      return;
    }
    let h = `<div class="imp-ok">✓ ${esc(t('dl.ready'))} · ${esc(r.name)}`
      + (r.size_text ? ` · ${esc(r.size_text)}` : '') + `</div>`;
    h += `<div class="hint">${esc(t('dl.from', { h: r.host }))}</div>`;
    h += `<div class="hint">${esc(t('dl.saveAt', { p: r.path || r.name }))}</div>`;
    if (r.resumable) h += `<div class="hint">${esc(t('dl.resumable'))}</div>`;
    (r.warnings || []).forEach((m) => { h += `<div class="imp-warn">⚠ ${esc(App.upgMsg(m))}</div>`; });
    h += `<div class="imp-warn">⚠ ${esc(t('dl.license'))}</div>`;
    box.innerHTML = h;
  },

  async dlStart() {
    const r = S.dl;
    if (!r || !r.ok) return;
    const ok = await confirmBox(tx('dl.confirmTitle'),
      tx('dl.confirmText', { n: r.name, h: r.host, s: r.size_text || t('dl.unknownSize') }),
      `<div class="hint" style="margin-top:10px">${esc(t('dl.license'))}</div>`);
    if (!ok) return;
    const b = $('#btnDlStart');
    b.disabled = true;
    try {
      const d = await api('/api/download/start', { url: S.dl._url, project: S.dl._proj, dest: S.dl._dest || '' });
      if (!d.ok) {
        S.dl = { ok: false, problems: d.problems || [] };
        App.paintDlResult();
        toast(tx('dl.failed'), 'err');
      } else {
        toast(tx('dl.started'), 'ok');
        App.paintDlJobs();
        App.dlPoll();
      }
    } catch (e) { toast(errDesc(e), 'err'); }
    b.disabled = false;
  },

  async paintDlJobs() {
    const box = $('#dlJobs');
    if (!box) return;
    try {
      const d = await api('/api/download/status', {});
      const items = (d.items || []).filter((x) => x.state === 'running' || x.state === 'error');
      if (!items.length) { box.innerHTML = ''; return; }
      box.innerHTML = items.map((j) => {
        const pct = j.percent == null ? 0 : j.percent;
        const st = j.state === 'running'
          ? `${j.done_text}${j.total_text ? ' / ' + j.total_text : ''}`
            + (j.speed ? ` · ${App.dlSpeed(j.speed)}` : '')
            + (j.eta_sec != null ? ` · ${App.dlEta(j.eta_sec)}` : '')
          : (j.problems || []).map((m) => App.upgMsg(m)).join('；');
        return `<div class="dl-job">
          <div class="dl-name" title="${esc(j.name)}">${esc(j.name)}</div>
          <div class="dl-bar"><i style="width:${pct}%"></i></div>
          <div class="dl-meta">${esc(st)}</div>
          ${j.state === 'running' ? `<button class="btn sm" data-dlcancel="${esc(j.id)}">${t('dl.cancel')}</button>` : ''}
        </div>`;
      }).join('');
      $$('#dlJobs [data-dlcancel]').forEach((el) => {
        el.onclick = async () => {
          await api('/api/download/cancel', { id: el.dataset.dlcancel });
          App.paintDlJobs();
        };
      });
    } catch (e) { /* 轮询失败不打扰 */ }
  },

  dlSpeed(bps) {
    if (!bps) return '';
    const u = ['B/s', 'KB/s', 'MB/s', 'GB/s'];
    let i = 0, v = bps;
    while (v >= 1024 && i < u.length - 1) { v /= 1024; i += 1; }
    return v.toFixed(1) + ' ' + u[i];
  },

  dlEta(sec) {
    if (sec == null) return '';
    if (sec < 60) return t('dl.etaS', { n: sec });
    if (sec < 3600) return t('dl.etaM', { n: Math.round(sec / 60) });
    return t('dl.etaH', { n: (sec / 3600).toFixed(1) });
  },

  dlPoll() {
    clearTimeout(App._dlTimer);
    App._dlTimer = setTimeout(async () => {
      if (!S.form.dlOpen) return;
      await App.paintDlJobs();
      const d = await api('/api/download/status', {}).catch(() => null);
      const running = d && (d.items || []).some((x) => x.state === 'running');
      if (running) App.dlPoll();
      else App.paintDlFiles();
    }, 1000);
  },

  async paintDlFiles() {
    const box = $('#dlFiles');
    if (!box) return;
    const proj = App.dlProject();
    try {
      // proj 为空时后端列公共 downloads/，同样要显示出来
      const dest = (($('#dlDest') && $('#dlDest').value) || '').trim();
      const d = await api('/api/download/files', { project: proj, dest });
      const items = (d.items || []).filter((x) => !x.partial);
      if (!items.length) { box.innerHTML = ''; return; }
      let h = `<div class="hint" style="margin-top:14px">${esc(t('dl.filesTitle'))}</div>`;
      h += items.slice(0, 12).map((f) => `<div class="ci-row">
        <div style="flex:1;min-width:0">
          <div class="ci-name" title="${esc(f.path)}">${esc(f.name)}</div>
          <div class="ci-meta">${esc(f.size_text)}</div>
        </div>
        <button class="btn sm" data-dluse="${esc(f.path)}">${t('dl.use')}</button>
      </div>`).join('');
      box.innerHTML = h;
      $$('#dlFiles [data-dluse]').forEach((el) => {
        el.onclick = () => {
          // 直接加成一条语料，路径填好，用户只需选类型
          S.form.corpus.push({ path: el.dataset.dluse, kind: 'auto', percent: null,
            info: null, clean_level: '', clean_custom: {}, dedup: 'bloom',
            strip_urls: true, nfkc: true, open: true });
          App.renderCorpus(); App.renderMixPreview();
          toast(tx('dl.added'), 'ok');
        };
      });
    } catch (e) { box.innerHTML = ''; }
  },

  /* ---------------- 词表规模 ----------------
     ★不设上限，只给参考：把「这个词表会吃掉多少嵌入参数/显存」当场算给用户看，
       让他自己判断，而不是替他拦下来。 */
  syncVocabUI() {
    const el = $('#fVocab');
    if (!el) return;
    const v = Math.max(256, Math.round(parseFloat(el.value) || 32000));
    $$('#segVocab button').forEach((b) => b.classList.toggle('on', +b.dataset.v === v));
    const hint = $('#vocabHint');
    if (!hint) return;
    // 嵌入参数：tie 时只算一份，否则输入输出各一份
    const a = App.archEffective();
    const h = +a.hidden_size || 768;
    const tie = a.tie_embeddings !== false;
    const emb = v * h * (tie ? 1 : 2);
    const gb = emb * 2 / 1024 ** 3;           // bf16 权重
    const preset = $('#fMMTokens') && $('#fMMTokens').checked ? 11 : 0;
    const extra = App.extraSpecialList();
    const totalSpecial = 5 + preset + extra.length;
    // ★数量分节中英不同：中文按万/亿（1e4/1e8），英文按 M/B（1e6/1e9）。
    //   只换单位标签而不换除数会让英文数值错 10~100 倍，所以必须一起换。
    const zhNum = PREF.lang === 'zh';
    let pTxt;
    if (zhNum) {
      pTxt = emb >= 1e8 ? (emb / 1e8).toFixed(2) + ' ' + t('num.yi')
        : (emb >= 1e4 ? (emb / 1e4).toFixed(0) + ' ' + t('num.wan') : emb.toLocaleString());
    } else {
      pTxt = emb >= 1e9 ? (emb / 1e9).toFixed(2) + ' ' + t('num.yi')
        : (emb >= 1e6 ? (emb / 1e6).toFixed(2) + ' ' + t('num.wan') : emb.toLocaleString());
    }
    hint.textContent = t('create.vocabCalc', {
      n: v.toLocaleString(),
      p: pTxt,
      g: gb.toFixed(2),
      m: t('create.vocabSpecial', { k: totalSpecial }),
    });
    const ti = hint.textContent;
    if (hint.title !== ti) hint.title = ti;
    // 自定义标记的即时反馈：数量 + 去重后清单，让用户确认解析结果
    const eh = $('#extraSpecialHint');
    if (eh) {
      eh.textContent = extra.length
        ? t('create.extraSpecialCount', { n: extra.length, s: extra.slice(0, 8).join('  ') })
        : t('create.extraSpecialHint');
      eh.title = eh.textContent;
    }
  },

  // 与后端 parse_extra_special 同口径：逗号/换行分隔、去空、去重保序
  extraSpecialList() {
    const el = $('#fExtraSpecial');
    if (!el) return [];
    const seen = new Set(), out = [];
    (el.value || '').split(/[,\n\r]+/).forEach((x) => {
      const s = x.trim();
      if (!s || /\s/.test(s) || seen.has(s)) return;
      seen.add(s); out.push(s);
    });
    return out;
  },

  /* 按参数量量级给一句提示：
       1B ~ 1024B   认真的大模型 → 贴心建议（不是玩笑）
       1T ~ 1024T   万亿级       → 玩笑
       1P ~ 1024P   千万亿级     → 玩笑
       > 1024P      更夸张       → 再一句
     ★不写「全球显卡都不够」这类断言：无法核实，属于编造事实。
       玩笑只调侃界面自己、电费、写小说，不对现实世界下结论。 */
  archScaleNote(n) {
    if (!isFinite(n) || n < 1e9) return '';
    const p = fmt.params(n);
    // ★分档必须跟「显示出来的单位」一致，不能另用一套阈值：
    //   单位换算是 1000 进制（1000B = 1T），若这里按 1024 判定，
    //   1023e9 会被显示成 1.02T 却仍归在 B 档，文案与数字自相矛盾。
    //   因此直接读格式化结果的单位字母来分档。
    const unit = (p.match(/[KMBTP]$/) || [''])[0];
    const val = parseFloat(p);
    let key, joke = true;
    if (unit === 'P' && val > 1024) key = 'create.archJokeBeyond';
    else if (unit === 'P') key = 'create.archJokeP';
    else if (unit === 'T') key = 'create.archJokeT';
    else { key = 'create.archTipBig'; joke = false; }
    const cls = joke ? 'ca-joke' : 'ca-tip';
    return `<div class="${cls}">${esc(t(key, { p }))}</div>`;
  },

  renderArch() {
    const box = $('#archPanel'), tgl = $('#btnArchToggle');
    // ★即使元数据还没到，也要先把按钮文字画上，避免首屏空窄条。
    //   面板内容依赖 S.meta，未就绪时只画按钮、不画面板。
    if (tgl) {
      tgl.classList.toggle('on', S.form.archOpen);
      tgl.innerHTML = (S.form.archOpen ? '▾ ' : '▸ ') + t('create.archToggle')
        + (S.form.archOn ? ` <span class="tag run">${t('create.archEnabled')}</span>` : '');
    }
    if (!S.meta) return;
    tgl.classList.toggle('on', S.form.archOpen);
    tgl.innerHTML = (S.form.archOpen ? '▾ ' : '▸ ') + t('create.archToggle')
      + (S.form.archOn ? ` <span class="tag run">${t('create.archEnabled')}</span>` : '');
    if (!S.form.archOpen) { box.innerHTML = ''; return; }

    const est = App.archEstimate(), base = App.archBase();
    const fields = S.meta.arch_fields.map((f) => {
      const custom = S.form.arch[f.key] != null && S.form.arch[f.key] !== '';
      const val = custom ? S.form.arch[f.key] : (base[f.key] != null ? base[f.key] : '');
      const ph = f.key === 'num_attention_heads' ? est.heads : (f.key === 'num_key_value_heads' ? est.kv : (f.key === 'head_dim' ? 64 : ''));
      return `<div class="cf">
        <div class="cf-head"><label>${t('arch.' + f.key)}</label>
          ${custom ? `<button class="cf-reset" data-archreset="${f.key}">${t('common.reset')}</button>` : `<span class="cf-auto">${t('common.preset')}</span>`}
        </div>
        <div class="cf-row"><input type="number" data-arch="${f.key}" value="${val === '' ? '' : val}"
          min="${f.min}" step="${f.step}" placeholder="${ph}"></div>
        <div class="cf-hint">${t('arch.hint.' + f.key)}</div>
      </div>`;
    }).join('');

    const budget = S.rec ? S.rec.budget_gb : 0;
    const over = est.vram > budget;
    box.innerHTML = `<div class="clean-adv">
      <div class="ca-title">${t('create.archTitle')}<span>${t('create.archSub')}</span></div>
      <label class="sw" style="margin-bottom:13px">
        <input type="checkbox" id="archEnable" ${S.form.archOn ? 'checked' : ''}>
        <span><b>${t('create.archEnable')}</b></span></label>
      <div class="metrics" style="margin-bottom:14px">
        <div class="metric c2"><div class="mk">${t('create.archParams')}</div>
          <div class="mv">${esc(fmt.params(est.params).replace(/[KMBTP]$/, ''))}<span class="mu">${esc((fmt.params(est.params).match(/[KMBTP]$/) || [''])[0])}</span></div></div>
        <div class="metric ${over ? 'c4' : 'c3'}"><div class="mk">${t('create.archVram')}</div>
          <div class="mv">${est.vram}<span class="mu">GB</span></div></div>
        <div class="metric c1"><div class="mk">${t('create.archHeads')}</div>
          <div class="mv" style="font-size:19px">${est.heads} / KV ${est.kv}</div></div>
      </div>
      <div class="hint" style="margin:-4px 0 6px">${esc(t('create.archVramDetail', {
        w: est.weights.toFixed(2), g: est.grads.toFixed(2),
        o: est.opt.toFixed(2), a: est.act.toFixed(2) }))}</div>
      <div class="hint" style="margin:0 0 10px">${esc(t('create.archVramBasis', {
        b: est.batch, s: est.block, d: est.dtype }))}</div>
      ${over ? `<div class="ca-warn">⚠ ${t('create.archOver', { a: est.vram, b: budget })}</div>` : ''}
      ${App.archScaleNote(est.params)}
      ${est.probs.length ? `<div class="ca-warn">${est.probs.map((p) => '⚠ ' + esc(p)).join('<br>')}</div>` : ''}
      <div class="hint" style="margin:2px 0 10px">${t('create.archUnitNote')}</div>
      <div class="cf-grid">${fields}</div>
      <div class="ca-switches"><label class="sw"><input type="checkbox" id="archTie" ${S.form.tie ? 'checked' : ''}>
        <span>${t('create.archTie')}</span></label></div>
      <div class="btn-row" style="margin-top:12px"><button class="btn sm" id="archClear">${t('create.archClear')}</button></div>
    </div>`;

    $('#archEnable').onchange = (e) => { S.form.archOn = e.target.checked; App.renderArch(); App.renderTiers(); };
    $('#archTie').onchange = (e) => { S.form.tie = e.target.checked; App.renderArch(); App.renderTiers(); };
    $('#archClear').onclick = () => { S.form.arch = {}; S.form.tie = true; toast(tx('clean.restored'), 'ok'); App.renderArch(); };
    $$('#archPanel [data-arch]').forEach((el) => {
      el.onchange = () => {
        const k = el.dataset.arch, raw = el.value.trim();
        if (raw === '') delete S.form.arch[k];
        else {
          const f = S.meta.arch_fields.find((x) => x.key === k);
          const v = parseInt(raw, 10);
          if (isFinite(v)) S.form.arch[k] = Math.max(f.min || 1, v);
        }
        App.renderArch();
      };
    });
    $$('#archPanel [data-archreset]').forEach((el) => {
      el.onclick = () => { delete S.form.arch[el.dataset.archreset]; App.renderArch(); };
    });
  },

  /* ---------------- corpus ---------------- */
  addCorpus() {
    S.form.corpus.push({ path: '', kind: 'auto', percent: null, info: null,
      clean_level: '', clean_custom: {}, dedup: 'bloom', strip_urls: true, nfkc: true, open: false });
    App.renderCorpus(); App.renderMixPreview();
  },

  shares() {
    const list = S.form.corpus;
    const vals = list.map((c) => {
      const v = parseFloat(c.percent);
      return isFinite(v) && v > 0 ? v : 0;
    });
    let sum = vals.reduce((a, b) => a + b, 0);
    if (sum <= 0) return list.map(() => list.length ? 100 / list.length : 0);
    return vals.map((v) => (v / sum) * 100);
  },

  renderMixPreview() {
    const box = $('#mixPreview');
    if (!box || !S.meta) return;
    const list = S.form.corpus;
    if (!list.length) { box.innerHTML = ''; return; }
    const sh = App.shares();
    box.innerHTML = `<div class="ca-title" style="margin-bottom:6px">${t('create.mixPreview')}</div>
      <div class="mix-bar">${sh.map((p, i) =>
        `<div class="mix-seg" style="width:${p}%;background:${MIX_COLORS[i % MIX_COLORS.length]}"></div>`).join('')}</div>
      <div class="mix-legend">${list.map((c, i) =>
        `<span><i style="background:${MIX_COLORS[i % MIX_COLORS.length]}"></i>${t('create.corpusN')} ${i + 1} · ${kindName(c.kind)} ${sh[i].toFixed(1)}%</span>`).join('')}</div>
      <div class="hint" style="margin-top:8px">${t('create.mixNote')}</div>`;
  },

  cleanPanel(c, i) {
    const cp = App.cleanParams(c.kind, c.clean_level || S.form.clean, c.clean_custom);
    const fields = S.meta.clean_fields.map((f) => {
      const b = S.meta.clean_bounds[f.key] || [0, 1];
      const overridden = c.clean_custom[f.key] != null && c.clean_custom[f.key] !== '';
      const val = overridden ? c.clean_custom[f.key] : cp[f.key];
      const isInt = f.step >= 1;
      const shown = val == null ? '' : (isInt ? Math.round(val) : (+val).toFixed(2));
      return `<div class="cf">
        <div class="cf-head"><label>${t('clean.' + f.key)}</label>
          ${overridden ? `<button class="cf-reset" data-reset="${i}" data-f="${f.key}">${t('common.reset')}</button>` : `<span class="cf-auto">${t('common.preset')}</span>`}
        </div>
        <div class="cf-row">
          <input type="range" data-cust="${i}" data-f="${f.key}" data-int="${isInt ? 1 : 0}"
            min="${b[0]}" max="${b[1]}" step="${f.step}" value="${val == null ? b[0] : val}" class="${overridden ? 'on' : ''}">
          <input type="number" data-custn="${i}" data-f="${f.key}" min="${b[0]}" max="${b[1]}" step="${f.step}"
            value="${shown}" placeholder="${cp[f.key] == null ? '' : cp[f.key]}">
        </div>
        <div class="cf-hint">${t('clean.hint.' + f.key)}</div>
      </div>`;
    }).join('');
    const warns = App.cleanWarns(c.kind, cp);
    return `<div class="clean-adv">
      <div class="ca-title">${t('clean.customTitle')}<span>${t('clean.customSub')}</span></div>
      ${warns.length ? `<div class="ca-warn">${warns.map((w) => '⚠ ' + w).join('<br>')}</div>` : ''}
      <div class="cf-grid">${fields}</div>
      <div class="ca-switches">
        <label class="sw"><input type="checkbox" data-sw="${i}" data-k="strip_urls" ${c.strip_urls !== false ? 'checked' : ''}><span>${t('clean.stripUrls')}</span></label>
        <label class="sw"><input type="checkbox" data-sw="${i}" data-k="nfkc" ${c.nfkc !== false ? 'checked' : ''}><span>${t('clean.nfkc')}</span></label>
        <div class="sw-select"><label>${t('clean.dedup')}</label>
          <select data-dedup="${i}">
            <option value="bloom" ${c.dedup !== 'exact' && c.dedup !== 'none' ? 'selected' : ''}>${t('clean.dedup.bloom')}</option>
            <option value="exact" ${c.dedup === 'exact' ? 'selected' : ''}>${t('clean.dedup.exact')}</option>
            <option value="none" ${c.dedup === 'none' ? 'selected' : ''}>${t('clean.dedup.none')}</option>
          </select></div>
      </div>
      <div class="btn-row" style="margin-top:12px"><button class="btn sm" data-clearcust="${i}">${t('common.resetAll')}</button></div>
    </div>`;
  },

  cleanWarns(kind, p) {
    const w = [];
    if (kind === 'code' && p.min_cjk_ratio > 0.05) w.push(t('clean.warn.code_cjk'));
    if (kind === 'code' && p.max_repeat_ratio < 0.52) w.push(t('clean.warn.code_rep'));
    if (kind === 'guji' && p.min_chars > 20) w.push(t('clean.warn.guji_len'));
    if (p.min_cjk_ratio > 0.8) w.push(t('clean.warn.cjk_high'));
    if (p.max_symbol_ratio < 0.1) w.push(t('clean.warn.sym_low'));
    if (p.max_chars && p.min_chars >= p.max_chars) w.push(t('clean.warn.len_conflict'));
    return w;
  },

  renderCorpus() {
    const box = $('#corpusList');
    if (!S.meta) return;
    if (!S.form.corpus.length) { box.innerHTML = `<div class="hint">${t('create.corpusEmpty')}</div>`; return; }
    const sh = App.shares();
    box.innerHTML = S.form.corpus.map((c, i) => {
      const kinds = S.meta.kinds.map((k) =>
        `<button class="kind-btn ${c.kind === k.key ? 'on' : ''}" data-i="${i}" data-k="${k.key}" title="${esc(sv(k.desc))}">${kindName(k.key)}</button>`).join('');
      const lv = c.clean_level || S.form.clean;
      const cp = App.cleanParams(c.kind, lv, c.clean_custom);
      const nCustom = Object.keys(c.clean_custom || {}).filter((k) => c.clean_custom[k] != null && c.clean_custom[k] !== '').length;
      const lvBtns = [`<button data-lv="${i}" data-v="" class="${!c.clean_level ? 'on' : ''}">${t('create.levelInherit')}</button>`]
        .concat(S.meta.levels.map((l) => `<button data-lv="${i}" data-v="${l.key}" class="${c.clean_level === l.key ? 'on' : ''}">${levelName(l.key)}</button>`)).join('');
      return `<div class="corpus-item">
        <div class="ci-head">
          <div class="ci-idx" style="background:${MIX_COLORS[i % MIX_COLORS.length]}">${i + 1}</div>
          <div class="ci-title">${t('create.corpusN')} ${i + 1}${nCustom ? ` <span class="tag run">${nCustom} ${t('common.custom_n')}</span>` : ''}</div>
          ${S.form.corpus.length > 1 ? `<button class="ci-del" data-del="${i}" title="✕">✕</button>` : ''}
        </div>
        <div class="field" style="margin-bottom:12px">
          <label>${t('create.path')}</label>
          <div style="display:flex;gap:8px">
            <input type="text" data-path="${i}" value="${esc(c.path)}" placeholder="${t('create.pathPh')}">
            <button class="btn sm" data-probe="${i}" style="flex:none">${t('common.detect')}</button>
          </div>
          <div class="hint">${c.info ? esc(sv(c.info)) : t('create.pathHint')}</div>
        </div>
        <div class="field" style="margin-bottom:12px"><label>${t('create.kind')}</label><div class="kind-grid">${kinds}</div></div>
        <div class="row" style="align-items:flex-end">
          <div class="field" style="margin:0;flex:2">
            <label>${t('create.level')}</label>
            <div class="seg mini">${lvBtns}</div>
          </div>
          <div class="field" style="margin:0;max-width:190px">
            <label>${t('create.percent')}</label>
            <input type="number" data-pct="${i}" value="${c.percent == null ? '' : c.percent}" min="0" step="0.1"
              placeholder="${sh[i].toFixed(1)}">
          </div>
        </div>
        <div class="ci-meta" style="margin-top:10px">
          <b>${t('create.actualThreshold')}：</b>${t('create.cjkMin')} ${cp.min_cjk_ratio}　${t('create.repMax')} ${cp.max_repeat_ratio}<br>
          ${t('create.symMax')} ${cp.max_symbol_ratio}　${t('create.minChars')} ${cp.min_chars} ${t('create.chars')}${cp.max_chars ? '　' + t('create.maxChars') + ' ' + cp.max_chars : ''}
        </div>
        <button class="ci-toggle ${c.impOpen ? 'on' : ''}" data-imptoggle="${i}">${c.impOpen ? '▾' : '▸'} ${t('import.corpusToggle')}${c.clean_import ? ` <span class="tag done">${t('import.on')}</span>` : ''}</button>
        ${c.impOpen ? `<div class="ci-imp">
          <label>${t('import.cleanedFile')}</label>
          <input type="text" data-cimp="${i}" value="${esc(c.clean_import || '')}" placeholder="${t('import.filePh')}">
          <div class="hint">${t('import.cleanedHint')}</div>
        </div>` : ''}
        <button class="ci-toggle ${c.open ? 'on' : ''}" data-toggle="${i}">${c.open ? '▾' : '▸'} ${t('create.customClean')}</button>
        ${c.open ? App.cleanPanel(c, i) : ''}
      </div>`;
    }).join('');

    $$('#corpusList [data-cimp]').forEach((el) => {
      el.oninput = () => { S.form.corpus[+el.dataset.cimp].clean_import = el.value; };
    });
    $$('#corpusList [data-imptoggle]').forEach((el) => {
      el.onclick = () => { const c = S.form.corpus[+el.dataset.imptoggle]; c.impOpen = !c.impOpen; App.renderCorpus(); };
    });
    $$('#corpusList [data-path]').forEach((el) => { el.oninput = () => { S.form.corpus[+el.dataset.path].path = el.value; }; });
    $$('#corpusList [data-pct]').forEach((el) => {
      el.oninput = () => {
        const v = el.value.trim();
        S.form.corpus[+el.dataset.pct].percent = v === '' ? null : (parseFloat(v) || 0);
        App.renderMixPreview();
      };
    });
    $$('#corpusList [data-lv]').forEach((el) => {
      el.onclick = () => { S.form.corpus[+el.dataset.lv].clean_level = el.dataset.v; App.renderCorpus(); };
    });
    $$('#corpusList .kind-btn').forEach((el) => {
      el.onclick = () => { S.form.corpus[+el.dataset.i].kind = el.dataset.k; App.renderCorpus(); App.renderMixPreview(); };
    });
    $$('#corpusList [data-del]').forEach((el) => {
      el.onclick = () => { S.form.corpus.splice(+el.dataset.del, 1); App.renderCorpus(); App.renderMixPreview(); };
    });
    $$('#corpusList [data-probe]').forEach((el) => {
      el.onclick = async () => {
        const i = +el.dataset.probe, p = S.form.corpus[i].path.trim();
        if (!p) { toast(tx('create.needCorpus'), 'err'); return; }
        el.textContent = t('common.detecting');
        try {
          const r = await api('/api/probe?path=' + encodeURIComponent(p));
          S.form.corpus[i].info = `${r.files} files · ${r.size_gb} GB (${r.sample.join(', ')})`;
        } catch (e) { S.form.corpus[i].info = '✕ ' + txRender(errDesc(e)); toast(errDesc(e), 'err'); }
        App.renderCorpus();
      };
    });
    $$('#corpusList [data-toggle]').forEach((el) => {
      el.onclick = () => { const i = +el.dataset.toggle; S.form.corpus[i].open = !S.form.corpus[i].open; App.renderCorpus(); };
    });
    $$('#corpusList [data-cust]').forEach((el) => {
      el.oninput = () => {
        const i = +el.dataset.cust, f = el.dataset.f, isInt = el.dataset.int === '1';
        const v = isInt ? parseInt(el.value, 10) : parseFloat(el.value);
        S.form.corpus[i].clean_custom[f] = v;
        const n = $(`#corpusList [data-custn="${i}"][data-f="${f}"]`);
        if (n) n.value = isInt ? v : v.toFixed(2);
        el.classList.add('on');
        App.updateCorpusMeta(i);
      };
      el.onchange = () => App.renderCorpus();
    });
    $$('#corpusList [data-custn]').forEach((el) => {
      el.onchange = () => {
        const i = +el.dataset.custn, f = el.dataset.f, raw = el.value.trim();
        if (raw === '') delete S.form.corpus[i].clean_custom[f];
        else {
          const b = S.meta.clean_bounds[f] || [0, 1];
          const v = parseFloat(raw);
          if (isFinite(v)) S.form.corpus[i].clean_custom[f] = b[1] > 5 ? Math.round(Math.max(b[0], Math.min(b[1], v))) : +Math.max(b[0], Math.min(b[1], v)).toFixed(3);
        }
        App.renderCorpus();
      };
    });
    $$('#corpusList [data-reset]').forEach((el) => {
      el.onclick = () => { delete S.form.corpus[+el.dataset.reset].clean_custom[el.dataset.f]; App.renderCorpus(); };
    });
    $$('#corpusList [data-clearcust]').forEach((el) => {
      el.onclick = () => {
        const i = +el.dataset.clearcust;
        Object.assign(S.form.corpus[i], { clean_custom: {}, dedup: 'bloom', strip_urls: true, nfkc: true });
        toast(tx('clean.restored'), 'ok'); App.renderCorpus();
      };
    });
    $$('#corpusList [data-sw]').forEach((el) => { el.onchange = () => { S.form.corpus[+el.dataset.sw][el.dataset.k] = el.checked; }; });
    $$('#corpusList [data-dedup]').forEach((el) => { el.onchange = () => { S.form.corpus[+el.dataset.dedup].dedup = el.value; }; });
  },

  updateCorpusMeta(i) {
    const c = S.form.corpus[i];
    const cp = App.cleanParams(c.kind, c.clean_level || S.form.clean, c.clean_custom);
    const item = $$('#corpusList .corpus-item')[i];
    if (!item) return;
    const meta = item.querySelector('.ci-meta');
    if (meta) meta.innerHTML = `<b>${t('create.actualThreshold')}：</b>${t('create.cjkMin')} ${cp.min_cjk_ratio}　${t('create.repMax')} ${cp.max_repeat_ratio}<br>
      ${t('create.symMax')} ${cp.max_symbol_ratio}　${t('create.minChars')} ${cp.min_chars} ${t('create.chars')}${cp.max_chars ? '　' + t('create.maxChars') + ' ' + cp.max_chars : ''}`;
    const warns = App.cleanWarns(c.kind, cp);
    let w = item.querySelector('.ca-warn');
    if (warns.length) {
      if (!w) { w = document.createElement('div'); w.className = 'ca-warn'; const g = item.querySelector('.cf-grid'); if (g) g.parentNode.insertBefore(w, g); }
      w.innerHTML = warns.map((x) => '⚠ ' + x).join('<br>');
    } else if (w) w.remove();
  },

  cleanParams(kind, level, custom) {
    const k = (S.meta.kinds.find((x) => x.key === kind) || S.meta.kinds.find((x) => x.key === 'auto')).clean;
    const d = { loose: [-0.15, 0.15, 0.15, 0.5], standard: [0, 0, 0, 1], strict: [0.15, -0.10, -0.10, 1.5] }[level] || [0, 0, 0, 1];
    const cl = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
    const out = {
      min_cjk_ratio: +cl(k.min_cjk_ratio + d[0], 0, 0.95).toFixed(2),
      max_repeat_ratio: +cl(k.max_repeat_ratio + d[1], 0.1, 0.95).toFixed(2),
      max_symbol_ratio: +cl(k.max_symbol_ratio + d[2], 0.05, 0.9).toFixed(2),
      min_chars: Math.max(4, Math.round(k.min_chars * d[3])),
    };
    const bounds = S.meta.clean_bounds || {};
    Object.entries(custom || {}).forEach(([key, v]) => {
      if (v == null || v === '' || !bounds[key]) return;
      const n = parseFloat(v);
      if (!isFinite(n)) return;
      const [lo, hi] = bounds[key], c = cl(n, lo, hi);
      out[key] = hi > 5 ? Math.round(c) : +c.toFixed(3);
    });
    return out;
  },

  renderCleanLevels() {
    $('#segClean') && ($('#segClean').innerHTML = S.meta.levels.map((l) =>
      `<button data-v="${l.key}" class="${S.form.clean === l.key ? 'on' : ''}">${levelName(l.key)}</button>`).join(''));
    $$('#segClean button').forEach((b) => {
      b.onclick = () => { S.form.clean = b.dataset.v; App.renderCleanLevels(); App.renderCorpus(); };
    });
  },

  /* ---------------- projects ---------------- */
  async loadProjects() {
    const d = await api('/api/projects');
    S.projects = d.projects; S.runner = d.runner;
    const box = $('#projectList');
    if (!d.projects.length) {
      box.innerHTML = `<div class="empty"><div class="ei">◇</div><p>${t('home.empty')}</p>
        <button class="btn primary" onclick="App.go('create')">${t('home.emptyBtn')}</button></div>`;
      return;
    }
    box.innerHTML = '<div class="pcards">' + d.projects.map((p) => {
      const pct = Math.round((p.stages_done / p.stages_total) * 100);
      const tag = p.running ? `<span class="tag run">${t('home.running')}</span>`
        : (p.stages_done === p.stages_total ? `<span class="tag done">${t('home.done')}</span>` : `<span class="tag idle">${t('home.pending')}</span>`);
      return `<div class="pcard" data-n="${esc(p.name)}">
        <div class="pcn">${esc(p.name)} ${tag}</div>
        <div class="pcm">${esc(tierLabel(p.tier, S.meta.tier_labels[p.tier]))} | ctx ${p.block_size}</div>
        <div class="pcp"><div class="big-prog" style="margin:0"><div class="fill" style="width:${pct}%"></div></div>
        <div class="hint" style="margin-top:6px">${p.stages_done}/${p.stages_total} ${t('home.stagesDone')}${p.current ? ' | ' + t('home.current') + ': ' + stageName(p.current) : ''}</div></div>
      </div>`;
    }).join('') + '</div>';
    $$('#projectList .pcard').forEach((el) => {
      el.onclick = async () => {
        S.current = el.dataset.n; S.lastDone = false;
        // 按项目进度决定落在哪一页：具备训练条件就去训练中心
        let view = 'data';
        try {
          const p = await api('/api/project?name=' + encodeURIComponent(S.current));
          S.proj = p; view = App.landingView(p.state);
        } catch (e) { /* 读不到状态就退回数据处理 */ }
        App.go(view);
      };
    });
  },

  readForm() {
    const num = (id, d) => { const v = parseFloat($(id).value); return isFinite(v) ? v : d; };
    const lrRaw = $('#fLr').value.trim();
    const arch = {};
    if (S.form.archOn) {
      Object.entries(S.form.arch).forEach(([k, v]) => { if (v != null && v !== '') arch[k] = v; });
      arch.tie_embeddings = S.form.tie;
    }
    const sh = App.shares();
    return {
      tier: S.form.tier || 'base',
      arch: S.form.archOn ? arch : null,
      block_size: Math.round(num('#fCtx', 1024)),
      max_tokens: Math.round(num('#fTokens', 0) * 1e9),
      clean_level: S.form.clean,
      vocab_size: Math.max(256, Math.round(num('#fVocab', 32000))),
      // ★默认 false：标准文本模型词表。勾选后追加预设扩展控制符。
      multimodal_tokens: !!$('#fMMTokens').checked,
      // 用户自定义特殊标记（任意领域可用），原样交后端解析
      extra_special: ($('#fExtraSpecial') && $('#fExtraSpecial').value.trim()) || '',
      lr: lrRaw ? parseFloat(lrRaw) : null,
      batch_size: Math.round(num('#fBatch', 4)),
      grad_accum: Math.round(num('#fAccum', 4)),
      save_every: Math.round(num('#fSave', 500)),
      keep_checkpoints: Math.round(num('#fKeep', 3)),
      warmup_steps: Math.round(num('#fWarm', 500)),
      eval_every: Math.round(num('#fEval', 500)),
      log_every: Math.round(num('#fLog', 20)),
      master_dtype: $('#fDtype').value,
      num_workers: Math.round(num('#fWorkers', 0)),
      output_dir: $('#fOutDir').value.trim(),
      backup_dir: $('#fBackup').value.trim(),
      backup_every: Math.round(num('#fBackupEvery', 500)),
      keep_backups: Math.round(num('#fKeepBk', 10)),
      spike_guard: S.form.spike,
      log_lang: S.form.logLang === 'en' ? 'en' : 'zh',
      corpus: S.form.corpus.filter((c) => c.path.trim() || (c.clean_import || '').trim()).map((c) => {
        const cc = {};
        Object.entries(c.clean_custom || {}).forEach(([k, v]) => { if (v != null && v !== '') cc[k] = v; });
        const realIdx = S.form.corpus.indexOf(c);
        return { path: c.path.trim(), kind: c.kind, percent: +sh[realIdx].toFixed(4),
          clean_level: c.clean_level || '', clean_custom: cc, dedup: c.dedup || 'bloom',
          strip_urls: c.strip_urls !== false, nfkc: c.nfkc !== false,
          clean_import: (c.clean_import || '').trim() };
      }),
      // 各工位来源：只提交真正选了「使用已有」且填了路径的项
      sources: (() => {
        const out = {};
        Object.entries(S.form.sources || {}).forEach(([k, v]) => {
          if (v && v.mode === 'import' && (v.path || '').trim()) {
            out[k] = { mode: 'import', path: v.path.trim() };
          }
        });
        return out;
      })(),
    };
  },

  // ---------------- 使用已有文件 ----------------
  renderImports() {
    const box = $('#importList');
    if (!box || !S.meta || !S.meta.import_specs) return;
    S.form.sources = S.form.sources || {};
    const specs = S.meta.import_specs;
    box.innerHTML = S.meta.stages.map((s) => {
      const spec = specs[s.key];
      if (!spec) return '';
      const cur = S.form.sources[s.key] || { mode: 'auto', path: '' };
      const on = cur.mode === 'import';
      return `<div class="imp-row" data-k="${s.key}">
        <div class="imp-head">
          <span class="imp-name">${stageName(s.key)}</span>
          <div class="seg sm">
            <button class="imp-mode ${!on ? 'on' : ''}" data-k="${s.key}" data-m="auto">${t('import.auto')}</button>
            <button class="imp-mode ${on ? 'on' : ''}" data-k="${s.key}" data-m="import">${t('import.use')}</button>
          </div>
        </div>
        ${on ? `<div class="imp-body">
          <div class="imp-input">
            <input type="text" class="imp-path" data-k="${s.key}" value="${esc(cur.path || '')}"
              placeholder="${spec.accept === 'dir' ? t('import.dirPh') : t('import.filePh')}">
            <button class="btn sm imp-check" data-k="${s.key}">${t('import.check')}</button>
          </div>
          <div class="hint">${esc(sv(spec.hint))}</div>
          <div class="imp-result" data-res="${s.key}"></div>
        </div>` : `<div class="hint imp-autohint">${t('import.autoHint', { s: stageName(s.key) })}</div>`}
      </div>`;
    }).join('');

    $$('#importList .imp-mode').forEach((el) => {
      el.onclick = () => {
        const k = el.dataset.k;
        S.form.sources[k] = S.form.sources[k] || { mode: 'auto', path: '' };
        if (S.form.sources[k].mode === el.dataset.m) return;
        S.form.sources[k].mode = el.dataset.m;
        App.renderImports();
        // 切到「使用已有」且已填过路径时，直接把上次结果显示出来
        if (el.dataset.m === 'import') {
          App.paintImportResult(k);
          if ((S.form.sources[k].path || '').trim()) App.checkImport(k, true);
        }
      };
    });
    $$('#importList .imp-path').forEach((el) => {
      // ★只更新数据与结果区，绝不重建整个列表：
      //   重建会销毁正在输入的 input，导致焦点丢失、输入被打断。
      el.oninput = () => {
        const k = el.dataset.k;
        S.form.sources[k] = S.form.sources[k] || { mode: 'import', path: '' };
        S.form.sources[k].path = el.value;
        if (S.form.importState) delete S.form.importState[k];
        App.paintImportResult(k);
        clearTimeout(App._impTimer && App._impTimer[k]);
        App._impTimer = App._impTimer || {};
        // 停止输入 600ms 后自动校验，省掉手动点按钮
        App._impTimer[k] = setTimeout(() => {
          if (el.value.trim()) App.checkImport(k, true);
        }, 600);
      };
      el.onblur = () => { if (el.value.trim()) App.checkImport(el.dataset.k, true); };
      el.onkeydown = (ev) => {
        if (ev.key === 'Enter') { ev.preventDefault(); App.checkImport(el.dataset.k); }
      };
    });
    $$('#importList .imp-check').forEach((el) => {
      el.onclick = () => App.checkImport(el.dataset.k);
    });
    Object.keys(S.form.importState || {}).forEach((k) => App.paintImportResult(k));
  },

  // 只刷新某一行的结果区，不动输入框
  paintImportResult(k) {
    const box = $(`#importList [data-res="${k}"]`);
    if (!box) return;
    const st = (S.form.importState || {})[k];
    if (!st) { box.innerHTML = ''; return; }
    if (st.checking) { box.innerHTML = `<div class="hint">${t('common.detecting')}</div>`; return; }
    if (st.ok) {
      const bits = [];
      const i = st.info || {};
      if (i.train_tokens) bits.push(`${fmt(i.train_tokens)} token`);
      if (i.vocab_size) bits.push(`vocab ${i.vocab_size}`);
      if (i.global_step != null) bits.push(t('import.step', { n: fmt(i.global_step) }));
      if (i.size_gb) bits.push(`${i.size_gb} GB`);
      if (i.size_mb) bits.push(`${i.size_mb} MB`);
      if (i.has_optimizer === false) bits.push(t('import.weightsOnly'));
      let h = `<div class="imp-ok">✓ ${t('import.usable')}${bits.length ? ' · ' + bits.join(' · ') : ''}</div>`;
      (st.warnings || []).forEach((w) => { h += `<div class="imp-warn">⚠ ${esc(txRender(w))}</div>`; });
      box.innerHTML = h;
    } else {
      // ★problems 里可能是后端 {k,v} 提示、也可能是前端包装的 {k}/{raw}，
      //   一律走 txRender：既能查词典，也不会把对象显示成 [object Object]。
      box.innerHTML = `<div class="imp-bad">✕ ${esc((st.problems || []).map(txRender).join(PREF.lang === 'en' ? '; ' : '；'))}</div>`;
    }
  },

  async checkImport(k, quiet) {
    const cur = (S.form.sources || {})[k] || {};
    const p = (cur.path || '').trim();
    if (!p) { if (!quiet) toast(tx('import.needPath'), 'err'); return; }
    S.form.importState = S.form.importState || {};
    // 同一路径正在校验或已校验过就不重复请求
    if (S.form.importState[k] && S.form.importState[k]._p === p
        && !S.form.importState[k].checking) {
      App.paintImportResult(k); return;
    }
    S.form.importState[k] = { checking: true, _p: p };
    App.paintImportResult(k);
    try {
      const r = await api('/api/import/check', { stage: k, path: p });
      // 请求期间用户可能又改了路径，过期结果直接丢弃
      const now = ((S.form.sources || {})[k] || {}).path || '';
      if (now.trim() !== p) return;
      r._p = p;
      S.form.importState[k] = r;
      App.paintImportResult(k);
      if (!r.ok && !quiet) toast(tx('import.bad'), 'err');
    } catch (e) {
      S.form.importState[k] = { ok: false, problems: [errDesc(e)], _p: p };
      App.paintImportResult(k);
    }
  },

  async check() {
    const c = App.readForm();
    const r = await api('/api/check', { tier: c.tier, block_size: c.block_size, arch: c.arch, vocab_size: c.vocab_size });
    const box = $('#checkResult');
    const warns = r.warnings || [];
    // ★横幅也要能随语言实时重译：保留后端原文，渲染时才翻译
    const paint = () => {
      const list = (arr, sep) => (arr || []).map((x) => esc(sv(x))).join(sep);
      if (!r.ok) {
        box.innerHTML = `<div class="banner err"><span class="bi">✕</span><div><b>${t('create.checkBad')}</b><br>${list(r.problems, '<br>')}</div></div>`;
      } else if (warns.length) {
        box.innerHTML = `<div class="banner"><span class="bi">⚠</span><div><b>${t('create.checkWarn')}</b>　${t('create.vramNeed', { v: r.vram_need_gb })}<br>${list(warns, '<br>')}
          ${(r.notes || []).length ? '<br>' + list(r.notes, ' ') : ''}</div></div>`;
      } else {
        box.innerHTML = `<div class="banner ok"><span class="bi">✓</span><div><b>${t('create.checkOk')}</b>　${t('create.vramNeed', { v: r.vram_need_gb })}
          ${list(r.notes, ' ')}</div></div>`;
      }
    };
    paint();
    liveDrop(S._checkLive);
    S._checkLive = liveAdd(box, txRaw(''), paint);
    return r.ok;
  },

  async create() {
    const name = $('#fName').value.trim();
    if (!name) { toast(tx('create.needName'), 'err'); return; }
    const cfg = App.readForm();
    if (!cfg.corpus.length) { toast(tx('create.needCorpus'), 'err'); return; }
    if (!(await App.check())) { toast(tx('create.checkBad'), 'err'); return; }
    try {
      await api('/api/projects/create', { name, config: cfg });
      toast(txJoin([tx('create.created'), txRaw(name)]), 'ok');
      S.current = name; S.lastDone = false; $('#fName').value = '';
      App.go('data');
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  /* ---------------- data page ---------------- */
  async refreshData() {
    if (!S.current) { $('#dataEmpty').style.display = ''; $('#dataBody').style.display = 'none'; return; }
    $('#dataEmpty').style.display = 'none'; $('#dataBody').style.display = '';
    try {
      const p = await api('/api/project?name=' + encodeURIComponent(S.current));
      S.proj = p;
      // 数据页此前不取全局运行态，导致切到别的项目时占用提示用的是旧值。
      // 项目列表也要留：占用提示要读「在跑的那个项目」的当前工位。
      try {
        const all = await api('/api/projects');
        S.runner = all.runner; S.projects = all.projects;
      } catch (e) { /* ignore */ }
      $('#dataName').textContent = p.name;
      const c = p.config;
      $('#dataCfg').textContent = `${(c.corpus || []).length} × ${t('create.corpusN')} | ${levelName(c.clean_level)} | vocab ${c.vocab_size}`;
      $('#btnDataStop').disabled = !p.state.running;
      App.renderDataPipe(p.state); App.renderGroups(p.state); App.renderDataCorpus(c);
      // 错误横幅存的是后端中文原文，必须过 sv() 才会随语言变
      $('#dataError').innerHTML = p.state.error
        ? `<div class="banner err" style="margin:16px 0 0"><span class="bi">✕</span><div>${esc(sv(p.state.error))}</div></div>` : '';
      await App.refreshDataLog();
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  renderDataPipe(st) {
    App.renderStepPick(st);
    const stages = S.meta.stages.filter((s) => DATA_STAGES.includes(s.key));
    $('#dataPipe').innerHTML = stages.map((s) => {
      const x = st.stages[s.key] || { status: 'pending', progress: 0 };
      const pct = x.status === 'done' ? 100 : Math.round((x.progress || 0) * 100);
      return `<div class="pstage ${x.status}" data-k="${s.key}">
        <div class="pbar"><div class="pfill" style="width:${pct}%"></div></div>
        <div class="pn">${stageName(s.key)}</div>
        <div class="ps">${x.status === 'running' ? pct + '%' : (x.status === 'done' ? '✓' : '')}</div></div>`;
    }).join('');
    $$('#dataPipe .pstage').forEach((el) => { el.onclick = () => { S.dataLogStage = el.dataset.k; App.refreshDataLog(); }; });
  },

  renderGroups(st) {
    const running = st.running;
    const ready = { prepare: true, build: st.stages.clean.status === 'done', all_data: true,
      train: st.stages.mix.status === 'done', test: st.stages.train.status === 'done', full: true };
    $('#groupList').innerHTML = S.meta.groups.map((g) => {
      const ok = ready[g.key];
      const allDone = g.stages.every((k) => st.stages[k].status === 'done');
      const names = g.stages.map(stageName).join(' → ');
      return `<div class="group ${(!ok || running) ? 'dis' : ''}" data-g="${g.key}">
        <div class="gn">${groupName(g.key)}${allDone ? ` <span class="tag done">${t('data.allDone')}</span>` : ''}</div>
        <div class="gd">${esc(sv(g.desc))}</div><div class="gs">${esc(names)}</div>
        <span class="gready ${ok ? 'yes' : 'no'}">${ok ? (allDone ? t('data.rerun') : t('data.ready')) : t('data.needPrev')}</span>
      </div>`;
    }).join('');
    $$('#groupList .group').forEach((el) => {
      el.onclick = async () => {
        if (el.classList.contains('dis')) { toast(tx(running ? 'data.running' : 'data.needPrevToast'), 'err'); return; }
        const g = S.meta.groups.find((x) => x.key === el.dataset.g);
        if (g.stages.every((k) => st.stages[k].status === 'done')) {
          if (!(await confirmBox(tx('data.rerunTitle'), tx('data.rerunText', { g: tx('group.' + g.key) })))) return;
          await api('/api/run/reset', { name: S.current, stages: g.stages });
        }
        try {
          await api('/api/run/start', { name: S.current, group: g.key });
          toast(txJoin([tx('data.started'), tx('group.' + g.key)]), 'ok');
          if (g.key === 'train') App.go('train');
          App.refreshData();
        } catch (e) { toast(errDesc(e), 'err'); }
      };
    });
  },

  renderDataCorpus(cfg) {
    const list = cfg.corpus || [];
    if (!list.length) { $('#dataCorpus').innerHTML = `<div class="hint">${t('data.noCorpus')}</div>`; return; }
    const vals = list.map((c) => (c.percent != null ? +c.percent : (c.weight || 1)));
    const sum = vals.reduce((a, b) => a + b, 0) || 1;
    $('#dataCorpus').innerHTML = `<table class="tbl-sm"><thead><tr>
      <th>#</th><th>${t('data.colPath')}</th><th>${t('data.colKind')}</th><th>${t('data.colLevel')}</th>
      <th>${t('data.colPct')}</th><th>${t('create.cjkMin')}</th><th>${t('create.repMax')}</th>
      <th>${t('create.symMax')}</th><th>${t('create.minChars')}</th><th>${t('data.colDedup')}</th><th>${t('data.colCustom')}</th>
      </tr></thead><tbody>` + list.map((c, i) => {
        const lv = c.clean_level || cfg.clean_level;
        const cp = App.cleanParams(c.kind, lv, c.clean_custom);
        const nc = Object.keys(c.clean_custom || {}).length;
        const dm = t('clean.dedup.' + (c.dedup || 'bloom'));
        const warns = App.cleanWarns(c.kind, cp);
        return `<tr><td>${i + 1}</td>
          <td class="dc-path"><input type="text" data-dcpath="${i}" value="${esc(c.path)}"
            title="${esc(c.path)}" placeholder="${esc(t('create.pathPh'))}"></td>
          <td>${kindName(c.kind)}</td><td>${levelName(lv)}</td>
          <td class="mono">${((vals[i] / sum) * 100).toFixed(1)}%</td>
          <td class="mono">${cp.min_cjk_ratio}</td><td class="mono">${cp.max_repeat_ratio}</td>
          <td class="mono">${cp.max_symbol_ratio}</td><td class="mono">${cp.min_chars}</td>
          <td>${dm}</td>
          <td>${nc ? `<span class="tag run">${nc}</span>` : `<span style="color:var(--txt3)">${t('common.preset')}</span>`}
            ${warns.length ? `<span title="${esc(warns.join('; '))}" style="color:var(--amber);cursor:help"> ⚠</span>` : ''}</td></tr>`;
      }).join('') + '</tbody></table>'
      + `<div class="btn-row" style="margin-top:12px">
           <button class="btn sm" id="dcSave" disabled>${t('data.savePath')}</button>
         </div>
         <div class="hint" id="dcHint" style="margin-top:10px">${t('data.pathHint')}</div>`;
    // ★路径可在本页直接改：语料挪盘/换目录后不必回新建项目页重填。
    //   改动先只记在内存，点保存才写配置，避免边打字边触发校验。
    const dirty = new Set();
    $$('#dataCorpus [data-dcpath]').forEach((el) => {
      el.oninput = () => {
        const i = +el.dataset.dcpath;
        if (el.value !== (list[i].path || '')) dirty.add(i); else dirty.delete(i);
        const b = $('#dcSave');
        if (b) b.disabled = !dirty.size || !!(S.runner && S.runner.running);
        const h = $('#dcHint');
        if (h) h.textContent = dirty.size ? t('data.pathDirty', { n: dirty.size }) : t('data.pathHint');
      };
    });
    const sv2 = $('#dcSave');
    if (sv2) sv2.onclick = async () => {
      // 后端也会拒绝运行中改配置；这里再挡一层，避免发出注定失败的请求
      if (!dirty.size || !S.current || (S.runner && S.runner.running)) return;
      const next = JSON.parse(JSON.stringify(cfg));
      dirty.forEach((i) => {
        const el = $(`#dataCorpus [data-dcpath="${i}"]`);
        next.corpus[i].path = (el.value || '').trim();
        // 路径变了，旧的探测结论不再可信
        delete next.corpus[i].info;
      });
      sv2.disabled = true;
      try {
        await api('/api/projects/config', { name: S.current, config: next });
        toast(tx('data.pathSaved'), 'ok');
        await App.refreshData();
      } catch (e) { toast(errDesc(e), 'err'); sv2.disabled = false; }
    };
  },

  async refreshDataLog() {
    const stages = S.meta.stages.filter((s) => DATA_STAGES.includes(s.key));
    $('#dataLogTabs').innerHTML = stages.map((s) =>
      `<button data-s="${s.key}" class="${S.dataLogStage === s.key ? 'on' : ''}">${stageName(s.key)}</button>`).join('');
    $$('#dataLogTabs button').forEach((b) => { b.onclick = () => { S.dataLogStage = b.dataset.s; App.refreshDataLog(); }; });
    const cur = stages.find((s) => s.key === S.dataLogStage);
    $('#dataLogName').textContent = cur ? stageName(cur.key) + ' · ' + sv(cur.desc) : '';
    try {
      const d = await api(`/api/log?name=${encodeURIComponent(S.current)}&stage=${S.dataLogStage}`);
      const box = $('#dataLogBox');
      const bottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
      box.textContent = d.text || '—';
      if (bottom) box.scrollTop = box.scrollHeight;
    } catch (e) { /* ignore */ }
  },

  /* ---------------- training ---------------- */
  async refreshTrain() {
    if (!S.current) { $('#trainEmpty').style.display = ''; $('#trainBody').style.display = 'none'; return; }
    $('#trainEmpty').style.display = 'none'; $('#trainBody').style.display = '';
    try {
      const p = await api('/api/project?name=' + encodeURIComponent(S.current));
      S.proj = p;
      // 同时留下项目列表：占用提示要从「在跑的那个项目」读它的当前工位
      try {
        const all = await api('/api/projects');
        S.runner = all.runner; S.projects = all.projects;
      } catch (e) { /* ignore */ }
      const c = p.config, st = p.state, ts = st.stages.train;
      $('#trainName').textContent = p.name;
      const archTxt = c.arch ? `${c.arch.hidden_size || '?'}×${c.arch.num_hidden_layers || '?'}` : tierLabel(c.tier, S.meta.tier_labels[c.tier]);
      $('#trainCfg').textContent = `${archTxt} | ctx ${c.block_size} | ${c.batch_size}×${c.grad_accum} | ckpt/${c.save_every}`
        + (p.output_dir ? ` | ${t('train.outAt')} ${p.output_dir}` : '');
      const dataReady = st.stages.mix.status === 'done';
      const isTrainRunning = st.running && st.current === 'train';
      const pausing = !!(S.runner && S.runner.pausing);
      $('#btnTrainStart').disabled = st.running || !dataReady;
      $('#btnTrainStop').disabled = !st.running;
      $('#btnTrainPause').disabled = !isTrainRunning || pausing;
      $('#btnTrainPause').innerHTML = pausing ? `<span class="spin"></span> ${t('train.pausing')}` : t('train.pause');
      $('#btnTest').disabled = st.running || ts.status !== 'done';
      $('#btnTrainStart').textContent = ts.status === 'done' ? t('train.restart')
        : (['paused', 'failed', 'stopped'].includes(ts.status) ? t('train.resume') : t('train.start'));
      $('#btnTrainStart').title = dataReady ? '' : t('train.needData');
      const tagMap = { done: 'done', running: 'run', paused: 'idle', failed: 'fail', stopped: 'idle', pending: 'idle' };
      const lblMap = { done: 'stDone', running: 'stRunning', paused: 'stPaused', failed: 'stFailed', stopped: 'stStopped', pending: 'stPending' };
      $('#trainStatusTag').innerHTML = `<span class="tag ${tagMap[ts.status] || 'idle'}">${t('train.' + (lblMap[ts.status] || 'stPending'))}</span>`;
      // ★别的项目占用单卡时，本项目按钮全灰但状态显示「待开始」，
      //   不说明就会让人以为坏了。这里显式指出是谁在跑、跑到哪一步。
      const r = S.runner || {};
      const busyOther = r.running && r.active && r.active !== p.name;
      // ★st 是本项目（空闲）的状态，不能用它的 current；
      //   要读在跑的那个项目在列表里的 current，才是它真实的工位。
      const actCur = busyOther
        ? (((S.projects || []).find((x) => x.name === r.active) || {}).current || '')
        : '';
      const busyTxt = busyOther
        ? t('train.busyOther', {
          a: r.active,
          s: actCur ? stageName(actCur) : t('home.running'),
        })
        : '';
      $('#trainError').innerHTML = st.error
        ? `<div class="banner err" style="margin:16px 0 0"><span class="bi">✕</span><div>${esc(sv(st.error))}</div></div>`
        : (busyOther ? `<div class="banner" style="margin:16px 0 0"><span class="bi">⚠</span><div>${esc(busyTxt)}</div></div>`
          : (!dataReady ? `<div class="banner" style="margin:16px 0 0"><span class="bi">⚠</span><div>${t('train.dataNotReady')}</div></div>` : ''));
      await Promise.all([App.refreshMetrics(), App.refreshCk(), App.refreshTrainLog()]);
      App.renderDoneBanner(p);
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  renderDoneBanner(p) {
    const ts = p.state.stages.train, box = $('#doneBanner');
    if (ts.status !== 'done') { box.innerHTML = ''; S.lastDone = false; return; }
    const dur = (ts.finished_at && ts.started_at) ? ts.finished_at - ts.started_at : null;
    const tested = p.state.stages.test.status === 'done';
    box.innerHTML = `<div class="done-banner">
      <div class="db-ic">✓</div>
      <div style="flex:1;min-width:220px">
        <div class="db-t">${t('train.doneTitle')}</div>
        <div class="db-s">${dur ? t('train.doneTime') + ' ' + fmt.dur(dur) + '　' : ''}${t('train.doneSaved')}${p.config.backup_dir ? ' ' + t('train.doneBackup') + ' ' + esc(p.config.backup_dir) : ''}.
          ${tested ? t('train.doneTested') : t('train.doneSuggest')}</div>
      </div></div>`;
    if (!S.lastDone) { S.lastDone = true; toast(tx('train.doneToast'), 'ok'); }
  },

  async refreshMetrics() {
    const d = await api('/api/trainlog?name=' + encodeURIComponent(S.current));
    const pts = d.points || [], last = d.latest, cfg = S.proj.config;
    const budget = cfg.max_tokens > 0 ? cfg.max_tokens : (S.proj.total_tokens || null);
    let eta = null, pct = 0;
    if (last) {
      if (last.tok_s && budget) eta = Math.max(0, (budget - last.tokens) / last.tok_s);
      if (budget) pct = Math.min(100, (last.tokens / budget) * 100);
    }
    const ts = S.proj.state.stages.train;
    if (ts.status === 'done') pct = 100;
    $('#trainFill').style.width = pct.toFixed(2) + '%';
    $('#trainProgPct').textContent = pct.toFixed(2) + '%';
    $('#trainProgText').textContent = ts.status === 'running' ? (sv(ts.message) || t('train.stRunning'))
      : (ts.status === 'done' ? t('train.doneTitle') : (sv(ts.message) || t('train.waiting')));
    $('#metricRow').innerHTML = `
      <div class="metric c1"><div class="mk">${t('train.mStep')}</div><div class="mv">${last ? fmt.n(last.step) : '—'}</div></div>
      <div class="metric c2"><div class="mk">${t('train.mLoss')}</div><div class="mv">${last ? fmt.f(last.loss, 3) : '—'}</div></div>
      <div class="metric c3"><div class="mk">${t('train.mTokens')}</div><div class="mv">${last ? fmt.tok(last.tokens) : '—'}</div></div>
      <div class="metric c1"><div class="mk">${t('train.mSpeed')}</div><div class="mv">${last ? fmt.n(Math.round(last.tok_s)) : '—'}<span class="mu">tok/s</span></div></div>
      <div class="metric c4"><div class="mk">${t('train.mVram')}</div><div class="mv">${last ? fmt.f(last.vram, 1) : '—'}<span class="mu">GB</span></div></div>
      <div class="metric c2"><div class="mk">${t('train.mEta')}</div><div class="mv" style="font-size:18px">${ts.status === 'done' ? t('train.finished') : fmt.eta(eta)}</div></div>
      <div class="metric ${last && last.spikes > 0 ? 'c4' : 'c3'}"><div class="mk">${t('train.mSpike')}</div><div class="mv">${last ? last.spikes + ' / ' + last.rollbacks : '—'}</div></div>`;
    $('#lossEmpty').style.display = pts.length ? 'none' : '';
    $('#perfEmpty').style.display = pts.length ? 'none' : '';
    if (pts.length) {
      const fl = App.rangeFilter(pts, d.evals || [], 'TrainLoss');
      const fp = App.rangeFilter(pts, [], 'TrainPerf');
      Chart.loss($('#lossChart'), fl.pts, fl.evals); Chart.perf($('#perfChart'), fp.pts);
    }
  },

  // ★图表时间范围：all / 秒数。按点的墙钟时间过滤；
  //   无墙钟的旧日志退回用最新点时间作基准。过滤后至少留 2 个点，
  //   窗口内没有数据时保留最近 2 个点，避免空图。
  rangeFilter(pts, evals, key) {
    const r = (S.chartRange || {})[key] || 'all';
    if (r === 'all' || !pts.length) return { pts, evals: evals || [] };
    const sec = Number(r);
    const lastT = pts[pts.length - 1].time || '';
    const base = lastT ? Date.parse(lastT.replace(' ', 'T')) : Date.now();
    const cut = base - sec * 1000;
    const keep = (p) => !p.time || Date.parse(p.time.replace(' ', 'T')) >= cut;
    let fp = pts.filter(keep);
    if (fp.length < 2) fp = pts.slice(-2);
    const fe = (evals || []).filter(keep);
    return { pts: fp, evals: fe };
  },

  setChartRange(key, r) {
    S.chartRange = S.chartRange || {};
    S.chartRange[key] = r;
    const box = $('#range' + key);
    if (box) box.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.r === r));
    if (key.startsWith('Train')) App.refreshTrain();
    else App.refreshWatchOne();
  },

  async refreshCk() {
    const d = await api('/api/checkpoints?name=' + encodeURIComponent(S.current));
    const c = S.proj.config;
    $('#ckSummary').textContent = t('train.ckSummary', { a: c.save_every, b: c.keep_checkpoints })
      + (c.backup_dir ? t('train.ckBackup', { c: c.backup_every, d: c.backup_dir, e: c.keep_backups }) : t('train.ckNoBackup'))
      + t('train.ckNever');
    const box = $('#ckList');
    if (!d.checkpoints.length) { box.innerHTML = `<div class="hint">${t('train.noCk')}</div>`; return; }
    box.innerHTML = `<table class="tbl-sm"><thead><tr><th>${t('train.ckName')}</th><th>${t('train.ckStep')}</th>
      <th>${t('train.ckSize')}</th><th>${t('train.ckTime')}</th><th style="text-align:right">${t('train.ckAction')}</th></tr></thead><tbody>`
      + d.checkpoints.map((x) => `<tr>
        <td><b>${esc(x.name)}</b>${/best|final/.test(x.name) ? ` <span class="tag done">${t('train.ckProtected')}</span>` : ''}</td>
        <td class="mono">${x.step != null ? fmt.n(x.step) : '—'}</td><td class="mono">${x.size_gb} GB</td>
        <td class="mono" style="color:var(--txt3)">${new Date(x.mtime * 1000).toLocaleString()}</td>
        <td style="text-align:right">${/^checkpoint-/.test(x.name) ? `<button class="btn sm" data-resume="${esc(x.name)}">${t('train.ckResume')}</button>` : ''}</td>
      </tr>`).join('') + '</tbody></table>'
      + (d.backup_dir ? `<div class="hint" style="margin-top:12px">${t('train.ckDir')} ${esc(d.backup_dir)}: ${d.backups.length ? d.backups.map(esc).join(', ') : t('train.ckNone')}</div>` : '');
    $$('#ckList [data-resume]').forEach((b) => {
      b.onclick = async () => {
        if (!(await confirmBox(tx('train.resumeTitle'), tx('train.resumeText', { c: b.dataset.resume })))) return;
        try { await api('/api/run/start', { name: S.current, group: 'train' }); toast(tx('train.resumed'), 'ok'); App.refreshTrain(); }
        catch (e) { toast(errDesc(e), 'err'); }
      };
    });
  },

  async editCkPolicy() {
    const c = S.proj.config;
    const html = `<div class="row">
      <div class="field"><label>${t('create.saveEvery')}</label><input type="number" id="eSave" value="${c.save_every}" min="1"></div>
      <div class="field"><label>${t('create.keep')}</label><input type="number" id="eKeep" value="${c.keep_checkpoints}" min="1"></div>
    </div><div class="row">
      <div class="field"><label>${t('create.backupDir')}</label><input type="text" id="eBdir" value="${esc(c.backup_dir)}"></div>
      <div class="field"><label>${t('create.keepBackup')}</label><input type="number" id="eKeepBk" value="${c.keep_backups}" min="1"></div>
    </div>`;
    if (!(await confirmBox(tx('train.policyTitle'), tx('train.policyText'), html))) return;
    try {
      await api('/api/projects/config', { name: S.current, config: {
        save_every: parseInt($('#eSave').value, 10) || 500,
        keep_checkpoints: parseInt($('#eKeep').value, 10) || 3,
        backup_dir: $('#eBdir').value.trim(),
        backup_every: parseInt($('#eSave').value, 10) || 500,
        keep_backups: parseInt($('#eKeepBk').value, 10) || 10 } });
      toast(tx('train.policySaved'), 'ok'); App.refreshTrain();
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  async refreshTrainLog() {
    $$('#trainLogTabs button').forEach((b) => {
      b.classList.toggle('on', b.dataset.s === S.trainLogStage);
      b.onclick = () => { S.trainLogStage = b.dataset.s; App.refreshTrainLog(); };
    });
    try {
      const d = await api(`/api/log?name=${encodeURIComponent(S.current)}&stage=${S.trainLogStage}`);
      const box = $('#trainLogBox');
      const bottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
      box.textContent = d.text || '—';
      if (bottom) box.scrollTop = box.scrollHeight;
    } catch (e) { /* ignore */ }
  },

  async startTrain() {
    const ts = S.proj.state.stages.train;
    if (ts.status === 'done') {
      if (!(await confirmBox(tx('train.restartTitle'), tx('train.restartText')))) return;
      await api('/api/run/reset', { name: S.current, stages: ['train', 'test'] });
    }
    try {
      await api('/api/run/start', { name: S.current, group: 'train' });
      toast(tx(ts.status === 'paused' ? 'train.resumed' : 'train.started'), 'ok');
      S.lastDone = false; App.refreshTrain();
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  async pauseTrain() {
    if (!(await confirmBox(tx('train.pauseTitle'), tx('train.pauseText')))) return;
    try {
      const r = await api('/api/run/pause', { name: S.current });
      S.runner = { ...(S.runner || {}), pausing: true };
      toast(r.message ? txRaw(r.message) : tx('train.pauseRequested'), 'ok');
      App.refreshTrain();
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  async stop() {
    if (!(await confirmBox(tx('train.stopTitle'), tx('train.stopText')))) return;
    try { await api('/api/run/stop', {}); toast(tx('train.stopped'), 'ok'); App.refreshTrain(); App.refreshData(); }
    catch (e) { toast(errDesc(e), 'err'); }
  },

  async runTest() {
    try {
      await api('/api/run/start', { name: S.current, group: 'test' });
      S.trainLogStage = 'test'; toast(tx('train.testStarted'), 'ok'); App.refreshTrain();
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  /* ---------------- external monitor ---------------- */
  async refreshWatch() {
    // ★1 秒轮询必须防重入：上一次还没回来就跳过这一拍，
    //   否则慢磁盘时请求会越堆越多，反而更卡。
    if (S._watchBusy) return;
    S._watchBusy = true;
    try {
      // 即使已点进详情，也要刷新上方卡片列表，
      // 否则卡片的步数与百分比会停在进入详情那一刻。
      if (S.watchName) {
        await Promise.all([App.refreshWatchList(), App.refreshWatchOne()]);
      } else {
        $('#watchDetail').style.display = 'none';
        await App.refreshWatchList();
      }
    } finally {
      S._watchBusy = false;
    }
  },

  // 填完输出目录就自动推断总步数与预算；用户已手填的值不覆盖
  async probeWatch(silent, force) {
    const dir = ($('#wDir').value || '').trim();
    const box = $('#wProbe');
    if (!dir) { if (box) box.innerHTML = ''; return; }
    const key = dir + '|' + (($('#wLog').value || '').trim());
    if (S._probeKey === key && !force) return;
    S._probeKey = key;
    if (box) box.innerHTML = `<div class="hint">${t('watch.probing')}</div>`;
    try {
      const d = await api('/api/watch/probe?dir=' + encodeURIComponent(dir)
        + '&log=' + encodeURIComponent(($('#wLog').value || '').trim()));
      // 请求期间用户又改了目录 → 丢弃过期结果
      if (($('#wDir').value || '').trim() !== dir) return;
      const tEl = $('#wTokens'), sEl = $('#wSteps');
      const filled = [];
      if (d.total_tokens > 0 && tEl && !tEl.value.trim()) {
        tEl.value = (d.total_tokens / 1e9).toFixed(3);
        tEl.classList.add('auto-filled');
        filled.push(t('watch.total'));
      }
      if (d.total_steps > 0 && sEl && !sEl.value.trim()) {
        sEl.value = String(d.total_steps);
        sEl.classList.add('auto-filled');
        filled.push(t('watch.steps'));
      }
      if (!box) return;
      if (!d.ok && !d.total_steps) {
        box.innerHTML = `<div class="imp-bad">✕ ${esc((d.problems || []).map(sv).join('; '))}</div>`;
        return;
      }
      const bits = [];
      if (d.total_steps) bits.push(t('watch.probeSteps', { n: fmt.n(d.total_steps) }));
      if (d.total_tokens) bits.push(t('watch.probeTokens', { n: (d.total_tokens / 1e9).toFixed(3) }));
      if (d.tokens_per_step) bits.push(t('watch.probeTps', { n: fmt.n(d.tokens_per_step) }));
      let h = `<div class="imp-ok">✓ ${t('watch.probed')}${bits.length ? ' · ' + bits.join(' · ') : ''}</div>`;
      if (filled.length) h += `<div class="hint">${t('watch.autoFilled', { f: filled.join(' / ') })}</div>`;
      // 来源如实标注：推断值与实测值不能混为一谈
      const src = (d.sources || []);
      if (src.includes('derived_from_steps')) h += `<div class="hint">${t('watch.srcDerived')}</div>`;
      if (src.includes('fallback_available')) h += `<div class="imp-warn">⚠ ${t('watch.srcFallback')}</div>`;
      if (!src.includes('console_total') && d.total_steps) h += `<div class="hint">${t('watch.srcNoConsole')}</div>`;
      box.innerHTML = h;
      liveDrop(S._probeLive);
      S._probeLive = liveAdd(box, txRaw(''), () => App.probeWatch(true, true));
    } catch (e) {
      if (box && !silent) box.innerHTML = `<div class="imp-bad">✕ ${esc(sv(e.message))}</div>`;
    }
  },

  async refreshWatchList() {
    try {
      const d = await api('/api/watch/list');
      const box = $('#watchList');
      if (!d.items.length) {
        box.innerHTML = `<div class="empty" style="padding:34px 20px"><div class="ei">◎</div><p>${t('watch.empty')}</p></div>`;
        S._watchSig = '';
        return;
      }
      // ★1 秒轮询绝不能重建卡片：重建会把鼠标下的元素换掉，
      //   :hover 随之丢失又立刻恢复，translateY 反复触发 → 卡片一直抖。
      //   改为：结构只建一次，之后原地改文字/宽度/类名，元素身份始终不变。
      const tag = { running: 'run', stalled: 'fail', finished: 'done', paused: 'idle', unknown: 'idle' };
      const lbl = { running: 'stRunning', stalled: 'stStalled', finished: 'stFinished', paused: 'stPaused', unknown: 'stUnknown' };
      const names = d.items.map((s) => s.name).join('\u0001');
      let grid = box.querySelector('.pcards');
      if (!grid || S._watchSig !== names) {
        box.innerHTML = '<div class="pcards">' + d.items.map((s) => `
          <div class="pcard" data-w="${esc(s.name)}" tabindex="0" role="button">
            <div class="pcn"><span class="pcn-name">${esc(s.name)}</span><span class="tag idle pc-tag"></span></div>
            <div class="pc-src"></div>
            <div class="pcm pc-meta">—</div>
            <div class="pcp"><div class="big-prog" style="margin:0"><div class="fill pc-fill" style="width:0"></div></div>
            <div class="hint pc-note" style="margin-top:6px"></div></div>
          </div>`).join('') + '</div>';
        grid = box.querySelector('.pcards');
        S._watchSig = names;
        // 只在结构新建时绑一次；事件委托到容器，避免重复绑定
        grid.onclick = (ev) => {
          const card = ev.target.closest('.pcard');
          if (card) App.openWatch(card.dataset.w);
        };
        grid.onkeydown = (ev) => {
          if (ev.key !== 'Enter' && ev.key !== ' ') return;
          const card = ev.target.closest('.pcard');
          if (card) { ev.preventDefault(); App.openWatch(card.dataset.w); }
        };
      }
      const setTxt = (el, v) => { if (el && el.textContent !== v) el.textContent = v; };
      d.items.forEach((s) => {
        const card = grid.querySelector(`.pcard[data-w="${CSS.escape(s.name)}"]`);
        if (!card) return;
        const L = s.log.latest, pct = s.percent != null ? s.percent : 0;
        card.classList.toggle('on', s.name === S.watchName);
        const tg = card.querySelector('.pc-tag');
        const cls = 'tag pc-tag ' + (tag[s.state] || 'idle');
        if (tg.className !== cls) tg.className = cls;
        setTxt(tg, t('watch.' + (lbl[s.state] || 'stUnknown')));
        // 来源如实标注：工坊项目 vs 外部登记，避免用户误以为能在本页操作外部训练
        const srcEl = card.querySelector('.pc-src');
        if (srcEl) {
          const isProj = s.source === 'project';
          const sCls = 'pc-src' + (isProj ? ' proj' : '');
          if (srcEl.className !== sCls) srcEl.className = sCls;
          setTxt(srcEl, isProj ? t('watch.srcProject') : t('watch.srcExternal'));
        }
        setTxt(card.querySelector('.pc-meta'),
          L ? `${t('train.mStep')} ${fmt.n(L.step)} | loss ${fmt.f(L.loss, 3)}` : '—');
        const fill = card.querySelector('.pc-fill');
        const w = pct.toFixed(2) + '%';
        if (fill.style.width !== w) fill.style.width = w;
        setTxt(card.querySelector('.pc-note'),
          (s.percent != null ? pct.toFixed(3) + '%' : t('watch.noTotalPct'))
          + (L ? ' | ' + fmt.tok(L.tokens) : ''));
      });
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  // 点卡片：选中 → 刷新 → 平滑滚到详情。滚动只在用户点击时做一次，
  // 定时刷新绝不滚动，否则每秒都会把页面拽回去。
  async openWatch(name) {
    if (!name) return;
    const changed = S.watchName !== name;
    S.watchName = name;
    await App.refreshWatch();
    if (!changed && S._watchScrolled === name) return;
    S._watchScrolled = name;
    const el = $('#watchDetail');
    if (!el || el.style.display === 'none') return;
    const hdr = document.querySelector('header');
    const off = (hdr ? hdr.getBoundingClientRect().height : 0) + 14;
    const y = el.getBoundingClientRect().top + window.scrollY - off;
    const reduce = window.matchMedia
      && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    window.scrollTo({ top: Math.max(0, y), behavior: reduce ? 'auto' : 'smooth' });
  },

  async refreshWatchOne() {
    if (!S.watchName) return;
    try {
      const s = await api('/api/watch/one?name=' + encodeURIComponent(S.watchName));
      S.watchSnap = s;
      $('#watchDetail').style.display = '';
      $('#wTitle').textContent = s.name;
      $('#wPath').textContent = s.out_dir;
      // ★工坊项目 vs 外部训练：按钮语义不同，不能混用
      const isProj = s.source === 'project';
      const rm = $('#btnWatchRemove'), go = $('#btnWatchGoTrain'), od = $('#btnWatchOpenDir');
      if (rm) rm.style.display = isProj ? 'none' : '';
      if (go) go.style.display = isProj ? '' : 'none';
      if (od) od.textContent = t(isProj ? 'rv.openModel' : 'rv.copyPath');
      const tag = { running: 'run', stalled: 'fail', finished: 'done', paused: 'idle', unknown: 'idle' };
      const lbl = { running: 'stRunning', stalled: 'stStalled', finished: 'stFinished', paused: 'stPaused', unknown: 'stUnknown' };
      $('#wStateTag').innerHTML = `<span class="tag ${tag[s.state] || 'idle'}">${t('watch.' + (lbl[s.state] || 'stUnknown'))}</span>`;
      const L = s.log.latest, pct = s.percent != null ? s.percent : 0;
      $('#wFill').style.width = pct.toFixed(2) + '%';
      $('#wProgPct').textContent = s.percent != null ? pct.toFixed(3) + '%' : '—';
      $('#wProgText').textContent = L ? `${t('train.mStep')} ${fmt.n(L.step)} | ${fmt.tok(L.tokens)}${s.total_tokens ? ' / ' + fmt.tok(s.total_tokens) : ''}` : '—';
      let notice = '';
      if (s.state === 'stalled') notice = `<div class="banner" style="margin:16px 0 0"><span class="bi">⚠</span><div>${t('watch.stalled', { a: fmt.dur(s.log_age_sec), b: fmt.dur(s.stall_threshold_sec) })}</div></div>`;
      else if (s.state === 'paused') notice = `<div class="banner" style="margin:16px 0 0"><span class="bi">⏸</span><div>${t('watch.paused')}</div></div>`;
      else if (s.state === 'running') notice = `<div class="hint" style="margin-top:12px">${t('watch.alive', { a: fmt.dur(s.log_age_sec), b: s.step_sec_est })}</div>`;
      if (!s.total_tokens && !s.total_steps) notice += `<div class="hint" style="margin-top:8px">${t('watch.noTotal')}</div>`;
      $('#wNotice').innerHTML = notice;
      $('#wMetrics').innerHTML = `
        <div class="metric c1"><div class="mk">${t('train.mStep')}</div><div class="mv">${L ? fmt.n(L.step) : '—'}</div></div>
        <div class="metric c2"><div class="mk">${t('train.mLoss')}</div><div class="mv">${L ? fmt.f(L.loss, 3) : '—'}</div></div>
        <div class="metric c3"><div class="mk">${t('train.mTokens')}</div><div class="mv">${L ? fmt.tok(L.tokens) : '—'}</div></div>
        <div class="metric c1"><div class="mk">${t('train.mSpeed')}</div><div class="mv">${L ? fmt.n(Math.round(L.tok_s)) : '—'}<span class="mu">tok/s</span></div></div>
        <div class="metric c4"><div class="mk">${t('train.mVram')}</div><div class="mv">${L ? fmt.f(L.vram, 1) : '—'}<span class="mu">GB</span></div></div>
        <div class="metric c2"><div class="mk">${t('train.mEta')}</div><div class="mv" style="font-size:18px">${s.state === 'finished' ? t('watch.stFinished') : (s.state === 'paused' ? t('watch.stPaused') : fmt.eta(s.eta_sec))}</div></div>
        <div class="metric ${L && L.spikes > 0 ? 'c4' : 'c3'}"><div class="mk">${t('train.mSpike')}</div><div class="mv">${L ? L.spikes + ' / ' + L.rollbacks : '—'}</div></div>`;
      const pts = s.log.points || [];
      $('#wLossEmpty').style.display = pts.length ? 'none' : '';
      $('#wPerfEmpty').style.display = pts.length ? 'none' : '';
      if (pts.length) {
        const fl = App.rangeFilter(pts, s.log.evals || [], 'WatchLoss');
        const fp = App.rangeFilter(pts, [], 'WatchPerf');
        Chart.loss($('#wLossChart'), fl.pts, fl.evals); Chart.perf($('#wPerfChart'), fp.pts);
      }
      const cks = s.checkpoints || [];
      $('#wCkList').innerHTML = cks.length
        ? `<table class="tbl-sm"><thead><tr><th>${t('train.ckName')}</th><th>${t('train.ckStep')}</th><th>${t('train.ckSize')}</th><th>${t('train.ckTime')}</th></tr></thead><tbody>`
          + cks.map((c) => `<tr><td><b>${esc(c.name)}</b>${/best|final/.test(c.name) ? ` <span class="tag done">${t('train.ckProtected')}</span>` : ''}</td>
            <td class="mono">${c.step != null ? fmt.n(c.step) : '—'}</td><td class="mono">${c.size_gb} GB</td>
            <td class="mono" style="color:var(--txt3)">${new Date(c.mtime * 1000).toLocaleString()}</td></tr>`).join('') + '</tbody></table>'
        : `<div class="hint">${t('train.noCk')}</div>`;
      const box = $('#wLogBox');
      const bottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
      box.textContent = s.tail || (s.log_file ? t('watch.logEmpty') : t('watch.noLog'));
      if (bottom) box.scrollTop = box.scrollHeight;
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  async watchAdd() {
    const name = $('#wName').value.trim(), dir = $('#wDir').value.trim();
    if (!name || !dir) { toast(tx('watch.needFields'), 'err'); return; }
    const raw = $('#wTokens').value.trim();
    let total = 0;
    if (raw) {
      const v = Number(raw);
      if (!isFinite(v) || v < 0) { toast(tx('watch.badTotal'), 'err'); return; }
      total = v * 1e9;
    }
    try {
      await api('/api/watch/add', { name, out_dir: dir, total_tokens: total,
        total_steps: parseInt($('#wSteps').value, 10) || 0, log_file: $('#wLog').value.trim() });
      toast(tx('watch.added'), 'ok');
      ['#wName', '#wDir', '#wTokens', '#wSteps', '#wLog'].forEach((s) => {
        $(s).value = ''; $(s).classList.remove('auto-filled');
      });
      // 新增后清空探测缓存与结果区，下次填目录才会重新检测
      S._probeKey = null;
      const pb = $('#wProbe'); if (pb) pb.innerHTML = '';
      await App.openWatch(name);      // 与点卡片一致：选中并滚到详情
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  async watchRemove() {
    if (!(await confirmBox(tx('watch.removeTitle'), tx('watch.removeText')))) return;
    try {
      await api('/api/watch/remove', { name: S.watchName });
      toast(tx('watch.removed'), 'ok');
      S.watchName = null; S._watchScrolled = null;
      App.refreshWatch();
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  /* ---------------- environment ---------------- */
  async refreshEnv(force) {
    try {
      const d = await api('/api/env' + (force ? '?force=1' : ''));
      S.env = d.env;
      const e = d.env, rt = d.runtime, box = $('#envStatus');
      if (e.ready) {
        const i = e.info;
        const missing = Object.entries(i.mods).filter(([, v]) => !v).map(([k]) => k);
        box.innerHTML = `<div class="done-banner" style="margin:0"><div class="db-ic">✓</div>
          <div style="flex:1"><div class="db-t">${t('env.ready')}</div>
          <div class="db-s">Python ${esc(i.ver)}　PyTorch ${esc(i.torch || '—')}　CUDA ${i.cuda ? t('env.cudaOk') + ' (' + esc(i.cuda_ver || '') + ')' : t('env.cudaNo')}</div></div></div>
          <div class="ci-meta" style="margin-top:14px"><b>${t('env.interpreter')}:</b> ${esc(i.exe)}<br>
          <b>${t('env.deps')}:</b> ${Object.entries(i.mods).map(([k, v]) => `<span style="color:${v ? 'var(--green)' : 'var(--txt3)'}">${v ? '✓' : '○'} ${esc(k)}</span>`).join('　')}</div>
          ${missing.length ? `<div class="hint" style="margin-top:10px">${t('env.optionalMissing', { d: missing.join(', ') })}</div>` : ''}`;
        $('#fPython').value = i.exe;
      } else {
        box.innerHTML = `<div class="banner err" style="margin:0"><span class="bi">✕</span>
          <div><b>${t('env.notReady')}</b><br>${t('env.notReadyText', { d: (e.required || []).join(', ') })}</div></div>
          ${e.tried && e.tried.length ? `<div class="hint" style="margin-top:12px">${t('env.tried', { n: e.tried.length })}</div>` : ''}`;
      }
      // ★安装指引过去直接用后端返回的中文数组，切到英文仍是中文。
      //   改为按序号取双语文案；后端数组只用来决定条数，不再决定内容。
      const nSteps = (e.howto || []).length || 5;
      const steps = [];
      for (let i = 1; i <= nSteps; i += 1) steps.push(t('env.step' + i));
      $('#envHowto').innerHTML = `<div class="logbox" style="max-height:none">${steps.map((s, n) => `${n + 1}. ${esc(s)}`).join('\n')}</div>
        <div class="hint" style="margin-top:12px">${t('env.howtoNote')}</div>`;
      $('#envRuntime').innerHTML = `<table class="tbl-sm"><tbody>
        <tr><td style="width:160px;color:var(--txt3)">${t('env.mode')}</td><td>${rt.frozen ? t('env.modeFrozen') : t('env.modeSource')}</td></tr>
        <tr><td style="color:var(--txt3)">${t('env.appRoot')}</td><td class="mono">${esc(rt.app_root)}</td></tr>
        <tr><td style="color:var(--txt3)">${t('env.webRoot')}</td><td class="mono">${esc(rt.resource_root)}</td></tr>
        <tr><td style="color:var(--txt3)">${t('env.engineDir')}</td><td class="mono">${esc(rt.engine_dir)}</td></tr>
        <tr><td style="color:var(--txt3)">${t('env.enginePy')}</td><td class="mono">${esc(rt.engine_python || t('env.notReadyShort'))}</td></tr>
      </tbody></table>`;
      App.renderUpgBackups();
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  /* ---------------- 导入更新包 ----------------
     ★两段式：校验只读 → 用户看过清单并确认 → 才写盘。
     ★所有提示都是 {k,v} 翻译键，切语言时整块重绘即时生效。 */
  upgMsg(m) {
    if (m == null) return '';
    if (typeof m === 'string') return sv(m);
    if (m.k) {
      const vars = {};
      Object.keys(m.v || {}).forEach((key) => {
        const x = m.v[key];
        vars[key] = (x && typeof x === 'object') ? App.upgMsg(x) : x;
      });
      return t(m.k, vars);
    }
    return String(m);
  },

  async checkUpgrade(quiet) {
    const p = ($('#fUpgPath').value || '').trim();
    const box = $('#upgResult');
    S.upg = null;
    $('#btnUpgApply').disabled = true;
    if (!p) { box.innerHTML = ''; if (!quiet) toast(tx('upg.noPath'), 'err'); return; }
    box.innerHTML = `<div class="hint">${t('common.detecting')}</div>`;
    try {
      const r = await api('/api/upgrade/inspect', { path: p });
      // 请求期间用户可能又改了路径，过期结果直接丢弃
      if ((($('#fUpgPath').value || '').trim()) !== p) return;
      S.upg = r; S.upg._p = p;
      App.paintUpgrade();
      if (!r.ok && !quiet) toast(tx('upg.checkBad'), 'err');
    } catch (e) {
      S.upg = { ok: false, problems: [{ k: 'upg.readFail', v: { e: e.message } }], _p: p };
      App.paintUpgrade();
    }
  },

  paintUpgrade() {
    const box = $('#upgResult');
    const r = S.upg;
    if (!box || !r) { if (box) box.innerHTML = ''; return; }
    $('#btnUpgApply').disabled = !r.ok;
    if (!r.ok) {
      box.innerHTML = (r.problems || []).map((m) =>
        `<div class="imp-bad">✕ ${esc(App.upgMsg(m))}</div>`).join('');
      return;
    }
    let h = `<div class="imp-ok">✓ ${t('upg.usable')} · ${t('upg.verFrom', { a: r.current, b: r.incoming })} · ${t('upg.fileCount', { n: r.file_count })} · ${r.total_mb} MB</div>`;
    (r.warnings || []).forEach((m) => { h += `<div class="imp-warn">⚠ ${esc(App.upgMsg(m))}</div>`; });
    h += `<div class="hint" style="margin-top:10px">${t('upg.willReplace', { n: r.file_count })}</div>`;
    h += `<div class="hint">${t('upg.willKeep', { f: (r.keep || []).join('、') })}</div>`;
    if ((r.ignored || []).length) {
      h += `<div class="hint">${t('upg.ignored', { f: r.ignored.join('、') })}</div>`;
    }
    box.innerHTML = h;
  },

  async applyUpgrade() {
    const r = S.upg;
    if (!r || !r.ok) return;
    const ok = await confirmBox(tx('upg.confirmTitle'),
      tx('upg.confirmText', { a: r.current, b: r.incoming, n: r.file_count }),
      `<div class="hint" style="margin-top:10px">${esc(t('upg.confirmKeep', { f: (r.keep || []).join('、') }))}</div>`);
    if (!ok) return;
    const b = $('#btnUpgApply');
    b.disabled = true; b.innerHTML = `<span class="spin"></span> ${t('upg.applying')}`;
    try {
      const d = await api('/api/upgrade/apply', { path: S.upg._p });
      if (!d.ok) {
        S.upg = { ok: false, problems: d.problems || [], _p: S.upg._p };
        App.paintUpgrade();
        toast(tx('upg.failed'), 'err');
      } else {
        $('#upgResult').innerHTML =
          `<div class="done-banner" style="margin:0"><div class="db-ic">✓</div>
           <div style="flex:1"><div class="db-t">${t('upg.done', { a: d.from, b: d.to, n: d.replaced })}</div>
           <div class="db-s">${t('upg.restart')}</div></div></div>
           <div class="hint" style="margin-top:10px">${t('upg.backedUp', { id: d.backup })}</div>`;
        toast(tx('upg.doneToast'), 'ok');
        S.upg = null;
        App.renderUpgBackups();
      }
    } catch (e) { toast(errDesc(e), 'err'); }
    b.disabled = false; b.textContent = t('upg.apply');
  },

  async renderUpgBackups() {
    const box = $('#upgBackups');
    if (!box) return;
    try {
      const d = await api('/api/upgrade/backups');
      const items = d.items || [];
      if (!items.length) { box.innerHTML = `<div class="hint" style="margin-top:14px">${t('upg.noBackups')}</div>`; return; }
      let h = `<div class="hint" style="margin-top:14px">${t('upg.backupsTitle')}</div>`;
      h += items.map((x) => {
        const when = x.at ? new Date(x.at * 1000).toLocaleString() : x.id;
        return `<div class="ci-row"><div style="flex:1;min-width:0">
          <div class="ci-name">${esc(when)}</div>
          <div class="ci-meta">${t('upg.backupMeta', { a: x.from || '?', b: x.to || '?', n: x.files })}</div>
        </div><button class="btn sm" data-rb="${esc(x.id)}">${t('upg.rollback')}</button></div>`;
      }).join('');
      box.innerHTML = h;
      $$('#upgBackups [data-rb]').forEach((el) => { el.onclick = () => App.doRollback(el.dataset.rb); });
    } catch (e) { box.innerHTML = ''; }
  },

  async doRollback(id) {
    const ok = await confirmBox(tx('upg.rbTitle'), tx('upg.rbText', { id }));
    if (!ok) return;
    try {
      const d = await api('/api/upgrade/rollback', { id });
      if (!d.ok) {
        toast(txJoin((d.problems || []).map((m) => ({ raw: App.upgMsg(m) }))), 'err');
        return;
      }
      toast(tx('upg.rbDone', { n: d.restored }), 'ok');
      $('#upgResult').innerHTML = `<div class="banner" style="margin:0"><span class="bi">⟲</span><div>${t('upg.restart')}</div></div>`;
      S.upg = null; $('#btnUpgApply').disabled = true;
      App.renderUpgBackups();
    } catch (e) { toast(errDesc(e), 'err'); }
  },

  async setEnv() {
    const p = $('#fPython').value.trim();
    if (!p) { toast(tx('env.needPath'), 'err'); return; }
    const b = $('#btnEnvSet');
    b.disabled = true; b.textContent = t('env.checking');
    try {
      await api('/api/env/set', { python: p });
      toast(tx('env.switched'), 'ok');
      await App.refreshEnv(true); await App.loadHardware();
    } catch (e) { toast(errDesc(e), 'err'); }
    b.disabled = false; b.textContent = t('env.use');
  },

  tick() {
    if (S.timer) clearInterval(S.timer);
    // ★监控/训练页用 1 秒轮询：新数据点一落盘就立刻显示，不再等 4 秒。
    //   注意上限由训练侧决定 —— 引擎每 log_every 步才写一次 CSV，
    //   轮询再快也不会凭空造出中间步，所以界面同时说明真实写入间隔。
    //   其余页面维持 4 秒，避免无谓请求。
    let n = 0;
    S.timer = setInterval(() => {
      n += 1;
      const on = (v) => { const e = $('#v-' + v); return e && e.classList.contains('on'); };
      const fast = on('watch') || on('train');
      if (on('watch')) { App.refreshWatch(); return; }
      if (on('train') && S.current) { App.refreshTrain(); return; }
      if (!fast && n % 4 === 0) {
        if (on('data') && S.current) App.refreshData();
        else if (on('home')) App.loadProjects();
      }
    }, 1000);
  },
};

/* ---------------- charts ---------------- */
const Chart = {
  css(name, fallback) {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  },
  // ★画布在隐藏的视图里 getBoundingClientRect() 全为 0，
  //   旧实现用 Math.max(1,…) 兜底 → 画布被设成 1×1，之后即使显示出来也是空白。
  //   现在：量不到尺寸就直接返回 null（调用方跳过绘制，保留上一次画面），
  //   并记下待重绘标记，等视图可见或窗口变化时补画。
  prep(cv) {
    if (!cv) return null;
    let r = cv.getBoundingClientRect();
    if ((!r.width || !r.height) && cv.parentElement) {
      const pr = cv.parentElement.getBoundingClientRect();
      r = { width: pr.width, height: pr.height };
    }
    if (!r.width || !r.height) {
      Chart.pending.add(cv);
      return null;
    }
    Chart.pending.delete(cv);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = Math.max(1, Math.round(r.width * dpr));
    const H = Math.max(1, Math.round(r.height * dpr));
    // 只在尺寸真的变了才重设，避免每 4 秒刷新都清空画布造成闪烁
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    const g = cv.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, r.width, r.height);
    return { g, w: r.width, h: r.height };
  },
  pending: new Set(),
  // 视图切换 / 窗口缩放后补画之前量不到尺寸的图
  flush() {
    if (!Chart.pending.size) return;
    Array.from(Chart.pending).forEach((cv) => {
      const fn = Chart.redraw.get(cv);
      if (fn) fn();
    });
  },
  redraw: new Map(),
  frame(g, w, h, pad, ymin, ymax, ylab) {
    const grid = Chart.css('--grid', 'rgba(120,140,200,.14)');
    const txt3 = Chart.css('--txt3', '#7d89a8');
    g.strokeStyle = grid; g.fillStyle = txt3;
    g.font = '11px Consolas, monospace'; g.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = pad.t + (h - pad.t - pad.b) * i / 4;
      g.beginPath(); g.moveTo(pad.l, y); g.lineTo(w - pad.r, y); g.stroke();
      const v = ymax - (ymax - ymin) * i / 4;
      g.textAlign = 'right';
      g.fillText(v.toFixed(ymax - ymin < 5 ? 2 : 0), pad.l - 7, y + 3);
    }
    if (ylab) { g.textAlign = 'left'; g.fillText(ylab, pad.l, 12); }
  },
  line(g, pts, color, width, fill) {
    if (pts.length < 2) return;
    g.beginPath();
    pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]));
    g.strokeStyle = color; g.lineWidth = width || 2;
    g.lineJoin = 'round'; g.lineCap = 'round'; g.stroke();
    if (fill) {
      g.lineTo(pts[pts.length - 1][0], fill.base); g.lineTo(pts[0][0], fill.base); g.closePath();
      const gr = g.createLinearGradient(0, fill.top, 0, fill.base);
      gr.addColorStop(0, fill.c0); gr.addColorStop(1, fill.c1);
      g.fillStyle = gr; g.fill();
    }
  },
  hexA(hex, a) {
    const h = hex.replace('#', '');
    if (h.length !== 6) return hex;
    const n = parseInt(h, 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  },
  loss(cv, pts, evals) {
    if (!cv) return;
    Chart.redraw.set(cv, () => Chart.loss(cv, pts, evals));
    const prep = Chart.prep(cv);
    if (!prep) return;                      // 视图不可见：保留原画面，等可见再画
    const { g, w, h } = prep;
    const pad = { l: 46, r: 16, t: 20, b: 26 };
    const cy = Chart.css('--cyan', '#22d3ee'), vi = Chart.css('--violet', '#a78bfa'), txt3 = Chart.css('--txt3', '#7d89a8');
    const vals = pts.map((p) => p.loss).filter((v) => v != null);
    if (!vals.length) return;
    let ymin = Math.min(...vals), ymax = Math.max(...vals);
    const m = (ymax - ymin) * 0.12 || 0.5;
    ymin = Math.max(0, ymin - m); ymax += m;
    const x0 = pts[0].step, x1 = pts[pts.length - 1].step || 1;
    const X = (s) => pad.l + (w - pad.l - pad.r) * ((s - x0) / Math.max(x1 - x0, 1));
    const Y = (v) => pad.t + (h - pad.t - pad.b) * (1 - (v - ymin) / (ymax - ymin));
    Chart.frame(g, w, h, pad, ymin, ymax, 'loss');
    const tp = pts.filter((p) => p.loss != null).map((p) => [X(p.step), Y(p.loss)]);
    Chart.line(g, tp, cy, 2, { base: h - pad.b, top: pad.t, c0: Chart.hexA(cy, .22), c1: Chart.hexA(cy, 0) });
    if (evals && evals.length) {
      const ep = evals.filter((e) => e.loss != null).map((e) => [X(e.step), Y(e.loss)]);
      Chart.line(g, ep, vi, 1.7);
      g.fillStyle = vi; ep.forEach((p) => { g.beginPath(); g.arc(p[0], p[1], 3, 0, 7); g.fill(); });
    }
    g.fillStyle = txt3; g.textAlign = 'left'; g.fillText(x0, pad.l, h - 8);
    g.textAlign = 'right'; g.fillText(x1, w - pad.r, h - 8);
    g.fillStyle = cy; g.fillText('— ' + t('train.chartTrain'), w - pad.r - 58, 12);
    g.fillStyle = vi; g.fillText('— ' + t('train.chartVal'), w - pad.r, 12);
  },
  perf(cv, pts) {
    if (!cv) return;
    Chart.redraw.set(cv, () => Chart.perf(cv, pts));
    const prep = Chart.prep(cv);
    if (!prep) return;
    const { g, w, h } = prep;
    const pad = { l: 50, r: 44, t: 20, b: 26 };
    const gr = Chart.css('--green', '#34d399'), am = Chart.css('--amber', '#fbbf24'), txt3 = Chart.css('--txt3', '#7d89a8');
    const sp = pts.filter((p) => p.tok_s != null), vr = pts.filter((p) => p.vram != null);
    if (!sp.length) return;
    const smax = Math.max(...sp.map((p) => p.tok_s)) * 1.15 || 1;
    const vmax = Math.max(...vr.map((p) => p.vram), 1) * 1.25;
    const x0 = pts[0].step, x1 = pts[pts.length - 1].step || 1;
    const X = (s) => pad.l + (w - pad.l - pad.r) * ((s - x0) / Math.max(x1 - x0, 1));
    const YS = (v) => pad.t + (h - pad.t - pad.b) * (1 - v / smax);
    const YV = (v) => pad.t + (h - pad.t - pad.b) * (1 - v / vmax);
    Chart.frame(g, w, h, pad, 0, smax, 'tok/s');
    Chart.line(g, sp.map((p) => [X(p.step), YS(p.tok_s)]), gr, 2,
      { base: h - pad.b, top: pad.t, c0: Chart.hexA(gr, .18), c1: Chart.hexA(gr, 0) });
    if (vr.length) Chart.line(g, vr.map((p) => [X(p.step), YV(p.vram)]), am, 1.7);
    g.fillStyle = am; g.textAlign = 'left'; g.font = '11px Consolas, monospace';
    for (let i = 0; i <= 4; i++) {
      const y = pad.t + (h - pad.t - pad.b) * i / 4;
      g.fillText((vmax - vmax * i / 4).toFixed(0) + 'G', w - pad.r + 6, y + 3);
    }
    g.fillStyle = txt3; g.textAlign = 'left'; g.fillText(x0, pad.l, h - 8);
    g.textAlign = 'right'; g.fillStyle = gr; g.fillText('— ' + t('train.chartSpeed'), w - pad.r - 56, 12);
    g.fillStyle = am; g.fillText('— ' + t('train.chartVram'), w - pad.r, 12);
  },
};

/* ---------------- hints ---------------- */
function updateSaveHint() {
  const el = $('#saveHint'); if (!el) return;
  const v = parseInt($('#fSave').value, 10) || 500;
  const ctx = parseInt($('#fCtx').value, 10) || 1024;
  const bs = parseInt($('#fBatch').value, 10) || 4;
  const ga = parseInt($('#fAccum').value, 10) || 4;
  el.textContent = t('create.saveHint', { v, t: fmt.tok(v * ctx * bs * ga) });
}

function updateTokensHint() {
  const el = $('#tokensHint'); if (!el) return;
  const b = parseFloat($('#fTokens').value);
  const v = isFinite(b) ? b : 0;
  el.textContent = t('create.tokensHint', { b: v.toFixed(3), n: fmt.n(Math.round(v * 1e9)) });
}

/* ---------------- init ---------------- */
(async function init() {
  applyTheme(); applyLang();

  $('#btnTheme').onclick = () => {
    PREF.theme = PREF.theme === 'dark' ? 'light' : 'dark';
    applyTheme();
    if (S.current && $('#v-train').classList.contains('on')) App.refreshMetrics();
    if (S.watchName && $('#v-watch').classList.contains('on')) App.refreshWatchOne();
  };
  $('#btnLang').onclick = () => {
    PREF.lang = PREF.lang === 'zh' ? 'en' : 'zh';
    App.rerenderAll();
  };

  // ★定高截断的提示统一补全文悬停：静态文案由 applyI18n 写 title，
  //   动态生成的（参数说明、探测结果、环境提示等）走这里的事件委托，
  //   一处覆盖全部，不会漏，也不会因重绘而失效。
  document.addEventListener('mouseover', (ev) => {
    const el = ev.target && ev.target.closest
      ? ev.target.closest('.hint, .cf-hint, .sub, .field label, .tier .tn, .group .gd, .card h2, .metric .mv, .metric .mk, .chart-range button, .hw-chip span') : null;
    if (!el) return;
    const txt = (el.textContent || '').trim();
    if (!txt) return;
    // ★数值格每次刷新都可能变（显存/步数），title 必须跟着更新，
    //   否则悬停会显示上一次的旧数值。其余静态文案已有 title 就不重复写。
    const dynamic = el.classList.contains('mv') || el.classList.contains('mk');
    if (dynamic) { if (el.title !== txt) el.title = txt; return; }
    if (!el.title) el.title = txt;
  }, true);

  $$('nav button').forEach((b) => { b.onclick = () => App.go(b.dataset.view); });
  $('#btnAddCorpus').onclick = App.addCorpus;
  $('#btnMixEven').onclick = () => {
    S.form.corpus.forEach((c) => { c.percent = null; });
    App.renderCorpus(); App.renderMixPreview();
  };
  $('#btnCreate').onclick = App.create;
  $('#btnCheck').onclick = () => App.check().catch((e) => toast(errDesc(e), 'err'));
  $('#btnDataStop').onclick = App.stop;
  $('#btnDataRefresh').onclick = App.refreshData;
  $('#btnTrainStart').onclick = App.startTrain;
  $('#btnTrainPause').onclick = App.pauseTrain;
  $('#btnTrainStop').onclick = App.stop;
  $('#btnTrainRefresh').onclick = App.refreshTrain;
  $('#btnTest').onclick = App.runTest;
  $('#btnEditCk').onclick = App.editCkPolicy;
  $('#btnWatchAdd').onclick = App.watchAdd;
  // 填完目录/日志即自动推断总量：失焦立刻查，打字停顿 700ms 也查
  ['#wDir', '#wLog'].forEach((sel) => {
    const el = $(sel);
    if (!el) return;
    let tm = null;
    el.addEventListener('input', () => {
      clearTimeout(tm);
      tm = setTimeout(() => App.probeWatch(true), 700);
    });
    el.addEventListener('blur', () => App.probeWatch(true));
    el.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter') { ev.preventDefault(); App.probeWatch(); }
    });
  });
  // 手动改过的值不再被自动填充覆盖，去掉高亮标记
  ['#wTokens', '#wSteps'].forEach((sel) => {
    const el = $(sel);
    if (el) el.addEventListener('input', () => el.classList.remove('auto-filled'));
  });
  $('#btnWatchRefresh').onclick = App.refreshWatchOne;
  $('#btnWatchBack').onclick = () => {
    S.watchName = null; S._watchScrolled = null;   // 复位，下次点同一张卡仍会滚动
    App.refreshWatch();
  };
  $('#btnWatchRemove').onclick = App.watchRemove;
  // 图表时间范围切换：每张图独立一组（损失 / 速度显存 × 训练 / 监控）
  ['rangeTrainLoss', 'rangeTrainPerf', 'rangeWatchLoss', 'rangeWatchPerf'].forEach((id) => {
    const box = $('#' + id);
    if (!box) return;
    box.onclick = (ev) => {
      const b = ev.target.closest('button[data-r]');
      if (!b) return;
      App.setChartRange(id.slice(5), b.dataset.r);
    };
  });
  $('#btnEnvRecheck').onclick = async () => {
    const b = $('#btnEnvRecheck');
    b.disabled = true; b.innerHTML = `<span class="spin"></span> ${t('common.detecting')}`;
    await App.refreshEnv(true); await App.loadHardware().catch(() => {});
    b.disabled = false; b.textContent = t('env.recheck');
  };
  $('#btnEnvSet').onclick = App.setEnv;

  // ---- 导入更新包 ----
  $('#btnUpgCheck').onclick = () => App.checkUpgrade(false);
  $('#btnUpgApply').onclick = App.applyUpgrade;
  $('#fUpgPath').oninput = () => {
    // 改了路径就作废上一次校验结果，避免拿着旧清单去更新另一个包
    S.upg = null; $('#upgResult').innerHTML = ''; $('#btnUpgApply').disabled = true;
    clearTimeout(App._upgTimer);
    App._upgTimer = setTimeout(() => {
      if (($('#fUpgPath').value || '').trim()) App.checkUpgrade(true);
    }, 700);
  };
  $('#fUpgPath').onkeydown = (ev) => {
    if (ev.key === 'Enter') { ev.preventDefault(); App.checkUpgrade(false); }
  };

  $('#btnArchToggle').onclick = () => { S.form.archOpen = !S.form.archOpen; App.renderArch(); };

  $$('#segSave button').forEach((b) => {
    b.onclick = () => {
      $$('#segSave button').forEach((x) => x.classList.remove('on'));
      b.classList.add('on');
      if (b.dataset.v !== 'custom') $('#fSave').value = b.dataset.v;
      else { $('#fSave').focus(); $('#fSave').select(); }
      updateSaveHint();
    };
  });
  ['#fSave', '#fCtx', '#fBatch', '#fAccum'].forEach((id) => $(id).addEventListener('input', updateSaveHint));
  $('#fTokens').addEventListener('input', updateTokensHint);
  // 打开模型目录（只传位置键，路径由后端解析）
  $('#btnTrainOpenDir').onclick = () => App.reveal('model');
  $('#btnTrainOpenBest').onclick = () => App.reveal('best');
  $('#btnTrainOpenFinal').onclick = () => App.reveal('final');
  $('#btnWatchOpenDir').onclick = () => {
    const s = S.watchSnap;
    if (s && s.source === 'project') App.reveal('model', s.project || s.name);
    else App.revealExternal();
  };
  $('#btnWatchGoTrain').onclick = async () => {
    const s = S.watchSnap;
    if (!s) return;
    S.current = s.project || s.name;
    await App.go('train');
  };

  // 链接下载面板
  $('#btnDlToggle').onclick = App.dlToggle;
  // 预设扩展开关与自定义标记：改动后立刻重算词表提示
  $('#fMMTokens').addEventListener('change', () => App.syncVocabUI());
  $('#fExtraSpecial').addEventListener('input', () => App.syncVocabUI());
  // ★用户一旦手动改词表，就以他填的为准，切档位不再自动覆盖
  $('#fVocab').addEventListener('input', () => { S.form.vocabTouched = true; App.syncVocabUI(); });
  $('#fVocab').addEventListener('change', () => {
    S.form.vocabTouched = true; App.syncVocabUI(); if (S.form.archOpen) App.renderArch();
  });
  // ★批大小/上下文/精度直接影响显存：改了就要重算自定义面板的估算，
  //   否则面板还显示旧值，用户以为改了没生效。
  ['#fBatch', '#fCtx', '#fAccum', '#fDtype'].forEach((id) => {
    const el = $(id);
    if (!el) return;
    // 卡片与面板都要重算：显存随这些参数变化，只刷面板会让两处对不上
    const refresh = () => { App.renderTiers(); if (S.form.archOpen) App.renderArch(); };
    el.addEventListener('input', refresh);
    el.addEventListener('change', refresh);
  });
  // 词表规模快捷档：点一下填入数值，仍可手动改成任意值
  $$('#segVocab button').forEach((b) => {
    b.onclick = () => {
      $('#fVocab').value = b.dataset.v;
      App.syncVocabUI();
      if (S.form.archOpen) App.renderArch();
    };
  });
  $$('#segSpike button').forEach((b) => {
    b.onclick = () => {
      $$('#segSpike button').forEach((x) => x.classList.remove('on'));
      b.classList.add('on'); S.form.spike = b.dataset.v === '1';
    };
  });

  $$('#segLogLang button').forEach((b) => {
    b.onclick = () => {
      $$('#segLogLang button').forEach((x) => x.classList.remove('on'));
      b.classList.add('on'); S.form.logLang = b.dataset.v === 'en' ? 'en' : 'zh';
    };
  });

  let rz;
  window.addEventListener('resize', () => {
    clearTimeout(rz);
    rz = setTimeout(() => {
      if ($('#v-train').classList.contains('on') && S.current) App.refreshMetrics();
      if ($('#v-watch').classList.contains('on') && S.watchName) App.refreshWatchOne();
      Chart.flush();          // 尺寸变了，补画之前量不到尺寸的图
    }, 200);
  });

  try {
    await App.loadMeta();
    await App.loadHardware();
    await App.loadProjects();
    updateSaveHint(); updateTokensHint(); App.syncVocabUI();
    App.tick();
    const d = await api('/api/env');
    S.env = d.env;
    if (!d.env.ready) { toast(tx('env.toastNoEnv'), 'err'); App.go('env'); await App.refreshEnv(); }
  } catch (e) { toast(errDesc(e), 'err'); }
  // ★硬件 5 秒一刷：可用显存/内存随其他程序实时变化，30 秒太钝。
  //   成本可控：detect 只跑两次 nvidia-smi 与一次系统调用，不加载 torch；
  //   渲染全部原地更新，不重建 DOM。页面隐藏时跳过，避免后台空转。
  setInterval(() => {
    if (document.hidden) return;
    App.loadHardware().catch(() => {});
  }, 5000);

  // ★小监控采样：平时 3 秒一次（够看趋势、成本低）；
  //   鼠标悬停或键盘聚焦时提到 1 秒一次，看细节更跟手。
  //   页面隐藏时完全停采，不占后台算力。
  await App.loadStat();
  const monEl = $('#hwMon');
  setInterval(() => {
    if (document.hidden) return;
    const open = monEl && (monEl.matches(':hover') || monEl.matches(':focus-within'));
    if (!open && (S._monTick = (S._monTick || 0) + 1) % 3 !== 0) return;
    App.loadStat();
    if (open) App.paintMonPop();
  }, 1000);
  if (monEl) {
    // ★用户要求"点击不要有反应"：这里显式吞掉点击与回车/空格，
    //   保证它只作为展示件存在，不会误触发任何行为。
    monEl.addEventListener('click', (ev) => { ev.preventDefault(); ev.stopPropagation(); });
    monEl.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); ev.stopPropagation(); }
    });
    monEl.addEventListener('mouseenter', () => { App.paintMonPop(); App.loadStat(); });
    monEl.addEventListener('focus', () => { App.paintMonPop(); App.loadStat(); });
  }
})();

window.App = App;

"""顶栏小监控：CPU / 内存 / 显卡 的占用与温度采样。

★成本约束（用户明确要求"查询速度不变、降低算力成本"）：
  - CPU 占用：GetSystemTimes 两次差分，实测 0.035ms，无子进程。
  - 内存：GlobalMemoryStatusEx，实测 0.02ms。
  - CPU 型号/基准主频：读注册表，无子进程，进程内只读一次。
  - 显卡：nvidia-smi 一次取全部字段，实测约 40ms —— 这是唯一较贵的一项，
    因此结果按 TTL 缓存；界面平时 3 秒一取、悬停时才 1 秒一取。
  - CPU 温度：Windows 上没有统一可靠来源。本机实测 MSAcpi_ThermalZoneTemperature
    直接失败、ThermalZoneInformation 返回空且耗时 5.8 秒。
    所以只在后台探一次并永久缓存结果；拿不到就如实返回 None，
    界面显示"暂未获取"，绝不猜一个数字，也绝不每次轮询都去试。

★所有子进程都带 CREATE_NO_WINDOW：否则打包成 exe 后每次采样都会闪黑框。
★所有子进程显式 utf-8 + errors=replace：本机实测默认 GBK 解码会抛
  UnicodeDecodeError（显卡/处理器名里有非 GBK 字节）。
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import time

IS_WIN = sys.platform == "win32"
NO_WINDOW = 0x08000000 if IS_WIN else 0

GPU_TTL = 1.0            # 显卡读数缓存秒数
_LOCK = threading.Lock()
_CPU_PREV: tuple | None = None
_GPU_CACHE: tuple[float, dict] | None = None
_STATIC: dict | None = None
_CPU_TEMP: dict = {"state": "pending", "value": None}
_CPU_TEMP_STARTED = False


def _run(cmd: list[str], timeout: float) -> str:
    try:
        r = subprocess.run(
            cmd, capture_output=True, timeout=timeout,
            encoding="utf-8", errors="replace",
            creationflags=NO_WINDOW,
        )
        if r.returncode != 0:
            return ""
        return (r.stdout or "").strip()
    except Exception:  # noqa: BLE001 探测失败一律降级，不影响界面
        return ""


# ---------------- CPU ----------------
def _cpu_times() -> tuple | None:
    if IS_WIN:
        import ctypes
        from ctypes import wintypes

        class FT(ctypes.Structure):
            _fields_ = [("lo", wintypes.DWORD), ("hi", wintypes.DWORD)]

        idle, kern, user = FT(), FT(), FT()
        fn = ctypes.windll.kernel32.GetSystemTimes
        fn.argtypes = [ctypes.POINTER(FT)] * 3
        fn.restype = wintypes.BOOL
        if not fn(ctypes.byref(idle), ctypes.byref(kern), ctypes.byref(user)):
            return None
        v = lambda f: (f.hi << 32) | f.lo
        # kernel 已含 idle，总时间 = kernel + user
        return v(idle), v(kern) + v(user)
    try:
        with open("/proc/stat", encoding="utf-8") as f:
            parts = f.readline().split()[1:]
        nums = [int(x) for x in parts]
        idle = nums[3] + (nums[4] if len(nums) > 4 else 0)
        return idle, sum(nums)
    except Exception:  # noqa: BLE001
        return None


def cpu_percent() -> float | None:
    """两次采样差分。首次调用没有基准，返回 None（界面显示 —）。"""
    global _CPU_PREV
    cur = _cpu_times()
    if cur is None:
        return None
    prev, _CPU_PREV = _CPU_PREV, cur
    if prev is None:
        return None
    d_idle = cur[0] - prev[0]
    d_total = cur[1] - prev[1]
    if d_total <= 0:
        return None
    return max(0.0, min(100.0, (1.0 - d_idle / d_total) * 100.0))


# ---------------- 内存 ----------------
def memory() -> dict:
    out = {"total_gb": None, "used_gb": None, "free_gb": None, "percent": None}
    if IS_WIN:
        import ctypes
        from ctypes import wintypes

        class MS(ctypes.Structure):
            _fields_ = [
                ("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]

        m = MS()
        m.dwLength = ctypes.sizeof(MS)
        fn = ctypes.windll.kernel32.GlobalMemoryStatusEx
        fn.argtypes = [ctypes.POINTER(MS)]
        fn.restype = wintypes.BOOL
        if fn(ctypes.byref(m)):
            tot = m.ullTotalPhys / 1024 ** 3
            free = m.ullAvailPhys / 1024 ** 3
            return {"total_gb": round(tot, 1), "free_gb": round(free, 1),
                    "used_gb": round(tot - free, 1), "percent": int(m.dwMemoryLoad)}
    try:
        import psutil  # noqa: PLC0415  有就用，没有也不强求
        vm = psutil.virtual_memory()
        tot = vm.total / 1024 ** 3
        free = vm.available / 1024 ** 3
        return {"total_gb": round(tot, 1), "free_gb": round(free, 1),
                "used_gb": round(tot - free, 1), "percent": round(vm.percent)}
    except Exception:  # noqa: BLE001
        return out


# ---------------- 静态信息（注册表，零子进程） ----------------
def _static_info() -> dict:
    global _STATIC
    if _STATIC is not None:
        return _STATIC
    info = {"cpu_name": None, "cpu_mhz": None, "cores": os.cpu_count() or 1}
    if IS_WIN:
        try:
            import winreg
            key = r"HARDWARE\DESCRIPTION\System\CentralProcessor\0"
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key) as k:
                try:
                    info["cpu_name"] = str(winreg.QueryValueEx(k, "ProcessorNameString")[0]).strip()
                except OSError:
                    pass
                try:
                    info["cpu_mhz"] = int(winreg.QueryValueEx(k, "~MHz")[0])
                except OSError:
                    pass
        except Exception:  # noqa: BLE001
            pass
    _STATIC = info
    return info


# ---------------- CPU 温度：后台探一次，永久缓存 ----------------
def _probe_cpu_temp() -> None:
    """本机实测两条 WMI 路径都拿不到；失败即永久记为不可用，不再重试。"""
    val = None
    raw = _run(["powershell.exe", "-NoProfile", "-Command",
                "Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature "
                "-ErrorAction Stop | Select-Object -First 1 -ExpandProperty CurrentTemperature"],
               timeout=6)
    if raw:
        try:
            # WMI 单位是开尔文 ×10
            val = round(int(raw.splitlines()[0].strip()) / 10.0 - 273.15, 1)
        except (ValueError, IndexError):
            val = None
    if val is None or not (-20 < val < 130):
        raw = _run(["powershell.exe", "-NoProfile", "-Command",
                    "Get-CimInstance -ClassName Win32_PerfFormattedData_Counters_ThermalZoneInformation "
                    "-ErrorAction Stop | Select-Object -First 1 -ExpandProperty Temperature"],
                   timeout=6)
        if raw:
            try:
                v = float(raw.splitlines()[0].strip())
                # 该类同样以开尔文给出
                val = round(v - 273.15, 1) if v > 200 else round(v, 1)
            except (ValueError, IndexError):
                val = None
    if val is None or not (-20 < val < 130):
        _CPU_TEMP.update(state="unavailable", value=None)
    else:
        _CPU_TEMP.update(state="ok", value=val)


def _ensure_cpu_temp() -> None:
    global _CPU_TEMP_STARTED
    if _CPU_TEMP_STARTED:
        return
    _CPU_TEMP_STARTED = True
    threading.Thread(target=_probe_cpu_temp, daemon=True).start()


# ---------------- 显卡 ----------------
def _num(s: str) -> float | None:
    s = (s or "").strip()
    if not s or s.startswith("["):        # [N/A] / [Not Supported]
        return None
    try:
        return float(s)
    except ValueError:
        return None


_GPU_FIELDS = ("utilization.gpu,memory.used,memory.total,temperature.gpu,"
               "power.draw,power.limit,fan.speed,clocks.current.sm,name,driver_version")


def gpu() -> dict:
    global _GPU_CACHE
    now = time.time()
    if _GPU_CACHE and now - _GPU_CACHE[0] < GPU_TTL:
        return _GPU_CACHE[1]
    out = {"present": False, "name": None, "util": None,
           "mem_used_gb": None, "mem_total_gb": None, "mem_percent": None,
           "temp_c": None, "power_w": None, "power_limit_w": None,
           "fan_percent": None, "clock_mhz": None, "driver": None, "count": 0}
    raw = _run(["nvidia-smi", "--query-gpu=" + _GPU_FIELDS,
                "--format=csv,noheader,nounits"], timeout=8)
    if raw:
        lines = [l for l in raw.splitlines() if l.strip()]
        f = [x.strip() for x in lines[0].split(",")]
        if len(f) >= 9:
            used, total = _num(f[1]), _num(f[2])
            out.update({
                "present": True, "count": len(lines),
                "util": _num(f[0]),
                "mem_used_gb": round(used / 1024, 2) if used is not None else None,
                "mem_total_gb": round(total / 1024, 2) if total is not None else None,
                "mem_percent": round(used / total * 100, 1) if used and total else None,
                "temp_c": _num(f[3]), "power_w": _num(f[4]),
                "power_limit_w": _num(f[5]), "fan_percent": _num(f[6]),
                "clock_mhz": _num(f[7]), "name": f[8] or None,
                "driver": f[9] if len(f) > 9 else None,
            })
    _GPU_CACHE = (now, out)
    return out


def snapshot() -> dict:
    """一次完整采样。全程只读，不写任何文件，不干预任何进程。"""
    _ensure_cpu_temp()
    st = _static_info()
    cp = cpu_percent()
    return {
        "ts": time.time(),
        "cpu": {"percent": round(cp, 1) if cp is not None else None,
                "cores": st["cores"], "name": st["cpu_name"],
                "base_mhz": st["cpu_mhz"],
                "temp_c": _CPU_TEMP["value"], "temp_state": _CPU_TEMP["state"]},
        "mem": memory(),
        "gpu": gpu(),
    }
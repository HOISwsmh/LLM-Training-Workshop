"""HTTP 服务：只用 Python 标准库，零第三方依赖。

设计取舍：不引入 FastAPI/Flask，避免为做界面而安装一堆包、
也避免破坏用户已有的训练环境。路由手写，够用且完全离线。
"""
from __future__ import annotations

import csv
import json
import mimetypes
import re
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import download as DL
from . import hardware as H
from . import modelcard as MC
from . import imports as IM
from . import paths as PA
from . import pipeline as PL
from . import projects as P
from . import reveal as RV
from . import sysstat as SS
from . import upgrade as UP
from . import watch as W

ROOT = PA.app_root()
WEB = PA.web_dir()

# ★特殊标记的唯一定义在 engine/mm_tokens.py（纯常量、无重依赖）。
#   界面要显示「基础/多模态」标记清单，必须与引擎同源，避免两处写死漂移。
import sys as _sys  # noqa: E402
_sys.path.insert(0, str(ROOT / "engine"))
try:
    import mm_tokens as _MM  # noqa: E402
    BASE_SPECIAL = list(_MM.BASE_SPECIAL)
    MULTIMODAL_SPECIAL = list(_MM.MULTIMODAL_SPECIAL)
except Exception:  # noqa: BLE001  定义缺失时界面退化为不显示，不影响服务
    BASE_SPECIAL = ["[PAD]", "[UNK]", "[BOS]", "[EOS]", "[MASK]"]
    MULTIMODAL_SPECIAL = []


def _json_bytes(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8")


# ★增量解析缓存：1 秒轮询下绝不能每次从文件头全量重扫。
#   旧实现以 (mtime,size) 为键缓存「最终结果」，但日志每写一行键就变，
#   下一秒仍要 O(整个日志) 重解析——数月长跑 CSV 几十万行时长期占 CPU/IO
#   （审计指出）。现在缓存「解析状态」：记住已读字节偏移与已累积的点，
#   每次只读新增部分，成本 O(新增行)。文件被截断/轮转（size 变小）才全量重读。
_TRAIN_STATE: dict = {}
_TRAIN_STATE_MAX = 12
# 已完成工位产物大小缓存：(项目, 工位, 完成时间) → 字节数
_ART_CACHE: dict = {}


def _train_fields():
    return ["wall_time", "phase", "step", "micro_step", "tokens_seen",
            "loss", "ppl", "lr", "tok_s", "vram_gb", "elapsed_s",
            "skipped_spikes", "rollbacks", "note"]


def _parse_train_row(r: dict, points: list, evals: list, events: list):
    ph = r.get("phase")
    if ph == "train":
        points.append({
            "step": int(r.get("step") or 0),
            "loss": float(r["loss"]) if r.get("loss") else None,
            "ppl": float(r["ppl"]) if r.get("ppl") else None,
            "lr": float(r["lr"]) if r.get("lr") else None,
            "tok_s": float(r["tok_s"]) if r.get("tok_s") else None,
            "vram": float(r["vram_gb"]) if r.get("vram_gb") else None,
            "tokens": int(r.get("tokens_seen") or 0),
            "spikes": int(r.get("skipped_spikes") or 0),
            "rollbacks": int(r.get("rollbacks") or 0),
            "time": r.get("wall_time", ""),
        })
    elif ph == "eval":
        evals.append({"step": int(r.get("step") or 0),
                      "loss": float(r["loss"]) if r.get("loss") else None,
                      "ppl": float(r["ppl"]) if r.get("ppl") else None})
    elif ph == "event":
        events.append({"step": int(r.get("step") or 0),
                       "note": r.get("note", ""),
                       "time": r.get("wall_time", "")})


def read_train_log(project: str, limit: int = 6000) -> dict:
    """读训练 CSV，供前端画曲线。增量解析，输出目录可能是用户自定义位置。"""
    p = P.output_dir(project) / "train_log.csv"
    if not p.exists():
        return {"points": [], "evals": [], "events": [], "latest": None}
    key = str(p)
    try:
        size = p.stat().st_size
    except OSError:
        return {"points": [], "evals": [], "events": [], "latest": None}
    st = _TRAIN_STATE.get(key)
    if st is None or st["size"] > size:
        st = {"offset": 0, "size": 0, "points": [], "evals": [], "events": [],
              "full_n": 0, "header": None}
        _TRAIN_STATE[key] = st
        if len(_TRAIN_STATE) > _TRAIN_STATE_MAX:
            # 淘汰最久未更新的（保留当前）
            for k in list(_TRAIN_STATE)[:-_TRAIN_STATE_MAX]:
                if k != key:
                    _TRAIN_STATE.pop(k, None)
    if size > st["size"]:
        try:
            with p.open("r", encoding="utf-8", newline="") as f:
                f.seek(st["offset"])
                if st["header"] is None:
                    first = f.readline()
                    if first.strip():
                        st["header"] = next(csv.reader([first]))
                    st["offset"] = f.tell()
                fields = st["header"] or _train_fields()
                # 只读到「最后一个完整行」：半截行留到下次，避免解析报错
                chunk = f.read()
                if chunk:
                    last_nl = chunk.rfind("\n")
                    if last_nl >= 0:
                        complete = chunk[:last_nl + 1]
                        st["offset"] += len(complete.encode("utf-8"))
                        for r in csv.DictReader(complete.splitlines(), fieldnames=fields):
                            before = len(st["points"])
                            _parse_train_row(r, st["points"], st["evals"], st["events"])
                            if len(st["points"]) > before:
                                st["full_n"] += 1
        except (OSError, ValueError):
            pass
        st["size"] = size
    # ★续训去重（用户实测「曲线断了」）：从 checkpoint-N 续训会把 N+1..旧末尾
    #   这段重跑一遍，CSV 里出现 step 回退（如 4880 → 4520），画出来就是断线/回折。
    #   这里按 step 保留「最后一次」记录：同 step 后写覆盖先写，并保证单调递增，
    #   曲线自然连上，且用的是续训后的真实值。
    dedup: dict = {}
    for p in st["points"]:
        dedup[p["step"]] = p
    points = [dedup[k] for k in sorted(dedup)]
    st["points"] = points
    full_n = len(points)
    st["full_n"] = full_n
    last = points[-1] if points else None
    if full_n > limit:
        stride = full_n // limit + 1
        shown = points[::stride]
        if last is not None and (not shown or shown[-1]["step"] != last["step"]):
            shown = shown + [last]
    else:
        shown = points
    return {"points": shown, "evals": st["evals"], "events": st["events"][-20:],
            "latest": last, "count": full_n}


def list_checkpoints(project: str) -> dict:
    out = P.output_dir(project)
    items = []
    if out.exists():
        for c in sorted(out.iterdir()):
            if not c.is_dir():
                continue
            size = sum(f.stat().st_size for f in c.rglob("*") if f.is_file())
            st = c / "trainer_state.json"
            gstep = None
            if st.exists():
                try:
                    gstep = json.loads(st.read_text(encoding="utf-8")).get("global_step")
                except ValueError:
                    pass
            items.append({"name": c.name, "size_gb": round(size / 1024 ** 3, 2),
                          "step": gstep, "mtime": c.stat().st_mtime})
    cfg = P.load(project)["config"]
    backups = []
    bdir = (cfg.get("backup_dir") or "").strip()
    if bdir:
        b = Path(bdir) / out.name
        if b.exists():
            backups = [x.name for x in sorted(b.iterdir()) if x.is_dir()]
    return {"checkpoints": items, "backups": backups, "backup_dir": bdir}


def tail_log(project: str, stage: str, lines: int = 80) -> str:
    if not re.fullmatch(r"[a-z_]+", stage or ""):
        return ""
    p = P.project_dir(project) / "logs" / f"{stage}.log"
    if not p.exists():
        return ""
    try:
        # ★只读文件尾部：旧实现用 deque 却仍从头扫到尾，单次成本 O(整个日志)，
        #   数百 MB 长跑日志下每秒轮询长期占 IO（审计指出）。
        #   现在 seek 到末尾往前取固定窗口，成本 O(窗口)，与日志总长无关。
        size = p.stat().st_size
        window = min(size, max(65536, lines * 512))
        with p.open("rb") as f:
            f.seek(size - window)
            data = f.read()
        text = data.decode("utf-8", errors="replace")
        buf = text.splitlines(keepends=True)
        if window < size and buf:
            buf = buf[1:]          # 丢弃窗口边界处的半截行
        return "".join(buf[-lines:])
    except OSError:
        return ""


class Handler(BaseHTTPRequestHandler):
    server_version = "LLMWorkshop/1.0"

    def log_message(self, *a):  # 静音默认访问日志
        pass

    # ---------- 工具 ----------
    def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _ok(self, obj):
        self._send(200, _json_bytes({"ok": True, "data": obj}))

    def _err(self, msg: str, code: int = 400):
        self._send(code, _json_bytes({"ok": False, "error": str(msg)}))

    # ---------- 请求来源与体积防护 ----------
    # ★只监听 127.0.0.1 挡不住「网页驱动本地服务」：
    #   浏览器对 text/plain 的跨站 POST 视为简单请求、不做 preflight，
    #   任意网站都能让工坊起训练、写文件；DNS rebinding 还能绕过本机限制。
    #   这里三道一起上：Host 白名单 + Origin 校验 + 请求体上限。
    MAX_BODY = 1024 * 1024          # 1MB：配置/路径类请求远小于此

    def _host_ok(self) -> bool:
        """Host 必须是本机回环，挡 DNS rebinding（外部域名解析到 127.0.0.1）。"""
        host = (self.headers.get("Host") or "").strip().lower()
        if not host:
            return False
        name = host.rsplit(":", 1)[0] if not host.startswith("[") else host.split("]")[0] + "]"
        return name in ("127.0.0.1", "localhost", "[::1]", "::1")

    def _origin_ok(self) -> bool:
        """有 Origin 就必须是本机；没有 Origin 放行（命令行/脚本调用不带）。"""
        origin = (self.headers.get("Origin") or "").strip()
        if not origin or origin == "null":
            return origin != "null"     # file:// 页面的 Origin 是 null，拒绝
        try:
            u = urlparse(origin)
        except ValueError:
            return False
        if u.scheme not in ("http", "https"):
            return False
        return (u.hostname or "").lower() in ("127.0.0.1", "localhost", "::1")

    def _guard(self) -> bool:
        """统一门禁。不通过时已回 403，调用方直接 return。"""
        if not self._host_ok():
            self._err("拒绝访问：Host 不是本机地址", 403)
            return False
        if not self._origin_ok():
            self._err("拒绝访问：请求来源不是本工坊页面", 403)
            return False
        return True

    def _body(self) -> dict:
        raw_len = self.headers.get("Content-Length") or "0"
        try:
            n = int(raw_len)
        except ValueError:
            raise ValueError("请求长度不合法")
        if n < 0:
            raise ValueError("请求长度不合法")
        if n > self.MAX_BODY:
            raise ValueError("请求内容过大（上限 1MB）")
        if not n:
            return {}
        data = self.rfile.read(n)
        try:
            obj = json.loads(data.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return {}
        # 顶层必须是对象：数组/标量会让后续 .get() 抛异常
        return obj if isinstance(obj, dict) else {}

    # ---------- GET ----------
    def do_GET(self):  # noqa: N802
        if not self._guard():
            return
        u = urlparse(self.path)
        q = parse_qs(u.query)
        path = u.path
        try:
            if path in ("/", "/index.html"):
                f = WEB / "index.html"
                if not f.exists():
                    return self._send(500, b"web/index.html missing", "text/plain")
                return self._send(200, f.read_bytes(), "text/html; charset=utf-8")

            if path.startswith("/static/"):
                rel = path[len("/static/"):]
                if ".." in rel or rel.startswith("/"):
                    return self._err("bad path", 403)
                f = (WEB / rel).resolve()
                if WEB.resolve() not in f.parents or not f.is_file():
                    return self._err("not found", 404)
                ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
                if ctype.startswith("text/") or ctype in ("application/javascript",):
                    ctype += "; charset=utf-8"
                return self._send(200, f.read_bytes(), ctype)

            if path == "/api/hardware":
                hw = H.detect()
                return self._ok({"hardware": hw, "recommend": H.recommend(hw)})

            # ---- 顶栏小监控：CPU / 内存 / 显卡 占用与温度 ----
            # ★只读采样：CPU/内存走系统调用（各约 0.03ms），
            #   显卡读数按 1 秒 TTL 缓存，避免每次轮询都起子进程。
            if path == "/api/sysstat":
                return self._ok(SS.snapshot())

            if path == "/api/env":
                force = (q.get("force") or ["0"])[0] == "1"
                env = PA.detect_env(force=force)
                return self._ok({"env": env, "runtime": PA.describe()})

            # ---- 训练监控（只读，不干预任何训练） ----
            # 同时列出工坊自己的项目与用户登记的外部训练，按输出目录去重。
            if path == "/api/watch/list":
                items = W.list_all_runs()
                return self._ok({"items": [W.snapshot(x) for x in items]})

            if path == "/api/watch/one":
                name = (q.get("name") or [""])[0]
                it = next((x for x in W.list_all_runs() if x["name"] == name), None)
                if it is None:
                    return self._err("未找到该监控项")
                snap = W.snapshot(it)
                snap["tail"] = W.tail(it.get("log_file") or "", 80)
                return self._ok(snap)

            if path == "/api/watch/probe":
                # 填完输出目录即自动推断总步数/预算。只读，不注册、不写任何文件。
                return self._ok(W.probe((q.get("dir") or [""])[0],
                                        (q.get("log") or [""])[0]))

            if path == "/api/meta":
                return self._ok({
                    # 版本号唯一来源在 paths.VERSION，界面据此显示
                    "version": PA.VERSION,
                    "stages": [{"key": k, "name": n, "desc": d} for k, n, d in P.STAGES],
                    "kinds": PL.CORPUS_KINDS,
                    "groups": PL.STEP_GROUPS,
                    # ★词表面板要显示已注册的特殊标记：基础 5 个 + 多模态（开关控制）
                    "special_base": BASE_SPECIAL,
                    "special_multimodal": MULTIMODAL_SPECIAL,
                    "levels": [
                        {"key": "loose", "name": "宽松", "desc": "保留更多，噪声也更多"},
                        {"key": "standard", "name": "标准", "desc": "推荐，按类型适配"},
                        {"key": "strict", "name": "严格", "desc": "只留高质量，可能损失较多"},
                        {"key": "custom", "name": "自定义", "desc": "直接填具体数值，所见即所得"},
                    ],
                    "clean_bounds": PL.CLEAN_BOUNDS,
                    "clean_fields": [
                        {"key": "min_cjk_ratio", "name": "非英文文字占比下限", "step": 0.05,
                         "hint": "统计中日韩等非英文文字字符占比，低于此值丢弃。代码类应设 0"},
                        {"key": "max_repeat_ratio", "name": "重复率上限", "step": 0.05,
                         "hint": "4-gram 重复率超过此值丢弃。代码类建议 ≥0.8"},
                        {"key": "max_symbol_ratio", "name": "符号占比上限", "step": 0.05,
                         "hint": "标点符号过多视为噪声"},
                        {"key": "min_chars", "name": "最短字符数", "step": 1,
                         "hint": "短于此值丢弃。中文古籍段落短，建议 8"},
                        {"key": "max_chars", "name": "最长字符数", "step": 1000,
                         "hint": "超长样本截断或丢弃，留空用默认"},
                        {"key": "max_digit_ratio", "name": "数字占比上限", "step": 0.05,
                         "hint": "纯数字表格类内容的过滤，留空用默认"},
                        {"key": "max_top_char_ratio", "name": "单字最高占比", "step": 0.05,
                         "hint": "某个字反复出现的刷屏文本，留空用默认"},
                    ],
                    "limits": H.LIMITS,
                    "tier_labels": H.TIER_LABEL,
                    "tier_lr": H.TIER_LR,
                    "tier_arch": H.TIER_ARCH,
                    "tier_vocab": H.TIER_VOCAB,
                    "tier_train": H.TIER_TRAIN,
                    # ★不设上限：min 仅防止 0/负数导致无法建模，max 一律不限
                    "arch_fields": [
                        {"key": "hidden_size", "name": "隐层宽度", "step": 64, "min": 1,
                         "hint": "模型主干维度，越大越强也越吃显存。不限上限"},
                        {"key": "num_hidden_layers", "name": "层数", "step": 1, "min": 1,
                         "hint": "Transformer 块数量，决定深度。不限上限"},
                        {"key": "intermediate_size", "name": "前馈中间维度", "step": 64, "min": 1,
                         "hint": "SwiGLU 内部维度，通常约为隐层的 2.7–4 倍。不限上限"},
                        {"key": "head_dim", "name": "每头维度", "step": 32, "min": 1,
                         "hint": "常用 64 或 128。不限上限"},
                        {"key": "num_attention_heads", "name": "注意力头数", "step": 1, "min": 1,
                         "hint": "留空则自动 = 隐层宽度 ÷ 每头维度。不限上限"},
                        {"key": "num_key_value_heads", "name": "KV 头数（GQA）", "step": 1, "min": 1,
                         "hint": "留空自动取头数的 1/4；不能整除时自动下调"},
                    ],
                    "defaults": P.DEFAULT_CONFIG,
                    # 每个工位的导入规格：界面据此显示「自己生成／使用已有」
                    "import_specs": IM.IMPORT_SPECS,
                })

            if path == "/api/clean_preview":
                kind = (q.get("kind") or ["auto"])[0]
                level = (q.get("level") or ["standard"])[0]
                custom = {}
                raw = (q.get("custom") or [""])[0]
                if raw:
                    try:
                        custom = json.loads(raw)
                    except ValueError:
                        custom = {}
                params = PL.clean_params(kind, level, custom)
                return self._ok({"kind": kind, "level": level, "params": params,
                                 "warnings": PL.clean_warnings(kind, params)})

            if path == "/api/probe":
                # ★容忍资源管理器「复制文件地址」带的首尾引号
                p = Path((q.get("path") or [""])[0].strip().strip('"').strip("'"))
                if not p.exists():
                    return self._err("路径不存在")
                files = ([p] if p.is_file() else
                         sorted(x for x in p.rglob("*")
                                if x.is_file() and x.suffix in (".jsonl", ".json", ".parquet", ".gz")))
                if not files:
                    return self._err("该路径下没有 jsonl/json/parquet/gz 文件")
                size = sum(f.stat().st_size for f in files)
                return self._ok({"files": len(files), "size_gb": round(size / 1024 ** 3, 3),
                                 "sample": [f.name for f in files[:5]]})

            if path == "/api/projects":
                return self._ok({"projects": P.list_all(), "runner": PL.RUNNER.status()})

            if path == "/api/project":
                name = (q.get("name") or [""])[0]
                proj = P.load(name)
                # 附带训练集实际 token 数，供界面算进度与剩余时间
                mp = P.project_dir(name) / "data" / "final" / "data_meta.json"
                total = 0
                if mp.exists():
                    try:
                        total = int(json.loads(mp.read_text(encoding="utf-8")).get("train_tokens", 0))
                    except (ValueError, OSError):
                        total = 0
                proj["total_tokens"] = total
                proj["output_dir"] = str(P.output_dir(name, proj["config"]))
                proj["project_dir"] = str(P.project_dir(name))
                # ★整合「全混合」要按各类实际 token 量显示占比：读各 packed_i
                #   的 data_meta（小 JSON），供界面实时算比例，不扫大文件。
                pt = []
                i = 0
                while True:
                    mp = P.project_dir(name) / "data" / f"packed_{i}" / "data_meta.json"
                    if not mp.exists():
                        break
                    try:
                        pt.append(int(json.loads(mp.read_text(encoding="utf-8")).get("train_tokens", 0)))
                    except (ValueError, OSError):
                        pt.append(0)
                    i += 1
                proj["pack_tokens"] = pt
                # 旧项目状态里没有 bytes：对已完成工位补算一次并缓存，
                # 之后轮询直接读缓存，不重复扫目录。
                d = P.project_dir(name)
                for k, x in proj["state"]["stages"].items():
                    if x.get("status") == "done" and "bytes" not in x:
                        ck = (name, k, x.get("finished_at"))
                        if ck not in _ART_CACHE:
                            _ART_CACHE[ck] = PL.stage_artifacts(d, k)
                            if len(_ART_CACHE) > 256:
                                _ART_CACHE.clear()
                        x["bytes"] = _ART_CACHE[ck]
                return self._ok(proj)

            if path == "/api/trainlog":
                name = (q.get("name") or [""])[0]
                return self._ok(read_train_log(name))

            if path == "/api/checkpoints":
                name = (q.get("name") or [""])[0]
                return self._ok(list_checkpoints(name))

            if path == "/api/log":
                name = (q.get("name") or [""])[0]
                stage = (q.get("stage") or [""])[0]
                return self._ok({"text": tail_log(name, stage)})

            # ---- v0.4.0 治理 / HF 批量下载 / 错误字典 ----
            if path == "/api/disk":
                from . import governance as GV
                return self._ok(GV.disk_usage())
            if path == "/api/hf/list":
                from . import governance as GV
                return self._ok(GV.hf_list((q.get("repo") or [""])[0]))
            return self._err("not found", 404)
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            return self._err(f"{type(e).__name__}: {e}", 500)

    # ---------- POST ----------
    def do_POST(self):  # noqa: N802
        if not self._guard():
            return
        u = urlparse(self.path)
        path = u.path
        try:
            b = self._body()
        except ValueError as e:
            return self._err(str(e), 413)
        try:
            # ---- 链接下载 ----
            # ★两段式：inspect 只读探测（不取正文），用户确认后才 start。
            #   协议/内网/体积/文件名校验不变；dest 允许用户自选保存位置，
            #   但必须是绝对路径且不能落在系统关键目录内。
            if path == "/api/download/inspect":
                return self._ok(DL.inspect(b.get("url", ""), b.get("project", ""),
                                           b.get("dest", "")))

            if path == "/api/download/start":
                return self._ok(DL.start(b.get("url", ""), b.get("project", ""),
                                         dest=b.get("dest", "")))

            if path == "/api/download/status":
                return self._ok(DL.status(b.get("id", "")))

            if path == "/api/download/cancel":
                return self._ok(DL.cancel(b.get("id", "")))

            if path == "/api/download/files":
                return self._ok(DL.list_files(b.get("project", ""), b.get("dest", "")))

            # ---- 在文件管理器中打开项目目录 ----
            # ★只接受 (项目名, 位置键)，真实路径由后端算，不接受任意路径。
            if path == "/api/reveal":
                return self._ok(RV.open_dir(b.get("name", ""), b.get("spot", "")))

            if path == "/api/projects/create":
                return self._ok(P.create(b.get("name", ""), b.get("config")))

            if path == "/api/projects/config":
                return self._ok(P.save_config(b.get("name", ""), b.get("config") or {}))

            if path == "/api/projects/delete":
                P.delete(b.get("name", ""))
                return self._ok({"deleted": b.get("name")})

            if path == "/api/check":
                hw = H.detect()
                # 只在字段缺失时兜底；0 是非法输入，必须原样交给校验函数拒绝
                bs = b.get("block_size")
                bs = 2048 if bs is None else int(bs)
                vs = b.get("vocab_size")
                vs = 32000 if vs is None else int(vs)
                bz = b.get("batch_size")
                bz = 1 if bz is None else int(bz)
                dt = b.get("master_dtype")
                dt = "bf16" if dt not in ("bf16", "fp32") else dt
                return self._ok(H.check_config(
                    b.get("tier", "base"), bs, hw,
                    arch=b.get("arch") or None, vocab_size=vs,
                    batch_size=bz, master_dtype=dt))

            if path == "/api/import/check":
                # 校验用户填的导入路径：只读，不复制不改动任何东西
                return self._ok(IM.validate(b.get("stage", ""), b.get("path", "")))

            # ---------- 导入更新包 ----------
            # ★两段式：inspect 只读校验并把清单给用户看，apply 才写盘。
            #   训练在跑时一律拒绝：引擎文件被占用，换掉会让训练行为不可预期。
            if path == "/api/upgrade/inspect":
                return self._ok(UP.inspect(b.get("path", ""),
                                           running=PL.RUNNER.is_running()))

            # ★失败也走 _ok 返回结构化 problems（{k,v}），前端按当前语言渲染。
            #   若用 _err 拼中文字符串，切到英文时这几条就翻不了。
            if path == "/api/upgrade/apply":
                return self._ok(UP.apply(b.get("path", ""),
                                         running=PL.RUNNER.is_running()))

            if path == "/api/upgrade/backups":
                return self._ok({"items": UP.list_backups()})

            if path == "/api/upgrade/rollback":
                return self._ok(UP.rollback(b.get("id", ""),
                                            running=PL.RUNNER.is_running()))

            if path == "/api/run/start":
                # stages = 用户勾选的工位组合（优先于 group）
                # resume_from = 用户指定的断点；fresh = 清空重训（前端已二次确认）
                PL.RUNNER.start(b.get("name", ""), b.get("from_stage"),
                                b.get("group"), stages=b.get("stages"),
                                resume_from=b.get("resume_from"),
                                fresh=bool(b.get("fresh")))
                return self._ok(PL.RUNNER.status())

            if path == "/api/run/reset":
                # 重跑指定步骤：把状态清回 pending
                name = b.get("name", "")
                proj = P.load(name)
                st = proj["state"]
                if st.get("running"):
                    return self._err("项目正在运行，请先停止")
                keys = b.get("stages") or [k for k, _n, _d in P.STAGES]
                for k in keys:
                    if k in st["stages"]:
                        st["stages"][k] = {"status": "pending", "progress": 0.0,
                                           "message": "", "started_at": None,
                                           "finished_at": None}
                # ★reset 也传播下游失效：旧实现只清指定工位，reset 清洗后
                #   跑 all_data 时已 done 的 pack/mix 被跳过用旧产物（审计指出）。
                #   与 start 共用同一失效映射，两条回退路径语义一致。
                PL.invalidate_downstream(st, keys, "上游已重置，结果已失效")
                st["error"] = None
                P.save_state(name, st)
                return self._ok(st)

            if path == "/api/run/markdone":
                # ★标记为完成（用户要求）：产物已就位但不想实际执行时手动认可该工位。
                #   只改状态不跑流程：done + 当前产物字节数 + 人工标记备注；
                #   运行中拒绝，避免与流水线状态写入打架。
                name = b.get("name", "")
                key = b.get("stage", "")
                proj = P.load(name)
                st = proj["state"]
                if st.get("running"):
                    return self._err("项目正在运行，请先停止")
                if key not in st.get("stages", {}):
                    return self._err("未知工位")
                d = P.project_dir(name)
                x = st["stages"][key]
                x.update({"status": "done", "progress": 1.0, "stale": False,
                          "skipped": False, "manual": True,
                          "finished_at": time.time(),
                          "bytes": PL.stage_artifacts(d, key),
                          "message": "已人工标记为完成（未实际执行）"})
                st["error"] = None
                P.save_state(name, st)
                return self._ok(st)

            if path == "/api/run/stop":
                PL.RUNNER.stop()
                return self._ok({"stopping": True})

            if path == "/api/run/pause":
                return self._ok(PL.RUNNER.pause(b.get("name", "")))

            if path == "/api/run/unpause":
                return self._ok(PL.RUNNER.cancel_pause(b.get("name", "")))

            if path == "/api/watch/add":
                return self._ok(W.add(
                    b.get("name", ""), b.get("out_dir", ""),
                    float(b.get("total_tokens") or 0),
                    int(b.get("total_steps") or 0),
                    b.get("log_file", "")))

            if path == "/api/watch/remove":
                W.remove(b.get("name", ""))
                return self._ok({"removed": b.get("name")})

            if path == "/api/env/set":
                raw = (b.get("python") or "").strip().strip('"')
                if not raw:
                    return self._err("请填写 python.exe 的完整路径")
                p = Path(raw)
                if not p.exists() or p.name.lower() not in ("python.exe", "python3.exe", "python"):
                    return self._err("路径不存在或不是 python 可执行文件")
                PA.set_python(str(p))
                env = PA.detect_env(force=True)
                if not env["ready"]:
                    return self._err("该环境缺少训练依赖（需要 torch/transformers/tokenizers/numpy），"
                                     "请先在其中安装后重试")
                return self._ok(env)

            # ---- v0.4.0 治理 / HF 批量下载 / 配置预测 / 错误字典 ----
            if path == "/api/disk/clean":
                from . import governance as GV
                return self._ok(GV.clean_target(b.get("name", ""), b.get("target", "")))
            if path == "/api/hf/download":
                from . import governance as GV
                return self._ok(GV.hf_download(b.get("repo", ""), b.get("files", []),
                                               b.get("dest", "")))
            if path == "/api/modelcard":
                # ★模型介绍导出（用户要求）：scope=full/public，fmt=md/txt
                return self._ok(MC.build(b.get("name", ""),
                                         b.get("scope", "full"), b.get("fmt", "md")))
            if path == "/api/config/predict":
                return self._ok(P.predict_rerun(b.get("name", ""), b.get("config") or {}))
            if path == "/api/err/explain":
                from . import errdict as ED
                return self._ok(ED.explain(b.get("error", "")))

            return self._err("not found", 404)
        except ValueError as e:
            return self._err(str(e), 400)
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            return self._err(f"{type(e).__name__}: {e}", 500)


def serve(host: str = "127.0.0.1", port: int = 1220) -> ThreadingHTTPServer:
    # ★启动即清理上次进程遗留的运行态：否则项目永久显示运行中，
    #   无法改配置/删除/续训（审计指出）。
    try:
        n = PL.recover_stale_states()
        if n:
            print(f"[i] 已恢复 {n} 个项目的中断状态（服务重启所致），可继续训练")
    except Exception:  # noqa: BLE001 恢复失败不该挡住服务启动
        pass
    httpd = ThreadingHTTPServer((host, port), Handler)
    return httpd

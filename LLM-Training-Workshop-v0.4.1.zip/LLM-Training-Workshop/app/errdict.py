# -*- coding: utf-8 -*-
"""错误字典：把高频错误映射成「原因 + 修复动作」，供界面给可操作提示。

匹配后端错误原文（中文），返回 {cause, actions:[{label, hint}]}。
界面渲染时按当前语言翻译 label/hint（键走 i18n）。
"""
from __future__ import annotations

import re

# (正则, 原因键, 动作键列表)
_RULES = [
    (re.compile(r"显存不足|CUDA OOM|out of memory"), "err.oom",
     ["act.lower_batch", "act.lower_ctx", "act.checkpointing", "act.smaller_tier"]),
    (re.compile(r"磁盘空间不足|磁盘剩余|No space left"), "err.disk",
     ["act.free_disk", "act.change_outdir", "act.clean_cache"]),
    (re.compile(r"词表.*不一致|指纹不一致|vocab"), "err.vocab",
     ["act.repack", "act.import_tokenizer"]),
    (re.compile(r"续训结构与当前配置不一致"), "err.struct",
     ["act.revert_config", "act.fresh_start"]),
    (re.compile(r"预算已用尽"), "err.budget",
     ["act.raise_budget", "act.fresh_start"]),
    (re.compile(r"缺少.*依赖|未找到.*环境|transformers.*过低|ModuleNotFoundError"), "err.dep",
     ["act.install_dep", "act.recheck_env"]),
    (re.compile(r"没有.*语料|未配置语料|清洗后无数据"), "err.corpus",
     ["act.add_corpus", "act.loosen_clean"]),
    (re.compile(r"缺少.*模型|没有可.*模型"), "err.model",
     ["act.train_first", "act.import_model"]),
    (re.compile(r"缺少 SFT|缺少 LoRA|对话数据"), "err.sftdata",
     ["act.add_sft_data"]),
    (re.compile(r"找不到 convert|llama-quantize|GGUF 转换失败"), "err.gguf",
     ["act.set_llama_cpp", "act.hf_only"]),
]


def explain(error: str) -> dict:
    """返回错误的原因键与修复动作键列表；无匹配返回空。"""
    for pat, cause, actions in _RULES:
        if pat.search(error or ""):
            return {"cause": cause, "actions": actions}
    return {}

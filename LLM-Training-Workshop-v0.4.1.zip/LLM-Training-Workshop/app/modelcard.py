"""modelcard.py —— 生成模型介绍（model card），可选 .md / .txt。

两档内容（用户要求）：
  full    完整自用：含本地路径、语料明细、全部超参、训练/导出状态，给自己看。
  public  公开商用：隐去本地路径、语料来源明细、敏感超参与内部状态，
          只保留架构/规模/词表/上下文/精度/用途/许可等可对外信息。

只读项目 config/state/产物 meta，不修改任何训练数据；输出到 项目/export/。
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from . import paths as PA
from . import projects as P
from . import hardware as H


def _fmt_n(n) -> str:
    n = int(n)
    for div, suf in ((1e12, "T"), (1e9, "B"), (1e6, "M"), (1e3, "K")):
        if n >= div:
            x = n / div
            return f"{x:.2f}".rstrip("0").rstrip(".") + suf
    return str(n)


def _read_json(p: Path):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def build(name: str, scope: str = "full", fmt: str = "md") -> dict:
    """生成介绍文本并落盘到 项目/export/model_card_<scope>.<fmt>。"""
    scope = "public" if scope == "public" else "full"
    fmt = "txt" if fmt == "txt" else "md"
    proj = P.load(name)
    cfg, st = proj["config"], proj["state"]
    d = P.project_dir(name)
    tier = cfg.get("tier") or "base"
    arch = cfg.get("arch") or H.TIER_ARCH.get(tier, {})
    params = H.TIER_PARAMS.get(tier, 0)
    vocab = int(cfg.get("vocab_size") or H.TIER_VOCAB.get(tier, 32000))
    ctx = int(cfg.get("block_size") or 2048)
    dtype = cfg.get("master_dtype") or "bf16"
    final_meta = _read_json(d / "data" / "final" / "data_meta.json") or {}
    train_tokens = int(final_meta.get("train_tokens", 0))
    stages = st.get("stages", {})

    L: list[str] = []
    if fmt == "md":
        L.append(f"# {name} · 模型介绍")
        L.append("")
        L.append(f"> 生成时间 {time.strftime('%Y-%m-%d %H:%M:%S')} · "
                 f"{'公开版（商用）' if scope == 'public' else '完整版（自用）'}")
        L.append("")
        L.append("## 概览")
        L.append(f"- 档位：{H.TIER_LABEL.get(tier, tier)}")
        L.append(f"- 参数量：约 {_fmt_n(params)}")
        L.append(f"- 上下文长度：{ctx}")
        L.append(f"- 词表大小：{vocab}")
        L.append(f"- 训练精度：{dtype}")
        L.append("")
        L.append("## 架构")
        for k, label in (("hidden_size", "隐层宽度"), ("num_hidden_layers", "层数"),
                         ("intermediate_size", "FFN 中间维度"), ("num_attention_heads", "注意力头数"),
                         ("num_key_value_heads", "KV 头数")):
            if arch.get(k) is not None:
                L.append(f"- {label}：{arch[k]}")
        L.append("")
        L.append("## 训练数据")
        if train_tokens:
            L.append(f"- 训练 token 总量：{_fmt_n(train_tokens)}")
        if scope == "full":
            for i, e in enumerate(cfg.get("corpus", [])):
                L.append(f"- 语料{i + 1}：{e.get('kind', 'auto')} · 路径 {e.get('path', '')}")
            L.append(f"- 清洗强度：{cfg.get('clean_level', 'standard')}")
            L.append(f"- 全混合：{'是' if cfg.get('mix_all') else '否'}")
        else:
            L.append("- 语料来源与明细：按商用保密要求隐去")
        L.append("")
        if scope == "full":
            L.append("## 训练超参（自用）")
            for k in ("batch_size", "grad_accum", "lr", "warmup_steps", "max_tokens",
                      "save_every", "eval_every"):
                L.append(f"- {k}：{cfg.get(k)}")
            L.append("")
            L.append("## 工位状态（自用）")
            for k, x in stages.items():
                L.append(f"- {k}：{x.get('status')}")
            L.append("")
        L.append("## 用途与限制")
        L.append("- 本模型为本地预训练产物，能力与数据规模相关，重要场景请自行评测。")
        L.append("- 许可与合规由使用者自行确认；公开版不含内部路径与语料明细。")
        L.append("")
        text = "\n".join(L)
    else:
        L.append(f"{name} · 模型介绍（{'公开版' if scope == 'public' else '完整版'}）")
        L.append(f"生成时间 {time.strftime('%Y-%m-%d %H:%M:%S')}")
        L.append("-" * 40)
        L.append(f"档位 {H.TIER_LABEL.get(tier, tier)} / 参数 {_fmt_n(params)} / 上下文 {ctx} / 词表 {vocab} / 精度 {dtype}")
        if train_tokens:
            L.append(f"训练 token {_fmt_n(train_tokens)}")
        if scope == "full":
            for i, e in enumerate(cfg.get("corpus", [])):
                L.append(f"语料{i + 1} {e.get('kind', 'auto')} {e.get('path', '')}")
            L.append(f"清洗 {cfg.get('clean_level', 'standard')} / 全混合 {'是' if cfg.get('mix_all') else '否'}")
            L.append(f"batch {cfg.get('batch_size')} accum {cfg.get('grad_accum')} lr {cfg.get('lr')}")
        else:
            L.append("语料来源与内部超参：按商用保密要求隐去")
        L.append("许可与合规由使用者自行确认。")
        text = "\n".join(L)

    out_dir = d / "export"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"model_card_{scope}.{fmt}"
    out.write_text(text, encoding="utf-8")
    return {"path": str(out), "scope": scope, "fmt": fmt, "bytes": out.stat().st_size}

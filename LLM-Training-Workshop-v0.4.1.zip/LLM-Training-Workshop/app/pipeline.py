"""流水线调度器：把九个工位串成"自动挡"。

三条铁律（全部来自真实踩坑）：
  1. 每步产物落盘才算完成 —— 下一步只认上一步的输出文件，不认"进程退出了"
  2. 进度看文件增长/日志时间，不看进程活着 —— 曾三次误判卡死
  3. 大文件步骤先看磁盘 —— 不够就提前报错，而不是跑到一半磁盘满
"""
from __future__ import annotations

import gzip
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from . import imports as IM
from . import paths as PA
from . import projects as P

ROOT = PA.app_root()
ENGINE = PA.engine_dir()
# ★解释器在每次启动时动态取：用户可能中途才装好环境。
#   绝不能用 sys.executable —— 冻结后它指向 exe 自身，会递归启动 GUI。


def _p(key: str, **v) -> dict:
    """可翻译警告：界面按 key 查双语词典，变量原样填充。"""
    return {"k": key, "v": v}


def _fmt_tok(n: int) -> str:
    """token 数用 K/M/B/T 单位（用户要求），中英界面通用，不再显示长串数字。"""
    n = int(n)
    for div, suf in ((1e12, "T"), (1e9, "B"), (1e6, "M"), (1e3, "K")):
        if n >= div:
            x = n / div
            return f"{x:.2f}".rstrip("0").rstrip(".") + suf
    return str(n)


def _dir_bytes(root: Path) -> int:
    """目录产物总字节数。只统计文件，符号链接按目标实际大小算一次。"""
    if not root.exists():
        return 0
    if root.is_file():
        return root.stat().st_size
    tot = 0
    for f in root.rglob("*"):
        if f.is_file():
            try:
                tot += f.stat().st_size
            except OSError:
                pass
    return tot


def _log_lines(path: Path) -> int:
    """流式数行，内存恒定——数月长跑的日志可能几百 MB，不能整读。"""
    if not path.exists():
        return 0
    n = 0
    with path.open("rb") as f:
        for _ in f:
            n += 1
    return n


# 各工位产物：界面显示大小用。路径相对项目目录。
STAGE_ARTIFACTS = {
    "adapt": ["data"],          # raw_*.jsonl（data 下还有清洗产物，单独算）
    "clean": ["data/cleaned_corpus.jsonl"],
    "tokenizer": ["tokenizer"],
    "pack": ["data"],           # 打包产物在 data 下按类存放，下面精确化
    "mix": ["data/final"],
    "train": ["output"],
}


# ★工位下游失效映射（start 与 reset 共用，保证两条回退路径语义一致）。
#   v0.4.0：train 之后接 sft/lora/export；base 变了微调/导出都要重跑。
DOWN_MAP = {
    "adapt": ["clean", "tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "clean": ["tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "tokenizer": ["pack", "mix", "train", "test", "sft", "lora", "export"],
    "pack": ["mix", "train", "test", "sft", "lora", "export"],
    "mix": ["train", "test", "sft", "lora", "export"],
    "train": ["test", "sft", "lora", "export"],
    "sft": ["export"],
    "lora": ["export"],
}

# ★配置字段 → 受影响工位：改这些参数后，对应已完成工位必须重跑，
#   否则一键跑会静默沿用旧词表/旧数据/旧结构（三份审计一致指出的最高危项）。
CONFIG_STAGE_KEYS = {
    "corpus": ["adapt", "clean", "tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "clean_level": ["clean", "tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "clean_level_adjust": ["clean", "tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "clean_values": ["clean", "tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "mix_all": ["mix", "train", "test", "sft", "lora", "export"],
    "clean_overrides": ["clean", "tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    # ★补全审计发现的漏项：这些键改了但下游不失效，会静默用旧产物
    "near_dup": ["clean", "tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "near_dup_threshold": ["clean", "tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "pii": ["clean", "tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "val_by_hash": ["pack", "mix", "train", "test", "sft", "lora", "export"],
    "sources": ["adapt", "clean", "tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "vocab_size": ["tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    # ★特殊标记影响词表→模型嵌入维度，sft/lora/export 同样依赖，旧映射漏了
    "multimodal_tokens": ["tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "extra_special": ["tokenizer", "pack", "mix", "train", "test", "sft", "lora", "export"],
    "block_size": ["pack", "mix", "train", "test", "sft", "lora"],
    "tier": ["train", "test", "sft", "lora", "export"],
    "arch": ["train", "test", "sft", "lora", "export"],
    "master_dtype": ["train", "sft", "lora"],
    "max_tokens": ["train"],
    # ★训练超参改了必须重训，旧映射完全没列（改 lr/batch 后 done 不失效）
    "lr": ["train", "test", "sft", "lora", "export"],
    "batch_size": ["train", "test", "sft", "lora", "export"],
    "grad_accum": ["train", "test", "sft", "lora", "export"],
    "warmup_steps": ["train", "test", "sft", "lora", "export"],
    "sft_data": ["sft", "lora", "export"],
    "sft_lr": ["sft"], "sft_steps": ["sft"], "sft_batch": ["sft"], "sft_accum": ["sft"],
    "lora_r": ["lora", "export"], "lora_alpha": ["lora", "export"],
    "lora_lr": ["lora"], "lora_steps": ["lora"],
    "lora_merge": ["lora", "export"],
    "export_quant": ["export"], "llama_cpp": ["export"],
    "quant_imatrix": ["export"], "quant_pure": ["export"],
    "quant_leave_output": ["export"], "quant_allow_requantize": ["export"],
    "quant_output_type": ["export"], "quant_embed_type": ["export"],
    "quant_tensor_types": ["export"], "quant_threads": ["export"],
    "quant_extra_args": ["export"],
}


def invalidate_downstream(st: dict, stages: list, reason: str) -> None:
    """把指定工位的已完成下游标为 stale（产物仍在，但与最新配置不一致）。

    ★不再直接打回 pending（用户实测：改个清洗参数，已训好的模型在数据页
      显示「没处理过」且训练被前置校验拦住）。stale 语义 = 产物完好可用、
      只是与当前配置有出入，界面用琥珀色提示「需重跑」，但不阻断下游启动，
      也不丢弃 bytes/finished_at 等产物信息。真正重跑时才转 running/done。
    """
    for k in stages:
        for dk in DOWN_MAP.get(k, []):
            cur = st.get("stages", {}).get(dk)
            if cur and cur.get("status") == "done":
                cur["status"] = "stale"
                cur["message"] = reason
                cur["stale"] = True


def _write_data_card(d: Path, cfg: dict, entries: list) -> None:
    """写数据卡 data_card.json：来源/类型/许可/处理参数/时间，供合规溯源。

    ★审计指出语料被压平后无法按来源下线、无许可记录。这里在清洗完成时
      记录每条语料的来源路径、类型、用户声明的许可、清洗强度与开关，
      形成可追溯的数据档案（不上传，仅本地）。
    """
    sources = []
    for i, e in enumerate(entries):
        sources.append({
            "index": i,
            "path": e.get("path") or e.get("clean_import") or "",
            "kind": e.get("kind", "auto"),
            "license": e.get("license", "未声明"),
            "imported": bool((e.get("clean_import") or "").strip()),
            "clean_level": e.get("clean_level") or cfg.get("clean_level", "standard"),
        })
    card = {
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "sources": sources,
        "processing": {
            "clean_level": cfg.get("clean_level", "standard"),
            "near_dup": bool(cfg.get("near_dup", False)),
            "pii": bool(cfg.get("pii", False)),
            "split_long": True,
        },
        "note": "来源与许可由用户声明；本工具不校验授权，发布模型前请自行确认合规。",
    }
    try:
        (d / "data" / "data_card.json").write_text(
            json.dumps(card, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def _merge_cleaned(d: Path, n: int) -> None:
    """把 clean_0..clean_{n-1}.jsonl 原子合并为 cleaned_corpus.jsonl。

    ★先写临时文件再 replace：旧实现直接 open("w") 截断覆盖，中途强停/断电
      会留半截语料，被词表训练或「导入已清洗文件」引用即坏数据（审计指出）。
    """
    merged = d / "data" / "cleaned_corpus.jsonl"
    tmp = merged.with_name(f".cleaned_corpus.tmp-{os.getpid()}")
    with tmp.open("w", encoding="utf-8") as out:
        for i in range(n):
            p = d / "data" / f"clean_{i}.jsonl"
            with p.open(encoding="utf-8") as f:
                shutil.copyfileobj(f, out, 1024 * 1024)
    tmp.replace(merged)


def stage_artifacts(d: Path, key: str) -> int:
    """某工位产物的字节数。adapt/pack 只算各自的文件，避免把 data 全目录重复计。"""
    if key == "adapt":
        return sum(f.stat().st_size for f in (d / "data").glob("raw_*.jsonl")
                   if f.is_file()) if (d / "data").exists() else 0
    if key == "pack":
        tot = 0
        for sub in (d / "data").iterdir() if (d / "data").exists() else []:
            if sub.is_dir() and (sub / "data_meta.json").exists() and sub.name != "final":
                tot += _dir_bytes(sub)
        return tot
    tot = 0
    for rel in STAGE_ARTIFACTS.get(key, []):
        tot += _dir_bytes(d / rel)
    return tot

# 语料类型：每类有自己的清洗预设与字段适配器。
# ★分类适配的必要性来自真实踩坑：
#   代码类 CJK 占比为 0，用通用"标准"强度会被全部误杀；
#   代码 4-gram 重复率中位数 0.52，用默认 0.5 阈值会误杀 56%；
#   古籍按段落切分，中位数仅 34 字，最短长度门槛必须放低。
CORPUS_KINDS = [
    {"key": "web", "name": "网页正文", "extractor": "skypile",
     "desc": "新闻、博客、论坛等长文本",
     "clean": {"min_cjk_ratio": 0.30, "max_repeat_ratio": 0.50,
               "max_symbol_ratio": 0.30, "min_chars": 20}},
    {"key": "wiki", "name": "百科词条", "extractor": "wikipedia",
     "desc": "维基百科、百度百科等结构化词条",
     "clean": {"min_cjk_ratio": 0.35, "max_repeat_ratio": 0.50,
               "max_symbol_ratio": 0.28, "min_chars": 20}},
    {"key": "qa", "name": "问答对话", "extractor": "zhihu",
     "desc": "知乎、问答社区、指令数据",
     "clean": {"min_cjk_ratio": 0.25, "max_repeat_ratio": 0.60,
               "max_symbol_ratio": 0.35, "min_chars": 8}},
    {"key": "book", "name": "书籍文献", "extractor": "wikipedia",
     "desc": "维基文库、电子书、长篇文章",
     "clean": {"min_cjk_ratio": 0.40, "max_repeat_ratio": 0.45,
               "max_symbol_ratio": 0.25, "min_chars": 30}},
    {"key": "guji", "name": "中文古籍", "extractor": "classical",
     "desc": "公版中文古籍，段落短、文言密度高（不含其他语言古籍）",
     "clean": {"min_cjk_ratio": 0.50, "max_repeat_ratio": 0.55,
               "max_symbol_ratio": 0.25, "min_chars": 8}},
    {"key": "code", "name": "代码", "extractor": "codeparrot",
     "desc": "源码文件，中文占比为 0 属正常",
     "clean": {"min_cjk_ratio": 0.0, "max_repeat_ratio": 0.80,
               "max_symbol_ratio": 0.55, "min_chars": 20}},
    {"key": "auto", "name": "自动识别", "extractor": "auto",
     "desc": "结构不确定的语料，按通用规则处理",
     "clean": {"min_cjk_ratio": 0.20, "max_repeat_ratio": 0.60,
               "max_symbol_ratio": 0.35, "min_chars": 8}},
    # ★「其他」：无清洗预设，参数全靠用户自设（识别失败也会落到这里）
    {"key": "other", "name": "其他", "extractor": "auto",
     "desc": "自定义类型，无预设清洗参数，请自行设置",
     "clean": None},
]

KIND_MAP = {k["key"]: k for k in CORPUS_KINDS}

# ★各类型「标准强度」下的合理保留率区间（经验参考值，不是硬标准）：
#   低于下限 → 可能阈值误杀/类型选错；高于上限 → 几乎没滤掉东西，
#   可能强度太松或该源本来极干净。低于下限的 1/4 视为严重丢弃。
#   宽松/严格强度会整体平移实际保留率，提示文案里已注明按标准强度估。
# ★上限校准（用户实测）：预过滤/本来就干净的语料（fineweb-2、维基文库）
#   标准强度下保留 95%~100% 属正常，旧上限 85%/97% 会误报「几乎没滤掉」。
#   上限只用于「高保留提醒」，放宽到接近 100%，真正该警惕的是低保留误杀。
CLEAN_KEEP_RANGE = {
    "web": (0.20, 1.00),    # 原始网页噪声多可滤大半；预过滤网页留近 100% 也正常
    "wiki": (0.50, 1.00),   # 百科本来就干净，留得少反而可疑
    "qa": (0.30, 0.98),     # 问答短文本多，长度门槛会滤掉一部分
    "book": (0.50, 1.00),   # 书籍/文库干净，留近 100% 正常；扫描版噪声可能拉低
    "guji": (0.30, 0.98),   # 古籍段落短，长度/重复门槛影响大
    "code": (0.30, 0.98),   # 代码重复率高（模板/许可证），去重会滤不少
    "auto": (0.20, 1.00),   # 成分不明，区间放宽
    "other": (0.05, 1.00),  # 自定义类型，无经验参考，区间放宽
}

# 清洗强度：在各类预设基础上整体收紧或放宽
# ★custom 档（用户要求）：不做任何缩放，直接用用户填的「具体数值」
#   （clean_values），所见即所得；未填的项才退回类型预设。
#   其余三档仍按类型预设缩放，保持「按类型适配、不一刀切」。
CLEAN_LEVELS = {
    "loose": {"cjk_delta": -0.15, "repeat_delta": 0.15, "symbol_delta": 0.15, "chars_scale": 0.5},
    "standard": {"cjk_delta": 0.0, "repeat_delta": 0.0, "symbol_delta": 0.0, "chars_scale": 1.0},
    "strict": {"cjk_delta": 0.15, "repeat_delta": -0.10, "symbol_delta": -0.10, "chars_scale": 1.5},
    "custom": {"cjk_delta": 0.0, "repeat_delta": 0.0, "symbol_delta": 0.0, "chars_scale": 1.0},
}

# 可单独执行的步骤分组（用户可只跑其中一段）
STEP_GROUPS = [
    {"key": "prepare", "name": "准备数据", "stages": ["adapt", "clean"],
     "desc": "识别字段 + 清洗"},
    {"key": "build", "name": "构建训练集", "stages": ["tokenizer", "pack", "mix"],
     "desc": "训词表 + 打包 + 混合"},
    {"key": "all_data", "name": "数据全流程", "stages": ["adapt", "clean", "tokenizer", "pack", "mix"],
     "desc": "从原始语料到可训练数据"},
    {"key": "train", "name": "仅训练", "stages": ["train"],
     "desc": "用已有训练集开始/继续训练"},
    {"key": "test", "name": "仅验证", "stages": ["test"],
     "desc": "对已训好的模型做生成与困惑度测试"},
    {"key": "sft", "name": "指令微调", "stages": ["sft"],
     "desc": "SFT 教 base 模型按问答格式回应"},
    {"key": "lora", "name": "LoRA微调", "stages": ["lora"],
     "desc": "低秩适配微调，省显存可叠加"},
    {"key": "export", "name": "导出", "stages": ["export"],
     "desc": "精简HF包+GGUF量化+自检"},
    {"key": "full", "name": "全部步骤", "stages": ["adapt", "clean", "tokenizer", "pack", "mix", "train", "test"],
     "desc": "预训练一条流水线跑到底（微调/导出单独跑）"},
]


# 自定义清洗参数的合法范围（防止用户填出必然清空语料的值）
CLEAN_BOUNDS = {
    "min_cjk_ratio": (0.0, 0.95),
    "max_repeat_ratio": (0.10, 0.99),
    "max_symbol_ratio": (0.05, 0.95),
    "min_chars": (1, 5000),
    "max_chars": (100, 2000000),
    "max_digit_ratio": (0.10, 0.99),
    "max_top_char_ratio": (0.10, 0.99),
}


def clean_params(kind: str, level: str, custom: dict | None = None,
                 adjust: dict | None = None, values: dict | None = None) -> dict:
    """按语料类型 + 强度算出清洗参数；custom 中的项逐个覆盖预设。

    custom 为 None 或空 → 完全走类型预设（保持原有行为）。
    只覆盖用户明确填写的字段，其余仍按类型适配，避免"改一个就丢掉全部适配"。

    ★values = 全局「具体数值」（clean_values，用户要求直观）：
      **仅在 level == "custom" 时生效**，直接作为最终阈值（不是偏移/倍数），
      未填的项退回类型预设。其余档位仍按类型预设×档位缩放，不会一刀切。
    ★adjust = 旧版全局微调（clean_level_adjust：比率偏移、min_chars_scale 倍数）：
      保留兼容旧 config.json，仅在非 custom 档且未提供 values 时套用。
      优先级：单条 custom > 全局具体数值(custom 档) > 旧版微调 > 类型预设×档位。
    """
    base = KIND_MAP.get(kind, KIND_MAP["auto"])["clean"]
    lv = CLEAN_LEVELS.get(level, CLEAN_LEVELS["standard"])
    if base is None:
        # ★「其他」类型无预设：只认用户自设参数；未设的项给最宽松兜底
        #   （不静默误杀），清洗工位会另行拦截提示用户设置。不走通用钳制。
        out = {"min_cjk_ratio": 0.0, "max_repeat_ratio": 0.99,
               "max_symbol_ratio": 0.95, "min_chars": 1}
    else:
        out = {
            "min_cjk_ratio": round(max(0.0, min(0.95, base["min_cjk_ratio"] + lv["cjk_delta"])), 3),
            "max_repeat_ratio": round(max(0.1, min(0.95, base["max_repeat_ratio"] + lv["repeat_delta"])), 3),
            "max_symbol_ratio": round(max(0.05, min(0.9, base["max_symbol_ratio"] + lv["symbol_delta"])), 3),
            "min_chars": max(4, int(base["min_chars"] * lv["chars_scale"])),
        }
    # ★全局微调：与前端 cleanParams 同口径（比率加偏移、最短乘倍数、最长取绝对值）
    a = adjust or {}

    def _num(v):
        try:
            f = float(v)
        except (TypeError, ValueError):
            return None
        return f if f == f else None  # 排除 NaN

    if level == "custom":
        # ★自定义档：用户填的就是最终阈值，直接取值（钳到合法范围），不做偏移/倍数
        v = values or {}
        for key in ("min_cjk_ratio", "max_repeat_ratio", "max_symbol_ratio",
                    "min_chars", "max_chars", "max_digit_ratio", "max_top_char_ratio"):
            n = _num(v.get(key))
            if n is None or key not in CLEAN_BOUNDS:
                continue
            lo, hi = CLEAN_BOUNDS[key]
            n = max(lo, min(hi, n))
            out[key] = int(n) if key in ("min_chars", "max_chars") else round(n, 3)
    else:
        ac, ar, as_ = _num(a.get("min_cjk_ratio")), _num(a.get("max_repeat_ratio")), _num(a.get("max_symbol_ratio"))
        am, ax = _num(a.get("min_chars_scale")), _num(a.get("max_chars"))
        if ac is not None:
            out["min_cjk_ratio"] = round(max(0.0, min(0.95, out["min_cjk_ratio"] + ac)), 3)
        if ar is not None:
            out["max_repeat_ratio"] = round(max(0.1, min(0.95, out["max_repeat_ratio"] + ar)), 3)
        if as_ is not None:
            out["max_symbol_ratio"] = round(max(0.05, min(0.9, out["max_symbol_ratio"] + as_)), 3)
        if am is not None and am > 0:
            out["min_chars"] = max(4, int(out["min_chars"] * am))
        if ax is not None:
            out["max_chars"] = int(max(100, min(2000000, ax)))
    for k, v in (custom or {}).items():
        if k not in CLEAN_BOUNDS or v is None or v == "":
            continue
        lo, hi = CLEAN_BOUNDS[k]
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        f = max(lo, min(hi, f))
        out[k] = int(f) if k in ("min_chars", "max_chars") else round(f, 3)
    return out


def detect_kind(path: Path) -> tuple[str, float]:
    """按内容抽样推断语料类型（auto 时用）。返回 (类型, 置信度0~1)。

    启发式规则，置信度不高时落「其他」让用户自设，不硬猜。
    """
    import random
    texts: list[str] = []
    try:
        if path.suffix == ".parquet":
            import pyarrow.parquet as pq
            pf = pq.ParquetFile(path)
            col = "text" if "text" in pf.schema_arrow.names else pf.schema_arrow.names[0]
            for b in pf.iter_batches(batch_size=100, columns=[col]):
                texts.extend(str(t) for t in b.column(0).to_pylist() if t)
                if len(texts) >= 200:
                    break
        else:
            opener = gzip.open if path.suffix == ".gz" else open
            with opener(path, "rt", encoding="utf-8", errors="replace") as fh:
                for ln in fh:
                    ln = ln.strip()
                    if not ln:
                        continue
                    # ★超大单行防护：16GB 单数组 .json 的首行就是整个文件，
                    #   旧实现 json.loads(ln) 全量读入直接 OOM。探测只需抽样，
                    #   超长行截前 64KB 解析；解析不了就当纯文本样本。
                    if len(ln) > 262144:
                        ln = ln[:262144]
                    try:
                        o = json.loads(ln)
                        t = o.get("text") or o.get("content") or o.get("code") or ""
                    except ValueError:
                        t = ln
                    if t:
                        texts.append(str(t)[:8192])
                    if len(texts) >= 400:
                        break
    except Exception:
        return "other", 0.0
    texts = texts[:200]
    if not texts:
        return "other", 0.0
    sample = texts if len(texts) <= 60 else random.Random(0).sample(texts, 60)
    cjk = asc = dig = sym = 0
    code_hits = qa_hits = 0
    code_pat = re.compile(r"^\s*(def |class |import |from |#include|function |const |var |let |public |private )", re.M)
    # ★中文古籍判定（用户要求：古籍只考虑中文古籍，且不能误判现代百科）：
    #   旧实现只要中文占比高 + 前 20 条里出现「曰/之乎者也」就判古籍，
    #   现代 wiki 引用一句古文就被误判（用户实测）。现改为逐条看「文言密度」：
    #   虚词/文言标志按字数归一，且要求多数样本达标，单条引用不再触发。
    guji_pat = re.compile(r"[之乎者也矣焉哉欤歟]|曰|欽定|四庫|爾雅|說文")
    guji_hits = 0
    for t in sample:
        head = t[:2000]
        for ch in head:
            o = ord(ch)
            if 0x4E00 <= o <= 0x9FFF:
                cjk += 1
            elif ch.isascii() and ch.isalpha():
                asc += 1
            elif ch.isdigit():
                dig += 1
            elif not ch.isspace():
                sym += 1
        if code_pat.search(t[:1500]):
            code_hits += 1
        if re.search(r"(问[:：]|答[:：]|^Q[:：]|^A[:：])", t[:300], re.M):
            qa_hits += 1
        # 文言密度：标志词次数 ÷ 汉字数。古籍通常 ≥2%，现代文引用古文远低于此
        cjk_n = sum(1 for ch in head if 0x4E00 <= ord(ch) <= 0x9FFF)
        if cjk_n >= 30 and len(guji_pat.findall(head)) / cjk_n >= 0.02:
            guji_hits += 1
    tot = max(1, cjk + asc + dig + sym)
    cjk_r, sym_r = cjk / tot, sym / tot
    n = len(sample)
    if code_hits / n >= 0.3 and cjk_r < 0.1:
        return "code", min(1.0, code_hits / n)
    # ★中文古籍：中文占比高 + 多数样本文言密度达标（不是前几条碰巧有「曰」）
    if cjk_r >= 0.5 and guji_hits / n >= 0.5:
        return "guji", min(0.9, 0.4 + guji_hits / n * 0.5)
    if qa_hits / n >= 0.3:
        return "qa", min(1.0, qa_hits / n)
    if cjk_r >= 0.35:
        return "web", 0.55
    if cjk_r >= 0.15:
        return "wiki", 0.45
    return "other", 0.3


def clean_warnings(kind: str, params: dict) -> list[str]:
    """对用户自定义值给出风险提示（不阻断，只提醒）。"""
    w = []
    if kind == "code" and params.get("min_cjk_ratio", 0) > 0.05:
        w.append("代码语料的中文占比通常为 0，中文门槛大于 0.05 可能滤掉绝大部分代码")
    if params.get("max_repeat_ratio", 1) < 0.52 and kind == "code":
        w.append("代码的 4-gram 重复率中位数约 0.52，阈值低于此值会误杀约一半样本")
    if kind == "guji" and params.get("min_chars", 0) > 20:
        w.append("中文古籍段落中位数约 34 字，最短门槛过高会滤掉大量正常段落")
    if params.get("min_cjk_ratio", 0) > 0.8:
        w.append("中文门槛过高，混合中英文的语料可能被大量丢弃")
    if params.get("max_symbol_ratio", 1) < 0.1:
        w.append("符号率上限过低，含公式或代码片段的文本容易被丢弃")
    mc = params.get("min_chars")
    xc = params.get("max_chars")
    if mc and xc and mc >= xc:
        w.append("最短字数不小于最长字数，会导致所有样本被丢弃")
    return w


class Runner:
    """单项目流水线执行器。同一时刻只允许一个项目在跑（单卡工具）。"""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._proc: subprocess.Popen | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.active: str | None = None
        self._only: set[str] | None = None
        self._pausing = False
        self._resume_from: str | None = None
        self._fresh = False

    # ---------------- 状态 ----------------
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def status(self) -> dict:
        return {"running": self.is_running(), "active": self.active,
                "pausing": self._pausing}

    # ---------------- 优雅暂停 ----------------
    def pause(self, name: str) -> dict:
        """请求优雅暂停：写停止标记，让训练在步边界保存断点后自行退出。

        ★不终止进程、不发控制台信号。训练自己决定何时安全退出，
          因此不会丢进度、不会写坏断点。
        """
        if not self.is_running() or self.active != name:
            raise ValueError(f"项目「{name}」当前没有正在运行的任务")
        st = P.load(name)["state"]
        cur = st.get("current")
        if cur != "train":
            raise ValueError(f"当前在「{cur}」步骤，只有训练步骤支持暂停")
        out = P.output_dir(name)
        if not out.exists():
            raise ValueError("训练输出目录尚未创建，请稍等再试")
        flag = out / "STOP_REQUESTED"
        try:
            flag.write_text(
                f"requested_at={time.time()}\nby=LLM训练工坊\n", encoding="utf-8")
        except OSError as e:
            raise ValueError(f"无法写入暂停标记：{e}") from e
        self._pausing = True
        # ★预估等待时长：暂停在完整优化步边界生效，大 block+高 accum+慢卡时
        #   一步可达数分钟，旧实现只说「请稍候」，用户易误判卡死而强杀（审计指出）。
        #   从训练日志最近步时估算「一步 + 保存」的量级，如实告知。
        wait_txt = ""
        try:
            from . import server as SV  # noqa: PLC0415
            tl = SV.read_train_log(name)
            pts = tl.get("points") or []
            if len(pts) >= 2 and pts[-1].get("time") and pts[-2].get("time"):
                import datetime as _dt
                t1 = _dt.datetime.strptime(pts[-1]["time"], "%Y-%m-%d %H:%M:%S")
                t0 = _dt.datetime.strptime(pts[-2]["time"], "%Y-%m-%d %H:%M:%S")
                ds = pts[-1]["step"] - pts[-2]["step"]
                dt = (t1 - t0).total_seconds()
                if ds > 0 and dt > 0:
                    per_step = dt / ds
                    cfg = P.load(name)["config"]
                    save_min = max(10, int(per_step * 2))
                    wait_txt = (f"预计需等待当前步完成（约 {per_step:.0f} 秒/步）"
                                f"再加保存断点（约 {save_min} 秒起，模型越大越久）。")
        except (OSError, ValueError, KeyError, ImportError):
            pass
        msg = "已请求暂停。训练会在当前完整优化步结束后保存断点再退出。" + wait_txt
        return {"requested": True, "flag": str(flag), "message": msg}

    def cancel_pause(self, name: str) -> dict:
        """撤销尚未被消费的暂停请求。"""
        flag = P.output_dir(name) / "STOP_REQUESTED"
        removed = False
        if flag.exists():
            try:
                flag.unlink()
                removed = True
            except OSError:
                pass
        self._pausing = False
        return {"cancelled": removed}

    # ---------------- 启动 ----------------
    def start(self, name: str, from_stage: str | None = None,
              group: str | None = None, stages: list[str] | None = None,
              resume_from: str | None = None, fresh: bool = False) -> None:
        """启动流水线。

        stages: 用户勾选的任意工位组合，按标准顺序执行（优先级最高）
        group: 只跑某一组步骤（prepare/build/all_data/train/test/full）
        from_stage: 从某个工位开始跑到最后（兼容断点续训）
        resume_from: 训练时从【用户指定】的断点续训（不再永远取最新）
        fresh: 清空重训——先把旧断点归档，再从头训练（破坏性，调用方须二次确认）
        """
        with self._lock:
            if self.is_running():
                raise ValueError(f"已有项目「{self.active}」在运行。本工具为单卡设计，一次只能训练一个项目。")
            proj = P.load(name)
            st = proj["state"]
            keys = [k for k, _n, _d in P.STAGES]
            # ★本次运行的训练选项：随 _run 传入 _train，用完即清
            self._resume_from = resume_from
            self._fresh = bool(fresh)

            # ★多选优先：只认合法工位，并强制按标准顺序执行。
            #   用户勾选顺序可能是乱的，但 pack 必须在 tokenizer 之后，
            #   所以这里按 keys 的顺序重排，而不是照用户点击顺序跑。
            picked = [k for k in keys if k in set(stages or [])]
            if stages is not None and not picked:
                raise ValueError("请至少选择一个要执行的步骤")

            if picked:
                self._only = set(picked)
                for k in picked:
                    if st["stages"][k]["status"] != "done":
                        st["stages"][k] = {"status": "pending", "progress": 0.0,
                                           "message": "", "started_at": None,
                                           "finished_at": None}
                group = None
            elif group:
                g = next((x for x in STEP_GROUPS if x["key"] == group), None)
                if g is None:
                    raise ValueError(f"未知步骤分组：{group}")
                self._only = set(g["stages"])
                # 重置本组内未完成的工位；组外保持原状
                # paused 也要重置为 pending，才能继续训练
                for k in self._only:
                    if st["stages"][k]["status"] != "done":
                        st["stages"][k] = {"status": "pending", "progress": 0.0,
                                           "message": "", "started_at": None,
                                           "finished_at": None}
            else:
                self._only = None
                if from_stage:
                    if from_stage not in keys:
                        raise ValueError(f"未知工位：{from_stage}")
                    idx = keys.index(from_stage)
                    for k in keys[idx:]:
                        st["stages"][k] = {"status": "pending", "progress": 0.0,
                                           "message": "", "started_at": None,
                                           "finished_at": None}
            # ★重跑上游必须让依赖它产物的已完成下游失效。
            #   否则重训分词器后「训练/验证」仍显示完成，流程跳过它们、
            #   直接拿旧权重配新词表导出 —— 静默错位，比报错更危险。
            will_run = [k for k in (sorted(self._only, key=keys.index)
                                    if self._only else keys)
                        if st["stages"][k]["status"] in ("pending", "paused", "stale")]
            invalidate_downstream(st, will_run, "上游重跑，结果已失效")
            st["running"] = True
            st["error"] = None
            st["group"] = group
            P.save_state(name, st)
            self._stop.clear()
            self.active = name
            self._thread = threading.Thread(target=self._run, args=(name,), daemon=True)
            self._thread.start()

    def stop(self) -> None:
        """请求停止：终止当前子进程树，保留已完成的工位。"""
        self._stop.set()
        p = self._proc
        if p and p.poll() is None:
            self._kill_tree(p)
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                pass

    # ---------------- 内部 ----------------
    def _set(self, name: str, key: str, **kw) -> dict:
        st = P.load(name)["state"]
        st["stages"][key].update(kw)
        if key:
            st["current"] = key
        # ★纯进度更新节流落盘：每条进度行都整份重写 state.json 是写放大
        #   （审计指出）。进度先留内存，距上次落盘 ≥3 秒才写一次；
        #   状态/消息等关键变更立即落盘，界面状态不延迟。
        now = time.time()
        only_progress = set(kw) <= {"progress"}
        last = getattr(self, "_state_flush_at", 0.0)
        if only_progress and now - last < 3.0:
            self._pending_state = (name, st)
            return st
        P.save_state(name, st)
        self._state_flush_at = now
        self._pending_state = None
        return st

    def _flush_state(self) -> None:
        """把节流的待写状态落盘（工位结束/暂停/停止时调，保证最终态不丢）。"""
        pend = getattr(self, "_pending_state", None)
        if pend:
            try:
                P.save_state(*pend)
            except (OSError, ValueError):
                pass
            self._pending_state = None

    def _run(self, name: str) -> None:
        d = P.project_dir(name)
        try:
            cfg = P.load(name)["config"]
            for key, label, _desc in P.STAGES:
                if self._only is not None and key not in self._only:
                    continue
                if self._stop.is_set():
                    self._set(name, key, status="stopped", message="用户停止")
                    break
                st = P.load(name)["state"]
                if st["stages"][key]["status"] == "done":
                    continue
                # ★重跑先清掉上一轮的「已跳过(导入)」标记，免得正常跑完仍显示跳过
                self._set(name, key, status="running", started_at=time.time(),
                          message=f"{label}中…", skipped=False, stale=False)
                ok, msg = self._stage(name, key, cfg, d)
                if ok:
                    # ★产物大小在完成时算一次存进状态，界面直接读，
                    #   避免每次轮询都扫几十 GB 的输出目录。
                    self._set(name, key, status="done", progress=1.0,
                              finished_at=time.time(), message=msg or "完成",
                              bytes=stage_artifacts(d, key))
                elif msg == "__PAUSED__":
                    # 优雅暂停：断点已保存，不是失败
                    self._set(name, key, status="paused",
                              finished_at=time.time(),
                              message="已暂停并保存断点，可点「继续训练」接着跑")
                    s = P.load(name)["state"]
                    s["error"] = None
                    s["running"] = False
                    P.save_state(name, s)
                    return
                elif msg == "__STOPPED__":
                    # ★强制停止是用户意图，记「已停止」而非红色「失败」
                    self._set(name, key, status="stopped",
                              finished_at=time.time(), message="用户停止")
                    s = P.load(name)["state"]
                    s["error"] = None
                    s["running"] = False
                    P.save_state(name, s)
                    return
                else:
                    self._set(name, key, status="failed", message=msg)
                    s = P.load(name)["state"]
                    s["error"] = f"{label}失败：{msg}"
                    s["running"] = False
                    P.save_state(name, s)
                    return
        except Exception as e:  # noqa: BLE001 任何异常都要落到状态里，不能静默
            s = P.load(name)["state"]
            s["error"] = f"{type(e).__name__}: {e}"
            s["running"] = False
            # ★外层异常也要把当前工位标 failed：旧实现只写全局 error，
            #   工位卡在 running 直到下次重启才修（审计指出）。
            cur = s.get("current")
            if cur and cur in s.get("stages", {}):
                if s["stages"][cur].get("status") == "running":
                    s["stages"][cur]["status"] = "failed"
                    s["stages"][cur]["message"] = f"{type(e).__name__}: {e}"[:200]
                    s["stages"][cur]["finished_at"] = time.time()
            P.save_state(name, s)
        finally:
            # ★先把节流的待写进度落盘，再读最新态收尾，保证最终进度不丢。
            self._flush_state()
            s = P.load(name)["state"]
            s["running"] = False
            s["current"] = None
            P.save_state(name, s)
            self.active = None
            self._proc = None
            # ★无论正常结束/崩溃/强停，暂停标记都必须复位，
            #   否则 UI 的「暂停并保存」永远转圈禁用（_pausing 卡死）
            self._pausing = False

    # ---------------- 子进程 ----------------
    @staticmethod
    def _kill_tree(proc: subprocess.Popen) -> None:
        """终止整个进程树，而非只杀直接子进程。

        ★DataLoader worker / 分词多进程都是孙进程，只 terminate 直接子进程
          会让它们残留占内存/显存（审计指出）。Windows 用 taskkill /T，
          其它平台用进程组 killpg。
        """
        if proc.poll() is not None:
            return
        try:
            if os.name == "nt":
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                               capture_output=True, timeout=20)
            else:
                import signal  # noqa: PLC0415
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except (OSError, subprocess.SubprocessError):
            try:
                proc.kill()
            except OSError:
                pass

    def _exec(self, name: str, script: str, args: list[str], stage: str,
              d: Path, expect: Path | None = None,
              progress_cb=None, timeout: float | None = None) -> tuple[bool, str]:
        """运行引擎脚本；实时读输出更新进度；结束后校验产物。"""
        log = d / "logs" / f"{stage}.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        env = dict(os.environ)
        env["LLM_WORKSHOP_ROOT"] = str(d)
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUNBUFFERED"] = "1"
        env.setdefault("HF_ENDPOINT", "https://hf-mirror.com")

        # ★把临时文件与各类缓存全部收进项目目录，避免悄悄占用系统盘(C:)。
        #   CUDA_CACHE_PATH：GPU 内核编译缓存，训练必然产生，默认在 %APPDATA%\NVIDIA
        #   HF_HOME / TRANSFORMERS_CACHE：模型与数据集缓存，默认在 ~\.cache
        #   TMP/TEMP：Python tempfile 与部分库的落地位置
        cache = d / "cache"
        tmpd = d / "tmp"
        for p in (cache, tmpd, cache / "cuda", cache / "hf", cache / "torch", cache / "triton"):
            try:
                p.mkdir(parents=True, exist_ok=True)
            except OSError:
                pass
        # ★日志语言：默认 zh，引擎侧中文分支一字不改；
        #   只有显式选 en 时才走英文输出，保证既有中文日志完全不受影响。
        try:
            lg_lang = (P.load(name)["config"].get("log_lang") or "zh")
        except (ValueError, OSError):
            lg_lang = "zh"
        env["LLM_LOG_LANG"] = "en" if lg_lang == "en" else "zh"
        env["LLM_WORKSHOP_TMP"] = str(tmpd)
        env["TMP"] = str(tmpd)
        env["TEMP"] = str(tmpd)
        env["TMPDIR"] = str(tmpd)
        env["CUDA_CACHE_PATH"] = str(cache / "cuda")
        env["HF_HOME"] = str(cache / "hf")
        env["HUGGINGFACE_HUB_CACHE"] = str(cache / "hf" / "hub")
        env["TRANSFORMERS_CACHE"] = str(cache / "hf" / "transformers")
        env["TORCH_HOME"] = str(cache / "torch")
        env["TRITON_CACHE_DIR"] = str(cache / "triton")
        env["XDG_CACHE_HOME"] = str(cache)
        py = PA.engine_python()
        if not py:
            return False, ("未找到可用的 Python 训练环境。请在「环境」页按指引安装依赖，"
                           "或手动指定 python.exe 后重试")
        cmd = [py, "-u", str(ENGINE / script), *args]
        tail: list[str] = []
        t0 = time.time()
        # ★长跑日志轮转：数月训练会让单个日志涨到几百 MB。
        #   超过 64MB 时滚动 .1→.2→.3，保留最近 3 份（旧实现只留 1 份，
        #   早期日志直接被顶掉不可追溯，审计指出），再老才删，避免撑爆磁盘。
        try:
            if log.exists() and log.stat().st_size > 64 * 1024 ** 2:
                for k in (3, 2, 1):
                    src = log.with_suffix(log.suffix + f".{k}")
                    dst = log.with_suffix(log.suffix + f".{k + 1}")
                    if k == 3:
                        if src.exists():
                            src.unlink()
                    elif src.exists():
                        if dst.exists():
                            dst.unlink()
                        src.rename(dst)
                log.rename(log.with_suffix(log.suffix + ".1"))
        except OSError:
            pass
        with log.open("a", encoding="utf-8") as lf:
            lf.write(f"\n===== {stage} START {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n")
            lf.write("CMD: " + " ".join(cmd) + "\n")
            lf.flush()
            try:
                # ★Windows 用新进程组：便于 taskkill /T 整树终止；
                #   POSIX 用 start_new_session 建独立进程组供 killpg。
                popen_kw = {}
                if os.name == "nt":
                    popen_kw["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
                else:
                    popen_kw["start_new_session"] = True
                self._proc = subprocess.Popen(
                    cmd, cwd=str(d), env=env, stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                    errors="replace", bufsize=1, **popen_kw,
                )
            except OSError as e:
                return False, f"无法启动引擎：{e}"
            proc = self._proc
            assert proc.stdout is not None
            # ★停止竞态修复：stop() 只杀当时的 _proc；若请求恰落在两个子进程
            #   之间，新进程要等首行输出才被杀，模型加载等静默期停不掉。
            #   启动后立即复查一次。
            if self._stop.is_set():
                self._kill_tree(proc)
                return False, "__STOPPED__"
            # ★静默挂起看门狗：旧实现 for line in stdout 是阻塞读，引擎若
            #   静默挂死（网络/IO/驱动），循环永远不转，停止与超时检查全都
            #   落空，工位永久「运行中」。改为后台线程读行入队，主循环带
            #   超时取行：每秒都能复查停止/超时；连续 30 分钟无任何输出且
            #   进程仍活着，判为挂起并终止（正常训练 log_every 必有心跳）。
            import queue as _queue  # noqa: PLC0415
            import threading as _threading  # noqa: PLC0415
            q: _queue.Queue = _queue.Queue()
            _SENTINEL = object()

            def _reader():
                try:
                    for ln in proc.stdout:
                        q.put(ln)
                except (OSError, ValueError):
                    pass
                finally:
                    q.put(_SENTINEL)

            _threading.Thread(target=_reader, daemon=True).start()
            last_out = time.time()
            SILENT_LIMIT = 1800.0
            ended = False
            while not ended:
                try:
                    line = q.get(timeout=1.0)
                except _queue.Empty:
                    if self._stop.is_set():
                        self._kill_tree(proc)
                        return False, "__STOPPED__"
                    if timeout and time.time() - t0 > timeout:
                        self._kill_tree(proc)
                        return False, f"超时（>{timeout:.0f}秒）"
                    if proc.poll() is None and time.time() - last_out > SILENT_LIMIT:
                        self._kill_tree(proc)
                        return False, "引擎长时间无输出（疑似挂起），已终止。请查看日志后重跑"
                    continue
                if line is _SENTINEL:
                    ended = True
                    break
                last_out = time.time()
                # ★@@WS 标记行是给调度器解析的结构化数据，不进日志不进尾窗，
                #   避免污染用户可见日志；只用于更新进度。
                if line.lstrip().startswith("@@WS"):
                    if progress_cb:
                        pr, msg = progress_cb(line)
                        if pr is not None:
                            self._set(name, stage, progress=pr, message=msg or "")
                    continue
                lf.write(line)
                lf.flush()
                tail.append(line.rstrip())
                if len(tail) > 40:
                    tail.pop(0)
                if progress_cb:
                    pr, msg = progress_cb(line)
                    if pr is not None:
                        self._set(name, stage, progress=pr, message=msg or "")
                if self._stop.is_set():
                    self._kill_tree(proc)
                    return False, "__STOPPED__"
                if timeout and time.time() - t0 > timeout:
                    self._kill_tree(proc)
                    return False, f"超时（>{timeout:.0f}秒）"
            code = proc.wait()
            lf.write(f"===== {stage} EXIT {code} =====\n")
        if self._stop.is_set():
            return False, "__STOPPED__"
        # 131 = 优雅暂停（已保存断点），130 = Ctrl+C 中断（也已保存）
        if code in (130, 131):
            self._pausing = False
            self._paused_code = code
            return False, "__PAUSED__"
        # ★4 = 预算已用尽（0 新增步）：不是失败也不是完成，明确提示追加预算，
        #   绝不拿旧 final 冒充本次训练成果（三份审计一致指出）。
        if code == 4:
            return False, ("预算已用尽：断点已达目标步数，本次没有新增训练。"
                           "请在项目配置提高 token 预算/步数后再「继续训练」，或「清空重训」。")
        # ★5 = CUDA OOM：引擎已给降档建议，这里汇总成可操作提示。
        if code == 5:
            return False, ("显存不足（CUDA OOM），训练中止。最近断点完好可续训。"
                           "请减小批大小或上下文、确认开启梯度检查点，或换更小档位后重试。")
        if code != 0:
            reason = next((l for l in reversed(tail)
                           if re.search(r"Error|error|Traceback|\[!\]", l)), None)
            return False, reason or f"退出码 {code}（详见日志）"
        # 铁律1：产物必须落盘
        if expect is not None and not expect.exists():
            return False, f"脚本正常退出但产物缺失：{expect.name}"
        return True, tail[-1][:200] if tail else "完成"

    # ---------------- 导入已有产物 ----------------
    def _src(self, cfg: dict, key: str) -> dict | None:
        """取某工位的导入设置；未设为 import 则返回 None（走自己生成）。"""
        s = (cfg.get("sources") or {}).get(key) or {}
        if s.get("mode") == "import" and (s.get("path") or "").strip():
            return s
        return None

    def _mark_imported(self, name: str, key: str, raw: str, info: dict) -> None:
        """把导入来源记进状态，便于日后追溯这个模型接的是谁的权重。"""
        st = P.load(name)["state"]
        st.setdefault("imports", {})[key] = IM.record(key, raw, info)
        P.save_state(name, st)

    def _import_stage(self, name: str, key: str, cfg: dict, d: Path):
        """尝试用已有产物完成该工位。返回 (handled, ok, msg)。

        handled=False 表示该工位没设导入，调用方继续走正常生成流程。
        """
        s = self._src(cfg, key)
        if s is None:
            return False, False, ""
        raw = s["path"]
        v = IM.validate(key, raw)
        if not v["ok"]:
            return True, False, "导入失败：" + "；".join(v["problems"])
        info = v["info"]
        real = info.get("path", raw)

        # ★用户用自己的文件顶替本工位 = 跳过生成，记标记供界面换色显示「已跳过」
        self._set(name, key, skipped=True)

        if key in ("adapt", "clean"):
            # 语料类：复制到工位期望的位置，让后续步骤照常读取
            fn = "raw_0.jsonl" if key == "adapt" else "clean_0.jsonl"
            ok, msg = IM.use_file(key, real, d / "data" / fn)
            if not ok:
                return True, False, msg
            if key == "clean":
                # 合并文件供词表训练使用；单条导入时它就是全部。原子替换。
                merged = d / "data" / "cleaned_corpus.jsonl"
                tmp = merged.with_name(f".cleaned_corpus.tmp-{os.getpid()}")
                try:
                    shutil.copy2(d / "data" / fn, tmp)
                    tmp.replace(merged)
                except OSError as e:
                    return True, False, f"生成合并语料失败：{e}"
            self._mark_imported(name, key, real, info)
            return True, True, "已导入：" + msg

        if key == "tokenizer":
            ok, msg = IM.use_tokenizer(real, d / "tokenizer")
            if not ok:
                return True, False, msg
            self._mark_imported(name, key, real, info)
            return True, True, msg

        if key in ("pack", "mix"):
            # ★token 流可能几十 GB：默认引用，不复制
            dst = d / "data" / ("packed_0" if key == "pack" else "final")
            ok, msg, ref = IM.link_or_copy_dir(Path(real), dst)
            if not ok:
                return True, False, msg
            wc = IM.vocab_conflict(info.get("vocab_size"), cfg.get("vocab_size"))
            if wc:
                self._set(name, key, message="⚠ " + wc)
            self._mark_imported(name, key, real, dict(info, referenced=ref))
            extra = f"，{info.get('train_tokens', 0):,} token" if info.get("train_tokens") else ""
            return True, True, msg + extra

        if key in ("train", "test"):
            # 模型类不复制：只把路径记下来，训练/验证时直接用
            self._mark_imported(name, key, real, info)
            gs = info.get("global_step")
            extra = f"，从第 {gs:,} 步接上" if gs else ""
            if key == "train" and not info.get("has_optimizer"):
                extra += "（仅继承权重）"
            return True, True, f"已选用已有模型{extra}"

        return False, False, ""

    # ---------------- 各工位 ----------------
    def _stage(self, name: str, key: str, cfg: dict, d: Path) -> tuple[bool, str]:
        # 先看该工位是否要用已有产物。train/test/sft/lora/export 例外：它们仍需
        # 真正执行，只是把模型来源换成导入路径，故在下面各自处理。
        if key not in ("train", "test", "sft", "lora", "export"):
            handled, ok, msg = self._import_stage(name, key, cfg, d)
            if handled:
                return ok, msg
        if key == "adapt":
            return self._adapt(name, cfg, d)
        if key == "clean":
            return self._clean(name, cfg, d)
        if key == "tokenizer":
            return self._tokenizer(name, cfg, d)
        if key == "pack":
            return self._pack(name, cfg, d)
        if key == "mix":
            return self._mix(name, cfg, d)
        if key == "train":
            return self._train(name, cfg, d, resume_from=self._resume_from,
                               fresh=self._fresh)
        if key == "test":
            return self._test(name, cfg, d)
        if key == "sft":
            return self._sft(name, cfg, d)
        if key == "lora":
            return self._lora(name, cfg, d)
        if key == "export":
            return self._export(name, cfg, d)
        return False, f"未实现的工位 {key}"

    @staticmethod
    def _corpus_files(entry: dict) -> list[Path]:
        # ★容忍资源管理器「复制文件地址」带的首尾引号（用户实测带引号路径被判不存在）
        p = Path((entry.get("path", "") or "").strip().strip('"').strip("'"))
        if not p.exists():
            return []
        if p.is_file():
            return [p]
        # ★文件夹递归抓取要过滤非语料文件：旧实现 rglob 一切同后缀文件，
        #   会把目录里的配置 json、旧清洗产物、下载残留也吞进训练（审计指出）。
        #   排除明显的产物/配置命名与隐藏目录；新增 .txt 纯文本支持。
        exclude_names = {"data_meta.json", "config.json", "state.json",
                         "tokenizer.json", "tokenizer_config.json",
                         "special_tokens_map.json", "generation_config.json",
                         "cleaned_corpus.jsonl", "manifest.json", "package.json"}
        out = []
        for x in sorted(p.rglob("*")):
            if not x.is_file():
                continue
            if x.suffix not in (".jsonl", ".json", ".parquet", ".gz", ".txt"):
                continue
            if x.name in exclude_names or x.name.startswith("."):
                continue
            if any(part in ("tokenizer", "packed_0", "final", "output", "cache", "tmp")
                   for part in x.relative_to(p).parts[:-1]):
                continue
            out.append(x)
        return out

    def _entries(self, cfg: dict) -> list[dict]:
        # ★纯清洗导入也算有效语料条目：旧实现只认原始 path，
        #   只填 clean_import 的项目会被判「未配置语料」，混合场景下
        #   纯导入条目被整体丢弃（审计指出）。前端允许只填 clean_import，
        #   后端必须同样接受，否则承诺的导入流程走不通。
        return [e for e in (cfg.get("corpus") or [])
                if (e.get("path") or "").strip() or (e.get("clean_import") or "").strip()]

    def _adapt(self, name, cfg, d):
        """按语料条目分别适配：每类用自己的字段提取器，产物分开存放。

        ★auto 类型按内容抽样自动判定；识别失败/结果为空不再整体报错，
          转「其他」并提示用户自设类型与清洗参数（用户要求）。
        """
        entries = self._entries(cfg)
        if not entries:
            return False, "未配置语料。请在「语料」里添加本地文件或文件夹路径"
        # ★磁盘预检：识别产物 raw_i 约为语料体积的 1.3 倍（48GB 语料实产
        #   61GB）。旧实现无预检，跑到一半磁盘写满才失败，几十 GB 半成品
        #   白占盘。这里按语料总体积估算，不足直接拦下。
        src_bytes = 0
        for e in entries:
            if (e.get("clean_import") or "").strip():
                continue
            for f in self._corpus_files(e):
                try:
                    src_bytes += f.stat().st_size
                except OSError:
                    pass
        need = int(src_bytes * 1.4) + 2 * 1024 ** 3
        free = shutil.disk_usage(str(d)).free
        if src_bytes and free < need:
            return False, (f"磁盘空间不足：识别约需 {need / 1024 ** 3:.1f}GB，"
                           f"剩余 {free / 1024 ** 3:.1f}GB。请清理磁盘或把项目放到更大的盘")
        total_mb = 0.0
        warns: list[str] = []
        changed = False
        for i, e in enumerate(entries):
            if self._stop.is_set():
                # ★返回 __STOPPED__ 而非中文串：调度器只认标记，旧实现
                #   走 failed 分支记红色错误，用户停止被当成失败
                return False, "__STOPPED__"
            # 该类若直接提供已清洗文件，则无需识别字段
            if (e.get("clean_import") or "").strip():
                self._set(name, "adapt", progress=(i + 1) / len(entries),
                          message=f"第{i + 1}类将用已清洗文件")
                continue
            kind = e.get("kind", "auto")
            files = self._corpus_files(e)
            if not files:
                e["kind"], e["kind_name"] = "other", ""
                changed = True
                warns.append(f"第{i + 1}类路径无可用语料文件，已转为「其他」，请检查路径并自设清洗参数")
                self._set(name, "adapt", progress=(i + 1) / len(entries),
                          message=f"第{i + 1}类已转「其他」")
                continue
            # ★auto：按内容抽样判类型，写回配置，后续清洗自动用对应预设
            if kind == "auto":
                dk, conf = detect_kind(files[0])
                e["kind"] = kind = dk
                changed = True
                warns.append(f"第{i + 1}类自动判定为「{KIND_MAP[dk]['name']}」（置信 {conf:.0%}），可在语料列表改类型")
            ex = KIND_MAP.get(kind, KIND_MAP["auto"])["extractor"]
            out = d / "data" / f"raw_{i}.jsonl"
            args = ["--src", *[str(f) for f in files], "--dst", str(out), "--kind", ex]

            def cb(line, i=i, n=len(entries)):
                # ★引擎实际打印「已写出」，旧正则找「已处理」永远落空；
                #   现统一认语言无关标记 @@WS processed N。
                m = re.search(r"@@WS processed (\d+)", line)
                if m:
                    return (i + 0.5) / n, f"第{i + 1}类 已识别 {int(m.group(1)):,} 条"
                return None, None

            ok, msg = self._exec(name, "adapt_corpus.py", args, "adapt", d,
                                 expect=out, progress_cb=cb)
            if not ok or out.stat().st_size == 0:
                e["kind"], e["kind_name"] = "other", ""
                changed = True
                reason = msg if not ok else "字段无法识别，结果为空"
                warns.append(f"第{i + 1}类识别失败（{reason}），已转为「其他」，请自设类型名称与清洗参数后重跑")
                self._set(name, "adapt", progress=(i + 1) / len(entries),
                          message=f"第{i + 1}类识别失败，已转「其他」")
                continue
            total_mb += out.stat().st_size / 1024 ** 2
            self._set(name, "adapt", progress=(i + 1) / len(entries),
                      message=f"{i + 1}/{len(entries)} 类已识别")
        if changed:
            # ★运行中写回自己的识别结果，必须走 internal 通道：
            #   普通 save_config 见 running 就拒绝，旧实现让识别工位
            #   跑到最后自抛「项目正在运行」整个 failed（用户实测）
            P.save_config(name, {"corpus": cfg.get("corpus") or []}, internal=True)
        self._set(name, "adapt", warnings=warns)
        return True, f"{len(entries)} 类语料共产出 {total_mb:.1f}MB" + (f"（{len(warns)} 条提示）" if warns else "")

    def _clean(self, name, cfg, d):
        """按语料类型分别清洗：各类用各自适配的阈值，避免一刀切误杀。"""
        entries = self._entries(cfg)
        # ★纯导入衔接：corpus 为空但已有 adapt 产物（raw_i）或导入的 clean_i
        #   时，按实际产物推导条目，而非判「未配置语料」或合并出 0 字节假成功
        #   （审计复现）。让纯导入项目也能走完后续工位。
        if not entries:
            derived = []
            i = 0
            while (d / "data" / f"raw_{i}.jsonl").exists() or (d / "data" / f"clean_{i}.jsonl").exists():
                derived.append({"kind": "auto"})
                i += 1
            if derived:
                entries = derived
            else:
                return False, "未配置语料，也没有可清洗的识别产物。请先添加语料或执行「识别字段」"
        # ★磁盘预检：清洗产物 clean_i 与合并文件 cleaned.jsonl 合计约为
        #   raw 的 2 倍（_merge_cleaned 保留分片又复制一份）。旧实现无预检，
        #   几十 GB 写到一半磁盘满才失败。按 raw 体积估算，不足提前拦下。
        raw_bytes = 0
        for i in range(len(entries)):
            rp = d / "data" / f"raw_{i}.jsonl"
            if rp.exists():
                raw_bytes += rp.stat().st_size
        if raw_bytes:
            need = raw_bytes * 2 + 2 * 1024 ** 3
            free = shutil.disk_usage(str(d)).free
            if free < need:
                return False, (f"磁盘空间不足：清洗约需 {need / 1024 ** 3:.1f}GB，"
                               f"剩余 {free / 1024 ** 3:.1f}GB。请清理磁盘或把项目放到更大的盘")
        # ★每条语料可单独导入已清洗文件：该类跳过识别与清洗，其余照常处理。
        imported_idx = set()
        kept_info = []
        total_mb = 0.0
        warns: list[dict] = []
        for i, e in enumerate(entries):
            raw = (e.get("clean_import") or "").strip()
            if not raw:
                continue
            v = IM.validate("clean", raw)
            if not v["ok"]:
                return False, f"第{i + 1}类导入失败：" + "；".join(v["problems"])
            ok, msg = IM.use_file("clean", v["info"].get("path", raw),
                                  d / "data" / f"clean_{i}.jsonl")
            if not ok:
                return False, f"第{i + 1}类：{msg}"
            imported_idx.add(i)
            mb = (d / "data" / f"clean_{i}.jsonl").stat().st_size / 1024 ** 2
            total_mb += mb
            kn = KIND_MAP.get(e.get("kind", "auto"), {}).get("name", e.get("kind", "auto"))
            kept_info.append(f"{kn} {mb:.0f}MB(导入)")
            self._mark_imported(name, f"clean_{i}", raw, v["info"])
        if imported_idx and len(imported_idx) == len(entries):
            _merge_cleaned(d, len(entries))
            _write_data_card(d, cfg, entries)
            self._set(name, "clean", progress=1.0, message="全部语料已导入")
            return True, f"已导入清洗语料：{'、'.join(kept_info)}"
        level = cfg.get("clean_level", "standard")
        for i, e in enumerate(entries):
            if i in imported_idx:
                continue
            if self._stop.is_set():
                return False, "__STOPPED__"
            kind = e.get("kind", "auto")
            # ★「其他」类型无预设：必须自设参数，否则拦下提示（不静默放行）。
            #   放在产物检查之前，提示更直接。
            if kind == "other" and not (e.get("clean_custom") or {}):
                return False, (f"第{i + 1}类类型为「其他」，没有预设清洗参数。"
                               "请在清洗面板为该语料设置清洗参数（或改选预设类型）后重跑")
            src = d / "data" / f"raw_{i}.jsonl"
            dst = d / "data" / f"clean_{i}.jsonl"
            # ★已有清洗产物（上次导入/清洗留下）且无原始 raw 时直接沿用，
            #   不报「缺适配产物」，让纯导入/混合来源项目走通（审计指出）。
            if not src.exists():
                if dst.exists() and dst.stat().st_size > 0:
                    mb = dst.stat().st_size / 1024 ** 2
                    total_mb += mb
                    kept_info.append(f"{KIND_MAP.get(kind, {}).get('name', kind)} {mb:.0f}MB(沿用)")
                    continue
                return False, f"缺少第{i + 1}类的适配产物，请先执行「识别字段」"
            # 每条语料可单独设强度；未设则用全局默认。
            # ★全局强度微调（clean_level_adjust）叠在类型预设×档位上，
            #   各类按自身基线联动；单条自定义最优先（clean_params 内处理）。
            lv_i = e.get("clean_level") or level
            cp = clean_params(kind, lv_i, e.get("clean_custom"),
                              cfg.get("clean_level_adjust"),
                              cfg.get("clean_values"))
            args = ["--src", str(src), "--dst", str(dst),
                    "--min-cjk-ratio", str(cp["min_cjk_ratio"]),
                    "--max-repeat-ratio", str(cp["max_repeat_ratio"]),
                    "--max-symbol-ratio", str(cp["max_symbol_ratio"]),
                    "--min-chars", str(cp["min_chars"]),
                    "--workers", str(min(8, os.cpu_count() or 4)),
                    "--dedup", e.get("dedup") or "bloom", "--progress-every", "50000"]
            # 以下为用户可选的进阶项，仅在填写时传入
            for key, flag in (("max_chars", "--max-chars"),
                              ("max_digit_ratio", "--max-digit-ratio"),
                              ("max_top_char_ratio", "--max-top-char-ratio")):
                if key in cp:
                    args += [flag, str(cp[key])]
            # ★代码语料保护预设：代码里的 <stdio.h>/vector<int>/JSX 会被当
            #   HTML 标签删掉，URL/NFKC/中文空格压缩也会改坏代码（审计指出）。
            #   code 类默认关闭这些破坏性规则；用户显式设置可覆盖。
            is_code = kind == "code"
            strip_html = e.get("strip_html", False if is_code else True)
            strip_urls = e.get("strip_urls", False if is_code else True)
            nfkc = e.get("nfkc", False if is_code else True)
            compact_cjk = e.get("compact_cjk", False if is_code else True)
            if strip_html is False:
                args.append("--no-strip-html")
            if strip_urls is False:
                args.append("--no-strip-urls")
            if nfkc is False:
                args.append("--no-nfkc")
            if compact_cjk is False:
                args.append("--no-compact-cjk")
            # ★近重复/脱敏开关（项目级配置，默认关）
            if cfg.get("near_dup"):
                args.append("--near-dup")
                args += ["--near-dup-threshold", str(cfg.get("near_dup_threshold", 0.8))]
            if cfg.get("pii"):
                args.append("--pii")

            def cb(line, i=i, n=len(entries)):
                # ★引擎实际打印「已保留」，旧正则找「已处理」永远落空导致进度恒 0；
                #   现统一认语言无关标记 @@WS kept N。
                m = re.search(r"@@WS kept (\d+)", line)
                if m:
                    return (i + 0.5) / n, f"第{i + 1}类 已清洗 {int(m.group(1)):,} 条"
                return None, None

            ok, msg = self._exec(name, "clean_data.py", args, "clean", d,
                                 expect=dst, progress_cb=cb)
            if not ok:
                return False, f"第{i + 1}类清洗失败：{msg}"
            kname = KIND_MAP.get(kind, {}).get("name", kind)
            if dst.stat().st_size == 0:
                return False, (f"「{kname}」清洗后无数据。该类阈值："
                               f"中文占比≥{cp['min_cjk_ratio']}、重复率≤{cp['max_repeat_ratio']}。"
                               "请把强度改为「宽松」，或确认语料类型选对了")
            mb = dst.stat().st_size / 1024 ** 2
            total_mb += mb
            kept_info.append(f"{kname} {mb:.0f}MB")
            # ★数据量警告：清洗引擎会打印「输入行数/保留」，据此算保留率。
            #   保留率过低 = 阈值误杀或类型选错；产出过小 = 语料本身太少。
            logp = d / "logs" / "clean.log"
            kept = tin = None
            if logp.exists():
                try:
                    # 流式只留尾部，避免整读长跑大日志
                    from collections import deque
                    tail = deque(maxlen=400)
                    with logp.open(encoding="utf-8", errors="replace") as f:
                        for ln in f:
                            tail.append(ln.rstrip("\n"))
                    # ★优先认语言无关标记（@@WS kept_total / @@WS input）：
                    #   旧实现靠中文前缀「保留/输入行数」解析，日志选英文时
                    #   前缀变 Kept/Input lines，告警会静默消失。
                    #   标记缺失（旧日志）时退回中文前缀兼容。
                    for ln in reversed(tail):
                        if kept is None:
                            m = re.search(r"@@WS kept_total (\d+)", ln)
                            if m:
                                kept = int(m.group(1))
                            elif ln.startswith("保留"):
                                m = re.search(r":\s*([\d,]+)", ln)
                                if m:
                                    kept = int(m.group(1).replace(",", ""))
                        if tin is None:
                            m = re.search(r"@@WS input (\d+)", ln)
                            if m:
                                tin = int(m.group(1))
                            elif ln.startswith("输入行数"):
                                m = re.search(r":\s*([\d,]+)", ln)
                                if m:
                                    tin = int(m.group(1).replace(",", ""))
                        if kept is not None and tin is not None:
                            break
                except OSError:
                    pass
            if kept is not None and tin:
                rate = kept / tin
                # ★保留率封顶 100%：长文拆段(split_long)会让输出条数略多于输入，
                #   真实「保留」不可能超 100%，界面不显示 >100% 的百分比（用户要求）。
                disp = min(rate, 1.0)
                # ★按语料类型判断：不同类型的合理保留率天然不同——
                #   网页噪声多可滤大半；百科/书籍本来就干净，留得太少才是问题；
                #   代码/古籍格式特殊，留得少不一定是误杀。区间见 CLEAN_KEEP_RANGE。
                lo, hi = CLEAN_KEEP_RANGE.get(kind, CLEAN_KEEP_RANGE["auto"])
                band = f"{lo:.0%}~{hi:.0%}"
                if rate < lo / 4:
                    warns.append(_p("pipe.cleanDropHigh", n=kname,
                                    r=f"{disp:.1%}", t=tin, k=kept, b=band))
                elif rate < lo:
                    warns.append(_p("pipe.cleanDropMed", n=kname,
                                    r=f"{disp:.1%}", b=band))
                elif hi < 1.0 and rate > hi and tin >= 1000:
                    # ★保留太多也要提示：几乎没滤掉东西，可能是强度太松、
                    #   类型选错（如把网页当百科），或该源本身极干净。
                    #   上限=100% 的类型（预过滤网页/百科/书籍）留满属正常，不提醒。
                    warns.append(_p("pipe.cleanKeepHigh", n=kname,
                                    r=f"{disp:.1%}", b=band))
            if kept is not None and kept < 1000:
                warns.append(_p("pipe.cleanTooFew", n=kname, k=kept))
            self._set(name, "clean", progress=(i + 1) / len(entries),
                      message=f"{i + 1}/{len(entries)} 类已清洗")
        # 合并供后续词表训练使用（原子替换，避免半截语料）
        _merge_cleaned(d, len(entries))
        _write_data_card(d, cfg, entries)
        self._set(name, "clean", warnings=warns)
        return True, f"清洗完成：{'、'.join(kept_info)}"

    def _tokenizer(self, name, cfg, d):
        src = d / "data" / "cleaned_corpus.jsonl"
        out = d / "tokenizer"
        args = ["--src", str(src), "--out-dir", str(out),
                "--vocab-size", str(int(cfg.get("vocab_size") or 32000)),
                "--sample-lines", "300000"]
        # ★默认产出普通文本 LLM 词表（只含 5 个基础标记）。
        #   仅当项目显式开启 multimodal_tokens 时才追加音频/谱面控制符，
        #   供第二阶段多模态训练使用。旧项目未设该字段 → 走默认纯文本。
        if cfg.get("multimodal_tokens"):
            args.append("--multimodal")
        # ★用户自定义特殊标记：任何领域都能加自己的控制符，不必改源码
        extra = (cfg.get("extra_special") or "").strip()
        if extra:
            args += ["--extra-special", extra]

        # ★词表工位此前没有进度上报，进度条会一直停在 0% 直到突然完成。
        #   现在解析脚本输出的阶段进度（准备语料 5% → 就绪 25% → BPE 完成 80%
        #   → 校验 95%），让这一条也有真实进度。
        def cb(line):
            m = re.search(r"\[progress\]\s*(\d+)%\s*(.*)", line)
            if m:
                return min(0.99, int(m.group(1)) / 100.0), (m.group(2) or "").strip()
            m2 = re.search(r"语料总行数\s*([\d,]+).*?参与训练\s*([\d,]+)", line)
            if m2:
                return 0.2, f"抽样 {m2.group(2)} / {m2.group(1)} 行"
            return None, None

        ok, msg = self._exec(name, "train_tokenizer.py", args, "tokenizer", d,
                             expect=out / "tokenizer.json", progress_cb=cb)
        return (True, "词表已生成") if ok else (False, msg)

    def _pack(self, name, cfg, d):
        """按类分别打包，产物分开存放，供整合阶段按权重混合。"""
        entries = self._entries(cfg)
        # ★纯导入衔接：corpus 为空但已有 clean_i 产物时按实际产物推导条目，
        #   而非空循环返回「合计约 0 token」假成功（审计复现）。
        if not entries:
            i = 0
            while (d / "data" / f"clean_{i}.jsonl").exists():
                entries.append({"kind": "auto"})
                i += 1
            if not entries:
                return False, "没有可打包的清洗产物，请先执行「清洗」或导入已清洗语料"
        tok = d / "tokenizer"
        if not (tok / "tokenizer.json").exists():
            return False, "缺少词表，请先执行「训练词表」或在该步导入已有词表"
        total_need = 0
        for i in range(len(entries)):
            p = d / "data" / f"clean_{i}.jsonl"
            if p.exists():
                total_need += p.stat().st_size
        free = shutil.disk_usage(str(d)).free
        need = total_need + 2 * 1024 ** 3
        if free < need:
            return False, (f"磁盘空间不足：约需 {need / 1024 ** 3:.1f}GB，"
                           f"剩余 {free / 1024 ** 3:.1f}GB")
        total_tok = 0
        for i, e in enumerate(entries):
            if self._stop.is_set():
                return False, "__STOPPED__"
            src = d / "data" / f"clean_{i}.jsonl"
            if not src.exists():
                return False, f"缺少第{i + 1}类清洗产物，请先执行「清洗」"
            out = d / "data" / f"packed_{i}"
            # ★写穿防护：packed_i 若是指向外部原始目录的联接（上次导入建的），
            #   先解链再写，让本次自动生成落在项目内真实目录，绝不改写外部数据。
            if IM.unlink_if_link(out):
                self._set(name, "pack", message=f"第{i + 1}类：已解除外部引用，改为项目内生成")
            args = ["--src", str(src), "--tokenizer", str(tok), "--out-dir", str(out),
                    "--workers", str(max(1, min(8, (os.cpu_count() or 4) - 2))),
                    "--progress-every", "50000"]
            if cfg.get("val_by_hash"):
                args.append("--val-by-hash")

            def cb(line, i=i, n=len(entries)):
                m = re.search(r"@@WS processed (\d+)", line)
                if m:
                    return (i + 0.5) / n, f"第{i + 1}类 已打包 {int(m.group(1)):,} 条"
                return None, None

            ok, msg = self._exec(name, "prepare_data.py", args, "pack", d,
                                 expect=out / "data_meta.json", progress_cb=cb)
            if not ok:
                return False, f"第{i + 1}类打包失败：{msg}"
            m = json.loads((out / "data_meta.json").read_text(encoding="utf-8"))
            total_tok += int(m.get("train_tokens", 0))
            self._set(name, "pack", progress=(i + 1) / len(entries),
                      message=f"{i + 1}/{len(entries)} 类已打包")
        return True, f"打包完成，合计约 {total_tok:,} token"

    def _mix(self, name, cfg, d):
        """整合：单类直接采用；多类调用引擎按权重混合。"""
        from . import hardware as H  # noqa: PLC0415
        entries = self._entries(cfg)
        final = d / "data" / "final"
        # ★打包步骤若为引用导入，final 可能已是指向别处的联接，
        #   此时绝不能再往里写，否则会污染用户的原始数据目录。
        if self._src(cfg, "pack") and (final / "data_meta.json").exists():
            meta = json.loads((final / "data_meta.json").read_text(encoding="utf-8"))
            total = int(meta.get("train_tokens", 0))
            if total <= 0:
                return False, "导入的训练集 token 为 0"
            self._set(name, "mix", progress=1.0, message=f"沿用导入数据 {_fmt_tok(total)} token",
                      warnings=self._mix_warns(cfg, total))
            return True, f"沿用已导入的训练集，{_fmt_tok(total)} token"
        final.mkdir(parents=True, exist_ok=True)
        # ★按实际 packed_i 产物收集，不依赖 corpus 条目数：纯 pack 导入
        #   （corpus 为空）时 packed_0 联接已存在，旧实现按 entries 找不到
        #   就报「没有打包产物」（审计复现）。扫到几个就用几个。
        packs = []
        i = 0
        while True:
            pk = d / "data" / f"packed_{i}"
            if not (pk / "data_meta.json").exists():
                break
            e = entries[i] if i < len(entries) else {"kind": "auto"}
            packs.append((i, e, pk))
            i += 1
        if not packs:
            return False, "没有打包产物，请先执行「打包」或导入已打包数据"

        if len(packs) == 1:
            # ★变量名绝不能叫 p：会遮蔽模块级翻译函数 _p()，多类分支再调
            #   _p(...) 就 TypeError: WindowsPath not callable（本次全链路实测抓到）。
            _i, _e, pk = packs[0]
            # ★单类无需混合，直接引用 packed 目录（不复制几十 GB）。
            #   写穿防护：final 若是旧联接先解链（只删链接不删目标）；
            #   整目录原子替换，绝不向旧 final 逐文件覆盖（会留旧分片残留、
            #   非原子，审计指出）。引用建在项目内，外部原始目录始终只读。
            if pk.resolve() != final.resolve():
                IM.unlink_if_link(final)
                if final.exists():
                    # 旧的真实目录：先挪走再建新引用，失败可回退
                    old = final.with_name(f"final.old-{os.getpid()}")
                    if old.exists():
                        shutil.rmtree(old, ignore_errors=True)
                    final.rename(old)
                    try:
                        ok, msg, _ref = IM.link_or_copy_dir(pk, final)
                        if not ok:
                            old.rename(final)      # 回退，保住旧产物
                            return False, msg
                        shutil.rmtree(old, ignore_errors=True)
                    except OSError:
                        if old.exists() and not final.exists():
                            old.rename(final)
                        raise
                else:
                    ok, msg, _ref = IM.link_or_copy_dir(pk, final)
                    if not ok:
                        return False, msg
            meta = json.loads((final / "data_meta.json").read_text(encoding="utf-8"))
            total = int(meta.get("train_tokens", 0))
            if total <= 0:
                return False, "训练集 token 为 0"
            self._set(name, "mix", progress=1.0, message=f"就绪 {_fmt_tok(total)} token",
                      warnings=self._mix_warns(cfg, total))
            return True, f"训练集 {_fmt_tok(total)} token"

        # 多类：用户可用百分比自由指定占比（sum 不必等于100，会自动归一化）；
        # 也可用 weight 相对权重。percent 优先。
        # ★全混合（mix_all，用户要求）：按各类实际 token 量成比例，用完全部数据，
        #   不受 weight/percent/max_tokens 截断——等权重下小类撑不起份额会白白
        #   丢掉大类数据，全混合避免这种浪费，配比=自然分布。
        counts = []
        for (_i, _e, pk) in packs:
            m = json.loads((pk / "data_meta.json").read_text(encoding="utf-8"))
            counts.append(int(m.get("train_tokens", 0)))
        avail_total = sum(counts)
        if cfg.get("mix_all"):
            weights = [float(c) for c in counts]
            s = sum(weights)
            if s <= 0:
                weights = [1.0] * len(packs); s = float(len(packs))
            ratios = [w / s for w in weights]
            # ★总量上限（用户要求）：全混合也可设 max_tokens 整体缩量，
            #   各类按原比例等比缩放（占比不变），留空/0 = 用完全部。
            want_all = int(cfg.get("max_tokens") or 0)
            target = min(want_all, avail_total) if want_all > 0 else avail_total
        else:
            weights = []
            for _i, e, _pk in packs:
                pv = e.get("percent")
                if pv is not None and pv != "":
                    try:
                        weights.append(max(0.0, float(pv)))
                        continue
                    except (TypeError, ValueError):
                        pass
                # ★weight=0 是合法意图（该类不参与混合）：旧实现 `or 1.0` 把 0
                #   吞成 1.0，零权重类照样混进去。只有 None/空串才兜底 1.0。
                wv = e.get("weight")
                weights.append(max(0.0, float(wv if wv not in (None, "") else 1.0)))
            s = sum(weights)
            if s <= 0:
                weights = [1.0] * len(packs)
                s = float(len(packs))
            ratios = [w / s for w in weights]
            want = int(cfg.get("max_tokens") or 0)
            target = min(want, avail_total) if want > 0 else avail_total
        src_args, ratio_parts = [], []
        for (i, e, pk), r in zip(packs, ratios):
            key = f"{e.get('kind', 'auto')}{i}"
            src_args += ["--source", f"{key}={pk}"]
            ratio_parts.append(f"{key}={r:.6f}")
        # ★写穿防护：多类混合会往 final 写新 bin，若 final 是旧导入联接，
        #   先解链（只删链接），让 mix_tokens 在项目内真实目录写，不碰外部数据。
        IM.unlink_if_link(final)
        final.mkdir(parents=True, exist_ok=True)
        args = [*src_args, "--ratio", ",".join(ratio_parts),
                "--target-tokens", str(target), "--out-dir", str(final),
                "--block-size", str(int(cfg.get("block_size") or 1024)),
                "--allow-insufficient"]
        def mix_cb(line):
            # ★混料写盘进度：引擎每写若干 token 打 @@WS mix_written N pct
            m = re.search(r"@@WS mix_written (\d+) ([\d.]+)", line)
            if m:
                return min(0.99, float(m.group(2)) / 100.0), f"已写出 {_fmt_tok(int(m.group(1)))} token"
            return None, None

        ok, msg = self._exec(name, "mix_tokens.py", args, "mix", d,
                             expect=final / "data_meta.json", progress_cb=mix_cb)
        if not ok:
            return False, msg
        meta = json.loads((final / "data_meta.json").read_text(encoding="utf-8"))
        total = int(meta.get("train_tokens", 0))
        if total <= 0:
            return False, "整合后训练集为 0"
        # ★全混合没有用户目标（want），用 0 表示「按实际供给」，避免未定义；
        #   且全混合的「短缺」只是配比×总量的取整零头（几千 token），不报警。
        want = 0 if cfg.get("mix_all") else int(cfg.get("max_tokens") or 0)
        warns = self._mix_warns(cfg, total, want)
        # ★短缺如实告知：保持配比不重分配，实际产量低于目标时明确警告
        short = {} if cfg.get("mix_all") else (meta.get("short") or {})
        if short:
            names = "、".join(short.keys())
            warns.append(_p("pipe.mixInsufficient", n=names, t=total, w=target))
        self._set(name, "mix", progress=1.0, message=f"就绪 {_fmt_tok(total)} token",
                  warnings=warns)
        return True, f"{len(packs)} 类已整合，训练集 {_fmt_tok(total)} token"

    def _mix_warns(self, cfg, total, want=0):
        """训练集相对模型规模过小、或实际供给远低于目标时给警告。"""
        from . import hardware as H  # noqa: PLC0415
        warns = []
        n_params = H.TIER_PARAMS.get(cfg.get("tier"), 0) or 0
        if n_params and total < 20 * n_params:
            # 小模型用 M 表示，避免 0.85M 显示成 0.0B
            b = (f"{n_params / 1e6:.0f}M" if n_params < 1e9
                 else f"{n_params / 1e9:.2f}B")
            warns.append(_p("pipe.mixSmall", t=total, b=b))
        if want and total < want * 0.8:
            warns.append(_p("pipe.mixShort", t=total, w=want))
        return warns

    def _train(self, name, cfg, d, resume_from=None, fresh=False):
        from . import hardware as H  # noqa: PLC0415

        hw = H.detect()
        arch = cfg.get("arch") or None
        chk = H.check_config(cfg["tier"], int(cfg["block_size"]), hw,
                             arch=arch, vocab_size=int(cfg.get("vocab_size") or 32000),
                             batch_size=int(cfg.get("batch_size") or 1),
                             master_dtype=cfg.get("master_dtype", "bf16"))
        if not chk["ok"]:
            return False, "；".join(chk["problems"])
        # ★显存不足/规模过大只警告，不阻止启动（用户明确要求）
        if chk.get("warnings"):
            self._set(name, "train",
                      message="风险提示：" + "；".join(chk["warnings"])[:300])
            log = d / "logs" / "train.log"
            try:
                log.parent.mkdir(parents=True, exist_ok=True)
                with log.open("a", encoding="utf-8") as f:
                    f.write("\n[风险提示] 以下问题不会阻止启动，由用户自行决定：\n")
                    for w in chk["warnings"]:
                        f.write("  - " + w + "\n")
            except OSError:
                pass

        # 数据目录：优先用整合产物；若用户直接导入了训练集则用它
        data_dir = d / "data" / "final"
        s_mix = self._src(cfg, "mix")
        if s_mix:
            v = IM.validate("mix", s_mix["path"])
            if not v["ok"]:
                return False, "导入的训练集不可用：" + "；".join(v["problems"])
            data_dir = Path(v["info"].get("path", s_mix["path"]))
            wc = IM.vocab_conflict(v["info"].get("vocab_size"), cfg.get("vocab_size"))
            if wc:
                return False, wc
        mp = data_dir / "data_meta.json"
        if not mp.exists():
            return False, "缺少训练集，请先执行「整合」或在该步导入已有训练集"
        meta = json.loads(mp.read_text(encoding="utf-8"))
        avail = int(meta.get("train_tokens", 0))
        want = int(cfg.get("max_tokens") or 0)
        budget = min(want, avail) if want > 0 else avail
        if budget <= 0:
            return False, "可用训练 token 为 0"
        # ★词表交叉校验闸：训练数据的 tokenizer_fp 必须与项目词表一致。
        #   旧实现只比 vocab_size，导入「同尺寸不同映射」的打包数据 + 自建词表
        #   会静默错位训废（三份审计一致指出）。两边都有指纹才硬拦；
        #   旧产物无指纹时退回 vocab_size 校验并提示重建。
        data_fp = meta.get("tokenizer_fp")
        proj_fp = IM.tokenizer_fingerprint(d / "tokenizer")
        if data_fp and proj_fp and data_fp != proj_fp:
            return False, ("训练数据与项目词表的内容指纹不一致：token 编号会整体错位，"
                           "训出来的权重是废的。请用同一分词器重新打包/整合，"
                           "或把「训练词表」改为导入该数据自带的词表。")
        if not data_fp:
            wc = IM.vocab_conflict(meta.get("vocab_size"), cfg.get("vocab_size"))
            if wc:
                return False, wc

        lr = cfg.get("lr") or H.TIER_LR.get(cfg["tier"], 1e-4)
        out = P.output_dir(name, cfg)
        # ★输出目录重叠校验：两个项目共用同一 output_dir 会互相覆盖断点，
        #   backup 指向别的训练目录会串档（审计指出）。开训前比对其它项目。
        try:
            out_r = out.resolve()
            for other in P.list_all():
                if other["name"] == name:
                    continue
                o_out = P.output_dir(other["name"]).resolve()
                if o_out == out_r or out_r in o_out.parents or o_out in out_r.parents:
                    return False, (f"输出目录与项目「{other['name']}」重叠（{out}）。"
                                   "两个项目共用输出会互相覆盖断点，请改用独立目录。")
        except (OSError, ValueError):
            pass
        try:
            out.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            return False, f"无法创建输出目录 {out}：{e}"
        # ★磁盘预检：训练要反复写断点（每个≈权重×2），剩余空间不足一个断点
        #   就提前告警。不阻断（与显存同口径，由用户决定），但绝不静默。
        try:
            n_par = H.TIER_PARAMS.get(cfg["tier"], 0) or 0
            if cfg.get("arch"):
                n_par = H.arch_params(cfg["arch"], int(cfg.get("vocab_size") or 32000))["params"]
            wb = 4 if cfg.get("master_dtype", "bf16") == "fp32" else 2
            ck_need = n_par * wb * 2 + 1024 ** 3
            free = shutil.disk_usage(str(out)).free
            if free < ck_need:
                self._set(name, "train",
                          message=f"⚠ 磁盘剩余 {free / 1024 ** 3:.1f}GB，"
                                  f"不足一个断点约 {ck_need / 1024 ** 3:.1f}GB，可能写坏断点")
        except (OSError, KeyError, TypeError):
            pass
        # ★清空重训：把旧断点整体归档（不删除，可恢复），再从头训练。
        #   旧实现「重新训练」只重置状态、恒传 --resume，实为续训，
        #   预算已满时甚至秒「完成」零训练（审计指出）。
        if fresh:
            archive = out.parent / f"{out.name}_archive_{time.strftime('%Y%m%d-%H%M%S')}"
            try:
                moved = []
                for sub in sorted(out.iterdir()):
                    if sub.name.startswith("checkpoint-") or sub.name in ("best", "final") \
                            or sub.name.startswith((".tmp-", ".old-")) or ".tmp-" in sub.name \
                            or sub.name == "train_log.csv" or sub.name == "STOP_REQUESTED":
                        archive.mkdir(parents=True, exist_ok=True)
                        shutil.move(str(sub), str(archive / sub.name))
                        moved.append(sub.name)
                if moved:
                    self._set(name, "train",
                              message=f"清空重训：旧断点已归档到 {archive}")
                    lg = d / "logs" / "train.log"
                    lg.parent.mkdir(parents=True, exist_ok=True)
                    with lg.open("a", encoding="utf-8") as f:
                        f.write(f"\n[清空重训] 旧产物已归档（未删除）：{archive}\n")
                    # ★归档保留上限：每次 fresh 都整份归档，多次重训会静默吃满
                    #   磁盘（审计指出）。默认只保留最近 2 份归档，超出提示用户
                    #   手动清理（不自动删——归档是可恢复数据，删除须用户决定）。
                    archives = sorted(out.parent.glob(f"{out.name}_archive_*"))
                    if len(archives) > 2:
                        old_n = len(archives) - 2
                        self._set(name, "train",
                                  message=f"清空重训：已归档。注意已有 {len(archives)} 份归档，"
                                          f"建议手动清理最旧的 {old_n} 份以释放磁盘")
            except OSError as e:
                return False, f"归档旧断点失败，已中止清空重训：{e}"
        # 词表目录：★只跑「仅训练」时词表工位不会执行，
        #   所以这里要负责把导入的词表落地，不能假设前面已经复制过。
        tok_dir = d / "tokenizer"
        if not (tok_dir / "tokenizer.json").exists():
            s_tk = self._src(cfg, "tokenizer")
            if s_tk:
                vt = IM.validate("tokenizer", s_tk["path"])
                if not vt["ok"]:
                    return False, "导入的词表不可用：" + "；".join(vt["problems"])
                ok, msg = IM.use_tokenizer(vt["info"].get("path", s_tk["path"]), tok_dir)
                if not ok:
                    return False, msg
                self._mark_imported(name, "tokenizer", s_tk["path"], vt["info"])
            else:
                return False, "缺少词表，请先执行「训练词表」或在该步导入已有词表"
        # ★热身步数必须跟总步数挂钩：写死 500 时，小语料总共才几百步，
        #   全程都在爬坡、学习率永远到不了设定值，测出来的结果没有参考价值。
        #   取 min(用户设定, 总步数的 5%)，并保证至少 1 步。
        tok_per_step = (int(cfg["block_size"]) * int(cfg["batch_size"])
                        * int(cfg["grad_accum"]))
        est_steps = max(1, budget // max(1, tok_per_step))
        warm_req = int(cfg["warmup_steps"])
        warm = max(1, min(warm_req, int(est_steps * 0.05)))
        # ★保存/评估间隔按总步数自适应：固定 500 时，总步数 <500 的小任务
        #   全程除 final 外无断点无评估，崩溃即全丢、best 永不更新（审计指出）。
        #   压到总步数的 ~10%，保证小任务也有多个断点与评估；大任务不受影响。
        save_every = max(1, min(int(cfg["save_every"]), max(1, est_steps // 10)))
        eval_every = max(1, min(int(cfg["eval_every"]), max(1, est_steps // 10)))
        if warm < warm_req:
            # 与本模块既有写法一致：直接追加到该工位的日志文件
            lg = d / "logs" / "train.log"
            try:
                lg.parent.mkdir(parents=True, exist_ok=True)
                with lg.open("a", encoding="utf-8") as f:
                    f.write(f"[i] 热身步数按总步数自动下调：{warm_req} → {warm}"
                            f"（预计 {est_steps:,} 步的 5%）\n")
            except OSError:
                pass                      # 日志写不进去不该挡住训练
        # ★显式声明优化器：别再依赖脚本默认值，界面/日志/断点三处口径一致。
        #   TIER_LR 是原项目在 Adafactor 下扫描定版的，保持 adafactor 不变。
        optimizer = cfg.get("optimizer") or "adafactor"
        args = ["--tier", cfg["tier"], "--data-dir", str(data_dir),
                "--tokenizer", str(tok_dir),
                "--optimizer", optimizer,
                "--master-dtype", cfg.get("master_dtype", "bf16"),
                "--lr", str(lr), "--block-size", str(int(cfg["block_size"])),
                "--batch-size", str(int(cfg["batch_size"])),
                "--grad-accum", str(int(cfg["grad_accum"])),
                "--max-tokens", str(budget),
                "--warmup-steps", str(warm),
                "--log-every", str(int(cfg["log_every"])),
                "--eval-every", str(eval_every),
                "--save-every", str(save_every),
                "--keep-checkpoints", str(int(cfg["keep_checkpoints"])),
                "--num-workers", str(int(cfg["num_workers"])),
                "--out-dir", str(out)]
        # ★续训语义三分：清空重训(--fresh) / 指定断点(--resume-from) / 默认最新(--resume)
        if fresh:
            args.append("--fresh")
        elif resume_from:
            args += ["--resume", "--resume-from", str(resume_from)]
        else:
            args.append("--resume")
        # ★导入已有模型：从别处的断点/权重接着训，而不是从零开始。
        #   清空重训或用户显式指定断点时，导入来源让位（避免两个 --resume-from）。
        s_tr = self._src(cfg, "train")
        if s_tr and not fresh and not resume_from:
            v = IM.validate("train", s_tr["path"])
            if not v["ok"]:
                return False, "导入的模型不可用：" + "；".join(v["problems"])
            rp = v["info"].get("path", s_tr["path"])
            # ★续训前必须确认分词器一致：大小相同但内容不同会静默毁掉模型
            mm = IM.tokenizer_mismatch(Path(rp), tok_dir)
            if mm:
                return False, mm
            args += ["--resume-from", str(rp)]
            self._mark_imported(name, "train", rp, v["info"])
            note = f"[导入] 从已有模型续训：{rp}"
            if not v["info"].get("has_optimizer"):
                note += "（无优化器状态，仅继承权重）"
            try:
                lg = d / "logs" / "train.log"
                lg.parent.mkdir(parents=True, exist_ok=True)
                with lg.open("a", encoding="utf-8") as f:
                    f.write("\n" + note + "\n")
            except OSError:
                pass
        if arch:
            args += ["--arch", json.dumps(arch, ensure_ascii=False)]
        if not cfg.get("spike_guard", True):
            args.append("--no-spike-guard")
        bdir = (cfg.get("backup_dir") or "").strip()
        if bdir:
            args += ["--backup-dir", bdir,
                     "--backup-every", str(int(cfg["backup_every"])),
                     "--keep-backups", str(int(cfg["keep_backups"]))]

        def cb(line):
            # ★分子也必须允许千分位逗号：引擎打印的是 "step    3,080/7,812"。
            #   旧正则分子写成 \d+，超过 999 步后永远匹配不上，
            #   进度条会卡在 995 步不动（本次端到端实测发现的真实 bug）。
            m = re.search(r"^step\s+([\d,]+)/([\d,]+)", line)
            if m:
                cur = int(m.group(1).replace(",", ""))
                tot = int(m.group(2).replace(",", ""))
                return min(0.999, cur / max(tot, 1)), f"第 {cur:,}/{tot:,} 步"
            return None, None

        ok, msg = self._exec(name, "train_model.py", args, "train", d,
                             expect=out / "final" / "config.json", progress_cb=cb)
        if not ok:
            return False, msg
        # ★成功判定加固：不能只查 final/config.json 存在——旧 final 在时
        #   本次保存失败也可能被误判成功（审计指出）。引擎保存失败现在会抛错
        #   非零退出，这里再验 final 权重分片完整，双保险。
        fin = out / "final"
        idx = fin / "model.safetensors.index.json"
        try:
            if idx.exists():
                wm = json.loads(idx.read_text(encoding="utf-8")).get("weight_map") or {}
                shards = set(wm.values())
                if not shards or not all((fin / s).exists() and (fin / s).stat().st_size > 0
                                         for s in shards):
                    return False, "final 权重分片不完整，本次训练产物不可用（请查日志/磁盘）"
            elif not list(fin.glob("*.safetensors")) and not (fin / "pytorch_model.bin").exists():
                return False, "final 缺少权重文件，本次训练产物不可用"
        except (OSError, ValueError) as e:
            return False, f"final 完整性校验失败：{e}"
        return True, "训练完成"

    def _test(self, name, cfg, d):
        # 验证对象：默认本项目训出的 final；也可导入任意已有模型
        model_dir = P.output_dir(name, cfg) / "final"
        s_te = self._src(cfg, "test")
        if s_te:
            v = IM.validate("test", s_te["path"])
            if not v["ok"]:
                return False, "导入的模型不可用：" + "；".join(v["problems"])
            model_dir = Path(v["info"].get("path", s_te["path"]))
            self._mark_imported(name, "test", str(model_dir), v["info"])
        elif not (model_dir / "config.json").exists():
            # 没训完但用户导入了训练起点时，退而验证那个模型
            s_tr = self._src(cfg, "train")
            if s_tr:
                v = IM.validate("train", s_tr["path"])
                if v["ok"]:
                    model_dir = Path(v["info"].get("path", s_tr["path"]))
        if not (model_dir / "config.json").exists():
            return False, "没有可验证的模型，请先完成训练或在该步导入已有模型"
        # ★困惑度优先用独立验证集（不含训练样本）：打包产物 tokens_val.bin。
        #   旧实现取 cleaned_corpus 前 200 行——那是训练语料头部，含训练样本，
        #   测出来偏乐观，不能当泛化指标（审计指出）。无验证集才退回清洗语料。
        data_dir = d / "data" / "final"
        s_mix = self._src(cfg, "mix")
        if s_mix:
            vm = IM.validate("mix", s_mix["path"])
            if vm["ok"]:
                data_dir = Path(vm["info"].get("path", s_mix["path"]))
        args = ["--model-dir", str(model_dir), "--prompt", "人工智能的未来",
                "--max-new-tokens", "40", "--eval-lines", "200",
                "--data-dir", str(data_dir),
                "--corpus", str(d / "data" / "cleaned_corpus.jsonl")]
        # ★用进度回调捕获困惑度状态标记（标记行不写日志，必须在此接住）
        ppl_state = {"skipped": False, "done": False}

        def test_cb(line):
            if "@@WS ppl_skipped" in line:
                ppl_state["skipped"] = True
            elif "@@WS ppl_done" in line:
                ppl_state["done"] = True
            # ★中间百分比：引擎按阶段打 @@WS test_progress N（0-100）
            m = re.search(r"@@WS test_progress (\d+)", line)
            if m:
                return min(1.0, int(m.group(1)) / 100.0), "验证中"
            return None, None

        ok, msg = self._exec(name, "test_model.py", args, "test", d,
                             progress_cb=test_cb)
        if not ok:
            return False, msg
        # ★区分「生成完成」与「困惑度已测/跳过」：PPL 跳过时不再笼统显示验证完成
        if ppl_state["skipped"] and not ppl_state["done"]:
            return True, f"生成测试完成（{model_dir.name}）；困惑度未执行（无验证集）"
        return True, f"验证完成（{model_dir.name}，含困惑度）"

    # ---------------- 微调 / 导出（v0.4.0） ----------------
    def _base_model_dir(self, name, cfg, d) -> Path:
        """微调/导出的 base 模型：优先 train 导入源，否则本项目 final/best。"""
        s_tr = self._src(cfg, "train")
        if s_tr:
            v = IM.validate("train", s_tr["path"])
            if v["ok"]:
                return Path(v["info"].get("path", s_tr["path"]))
        out = P.output_dir(name, cfg)
        for cand in (out / "final", out / "best"):
            if (cand / "config.json").exists():
                return cand
        return out / "final"

    def _sft_data(self, cfg, d) -> Path:
        raw = (cfg.get("sft_data") or "").strip().strip('"').strip("'")
        return Path(raw) if raw else d / "data" / "sft.jsonl"

    def _ft_cb(self, line):
        m = re.search(r"^step\s+([\d,]+)/([\d,]+)", line)
        if m:
            cur = int(m.group(1).replace(",", ""))
            tot = int(m.group(2).replace(",", ""))
            return min(0.999, cur / max(tot, 1)), f"第 {cur:,}/{tot:,} 步"
        return None, None

    def _sft(self, name, cfg, d):
        base = self._base_model_dir(name, cfg, d)
        if not (base / "config.json").exists():
            return False, "没有可微调的 base 模型，请先完成训练或导入模型"
        data = self._sft_data(cfg, d)
        if not data.exists():
            return False, f"缺少 SFT 对话数据：{data}（messages/instruction-output 格式 jsonl）"
        out = d / "output" / "sft"
        args = ["--base-dir", str(base), "--data", str(data), "--out-dir", str(out),
                "--block-size", str(int(cfg["block_size"])),
                "--batch-size", str(int(cfg.get("sft_batch", 2))),
                "--grad-accum", str(int(cfg.get("sft_accum", 8))),
                "--lr", str(cfg.get("sft_lr", 2e-5)),
                "--max-steps", str(int(cfg.get("sft_steps", 2000))),
                "--save-every", str(max(1, int(cfg.get("sft_steps", 2000)) // 10)),
                "--log-every", str(int(cfg.get("log_every", 20))),
                "--master-dtype", cfg.get("master_dtype", "bf16"),
                "--keep-checkpoints", str(int(cfg.get("keep_checkpoints", 3)))]
        if cfg.get("backup_dir"):
            args += ["--backup-dir", cfg["backup_dir"]]
        # ★续训：输出目录已有完整断点时自动从断点接着跑（引擎侧 --resume
        #   会恢复权重/优化器/步数）。旧实现不传 --resume，停止后从零重跑。
        if any(out.glob("checkpoint-*")):
            args.append("--resume")
        ok, msg = self._exec(name, "train_sft.py", args, "sft", d,
                             expect=out / "final" / "config.json", progress_cb=self._ft_cb)
        return (True, "SFT 完成") if ok else (False, msg)

    def _lora(self, name, cfg, d):
        base = self._base_model_dir(name, cfg, d)
        if not (base / "config.json").exists():
            return False, "没有可微调的 base 模型，请先完成训练或导入模型"
        data = self._sft_data(cfg, d)
        if not data.exists():
            return False, f"缺少 LoRA 对话数据：{data}"
        out = d / "output" / "lora"
        args = ["--base-dir", str(base), "--data", str(data), "--out-dir", str(out),
                "--r", str(int(cfg.get("lora_r", 16))),
                "--alpha", str(cfg.get("lora_alpha", 32)),
                "--block-size", str(int(cfg["block_size"])),
                "--batch-size", str(int(cfg.get("sft_batch", 2))),
                "--grad-accum", str(int(cfg.get("sft_accum", 8))),
                "--lr", str(cfg.get("lora_lr", 1e-4)),
                "--max-steps", str(int(cfg.get("lora_steps", 2000))),
                "--save-every", str(max(1, int(cfg.get("lora_steps", 2000)) // 10)),
                "--log-every", str(int(cfg.get("log_every", 20))),
                "--master-dtype", cfg.get("master_dtype", "bf16"),
                "--keep-checkpoints", str(int(cfg.get("keep_checkpoints", 3)))]
        if cfg.get("lora_merge", True):
            args.append("--merge")
        if cfg.get("backup_dir"):
            args += ["--backup-dir", cfg["backup_dir"]]
        # ★续训：输出目录已有完整断点时自动从断点接着跑（引擎侧 --resume
        #   会恢复适配器/优化器/步数）。旧实现不传 --resume，停止后从零重跑。
        if any(out.glob("checkpoint-*")):
            args.append("--resume")
        ok, msg = self._exec(name, "train_lora.py", args, "lora", d,
                             expect=out / "final" / "adapter.pt", progress_cb=self._ft_cb)
        return (True, "LoRA 完成") if ok else (False, msg)

    def _export(self, name, cfg, d):
        # 导出对象：优先 LoRA merged / SFT final，否则 base final
        candidates = [d / "output" / "lora" / "merged", d / "output" / "sft" / "final",
                      self._base_model_dir(name, cfg, d)]
        model_dir = next((c for c in candidates if (c / "config.json").exists()), None)
        if model_dir is None:
            return False, "没有可导出的模型，请先完成训练/微调"
        out = d / "export"
        args = ["--model-dir", str(model_dir), "--out-dir", str(out),
                "--quant", cfg.get("export_quant", "Q4_K_M"),
                "--model-name", name]
        if (cfg.get("llama_cpp") or "").strip():
            args += ["--llama-cpp", cfg["llama_cpp"].strip()]
        # ★自定义量化调参透传（空/False 不传，保持默认行为）
        for key, flag in (("quant_imatrix", "--imatrix"),
                          ("quant_output_type", "--output-tensor-type"),
                          ("quant_embed_type", "--token-embedding-type"),
                          ("quant_extra_args", "--quant-args")):
            v = (cfg.get(key) or "").strip()
            if v:
                args += [flag, v]
        for key, flag in (("quant_pure", "--pure"),
                          ("quant_leave_output", "--leave-output"),
                          ("quant_allow_requantize", "--allow-requantize")):
            if cfg.get(key):
                args.append(flag)
        for line in (cfg.get("quant_tensor_types") or "").splitlines():
            line = line.strip()
            if line:
                args += ["--tensor-type", line]
        if int(cfg.get("quant_threads") or 0) > 0:
            args += ["--threads", str(int(cfg["quant_threads"]))]
        ok, msg = self._exec(name, "export_gguf.py", args, "export", d,
                             expect=out / "hf" / "config.json")
        return (True, f"导出完成（{model_dir.name}）") if ok else (False, msg)


RUNNER = Runner()


def _sweep_stale_tmp(d: Path) -> int:
    """清扫上次异常中断遗留的临时产物（只删明确可再生的 tmp，不碰正式产物）。

    ★旧实现 .mix_tmp_*/断点 .tmp-/.old-/打包 .tmp 只在特定运行路径清理，
      崩溃后不再触发对应路径就永久残留，体积不可预测（审计指出）。
      服务启动时统一清扫。返回清理项数。
    """
    removed = 0
    patterns = [
        d / "data" / ".mix_tmp_*",
        d / "data" / "final" / ".mix_tmp_*",
        d / "data" / ".cleaned_corpus.tmp-*",
        d / "data" / "packed_*" / ".tokens_*.tmp-*",
        d / "data" / "packed_*" / ".data_meta.tmp-*",
    ]
    # 断点临时目录在输出目录（可能自定义），从 config 读
    try:
        cfg = P.load(d.name)["config"]
        out = P.output_dir(d.name, cfg)
        patterns += [out / "*.tmp-*", out / "*.old-*"]
    except (OSError, ValueError):
        pass
    for pat in patterns:
        for p in pat.parent.glob(pat.name):
            try:
                if p.is_dir():
                    shutil.rmtree(p, ignore_errors=True)
                else:
                    p.unlink()
                removed += 1
            except OSError:
                pass
    return removed


def recover_stale_states() -> int:
    """服务启动时清理「上次进程遗留」的运行态与临时产物。

    ★旧实现重启后 state.json 里的 running/current 原样保留，新 Runner
      又不认识旧子进程，项目永久显示运行中，无法改配置/删除/续训，
      旧训练进程还可能成孤儿（审计指出）。
      现在启动即把 running 复位，正在跑的工位标为 stopped（可续训），
      并如实注明是服务重启所致；同时清扫遗留临时产物。返回清理的项目数。
    """
    n = 0
    try:
        projects = P.list_all()
    except (OSError, ValueError):
        return 0
    for proj in projects:
        name = proj["name"]
        try:
            _sweep_stale_tmp(P.project_dir(name))
        except (OSError, ValueError):
            pass
        try:
            st = P.load(name)["state"]
        except (OSError, ValueError):
            continue
        if not st.get("running"):
            continue
        cur = st.get("current")
        if cur and cur in st.get("stages", {}):
            if st["stages"][cur].get("status") == "running":
                st["stages"][cur]["status"] = "stopped"
                st["stages"][cur]["message"] = "服务重启，任务已中断（可继续）"
        st["running"] = False
        st["current"] = None
        st["error"] = None
        P.save_state(name, st)
        n += 1
    return n

# -*- coding: utf-8 -*-
"""治理与 HF 批量下载：磁盘占用/清理、HF 仓库分片列表/下载（界面入口）。

零第三方依赖（HF 部分用训练环境的 huggingface_hub，经子进程调用 fetch_corpus）。
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

from . import paths as PA
from . import projects as P


def _dir_size(p: Path) -> int:
    if not p.exists():
        return 0
    if p.is_file():
        return p.stat().st_size
    tot = 0
    for f in p.rglob("*"):
        if f.is_file():
            try:
                tot += f.stat().st_size
            except OSError:
                pass
    return tot


def disk_usage() -> dict:
    """每项目占用 + downloads/归档/缓存汇总，供磁盘治理面板。"""
    projects = []
    for proj in P.list_all():
        d = P.project_dir(proj["name"])
        projects.append({"name": proj["name"], "bytes": _dir_size(d)})
    root = PA.app_root()
    downloads = _dir_size(root / "downloads")
    archives = 0
    for proj in P.list_all():
        out = P.output_dir(proj["name"])
        archives += _dir_size(out.parent) if out.parent.exists() else 0
    return {"projects": projects, "downloads_bytes": downloads,
            "total_bytes": sum(p["bytes"] for p in projects) + downloads}


def clean_target(name: str, target: str) -> dict:
    """清理指定项目的可再生目录（cache/tmp/归档），不碰正式产物/语料。"""
    # ★运行中拒绝：cache/tmp 可能被引擎占用，归档目录可能是 fresh 刚归档
    #   的旧断点（用户还要回滚），运行中删掉会丢恢复点
    from .pipeline import RUNNER  # noqa: PLC0415  延迟导入避免循环
    if RUNNER.is_running():
        raise ValueError("项目正在运行，请先停止再清理")
    d = P.project_dir(name)
    removed = 0
    if target == "cache":
        for sub in ("cache", "tmp"):
            p = d / sub
            if p.exists():
                removed += _dir_size(p)
                shutil.rmtree(p, ignore_errors=True)
    elif target == "archives":
        out = P.output_dir(name)
        for p in out.parent.glob(f"{out.name}_archive_*"):
            removed += _dir_size(p)
            shutil.rmtree(p, ignore_errors=True)
    elif target == "downloads":
        p = PA.app_root() / "downloads"
        removed += _dir_size(p)
        shutil.rmtree(p, ignore_errors=True)
    else:
        raise ValueError(f"未知清理目标：{target}")
    return {"removed_bytes": removed}


def hf_list(repo: str) -> dict:
    """列 HF 数据集仓库分片清单（走 hf-mirror），供界面勾选下载。"""
    code = (
        "import os,sys,json;os.environ.setdefault('HF_ENDPOINT','https://hf-mirror.com');"
        "os.environ.setdefault('HF_HUB_DISABLE_XET','1');"
        "from huggingface_hub import HfApi;api=HfApi();"
        f"info=api.repo_info({repo!r},repo_type='dataset',files_metadata=True);"
        "print(json.dumps([{'fn':s.rfilename,'size':s.size or 0} for s in info.siblings]))"
    )
    py = PA.engine_python()
    if not py:
        return {"ok": False, "problems": ["未找到训练环境（需 huggingface_hub）"]}
    r = subprocess.run([py, "-c", code], capture_output=True, text=True,
                       timeout=120, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        return {"ok": False, "problems": [f"清单获取失败：{r.stderr[-200:]}"]}
    try:
        shards = json.loads(r.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return {"ok": False, "problems": ["清单解析失败"]}
    return {"ok": True, "shards": shards}


def hf_download(repo: str, files: list, dest: str) -> dict:
    """下载勾选的 HF 分片：★逐分片注册成独立下载任务（用户要求实时进度 + 多条进度条）。

    旧实现用 subprocess.run 同步阻塞跑 hf_hub_download：前端干等，期间没有
    进度/速度/取消，还有 3600s 硬超时，大分片直接超时失败。
    现在拼 hf-mirror 直链交给 download.start 后台线程 —— 每个分片一条独立
    进度条（百分比/已下载/速度/剩余/取消），支持 Range 续传，多分片并行，
    且不再有整体超时。dest 边界仍复用普通下载的校验。
    """
    from .download import downloads_dir, start as dl_start  # noqa: PLC0415 延迟导入避免循环
    try:
        dest_p = downloads_dir("", dest)
    except ValueError as e:
        return {"ok": False, "problems": [str(e)]}
    repo = (repo or "").strip().strip("/")
    if not repo:
        return {"ok": False, "problems": ["未指定数据集仓库"]}
    jobs, problems = [], []
    for fn in files or []:
        fn = str(fn).strip().lstrip("/")
        if not fn or ".." in fn.split("/"):
            problems.append(f"分片名不合法：{fn}")
            continue
        # HF 数据集直链口径：/datasets/<repo>/resolve/main/<仓库内路径>
        url = f"https://hf-mirror.com/datasets/{repo}/resolve/main/{fn}"
        # 保留仓库内子目录结构，避免不同子目录的同名分片互相覆盖
        parent = Path(fn).parent
        sub = str(dest_p / parent) if parent != Path(".") else str(dest_p)
        r = dl_start(url, "", dest=sub)
        if r.get("ok"):
            jobs.append(r.get("job") or {})
        else:
            problems.append(f"{fn}：" + "；".join(str(x) for x in (r.get("problems") or [])))
    return {"ok": bool(jobs), "started": len(jobs), "done": len(jobs),
            "fail": len(problems), "jobs": jobs, "problems": problems}

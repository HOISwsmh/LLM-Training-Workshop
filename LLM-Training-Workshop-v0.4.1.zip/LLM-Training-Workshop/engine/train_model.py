# -*- coding: utf-8 -*-
"""train_model.py —— 2-3B 中文 LLM 预训练（含断点续训）

★两个关键架构决策，都是被硬件条件决定的：

1. 用 LLaMA 而不是 GPT-2
   GPT-2 的绝对位置编码、LayerNorm、带 bias 的注意力和 MLP、gelu，
   在 2-3B 规模上都不如 LLaMA 的 RoPE + RMSNorm + SwiGLU + 无 bias。
   同等参数量下 LLaMA 收敛更快、效果更好，且 RoPE 便于后续扩长上下文。
   还用了 GQA（num_key_value_heads < num_attention_heads）省 KV 缓存。

2. 用 Adafactor 而不是 AdamW
   实测 3B 模型 AdamW 的优化器状态需要 33.5 GB，超过单卡 31.8 GB 显存，
   而 Adafactor 的状态只要 0.09 GB（0.031 B/param vs AdamW 的 12 B/param）。
   代价是 Adafactor 收敛略慢、对学习率更敏感，所以默认学习率调高到 1e-2
   （AdamW 量级是 3e-4），并配 warmup + cosine 衰减。
   若装 bitsandbytes，可换 8-bit AdamW 折中。

显存策略：模型权重与梯度全程 bf16（3B 各占 6 GB），配非重入梯度检查点。
已实测 bf16 + Adafactor + gradient_checkpointing + generate 四者可共存。

注意：环境未安装 accelerate，transformers 的 Trainer 不可用
（实测直接 ImportError），因此本脚本自己实现训练循环。

档位（meta 设备实测参数量，tie_word_embeddings=True）：
    nano     0.85M  冒烟测试，秒级跑完，只验链路
    tiny    14.9M   验证链路，几分钟跑完
    base   123.7M
    0.5b     0.495B  常见小模型量级
    1.5b     1.500B  常见中型量级
    3b       2.934B  31.8GB 显卡靠 Adafactor 才可训（32000 词表，与定版一致）
    7b       7.010B  48GB 级显存舒适；★用完整注意力（KV头=查询头），
                     与业界 LLaMA-7B 口径一致，不是 GQA 缩水版

    旧档位 small/mid/large/xl/2b/5.8b 保留为别名，老配置仍可用。

    档位名与实际参数量已逐项校准：名称里的数字就是 meta 设备上的真实
    参数量，不是估算值。改动 TIERS 后请用 build_config + meta 设备复核。

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/train_model.py --tier tiny --max-steps 200
    python engine/train_model.py --tier 2b --max-tokens 100e9
    python engine/train_model.py --resume   # 断点续训
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import random
import shutil
import statistics
import sys
import time
from collections import deque
from pathlib import Path

import numpy as np
import torch
from transformers import AutoTokenizer, LlamaConfig, LlamaForCausalLM, Adafactor

# 日志语言：默认中文，原样输出；仅当 LLM_LOG_LANG=en 时译为英文。
# ★不改动任何既有中文语句，查不到译文会退回中文，绝不丢日志。
try:
    from log_i18n import install as _install_log_lang
    _install_log_lang()
except Exception:
    pass

ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent)
DATA_DIR = ROOT / "data"
TOK_DIR = ROOT / "tokenizer"
OUT_ROOT = ROOT / "output"

# name: (hidden_size, num_hidden_layers, intermediate_size, vocab_size)
# 词表需与 train_tokenizer.py 实际产出一致，脚本会自动校正
TIERS = {
    "nano":  (128,  3,    384,  2048),   # 0.85M   冒烟测试：秒级跑完，只验链路
    "tiny":  (384,  6,   1408,  8192),   # 14.9M   验证链路，几分钟跑完
    "base":  (768, 12,   2944, 32000),   # 123.7M
    "0.5b":  (1280, 18,  5504, 32000),   # 0.495B  常见小模型量级
    "1.5b":  (2048, 21,  9408, 32000),   # 1.500B  常见中型量级（heads32/kv8 可整除）
    "3b":    (2560, 32,  9472, 32000),   # 2.934B  31.8GB 靠 Adafactor 才可训
    # ★词表 32000 与用户定版一致；49152 是早期推荐值，曾让 3B 词表比 7B 还大。
    #   实际词表以分词器为准（下面会自动校正），这里只影响从零新建时的默认。
    # ★7B 用完整注意力（KV 头 = 查询头），与业界 LLaMA-7B 口径一致：
    #   之前的 4096×32×11008 + GQA + tie 只有 5.802B，名不副实。
    #   这里 inter 取 12032 且关掉 GQA → 实测 7.010B。
    "7b":    (4096, 32, 12032, 32000),   # 7.010B  48GB 级显存舒适
    # ---- 旧档位名保留为别名，老配置/脚本仍可用（不进界面推荐列表）----
    "small": (512,  8,   1408, 32000),   # 38.9M   → 建议改用 base
    "mid":   (1024, 16,  5504, 32000),   # 345.3M  → 建议改用 0.5b
    "large": (1536, 16,  8192, 32000),   # 747.6M  → 建议改用 0.5b/1.5b
    "xl":    (2048, 24,  6656, 32000),   # 1.299B  → 建议改用 1.5b
    "2b":    (2560, 24,  8192, 32000),   # 1.985B  → 建议改用 1.5b/3b
    "5.8b":  (4096, 32, 11008, 32000),   # 5.802B  → 现 7b 已是真 7B
}
HEAD_DIM = 64           # 注意力头维度，业界常用 64/128
KV_GROUPS = 4           # GQA：每 4 个查询头共享 1 组 KV
# ★个别档位不用 GQA：7B 要与业界口径对齐，KV 头必须等于查询头。
#   值为 1 表示 KV 头 = 查询头（完整多头注意力）。
TIER_KV_GROUPS = {"7b": 1}


# ---------------------------------------------------------------- 暂停控制


class StopRequested(Exception):
    """外部请求优雅暂停（通过 out_dir/STOP_REQUESTED 标记触发）。

    与控制台信号无关，因此后台无窗口启动的训练也能被安全暂停。
    """


# ---------------------------------------------------------------- 数据集


class PackedMemmapDataset:
    """把 memmap 的 token 流按 block_size+1 切成等长块。

    打包式训练不需要 padding：样本已在 prepare_data.py 阶段用
    BOS/EOS 分隔并首尾相接，这里按固定长度滑窗取块即可。
    内存占用恒定，与语料大小无关。
    """

    def __init__(self, path: Path, dtype_str: str, block_size: int) -> None:
        self.data = np.memmap(str(path), dtype=np.dtype(dtype_str), mode="r")
        self.block_size = block_size
        self.n_blocks = max(0, (len(self.data) - 1) // (block_size + 1))

    def __len__(self) -> int:
        return self.n_blocks

    def __getitem__(self, idx) -> tuple[torch.Tensor, torch.Tensor]:
        i = int(idx) * (self.block_size + 1)
        chunk = np.asarray(self.data[i:i + self.block_size + 1], dtype=np.int64)
        x = torch.from_numpy(chunk[:-1])
        y = torch.from_numpy(chunk[1:])
        return x, y


def collate(batch: list[tuple[torch.Tensor, torch.Tensor]]):
    xs = torch.stack([b[0] for b in batch])
    ys = torch.stack([b[1] for b in batch])
    return xs, ys


class EpochShuffleSampler(torch.utils.data.Sampler):
    """确定性洗牌采样器：顺序 = f(seed, epoch)，与进程重启无关。

    ★为什么不用 DataLoader(shuffle=True) + generator 状态：
      那只保证「同一次运行内」可复现；暂停→续训是新进程，DataLoader
      会从头重建 epoch，即使恢复了 generator 状态，数据顺序也对不上，
      「续训数据顺序与暂停前一致」的承诺并不成立（审计指出）。
      改为每个 epoch 用 random.Random(seed*1000003+epoch) 独立洗牌，
      续训时只要知道 epoch 与批内位置，就能精确重建剩余顺序。
    ★内存 O(n_blocks) 的 int 列表：42B token/块长2048 约 2000 万块 ≈ 160MB，
      相对模型与数据本身可忽略；不随训练时长增长。
    """

    def __init__(self, n: int, seed: int, epoch: int = 0) -> None:
        self.n = n
        self.seed = seed
        self.epoch = epoch

    def set_epoch(self, epoch: int) -> None:
        self.epoch = epoch

    def __iter__(self):
        order = list(range(self.n))
        random.Random(self.seed * 1000003 + self.epoch).shuffle(order)
        return iter(order)

    def __len__(self) -> int:
        return self.n


# ---------------------------------------------------------------- 配置


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="2-3B 中文 LLM 预训练",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--tier", choices=sorted(TIERS), default="tiny")
    ap.add_argument("--arch", default=None,
                    help="自定义架构 JSON，未填项沿用档位预设。可含 hidden_size / "
                         "num_hidden_layers / intermediate_size / num_attention_heads / "
                         "num_key_value_heads / head_dim / tie_embeddings")
    ap.add_argument("--out-dir", default=None, help="默认 output/<tier>_model")
    ap.add_argument("--data-dir", default=str(DATA_DIR))
    ap.add_argument("--tokenizer", default=str(TOK_DIR))
    ap.add_argument("--block-size", type=int, default=1024, help="上下文长度")
    ap.add_argument("--batch-size", type=int, default=4, help="每步微批大小")
    ap.add_argument("--grad-accum", type=int, default=8, help="梯度累积步数")
    ap.add_argument("--lr", type=float, default=1e-2, help="Adafactor 学习率，比 AdamW 高约 30 倍")
    ap.add_argument("--min-lr-ratio", type=float, default=0.1, help="cosine 衰减下限比例")
    ap.add_argument("--warmup-steps", type=int, default=500)
    ap.add_argument("--decay-steps", type=int, default=0, help="0 表示用 max-steps")
    ap.add_argument("--max-steps", type=int, default=1000)
    ap.add_argument("--max-tokens", type=float, default=0,
                    help="按 token 预算训练，>0 时覆盖 max-steps")
    ap.add_argument("--weight-decay", type=float, default=0.0)
    ap.add_argument("--grad-clip", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--log-every", type=int, default=10)
    ap.add_argument("--eval-every", type=int, default=200)
    ap.add_argument("--eval-batches", type=int, default=20)
    ap.add_argument("--save-every", type=int, default=200)
    ap.add_argument("--keep-checkpoints", type=int, default=3)
    ap.add_argument("--resume", action="store_true", help="从 out-dir 最新检查点续训")
    ap.add_argument("--resume-from", default=None,
                    help="从指定目录续训（可为别处的检查点，或含 config.json 的模型目录）。"
                         "优先级高于 --resume；目录内无 optimizer.pt 时按仅继承权重处理")
    ap.add_argument("--fresh", action="store_true",
                    help="清空重训：忽略 --resume/--resume-from，从头开始。"
                         "旧断点由调用方先行归档，本参数只保证不接续")
    ap.add_argument("--optimizer", choices=("adafactor", "adamw"), default="adafactor",
                    help="adamw 仅适用于 ≤750M 档位，3B 会 OOM")
    ap.add_argument("--no-checkpointing", action="store_true",
                    help="关闭梯度检查点（显存充裕时可提速约 25%%）")
    ap.add_argument("--compile", action="store_true", help="torch.compile 加速")
    # ★CLI 默认与工坊项目默认对齐（审计指出双入口漂移）：workers=0（Windows
    #   spawn 稳妥）、master-dtype=bf16（界面默认）。命令行直跑与界面训练同口径。
    #   fp32 主权重更稳但显存约翻倍，大模型显存紧张时用 bf16，按需显式指定。
    ap.add_argument("--num-workers", type=int, default=0, help="DataLoader 进程数（默认0，Windows稳妥）")
    ap.add_argument("--master-dtype", choices=("fp32", "bf16"), default="bf16",
                    help="主权重精度。bf16=权重与梯度全bf16（默认，省显存）；"
                         "fp32=主权重fp32+autocast bf16计算（更稳，显存约翻倍，小更新不被舍入吞掉）")
    # ---- C.3 训练日志持久化（CSV，零第三方依赖）
    ap.add_argument("--log-csv", default=None,
                    help="训练日志 CSV 路径，缺省为 out-dir/train_log.csv；传 none 关闭")
    # ---- C.2 loss 尖刺处理
    ap.add_argument("--spike-abs", type=float, default=20.0,
                    help="loss 绝对上限，超过即判为尖刺并跳过该 micro-batch")
    ap.add_argument("--spike-ratio", type=float, default=3.0,
                    help="相对近期中位数的倍数上限，0 表示关闭相对判据")
    ap.add_argument("--spike-window", type=int, default=50,
                    help="相对判据的滑动窗口长度（micro-batch 数）")
    ap.add_argument("--spike-rollback-after", type=int, default=5,
                    help="连续尖刺达到此数则回滚到最近检查点并降 lr，0 表示关闭回滚")
    ap.add_argument("--spike-lr-decay", type=float, default=0.5,
                    help="回滚时学习率乘以此系数")
    ap.add_argument("--spike-max-rollbacks", type=int, default=3,
                    help="累计回滚达到此数仍未恢复则止损退出，0 表示不限制")
    ap.add_argument("--no-spike-guard", action="store_true", help="完全关闭尖刺防护")
    # ---- D.1 检查点异盘备份
    ap.add_argument("--backup-dir", default=None,
                    help="检查点备份目录，应位于另一块物理盘；缺省不备份")
    ap.add_argument("--backup-every", type=int, default=0,
                    help="每多少个编号检查点备份一次，0 表示 save-every 的 5 倍；best/final 始终备份")
    ap.add_argument("--keep-backups", type=int, default=3,
                    help="备份目录保留的编号检查点个数，best/final 不受影响")
    return ap.parse_args()


def lr_at(step: int, args) -> float:
    """线性 warmup + cosine 衰减到 lr * min_lr_ratio。"""
    if step < args.warmup_steps:
        return args.lr * (step + 1) / max(1, args.warmup_steps)
    total = args.decay_steps or args.max_steps
    prog = min(1.0, (step - args.warmup_steps) / max(1, total - args.warmup_steps))
    cos = 0.5 * (1 + math.cos(math.pi * prog))
    return args.lr * (args.min_lr_ratio + (1 - args.min_lr_ratio) * cos)


def build_config(tier: str, vocab_size: int, block_size: int, pad_id, bos_id, eos_id,
                 arch: dict | None = None) -> LlamaConfig:
    """构建模型配置。arch 非空时用自定义架构覆盖档位预设。

    arch 可含：hidden_size / num_hidden_layers / intermediate_size /
               num_attention_heads / num_key_value_heads / head_dim / tie_embeddings
    ★词表始终以实际分词器为准，不受 arch 影响（否则 embedding 与数据会错位）。
    """
    hidden, layers, inter, tier_vocab = TIERS[tier]
    if vocab_size != tier_vocab:
        print(f"[i] 词表校正：档位默认 {tier_vocab:,} → 实际分词器 {vocab_size:,}")

    a = arch or {}
    if a:
        hidden = int(a.get("hidden_size") or hidden)
        layers = int(a.get("num_hidden_layers") or layers)
        inter = int(a.get("intermediate_size") or inter)
        print(f"[i] 自定义架构：hidden={hidden} layers={layers} inter={inter}")

    head_dim = int(a.get("head_dim") or HEAD_DIM)
    if a.get("num_attention_heads"):
        heads = int(a["num_attention_heads"])
    else:
        heads = max(hidden // head_dim, 1)
    if a.get("num_key_value_heads"):
        kv_heads = int(a["num_key_value_heads"])
    else:
        # 按档位取 KV 分组：7B 用完整注意力（与业界口径一致），其余沿用 GQA
        kv_heads = max(heads // TIER_KV_GROUPS.get(tier, KV_GROUPS), 1)
    # 合法性约束：查询头数须能被 KV 头数整除，hidden 须与 heads*head_dim 一致
    kv_heads = max(1, min(kv_heads, heads))
    while heads % kv_heads != 0 and kv_heads > 1:
        kv_heads -= 1
    tie = bool(a.get("tie_embeddings", True))
    # transformers 5.x 把 rope_theta 放进了 rope_parameters
    return LlamaConfig(
        vocab_size=vocab_size,
        hidden_size=hidden,
        intermediate_size=inter,
        num_hidden_layers=layers,
        num_attention_heads=heads,
        num_key_value_heads=kv_heads,
        head_dim=head_dim,
        max_position_embeddings=block_size,
        hidden_act="silu",
        rms_norm_eps=1e-5,
        rope_parameters={"rope_type": "default", "rope_theta": 500000.0},
        attention_bias=False,
        mlp_bias=False,
        tie_word_embeddings=tie,      # 共享输入输出 embedding，中小模型可省数亿参数
        initializer_range=0.02,
        bos_token_id=bos_id,
        eos_token_id=eos_id,
        pad_token_id=pad_id,
        use_cache=False,
    )


def count_params(model) -> int:
    return sum(p.numel() for p in model.parameters())


# ---------------------------------------------------------------- C.3 日志持久化


class CsvLogger:
    """训练日志持久化。只用标准库 csv，每行 flush，断电不丢已写部分。

    设计要点：
      - 追加模式打开，resume 时不覆盖历史
      - 每写一行立即 flush + os.fsync 不做（fsync 太慢），flush 已足够对抗进程退出
      - train / eval / event 三类记录同表，用 phase 列区分，便于事后统一分析
    """

    FIELDS = ["wall_time", "phase", "step", "micro_step", "tokens_seen",
              "loss", "ppl", "lr", "tok_s", "vram_gb", "elapsed_s",
              "skipped_spikes", "rollbacks", "note"]

    def __init__(self, path: Path | None, resume: bool = False) -> None:
        self.fh = None
        self.writer = None
        self.path = path
        self.failed = False        # ★写失败必须让用户知道，不能静默停更曲线
        if path is None:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        is_new = not path.exists() or path.stat().st_size == 0
        self.fh = path.open("a", encoding="utf-8", newline="")
        self.writer = csv.DictWriter(self.fh, fieldnames=self.FIELDS, extrasaction="ignore")
        if is_new:
            self.writer.writeheader()
            self.fh.flush()
        if resume:
            self.log("event", note="resume")

    def log(self, phase: str, **kw) -> None:
        if self.writer is None:
            return
        row = {"wall_time": time.strftime("%Y-%m-%d %H:%M:%S"), "phase": phase}
        row.update(kw)
        try:
            self.writer.writerow(row)
            self.fh.flush()          # ★长跑必须每行落盘
        except (OSError, ValueError) as e:
            # ★日志失败绝不中断训练，但也绝不静默：曲线停更数天而用户
            #   毫不知情是最坏的长跑故障。首次失败大声告警并打标记，
            #   之后每 500 次重试提醒一次，避免刷屏。
            self._fail_n = getattr(self, "_fail_n", 0) + 1
            if self._fail_n == 1 or self._fail_n % 500 == 0:
                print(f"[!] 训练日志写入失败（第 {self._fail_n} 次）：{type(e).__name__}: {e}")
                print("    曲线将停止更新，但训练继续。请检查磁盘空间/文件占用，"
                      "修复后重启训练即可恢复记录。")
                self.failed = True

    def close(self) -> None:
        if self.fh is not None:
            try:
                self.fh.close()
            except OSError:
                pass
            self.fh = None


# ---------------------------------------------------------------- C.2 尖刺防护


class SpikeGuard:
    """loss 尖刺检测：NaN/Inf、绝对阈值、相对滑动中位数三条判据。

    只用 collections.deque + statistics.median，零第三方依赖。
    注意：传入的必须是【未除以 grad_accum 的真实 loss】，否则阈值会被
    同步缩小 grad_accum 倍，防护形同虚设（本项目踩过的坑）。
    """

    def __init__(self, args) -> None:
        self.enabled = not args.no_spike_guard
        self.abs_max = args.spike_abs
        self.ratio = args.spike_ratio
        self.hist: deque[float] = deque(maxlen=max(2, args.spike_window))
        self.consecutive = 0
        self.skipped = 0
        self.rollbacks = 0

    def check(self, real_loss: float) -> str | None:
        """返回 None 表示正常；否则返回尖刺原因字符串。"""
        if not self.enabled:
            self.hist.append(real_loss)
            return None
        if not math.isfinite(real_loss):
            self.consecutive += 1
            self.skipped += 1
            return "non_finite"
        if self.abs_max > 0 and real_loss > self.abs_max:
            self.consecutive += 1
            self.skipped += 1
            return f"abs>{self.abs_max:g}"
        if self.ratio > 0 and len(self.hist) >= 8:
            med = statistics.median(self.hist)
            if med > 0 and real_loss > self.ratio * med:
                self.consecutive += 1
                self.skipped += 1
                return f"ratio>{self.ratio:g}x(med={med:.3f})"
        self.hist.append(real_loss)
        self.consecutive = 0
        return None

    def should_rollback(self, limit: int) -> bool:
        return limit > 0 and self.consecutive >= limit

    def reset_streak(self) -> None:
        self.consecutive = 0


def estimate_memory(n_params: int, optimizer: str, checkpointing: bool,
                    master_dtype: str = "fp32", batch_size: int = 0,
                    block_size: int = 0, hidden_size: int = 0,
                    num_layers: int = 0, vocab_size: int = 32000) -> dict:
    """粗估显存（GB）。用于开训前拦截必然 OOM 的配置。

    ★激活项必须随 batch/block 变化：以前写死 2/8 GB，
      导致 batch=1/block=512 的小配置被误判 OOM，
      而 batch=4/block=1024 的大配置估偏低却真会炸。
      给出结构参数时按 L·b·s·h·k 估；缺参数则退回保守基线（兼容旧调用）。
    """
    wbytes = 4 if master_dtype == "fp32" else 2
    weights = n_params * wbytes / 1024 ** 3      # 主权重
    grads = n_params * wbytes / 1024 ** 3        # 梯度与主权重同 dtype
    if optimizer == "adamw":
        opt_state = n_params * (4 + 4) / 1024 ** 3   # m + v（主权重已单列）
    else:
        opt_state = n_params * 0.031 / 1024 ** 3
    if batch_size > 0 and block_size > 0 and hidden_size > 0 and num_layers > 0:
        # 每 token 每层需保存的中间激活字节数（bf16 计算）。
        # ★k 由原项目 3B 定版实测反解校准：block4096+batch4+bf16+检查点
        #   实测总占用 19.68GB，减去静态 11.02GB 与 logits 2.93GB，
        #   反解 k≈4.6，取 5.0 留一点余量（估 20.2GB，偏保守 0.5GB）。
        #   不开检查点要存 attention/MLP 全部中间量，按约 3 倍计。
        k = 5.0 if checkpointing else 15.0
        act = num_layers * batch_size * block_size * hidden_size * k / 1024 ** 3
        # 输出 logits 是大头且与词表相关：b·s·V·2字节(bf16) + fp32 softmax 副本
        # ★用真实词表：写死 32000 会让大词表（如导入的 151643）低估激活显存，
        #   与界面卡片（按真实词表算）口径分裂。缺省仍按 32000 兼容旧调用。
        act += batch_size * block_size * max(int(vocab_size or 32000), 1) * 6 / 1024 ** 3
        act = max(act, 0.3)
    else:
        act = 2.0 if checkpointing else 8.0
    return {"weights": weights, "grads": grads, "opt": opt_state,
            "act": act, "total": weights + grads + opt_state + act}


# ---------------------------------------------------------------- 训练


@torch.no_grad()
def evaluate(model, loader, device, max_batches: int, block_size: int) -> tuple[float, float]:
    model.eval()
    total_loss, total_tokens, n = 0.0, 0, 0
    for x, y in loader:
        x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
            loss = model(x, labels=y).loss
        total_loss += loss.item() * x.numel()
        total_tokens += x.numel()
        n += 1
        if n >= max_batches:
            break
    model.train()
    if total_tokens == 0:
        return float("nan"), float("nan")
    avg = total_loss / total_tokens
    return avg, math.exp(min(avg, 20))     # 困惑度，截断避免溢出


def _load_weights_inplace(raw_model, ck_dir: Path, master_dtype, device) -> None:
    """把检查点权重逐张量灌进现有模型，不额外构造第二份完整模型。

    ★回滚场景专用：from_pretrained 会再建一整份模型（3B 约 +6GB），
      在显存已经吃紧、正需要回滚救命时反而可能直接 OOM。
      这里每次只把一个张量读进来 copy_ 到目标参数，峰值额外占用≈最大单张量。
    兼容 safetensors 分片（含 index）与单文件；找不到时退回 pytorch_model.bin。
    """
    import gc

    target = dict(raw_model.state_dict())
    loaded = set()

    files = sorted(ck_dir.glob("*.safetensors"))
    if files:
        from safetensors import safe_open
        for f in files:
            with safe_open(str(f), framework="pt") as sf:
                for name in sf.keys():
                    if name not in target:
                        continue        # 跳过不属于当前结构的键（如已弃用的缓冲）
                    # ★按目标参数自身的 dtype 转换，不要强行统一成 bf16/fp32：
                    #   多余的一次转换会引入额外舍入（实测 fp32 参数被转 bf16
                    #   再转回来，误差约 1.7e-4），回滚后权重就不等于检查点了。
                    #   copy_ 本身也会转 dtype，这里显式对齐只为少一次中间副本。
                    t = sf.get_tensor(name)
                    target[name].copy_(t.to(dtype=target[name].dtype))
                    loaded.add(name)
                    del t
    else:
        binf = ck_dir / "pytorch_model.bin"
        if not binf.exists():
            raise FileNotFoundError(f"检查点内没有权重文件：{ck_dir}")
        sd = torch.load(binf, map_location="cpu", weights_only=True)
        for name, t in sd.items():
            if name in target:
                target[name].copy_(t.to(dtype=target[name].dtype))
                loaded.add(name)
        del sd

    missing = set(target) - loaded
    # tie_embeddings 时 lm_head 与 embedding 共享存储，缺一个属正常
    if missing and not getattr(raw_model.config, "tie_word_embeddings", False):
        raise RuntimeError(f"检查点缺少 {len(missing)} 个权重，拒绝带着不完整模型继续训练")
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()


def checkpoint_complete(d: Path) -> bool:
    """断点完整性检查：config + trainer_state + 权重齐全才算可用。

    ★强停/磁盘满/崩溃可能留下「目录存在但权重残缺」的最新断点。
      续训若按编号取最新而不验完整性，会直接崩在加载，或更糟——
      带着不完整权重继续训。分片权重按 index 的 weight_map 逐片核对。
    """
    try:
        if not (d / "config.json").exists() or not (d / "trainer_state.json").exists():
            return False
        idx = d / "model.safetensors.index.json"
        if idx.exists():
            wm = json.loads(idx.read_text(encoding="utf-8")).get("weight_map") or {}
            shards = set(wm.values())
            return bool(shards) and all((d / s).exists() and (d / s).stat().st_size > 0
                                        for s in shards)
        sts = list(d.glob("*.safetensors"))
        if sts:
            return all(f.stat().st_size > 0 for f in sts)
        pb = d / "pytorch_model.bin"
        if pb.exists():
            return pb.stat().st_size > 0
        bins = list(d.glob("pytorch_model-*.bin"))
        return bool(bins) and all(f.stat().st_size > 0 for f in bins)
    except (OSError, ValueError):
        return False


def load_latest_checkpoint(out_dir: Path):
    """取最新的【完整】编号断点；残缺的跳过并告警，绝不静默选用。"""
    cks = sorted(out_dir.glob("checkpoint-*"),
                 key=lambda p: int(p.name.split("-")[1]) if p.name.split("-")[1].isdigit() else -1)
    for c in reversed(cks):
        if checkpoint_complete(c):
            return c
        print(f"[!] 断点 {c.name} 不完整（可能写入中断），已跳过")
    return None


def _atomic_dir(target: Path) -> Path:
    """断点先写临时目录，成功后整体切换，避免留下半成品。

    ★直接写 best/final/checkpoint-N 时，强停/磁盘满会留下残缺目录，
      而续训/回滚恰恰优先选最新的那个。改为写 <name>.tmp-<pid>，
      全部落盘后再把旧目录挪走、临时目录顶上；任何一步失败都保留旧目录。
    """
    tmp = target.with_name(f"{target.name}.tmp-{os.getpid()}")
    if tmp.exists():
        shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    return tmp


def _commit_dir(tmp: Path, target: Path) -> None:
    """临时目录 → 正式目录的原子切换（尽力而为，失败不丢旧数据）。"""
    old = None
    if target.exists():
        old = target.with_name(f"{target.name}.old-{os.getpid()}")
        if old.exists():
            shutil.rmtree(old, ignore_errors=True)
        target.rename(old)
    try:
        tmp.rename(target)
    except OSError:
        # 切换失败：把旧目录放回去，临时目录留着供排查
        if old is not None and old.exists():
            old.rename(target)
        raise
    if old is not None:
        shutil.rmtree(old, ignore_errors=True)


def main() -> int:
    args = parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type != "cuda":
        print("[!] 未检测到 CUDA。2B 以上在 CPU 上无法完成预训练，"
              "仅可用于 --tier tiny 的链路验证。")
    else:
        p = torch.cuda.get_device_properties(0)
        print(f"[i] GPU: {p.name}  {p.total_memory / 1024 ** 3:.1f} GB  算力 {p.major}.{p.minor}")
        if not torch.cuda.is_bf16_supported():
            print("[!] 该显卡不支持 bf16，训练将无法进行")
            return 1

    data_dir, tok_dir = Path(args.data_dir), Path(args.tokenizer)
    train_bin, val_bin = data_dir / "tokens_train.bin", data_dir / "tokens_val.bin"
    meta_path = data_dir / "data_meta.json"
    for label, p in (("分词器", tok_dir), ("训练数据", train_bin), ("数据元信息", meta_path)):
        if not p.exists():
            print(f"[!] 找不到{label}：{p}")
            print("    请依次运行 clean_data.py → train_tokenizer.py → prepare_data.py")
            return 1

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    dtype_str = meta["dtype"]
    vocab_size = meta["vocab_size"]

    tokenizer = AutoTokenizer.from_pretrained(str(tok_dir))
    pad_id = tokenizer.pad_token_id
    bos_id = tokenizer.bos_token_id
    eos_id = tokenizer.eos_token_id

    train_ds = PackedMemmapDataset(train_bin, dtype_str, args.block_size)
    if len(train_ds) == 0:
        print(f"[!] {train_bin} 太小，切不出一个 {args.block_size} 长度的块。"
              f"请增加语料或减小 --block-size")
        return 1
    # ★块数不足一个微批时 drop_last=True 会一个 batch 都产不出，
    #   外层 while 空转：进程活着、日志不写、进度永远 0%（静默死循环）。
    #   这里提前拦住并给出可操作的出路。
    if len(train_ds) < args.batch_size:
        print(f"[!] 训练块只有 {len(train_ds)} 个，不足一个微批（batch-size={args.batch_size}），"
              f"无法产出任何训练批次。请减小 --batch-size 或增加语料")
        return 1
    print(f"[i] 训练块 {len(train_ds):,} × {args.block_size} token "
          f"（共 {train_ds.data.shape[0]:,} token）")

    has_val = val_bin.exists() and val_bin.stat().st_size > 0
    val_ds = PackedMemmapDataset(val_bin, dtype_str, args.block_size) if has_val else None
    if val_ds is not None and len(val_ds) == 0:
        val_ds = None
    print(f"[i] 验证集：{len(val_ds):,} 块" if val_ds else "[i] 验证集：无（跳过评估）")

    arch = None
    if args.arch:
        try:
            arch = json.loads(args.arch)
            if not isinstance(arch, dict):
                arch = None
        except ValueError as e:
            print(f"[!] --arch 不是合法 JSON，忽略：{e}")
    config = build_config(args.tier, vocab_size, args.block_size, pad_id, bos_id, eos_id,
                          arch=arch)
    n_params = None
    with torch.device("meta"):
        n_params = count_params(LlamaForCausalLM(config))

    mem = estimate_memory(n_params, args.optimizer, not args.no_checkpointing,
                          args.master_dtype, batch_size=args.batch_size,
                          block_size=args.block_size,
                          hidden_size=config.hidden_size,
                          num_layers=config.num_hidden_layers,
                          vocab_size=vocab_size)
    print(f"[i] 档位 {args.tier}：{n_params:,} 参数 = {n_params / 1e9:.3f}B")
    print(f"[i] 预估显存：权重 {mem['weights']:.2f} + 梯度 {mem['grads']:.2f} "
          f"+ 优化器 {mem['opt']:.2f} + 激活 {mem['act']:.1f} ≈ {mem['total']:.2f} GB")

    if device.type == "cuda":
        # ★只警告不拦截（与界面/文档承诺一致，用户明确要求"是否尝试由我决定"）。
        #   口径用「当前剩余」而非总显存：与开训前体检同一套，避免两处互相打脸；
        #   剩余拿不到时退回总显存并注明。真正 OOM 由 CUDA 报错兜底。
        try:
            free_b, total_b = torch.cuda.mem_get_info(0)
            vram = free_b / 1024 ** 3
            basis = "当前剩余"
        except (RuntimeError, AssertionError):
            vram = torch.cuda.get_device_properties(0).total_memory / 1024 ** 3
            basis = "总"
        if mem["total"] > vram:
            print(f"\n[!] 预估 {mem['total']:.1f} GB 超出{basis}显存 {vram:.1f} GB，很可能 OOM。"
                  "仍将继续尝试——是否值得由你决定。")
            if args.optimizer == "adamw":
                print("    → 改用 --optimizer adafactor（优化器状态从 "
                      f"{mem['opt']:.1f} GB 降到 {n_params * 0.031 / 1024 ** 3:.2f} GB）")
            print("    → 或降档：--tier 小一档；或减小 --batch-size / --block-size")
            print("    → 或开启梯度检查点（去掉 --no-checkpointing）\n")

    # ---- 加载或新建模型
    out_dir = Path(args.out_dir) if args.out_dir else OUT_ROOT / f"{args.tier}_model"
    out_dir.mkdir(parents=True, exist_ok=True)
    start_step = 0

    # ★暂停竞态修复：停止标记必须在【任何耗时操作之前】清掉。
    #   旧实现把清除放在模型加载之后，大模型加载要数分钟，期间用户点的
    #   暂停会被当成「上次遗留标记」删掉，请求静默失效。
    #   现在进 main 就清；加载期间的新请求会保留，训练一开始即被响应。
    stop_flag = out_dir / "STOP_REQUESTED"
    if stop_flag.exists():
        try:
            stop_flag.unlink()
            print("[i] 已清除上次遗留的停止标记")
        except OSError:
            pass

    # ★清空重训：--fresh 时忽略一切续训来源，从头开始。
    #   旧断点由调用方（工坊）先行归档，这里只保证不接续。
    if args.fresh:
        if args.resume or args.resume_from:
            print("[i] --fresh：忽略续训参数，从头开始训练")
        args.resume = False
        args.resume_from = None

    resume_from = None
    if args.resume_from:
        # 导入外部已有模型/检查点：允许指向别处，不要求在本项目输出目录内。
        rp = Path(args.resume_from)
        if not rp.is_dir():
            print(f"[!] 指定的续训目录不存在：{rp}")
            return 1
        if (rp / "config.json").exists():
            # ★用户显式指定的断点也要验完整性：残缺权重续训会崩或静默变废。
            #   仅权重模型（无 trainer_state）属正常导入，不在此拦截。
            if (rp / "trainer_state.json").exists() and not checkpoint_complete(rp):
                print(f"[!] 指定的断点不完整（缺权重或状态文件）：{rp}")
                print("    请改用其它完整断点，或先修复该目录")
                return 1
            resume_from = rp                       # 直接就是模型/检查点目录
        else:
            resume_from = load_latest_checkpoint(rp)  # 是包含多个 checkpoint-* 的父目录
            if resume_from is None:
                print(f"[!] {rp} 内既无 config.json 也无完整 checkpoint-*，无法续训")
                return 1
    elif args.resume:
        resume_from = load_latest_checkpoint(out_dir)
        if resume_from is None:
            print(f"[!] {out_dir} 下没有完整的 checkpoint-*，将从头开始训练")

    # ★主权重精度：bf16 只有 8 位尾数，权重 0.02 减 1e-5 会被舍入吞掉
    #   （实测 bf16 下结果反而变大），导致大模型训练震荡。
    #   fp32 主权重 + autocast bf16 计算是标准做法，显存代价约 +5.5GB。
    master_dtype = torch.float32 if args.master_dtype == "fp32" else torch.bfloat16

    state = {}
    if resume_from is not None:
        print(f"[i] 从检查点续训：{resume_from}")
        # ★续训结构守卫：from_pretrained 用的是断点自带 config，若用户改了
        #   词表大小/档位/自定义架构，新配置会被旧断点静默覆盖，token 错位
        #   训废且无报错（三份审计一致指出）。这里在加载前比对关键结构字段，
        #   不一致即阻断并给出路。上下文长度变化属合法（RoPE 可外推），只提示。
        try:
            ck_cfg = json.loads((resume_from / "config.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            ck_cfg = {}
        struct_keys = ("vocab_size", "hidden_size", "num_hidden_layers",
                       "intermediate_size", "num_attention_heads",
                       "num_key_value_heads", "head_dim", "tie_word_embeddings")
        mismatch = [k for k in struct_keys
                    if ck_cfg.get(k) is not None and getattr(config, k, None) is not None
                    and ck_cfg.get(k) != getattr(config, k)]
        if mismatch:
            print(f"[!] 续训结构与当前配置不一致：{', '.join(mismatch)}")
            for k in mismatch:
                print(f"    {k}: 断点={ck_cfg.get(k)} 当前={getattr(config, k)}")
            print("    直接续训会让 token 编号/权重错位，模型静默变废。请三选一：")
            print("    → 把配置改回断点的结构（沿用旧模型）")
            print("    → 清空重训（--fresh，旧断点会归档）")
            print("    → 换一个与当前配置匹配的断点")
            return 1
        if ck_cfg.get("max_position_embeddings") not in (None, config.max_position_embeddings):
            print(f"[i] 上下文长度变化：断点 {ck_cfg.get('max_position_embeddings')} → "
                  f"当前 {config.max_position_embeddings}（RoPE 可外推，属合法调整）")
        model = LlamaForCausalLM.from_pretrained(str(resume_from), dtype=master_dtype)
        # ★外部导入的仅权重模型没有 trainer_state.json：以前无条件读会直接崩。
        #   缺失时按从头计步，权重照常继承。
        st_p = resume_from / "trainer_state.json"
        if st_p.exists():
            try:
                state = json.loads(st_p.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                print("[!] trainer_state.json 损坏，按从头计步继续")
        else:
            print("[i] 该目录无 trainer_state.json（外部权重属正常），步数从 0 计")
        start_step = state.get("global_step", 0)
    else:
        # ★直接按目标精度构建：旧实现先在 CPU 建 fp32 再 .to(bf16)，
        #   7B 会瞬时占约 28GB 主机内存，小内存机开训即失败（审计指出）。
        #   按 master_dtype 构建可省一半峰值（bf16 时 7B 约 14GB）。
        model = LlamaForCausalLM(config).to(dtype=master_dtype)
        model = model.to(device)
    model = model.to(device)
    print(f"[i] 主权重精度：{args.master_dtype}（计算 autocast bf16）")

    if not args.no_checkpointing:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        model.config.use_cache = False

    if args.optimizer == "adafactor":
        optimizer = Adafactor(
            model.parameters(), lr=args.lr, scale_parameter=False,
            relative_step=False, warmup_init=False,
            weight_decay=args.weight_decay, clip_threshold=1.0,
            decay_rate=-0.8, beta1=None,
        )
    else:
        optimizer = torch.optim.AdamW(
            model.parameters(), lr=args.lr, betas=(0.9, 0.95),
            weight_decay=args.weight_decay, eps=1e-8, fused=(device.type == "cuda"),
        )

    if resume_from is not None:
        opt_state = resume_from / "optimizer.pt"
        if opt_state.exists():
            optimizer.load_state_dict(torch.load(opt_state, map_location=device, weights_only=True))
            print("[i] 优化器状态已恢复")

    if args.compile:
        print("[i] 正在 torch.compile（首次编译较慢）…")
        model = torch.compile(model)

    # ---- 步数预算
    tokens_per_step = args.batch_size * args.grad_accum * args.block_size
    if args.max_tokens > 0:
        args.max_steps = max(1, int(args.max_tokens / tokens_per_step))
        print(f"[i] 按 token 预算 {args.max_tokens:.3g} → {args.max_steps:,} 步")
    print(f"[i] 每步消耗 {tokens_per_step:,} token "
          f"（batch {args.batch_size} × accum {args.grad_accum} × block {args.block_size}）")

    # ★数据顺序精确续接：用确定性采样器（顺序=f(seed,epoch)）替代
    #   DataLoader 内置 shuffle。续训时从断点读出 epoch 与批内位置，
    #   重建该 epoch 的洗牌顺序并跳过已消耗的批，真正做到「接着上次的位置」。
    #   旧实现只恢复 generator 状态，新进程仍从 epoch 头重建，顺序对不上。
    data_gen = torch.Generator()
    data_gen.manual_seed(args.seed)
    resume_epoch = int(state.get("epoch", 0))
    resume_batch = int(state.get("batch_in_epoch", 0))
    if resume_from is not None:
        rng_f = resume_from / "rng_state.pt"
        if rng_f.exists():
            try:
                # ★安全反序列化：rng_state 内容全是张量/列表/None，用
                #   weights_only=True 拒绝 pickle 任意对象。外部不可信断点
                #   若含恶意 pickle 会在此被拒，而非执行任意代码（审计指出）。
                rs = torch.load(rng_f, map_location="cpu", weights_only=True)
                if "data_gen" in rs:
                    data_gen.set_state(rs["data_gen"])
                torch.set_rng_state(rs["torch_cpu"])
                if device.type == "cuda" and rs.get("cuda") is not None:
                    torch.cuda.set_rng_state_all(rs["cuda"])
                print("[i] 随机状态已恢复")
            except (OSError, RuntimeError, KeyError, TypeError, ValueError,
                    torch.serialization.pickle.UnpicklingError) as e:
                print(f"[!] 随机状态恢复失败（{type(e).__name__}），按种子重新开始")
        elif start_step > 0:
            print("[i] 该检查点无随机状态文件（外部导入的权重属正常），数据顺序按种子重新开始")
        if "epoch" in state:
            print(f"[i] 数据位置已恢复：第 {resume_epoch} 轮第 {resume_batch} 批，续训从此接着走")
        elif start_step > 0:
            print("[i] 该断点无数据位置记录（旧版断点），本轮数据从头洗牌")
    train_sampler = EpochShuffleSampler(len(train_ds), args.seed, resume_epoch)
    train_loader = torch.utils.data.DataLoader(
        train_ds, batch_size=args.batch_size, sampler=train_sampler,
        num_workers=args.num_workers,
        collate_fn=collate, pin_memory=(device.type == "cuda"),
        drop_last=True, persistent_workers=args.num_workers > 0)
    # ★验证集 drop_last=False：旧实现 True 时，验证块数不足一个 batch
    #   会产不出任何批，evaluate 返回 NaN，best 永不更新（审计指出）。
    #   验证不需要凑整批，有多少评多少。
    val_loader = torch.utils.data.DataLoader(
        val_ds, batch_size=args.batch_size, shuffle=False, num_workers=0,
        collate_fn=collate, drop_last=False) if val_ds else None

    model.train()
    step = start_step          # 优化器步数：只有真正 optimizer.step() 之后才自增
    micro_step = 0             # micro-batch 计数：只用来控制梯度累积节奏
    running = 0.0              # 累计未缩放的真实 loss，供日志统计
    running_micro = 0          # 本日志区间实际参与的 micro-batch 数
    tokens_seen = step * tokens_per_step
    tokens_at_log = tokens_seen
    t0 = time.time()
    # ★续训保全：best_val 若重置为 inf，续训后第一个（可能更差的）验证值
    #   就会覆盖 best 目录，把历史最佳模型毁掉。从断点状态恢复。
    best_val = float(state.get("best_val", float("inf")))

    # ---- C.3 日志：默认写到 out_dir/train_log.csv，传 --log-csv none 关闭
    log_path = None
    if args.log_csv and args.log_csv.lower() != "none":
        log_path = Path(args.log_csv)
    elif not args.log_csv:
        log_path = out_dir / "train_log.csv"
    logger = CsvLogger(log_path, resume=(resume_from is not None))
    if log_path:
        print(f"[i] 训练日志：{log_path}")
    guard = SpikeGuard(args)
    # ★续训保全：回滚计数不清零，否则反复暂停/续训可绕过止损上限
    guard.rollbacks = int(state.get("rollbacks", 0))
    if guard.enabled:
        print(f"[i] 尖刺防护：abs>{args.spike_abs:g} / ratio>{args.spike_ratio:g}x "
              f"/ 窗口{args.spike_window} / 连续{args.spike_rollback_after}次回滚")
    if args.backup_dir:
        every = args.backup_every or (args.save_every * 5)
        print(f"[i] 检查点备份：{args.backup_dir}（每 {every} 步 + best/final）")
    logger.log("event", step=step, tokens_seen=tokens_seen, lr=args.lr,
               note=f"start tier={args.tier} params={n_params} "
                    f"batch={args.batch_size} accum={args.grad_accum} block={args.block_size}")

    # ★续训保全：回滚降过的 lr 系数要带回来，否则续训后 LR 复原、防护失效
    lr_scale = float(state.get("lr_scale", 1.0))   # 尖刺回滚时下调，乘在 lr_at 之上

    # ★优雅暂停：外部程序（如工坊界面）在 out_dir 放一个停止标记文件，
    #   训练在【完整优化步边界】检测到后保存断点再退出，不丢已累积梯度。
    #   为什么不用控制台 Ctrl+C 信号：后台启动的训练没有可见控制台，
    #   跨进程附着控制台不可靠；文件标记与控制台无关，跨进程稳定可用。
    #   标记的清除已提前到 main 开头（修复加载期间暂停被误删的竞态）。

    # ---- 数据位置与磁盘告警的运行时变量
    epoch = resume_epoch
    batch_in_epoch = 0
    batches_per_epoch = max(1, len(train_ds) // args.batch_size)
    skip_batches = resume_batch if resume_from is not None else 0
    if skip_batches >= batches_per_epoch:
        # 断点恰好停在 epoch 末尾：进入下一轮，不跳过
        epoch += 1
        skip_batches = 0
        train_sampler.set_epoch(epoch)
    disk_warned = False
    rolled_back = False
    ck_bytes_est = n_params * (4 if args.master_dtype == "fp32" else 2) * 2 + 1024 ** 3

    # ★预算已用尽：续训起点已达/超目标步数时，明确告知而非假装「训练完成」。
    #   旧实现 while 不进循环直接存 final 报成功，用户以为训了实际 0 步
    #   （三份审计一致指出）。这里返回独立退出码 4，调度器据此提示追加预算。
    if step >= args.max_steps:
        print(f"[!] 预算已用尽：断点已在第 {step:,} 步，目标 {args.max_steps:,} 步。")
        print("    本次没有新增训练。如需继续，请提高 token 预算/步数，或清空重训。")
        logger.log("event", step=step, note="budget_exhausted no_new_training")
        logger.close()
        return 4

    def _disk_low() -> bool:
        """输出盘剩余空间是否已低于一个断点的估算体积（只告警一次）。"""
        nonlocal disk_warned
        try:
            free = shutil.disk_usage(str(out_dir)).free
        except OSError:
            return False
        if free < ck_bytes_est and not disk_warned:
            disk_warned = True
            print(f"\n[!] 磁盘空间偏低：剩余 {free / 1024 ** 3:.1f}GB，"
                  f"不足一个断点约 {ck_bytes_est / 1024 ** 3:.1f}GB。"
                  "继续训练可能写坏断点，请尽快清理或更换输出目录。")
            logger.log("event", step=step, note=f"low_disk free_gb={free / 1024 ** 3:.2f}")
        return disk_warned

    try:
        while step < args.max_steps:
            train_sampler.set_epoch(epoch)
            batch_in_epoch = 0
            for x, y in train_loader:
                if step >= args.max_steps:
                    break
                # ★续训跳过已消耗的批：精确接上暂停前的数据位置
                if skip_batches > 0:
                    skip_batches -= 1
                    batch_in_epoch += 1
                    continue
                x = x.to(device, non_blocking=True)
                y = y.to(device, non_blocking=True)
                lr = lr_at(step, args) * lr_scale
                for g in optimizer.param_groups:
                    g["lr"] = lr

                with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
                    raw_loss = model(x, labels=y).loss
                real_loss = raw_loss.item()

                # ---- C.2 尖刺检测：必须在 backward 之前，且用未缩放真值
                reason = guard.check(real_loss)
                if reason is not None:
                    print(f"    [尖刺] micro_step {micro_step} loss={real_loss:.4g} "
                          f"原因={reason} → 丢弃当前累积、跳过该 batch")
                    # ★尖刺跳过不再 micro_step+=1：旧实现既清梯度又占计数，
                    #   优化器会在不足 grad_accum 个微批时更新，等效学习率与
                    #   每步 token 统计失真。现在丢弃已累积梯度、重置窗口计数，
                    #   该批不计入任何统计，下一个完整窗口重新开始。
                    optimizer.zero_grad(set_to_none=True)
                    micro_step = 0
                    running, running_micro = 0.0, 0
                    batch_in_epoch += 1
                    logger.log("event", step=step, micro_step=micro_step,
                               tokens_seen=tokens_seen, loss=real_loss, lr=lr,
                               skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                               note=f"spike_skip {reason}")
                    if guard.should_rollback(args.spike_rollback_after):
                        # ★优先回滚到 best（验证 loss 最优，权重已知良好）；
                        #   最新的编号检查点可能是崩坏后保存的坏权重，回滚回去仍会崩。
                        ck = None
                        best_dir = out_dir / "best"
                        # ★回滚目标也要验完整性：best 若被写入中断污染，
                        #   回滚回去仍会崩，形成无限循环。
                        if (best_dir / "config.json").exists() and checkpoint_complete(best_dir):
                            ck = best_dir
                        else:
                            ck = load_latest_checkpoint(out_dir)
                        if ck is None:
                            # 无任何检查点可回滚（开局即崩）：继续跑只会无限空转
                            print(f"\n[!] 连续 {guard.consecutive} 次尖刺，且尚无任何检查点可回滚。")
                            print("    这通常意味着学习率过高或数据/配置有问题，继续训练只会空转。")
                            print("    建议：降低 --lr（如降到当前值的 1/3～1/10）、"
                                  "延长 --warmup-steps，或检查语料是否异常。")
                            logger.log("event", step=step, micro_step=micro_step,
                                       tokens_seen=tokens_seen, lr=lr,
                                       skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                                       note="abort: consecutive spikes with no checkpoint")
                            logger.close()
                            return 2

                        guard.rollbacks += 1
                        # ★回滚次数上限：反复回滚仍崩说明权重或配置已不可救，止损退出
                        if (args.spike_max_rollbacks > 0
                                and guard.rollbacks > args.spike_max_rollbacks):
                            print(f"\n[!] 已回滚 {guard.rollbacks - 1} 次仍持续尖刺，判定无法自动恢复。")
                            print("    请人工介入：降低 --lr、检查语料，或从更早的健康检查点重启。")
                            logger.log("event", step=step, micro_step=micro_step,
                                       tokens_seen=tokens_seen, lr=lr,
                                       skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                                       note="abort: max rollbacks exceeded")
                            logger.close()
                            return 3

                        lr_scale *= args.spike_lr_decay
                        print(f"    [回滚] 连续 {guard.consecutive} 次尖刺 → "
                              f"载入 {ck.name}，lr 系数降至 {lr_scale:.3g}")
                        raw = model._orig_mod if hasattr(model, "_orig_mod") else model
                        # ★不能再用 from_pretrained：那会在内存里多建一整份模型
                        #   （3B 约 +6GB），偏偏"最需要回滚的时候"最容易因此 OOM。
                        #   改为逐个张量读盘直接 copy_ 进现有权重，额外占用≈单个张量。
                        _load_weights_inplace(raw, ck, master_dtype, device)
                        opt_f = ck / "optimizer.pt"
                        if opt_f.exists():
                            optimizer.load_state_dict(
                                torch.load(opt_f, map_location=device, weights_only=True))
                        optimizer.zero_grad(set_to_none=True)
                        micro_step = 0
                        # ★回到检查点的步数与数据位置，避免用崩坏进度继续推进。
                        #   旧实现只回退 step，数据迭代位置不回退，回滚后仍从
                        #   崩坏处往后喂数据；现在连 epoch/批内位置一起恢复，
                        #   跳出当前 epoch 循环，从检查点位置重新走。
                        st_f = ck / "trainer_state.json"
                        if st_f.exists():
                            try:
                                ckst = json.loads(st_f.read_text(encoding="utf-8"))
                                ck_step = ckst.get("global_step")
                                if isinstance(ck_step, int) and ck_step < step:
                                    step = ck_step
                                    tokens_seen = step * tokens_per_step
                                    tokens_at_log = tokens_seen
                                if "epoch" in ckst:
                                    epoch = int(ckst.get("epoch", 0))
                                    skip_batches = int(ckst.get("batch_in_epoch", 0))
                                    if skip_batches >= batches_per_epoch:
                                        epoch += 1
                                        skip_batches = 0
                                    train_sampler.set_epoch(epoch)
                            except (OSError, ValueError):
                                pass
                        guard.reset_streak()
                        guard.hist.clear()
                        running, running_micro = 0.0, 0
                        logger.log("event", step=step, micro_step=micro_step,
                                   tokens_seen=tokens_seen, lr=lr,
                                   skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                                   note=f"rollback to {ck.name} lr_scale={lr_scale:.4g}")
                        rolled_back = True
                        if step >= args.max_steps:
                            break
                        break          # 跳出 for，让 while 用恢复后的 epoch 重建迭代
                    continue

                (raw_loss / args.grad_accum).backward()

                # 日志必须用未缩放的真实 loss：raw_loss 若直接除以 grad_accum 再累加，
                # 会让打印值偏小 grad_accum 倍，且与 val_loss 量纲不一致。
                running += real_loss
                running_micro += 1
                tokens_seen += x.numel()
                batch_in_epoch += 1

                micro_step += 1
                if micro_step % args.grad_accum == 0:
                    if args.grad_clip > 0:
                        torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
                    optimizer.step()
                    optimizer.zero_grad(set_to_none=True)
                    step += 1

                    if step % args.log_every == 0:
                        avg = running / max(running_micro, 1)
                        elapsed = time.time() - t0
                        # 用真实 token 增量计时：每个 micro-batch 只消耗
                        # batch_size × block_size，乘 tokens_per_step 会虚高 grad_accum 倍。
                        tps = (tokens_seen - tokens_at_log) / elapsed if elapsed > 0 else 0
                        eta = (args.max_steps - step) / max(tps / tokens_per_step, 1e-6) / 3600
                        vram = (torch.cuda.max_memory_allocated() / 1024 ** 3
                                if device.type == "cuda" else 0.0)
                        print(f"step {step:>8,}/{args.max_steps:,} | loss {avg:.4f} "
                              f"| ppl {math.exp(min(avg, 20)):7.2f} | lr {lr:.2e} "
                              f"| {tps:,.0f} tok/s | {tokens_seen / 1e9:.3f}B tok "
                              f"| ETA {eta:.1f}h")
                        logger.log("train", step=step, micro_step=micro_step,
                                   tokens_seen=tokens_seen, loss=round(avg, 6),
                                   ppl=round(math.exp(min(avg, 20)), 3), lr=lr,
                                   tok_s=round(tps, 1), vram_gb=round(vram, 3),
                                   elapsed_s=round(elapsed, 3),
                                   skipped_spikes=guard.skipped, rollbacks=guard.rollbacks)
                        running, running_micro = 0.0, 0
                        tokens_at_log = tokens_seen
                        t0 = time.time()

                    if val_loader and step % args.eval_every == 0:
                        vl, vp = evaluate(model, val_loader, device, args.eval_batches, args.block_size)
                        print(f"    [eval] step {step:,} | val_loss {vl:.4f} | val_ppl {vp:.2f}")
                        logger.log("eval", step=step, micro_step=micro_step,
                                   tokens_seen=tokens_seen, loss=round(vl, 6),
                                   ppl=round(vp, 3), lr=lr,
                                   skipped_spikes=guard.skipped, rollbacks=guard.rollbacks)
                        if vl == vl and vl < best_val:      # NaN 安全比较
                            # ★别让崩坏权重占据 best：best 是尖刺回滚的首选目标，
                            #   若被坏权重污染，回滚回去仍会崩，形成无限循环。
                            polluted = (guard.enabled and args.spike_abs > 0
                                        and vl > args.spike_abs)
                            if polluted:
                                print(f"    [!] val_loss {vl:.4f} 超过尖刺阈值 "
                                      f"{args.spike_abs:g}，跳过 best 保存以免污染回滚目标")
                                logger.log("event", step=step, tokens_seen=tokens_seen,
                                           loss=round(vl, 6),
                                           note="skip best save: val_loss above spike threshold")
                            else:
                                best_val = vl
                                save_checkpoint(model, tokenizer, optimizer, step, out_dir,
                                                args, n_params, best=True,
                                                data_gen=data_gen,
                                                extra_state={"best_val": best_val,
                                                             "lr_scale": lr_scale,
                                                             "rollbacks": guard.rollbacks,
                                                             "epoch": epoch,
                                                             "batch_in_epoch": batch_in_epoch})

                    if step % args.save_every == 0:
                        _disk_low()
                        save_checkpoint(model, tokenizer, optimizer, step, out_dir,
                                        args, n_params, best=False,
                                        data_gen=data_gen,
                                        extra_state={"best_val": best_val,
                                                     "lr_scale": lr_scale,
                                                     "rollbacks": guard.rollbacks,
                                                     "epoch": epoch,
                                                     "batch_in_epoch": batch_in_epoch})
                        prune_checkpoints(out_dir, args.keep_checkpoints)

                    # ★暂停只在完整优化步边界生效：此时梯度已清零、断点可保存，
                    #   不会丢掉当前正在累积的微批。旧实现在每个微批前检查，
                    #   会丢弃已累积梯度且数据位置对不上（审计指出）。
                    if stop_flag.exists():
                        raise StopRequested()
                    if step >= args.max_steps:
                        break
            # ★回滚恢复的 epoch 是「正要重新走的那一轮」，轮末不能再 +1，
            #   否则下轮用 N+1 的洗牌却按 N 的坐标跳批，数据重复/遗漏
            #   （三份审计一致指出，本次修复）。正常走完一轮才自增。
            if rolled_back:
                rolled_back = False
            else:
                epoch += 1             # 本轮数据走完，进入下一轮洗牌
    except StopRequested:
        print(f"\n[!] 收到暂停请求，已在完整优化步边界停下，保存进度（step {step}）…")
        save_checkpoint(model, tokenizer, optimizer, step, out_dir, args, n_params, best=False,
                        data_gen=data_gen, do_backup=False,
                        extra_state={"best_val": best_val, "lr_scale": lr_scale,
                                     "rollbacks": guard.rollbacks,
                                     "epoch": epoch, "batch_in_epoch": batch_in_epoch})
        # ★暂停必备份：不受 backup_every 抽样门限制（用户暂停就是为了保进度），
        #   内部抽样备份已跳过，这里只备份这一次。
        backup_checkpoint(out_dir / f"checkpoint-{step}", f"checkpoint-{step}", step, args,
                          force=True)
        try:
            stop_flag.unlink()      # 消费掉标记，便于下次直接续训
        except OSError:
            pass
        logger.log("event", step=step, micro_step=micro_step, tokens_seen=tokens_seen,
                   skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                   note="paused_by_request")
        logger.close()
        print(f"[i] 已暂停并保存断点 checkpoint-{step}，可续训")
        return 131

    except KeyboardInterrupt:
        print(f"\n[!] 收到中断，保存当前进度（step {step}）…")
        save_checkpoint(model, tokenizer, optimizer, step, out_dir, args, n_params, best=False,
                        data_gen=data_gen, do_backup=False,
                        extra_state={"best_val": best_val, "lr_scale": lr_scale,
                                     "rollbacks": guard.rollbacks,
                                     "epoch": epoch, "batch_in_epoch": batch_in_epoch})
        backup_checkpoint(out_dir / f"checkpoint-{step}", f"checkpoint-{step}", step, args,
                          force=True)
        logger.log("event", step=step, micro_step=micro_step, tokens_seen=tokens_seen,
                   skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                   note="keyboard_interrupt")
        logger.close()
        return 130

    except torch.cuda.OutOfMemoryError:
        # ★OOM 不再让进程无声死掉：清缓存、给出可操作的降档建议、记录事件。
        #   不静默改 batch/block（那会改变训练语义），由用户决定后从断点续训。
        #   最近断点完好（原子写入），损失至多最后一个保存间隔。
        try:
            torch.cuda.empty_cache()
        except Exception:  # noqa: BLE001
            pass
        print(f"\n[!] 显存不足（CUDA OOM），训练在第 {step:,} 步中止。")
        print(f"    最近断点完好，可从它续训。建议（按效果排序）：")
        print(f"    → 减小 --batch-size（当前 {args.batch_size}，试 {max(1, args.batch_size // 2)}）"
              f"并相应增大 --grad-accum 保持有效批量")
        print(f"    → 减小 --block-size（当前 {args.block_size}）")
        print(f"    → 确认已开梯度检查点（去掉 --no-checkpointing）")
        print(f"    → 换更小档位，或关闭占显存的其它程序")
        logger.log("event", step=step, note=f"cuda_oom batch={args.batch_size} block={args.block_size}")
        logger.close()
        return 5

    save_checkpoint(model, tokenizer, optimizer, step, out_dir, args, n_params, best=False,
                    final=True, data_gen=data_gen,
                    extra_state={"best_val": best_val, "lr_scale": lr_scale,
                                 "rollbacks": guard.rollbacks,
                                 "epoch": epoch, "batch_in_epoch": batch_in_epoch})
    logger.log("event", step=step, micro_step=micro_step, tokens_seen=tokens_seen,
               skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
               note=f"done best_val={best_val:.6f}")
    logger.close()
    print(f"\n[i] 训练完成：{step:,} 步，{tokens_seen / 1e9:.3f}B token")
    print(f"[i] 模型已保存到 {out_dir}")
    if val_loader:
        print(f"[i] 最佳验证 loss：{best_val:.4f}")
    if guard.enabled and (guard.skipped or guard.rollbacks):
        print(f"[i] 尖刺统计：跳过 {guard.skipped} 个 micro-batch，回滚 {guard.rollbacks} 次")
    if log_path:
        print(f"[i] 训练日志：{log_path}")
    print(f"[i] 下一步：python engine/test_model.py --tier {args.tier}")
    return 0


def save_checkpoint(model, tokenizer, optimizer, step, out_dir: Path,
                    args, n_params: int, best: bool = False, final: bool = False,
                    data_gen=None, extra_state=None, do_backup: bool = True) -> None:
    """保存完整检查点：模型 + 优化器 + 训练状态 + 随机状态，支持断点续训。

    ★原子写入：先写 <name>.tmp-<pid>，全部落盘后再整体切换到正式目录。
      强停/磁盘满/崩溃只会留下临时目录，不会污染 best/final/checkpoint-N，
      续训与回滚也就不会选中残缺断点。
    """
    name = "best" if best else ("final" if final else f"checkpoint-{step}")
    target = out_dir / name
    tmp = _atomic_dir(target)

    # torch.compile 后真实模型在 _orig_mod 下
    raw = model._orig_mod if hasattr(model, "_orig_mod") else model
    # ★显式声明分片上限：7B bf16 约 14GB，默认 5GB 会切成多片；
    #   备份/回滚/导出都按 *.safetensors + index 全量处理，不依赖单文件假设。
    raw.save_pretrained(str(tmp), max_shard_size="5GB")
    tokenizer.save_pretrained(str(tmp))
    torch.save(optimizer.state_dict(), tmp / "optimizer.pt")
    (tmp / "trainer_state.json").write_text(json.dumps({
        "global_step": step,
        "tier": args.tier,
        "n_params": n_params,
        "block_size": args.block_size,
        "batch_size": args.batch_size,
        "grad_accum": args.grad_accum,
        "optimizer": args.optimizer,
        "lr": args.lr,
        "master_dtype": args.master_dtype,
        "warmup_steps": args.warmup_steps,
        "seed": args.seed,
        # ★续训保全字段：缺了它们续训会覆盖 best、复原 LR、绕过止损
        **(extra_state or {}),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    # ★随机状态单独存：续训时恢复它，数据顺序才与暂停前一致，
    #   否则 loss 曲线会出现无法解释的台阶。存不了不影响训练。
    if data_gen is not None:
        try:
            torch.save({
                "data_gen": data_gen.get_state(),
                "torch_cpu": torch.get_rng_state(),
                "cuda": (torch.cuda.get_rng_state_all()
                         if torch.cuda.is_available() else None),
            }, tmp / "rng_state.pt")
        except (OSError, RuntimeError) as e:
            print(f"    [!] 随机状态保存失败（{type(e).__name__}），续训顺序可能不同")
    # ★全部落盘后再原子切换到正式目录；切换前再验一次完整性，
    #   残缺的宁可留在临时目录也不顶掉旧的好断点。
    # ★校验失败必须抛错而非静默 return：旧实现只 print+return，调用方
    #   不知道失败，_train 又只查 final/config.json 存在，旧 final 在时
    #   本次保存失败仍被判「训练成功」（三份审计一致指出）。抛错后训练
    #   以非零码退出，调度器标 failed，绝不拿陈旧模型冒充本次成果。
    if not checkpoint_complete(tmp):
        raise RuntimeError(f"断点写入不完整（{name}），已保留临时目录供排查：{tmp}")
    _commit_dir(tmp, target)
    print(f"    [保存] {target}")
    # 暂停/中断的强制备份由调用方单独做（force=True），这里跳过以免重复拷贝
    if do_backup:
        backup_checkpoint(target, name, step, args, best=best, final=final)


def backup_checkpoint(target: Path, name: str, step: int, args,
                      best: bool = False, final: bool = False,
                      force: bool = False) -> None:
    """D.1 检查点异盘备份。

    ★备份失败绝不中断训练：整段 try/except，只打警告。
    ★best/final 始终备份；编号检查点按 backup-every 抽样，避免频繁写大盘。
    ★force=True（暂停/中断）无视抽样门：用户停下来就是为了保进度。
    """
    if not args.backup_dir:
        return
    every = args.backup_every or (args.save_every * 5)
    if not (best or final or force) and (every <= 0 or step % every != 0):
        return

    root = Path(args.backup_dir)
    dest = root / target.parent.name / name
    try:
        # ★备份也走原子切换：先写临时目录，验证完整后再顶掉旧备份，
        #   避免复制中断留下「看似存在实则残缺」的备份。
        tmp = dest.with_name(f"{dest.name}.tmp-{os.getpid()}")
        if tmp.exists():
            shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True)
        # 只复制续训必需的文件，跳过无关产物。
        # ★权重可能是多分片（7B bf16 > 5GB）：单文件白名单会漏掉分片与 index，
        #   备份出来的模型加载不了。改为全量 safetensors + index。
        # ★rng_state.pt 必须带上：丢了它从备份续训数据顺序就对不上。
        wanted = ["config.json", "generation_config.json",
                  "trainer_state.json", "optimizer.pt", "rng_state.pt",
                  "tokenizer.json", "tokenizer_config.json",
                  "special_tokens_map.json", "added_tokens.json"]
        wanted += [p.name for p in sorted(target.glob("*.safetensors"))]
        wanted += [p.name for p in sorted(target.glob("*.safetensors.index.json"))]
        copied = 0
        for fn in wanted:
            src = target / fn
            if src.exists():
                shutil.copy2(src, tmp / fn)
                copied += 1
        # ★完整性验证：只数文件数不够，权重分片/索引/状态必须齐全且非空，
        #   否则「备份成功」是假承诺。验证不过就保留旧备份、大声告警。
        if not checkpoint_complete(tmp):
            shutil.rmtree(tmp, ignore_errors=True)
            print(f"    [!] 备份不完整（缺权重/状态文件），已保留旧备份：{dest}")
            return
        _commit_dir(tmp, dest)
        print(f"    [备份] {dest}  ({copied} 个文件，已验证完整)")
        if not (best or final):
            prune_backups(dest.parent, args.keep_backups)
    except Exception as e:                      # noqa: BLE001 备份不能拖垮训练
        print(f"    [!] 备份失败（训练继续）：{type(e).__name__}: {e}")


def prune_backups(root: Path, keep: int) -> None:
    """备份目录同样做保留个数清理，best/final 不动。"""
    if keep <= 0 or not root.exists():
        return
    cks = sorted(root.glob("checkpoint-*"), key=lambda p: int(p.name.split("-")[1]))
    for old in cks[:-keep]:
        try:
            for f in old.iterdir():
                f.unlink(missing_ok=True)
            old.rmdir()
        except OSError:
            pass


def prune_checkpoints(out_dir: Path, keep: int) -> None:
    """只保留最近 keep 个编号检查点，避免磁盘被占满（best/final 不动）。

    ★顺手清理写入中断留下的 .tmp-*/.old-* 临时目录：它们不是有效断点，
      留着只会白占磁盘（一个 3B 断点就是十几 GB）。
    """
    for junk in list(out_dir.glob("*.tmp-*")) + list(out_dir.glob("*.old-*")):
        if junk.is_dir():
            shutil.rmtree(junk, ignore_errors=True)
    if keep <= 0:
        return
    cks = sorted(out_dir.glob("checkpoint-*"), key=lambda p: int(p.name.split("-")[1]))
    for old in cks[:-keep]:
        # ★异常保护：Windows 文件占用/杀毒扫描会让 unlink/rmdir 抛 OSError，
        #   旧实现无保护，训练刚保存完断点就因清理失败整个崩溃（审计指出）。
        #   清理是辅助操作，失败只警告，绝不能打断训练。
        try:
            for f in old.iterdir():
                f.unlink(missing_ok=True)
            old.rmdir()
        except OSError as e:
            print(f"[!] 旧断点清理失败（不影响训练，可稍后手动删）：{old.name} {e}",
                  file=sys.stderr, flush=True)


if __name__ == "__main__":
    sys.exit(main())

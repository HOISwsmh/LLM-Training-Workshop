"""引擎日志双语输出。

★铁律：中文是默认且唯一的源语言。
  - 未设 LLM_LOG_LANG 或设为 zh → 原样输出中文，一个字节都不变。
  - 设为 en → 查表翻译；查不到就退回中文原文，绝不丢日志、绝不抛异常。
新增日志语句时不必维护两份：漏翻译只会显示中文，不会报错。

接法（引擎脚本里只加两行，原有中文 print 全部不动）：
    from log_i18n import install
    install()          # 把 builtins.print 换成双语版
"""
from __future__ import annotations

import builtins
import os
import re

LANG = (os.environ.get("LLM_LOG_LANG") or "zh").strip().lower()
EN = LANG == "en"

# 键 = 中文文案骨架（数字与变量位置统一写成 {}）
# 值 = 英文，占位符顺序与中文完全一致
MAP: dict[str, str] = {
    # ---------- train_model ----------
    "[i] 训练块 {} × {} token （共 {} token）":
        "[i] Training blocks {} x {} tokens ({} tokens total)",
    "[i] 档位 {}：{} 参数 = {}B": "[i] Tier {}: {} params = {}B",
    "[i] 预估显存：权重 {} + 梯度 {} + 优化器 {} + 激活 {} ≈ {} GB":
        "[i] Estimated VRAM: weights {} + grads {} + optimizer {} + activations {} ~= {} GB",
    # ★骨架键会抹掉数字/英文：这两条中文骨架相同，后写的曾被丢弃，
    #   导致 fp32 永远被译成 bf16。改为按完整字面量各译各的（值只有两种）。
    "[i] 主权重精度：bf16（计算 autocast bf16）": "[i] Master weights: bf16 (compute in autocast bf16)",
    "[i] 主权重精度：fp32（计算 autocast bf16）": "[i] Master weights: fp32 (compute in autocast bf16)",
    "[i] 每步消耗 {} token （batch {} × accum {} × block {}）":
        "[i] Tokens per step {} (batch {} x accum {} x block {})",
    "[i] 训练完成：{} 步，{}B token": "[i] Training finished: {} steps, {}B tokens",
    "[i] 模型已保存到 {}": "[i] Model saved to {}",
    "[i] 下一步：python engine/test_model.py --tier {}":
        "[i] Next: python engine/test_model.py --tier {}",
    "[保存] {}": "[save] {}",
    "[i] 词表校正：档位默认 {} → 实际分词器 {}":
        "[i] Vocab adjusted: tier default {} -> tokenizer {}",
    "[i] 自定义架构：hidden={} layers={} inter={}":
        "[i] Custom architecture: hidden={} layers={} inter={}",
    "[!] 未检测到 CUDA。2B 以上在 CPU 上无法完成预训练，仅可用于 --tier tiny 的链路验证。":
        "[!] No CUDA detected. Models above 2B cannot be pretrained on CPU; only --tier tiny is usable for a smoke test.",
    # ★GPU 三条曾撞键（中文骨架都只剩「算力」），任何卡都被译成 RTX PRO 且丢型号。
    #   改为单变量：型号之后的整段（显存+算力）原样保留，数字不拆不丢。
    "[i] GPU: {}": "[i] GPU: {}",
    "[!] {} 太小，切不出一个 {} 长度的块。请增加语料或减小 --block-size":
        "[!] {} is too small to cut a single block of {}. Add more corpus or lower --block-size",
    "[i] 从检查点续训：{}": "[i] Resuming from checkpoint: {}",
    "[i] 正在 torch.compile（首次编译较慢）…": "[i] Running torch.compile (first compile is slow)...",
    "[i] 按 token 预算 {} → {} 步": "[i] Token budget {} -> {} steps",
    "[i] 训练日志：{}": "[i] Training log: {}",
    "[i] 尖刺防护：abs>{} / ratio>{}x / 窗口{} / 连续{}次回滚":
        "[i] Spike guard: abs>{} / ratio>{}x / window {} / rollback after {} in a row",
    "[i] 检查点备份：{}（每 {} 步 + best/final）":
        "[i] Checkpoint backup: {} (every {} steps + best/final)",
    "[i] 最佳验证 loss：{}": "[i] Best validation loss: {}",
    "[i] 尖刺统计：跳过 {} 个 micro-batch，回滚 {} 次":
        "[i] Spike stats: skipped {} micro-batches, rolled back {} times",
    "[备份] {} ({} 个文件)": "[backup] {}  ({} files)",
    "[!] 该显卡不支持 bf16，训练将无法进行": "[!] This GPU does not support bf16; training cannot proceed",
    "[!] 找不到{}：{}": "[!] Not found - {}: {}",
    "请依次运行 clean_data.py → train_tokenizer.py → prepare_data.py":
        "Run in order: clean_data.py -> train_tokenizer.py -> prepare_data.py",
    "[!] 预估 {} GB 超出显存 {} GB，几乎必然 OOM。":
        "[!] Estimated {} GB exceeds available VRAM {} GB; OOM is almost certain.",
    "→ 或降档：--tier 小一档；或减小 --batch-size / --block-size":
        "-> Or step down: use a smaller --tier, or lower --batch-size / --block-size",
    "→ 或开启梯度检查点（去掉 --no-checkpointing）":
        "-> Or enable gradient checkpointing (drop --no-checkpointing)",
    "[!] 指定的续训目录不存在：{}": "[!] The given resume directory does not exist: {}",
    "[i] 优化器状态已恢复": "[i] Optimizer state restored",
    "[i] 已清除上次遗留的停止标记": "[i] Cleared a leftover stop flag from the previous run",
    "[!] 收到暂停请求，保存当前进度（step {}）…":
        "[!] Pause requested, saving progress (step {})...",
    "[i] 已暂停并保存断点 checkpoint-{}，可续训":
        "[i] Paused and saved checkpoint-{}; you can resume later",
    "[!] 收到中断，保存当前进度（step {}）…": "[!] Interrupted, saving progress (step {})...",
    "[!] 备份失败（训练继续）：{}: {}": "[!] Backup failed (training continues): {}: {}",
    "[!] --arch 不是合法 JSON，忽略：{}": "[!] --arch is not valid JSON, ignored: {}",
    "→ 改用 --optimizer adafactor（优化器状态从 {} GB 降到 {} GB）":
        "-> Use --optimizer adafactor instead (optimizer state drops from {} GB to {} GB)",
    "[!] {} 内既无 config.json 也无 checkpoint-*，无法续训":
        "[!] {} has neither config.json nor checkpoint-*; cannot resume",
    "[!] {} 下没有 checkpoint-*，将从头开始训练":
        "[!] No checkpoint-* under {}; starting from scratch",
    "[尖刺] micro_step {} loss={} 原因={} → 跳过该 batch":
        "[spike] micro_step {} loss={} reason={} -> batch skipped",
    "[回滚] 连续 {} 次尖刺 → 载入 {}，lr 系数降至 {}":
        "[rollback] {} spikes in a row -> loading {}, lr factor lowered to {}",
    "[!] 连续 {} 次尖刺，且尚无任何检查点可回滚。":
        "[!] {} spikes in a row and there is no checkpoint to roll back to.",
    "这通常意味着学习率过高或数据/配置有问题，继续训练只会空转。":
        "This usually means the learning rate is too high or the data/config is wrong; continuing would just spin.",
    "建议：降低 --lr（如降到当前值的 1/3～1/10）、延长 --warmup-steps，或检查语料是否异常。":
        "Suggested: lower --lr (to 1/3 - 1/10 of current), lengthen --warmup-steps, or inspect the corpus.",
    "[!] 已回滚 {} 次仍持续尖刺，判定无法自动恢复。":
        "[!] Still spiking after {} rollbacks; automatic recovery is not possible.",
    "请人工介入：降低 --lr、检查语料，或从更早的健康检查点重启。":
        "Manual action needed: lower --lr, inspect the corpus, or restart from an earlier healthy checkpoint.",
    "[!] val_loss {} 超过尖刺阈值 {}，跳过 best 保存以免污染回滚目标":
        "[!] val_loss {} exceeds the spike threshold {}; skipping best save to keep the rollback target clean",
    "[i] 验证集：{} 块": "[i] Validation set: {} blocks",
    "[i] 验证集：无（跳过评估）": "[i] Validation set: none (evaluation skipped)",
    # ---------- clean_data ----------
    "输入行数 : {}": "Input lines      : {}",
    "保留 : {} ({}%)": "Kept             : {} ({}%)",
    "空行 : {}": "Blank lines      : {}",
    "救回的纯文本行 : {}": "Recovered plain  : {}",
    "非文本记录透传 : {}": "Non-text passed  : {}",
    "删除的链接数 : {}": "URLs removed     : {}",
    "剔除的不可见字符 : {}": "Invisible chars  : {}",
    "丢弃原因分布：": "Drop reasons:",
    "保留样本的 CJK 占比直方图（用于决定 --min-cjk-ratio）：":
        "CJK ratio histogram of kept samples (use it to pick --min-cjk-ratio):",
    "[i] 耗时 {}s，{} 行/秒，workers={}": "[i] Elapsed {}s, {} lines/s, workers={}",
    "[!] 找不到原始语料：{}": "[!] Raw corpus not found: {}",
    "请先生成 data/raw_corpus.jsonl（每行一条 JSON），再运行本脚本":
        "Create data/raw_corpus.jsonl (one JSON per line) first, then run this script",
    "[i] 布隆去重：{} MB / {} 哈希，恒定内存，存在极低误判率":
        "[i] Bloom dedup: {} MB / {} hashes, constant memory, very low false-positive rate",
    "[i] 当前未按语言过滤。若做纯中文预训练，可依据上面的直方图设置":
        "[i] No language filter applied. For Chinese-only pretraining, use the histogram above to set",
    "--min-cjk-ratio 0.3 左右，滤掉纯符号/纯外文噪声。":
        "--min-cjk-ratio around 0.3 to drop symbol-only / foreign-language noise.",
    "[i] exact 去重内存占用已较大，超大语料建议改用 --dedup bloom。":
        "[i] Exact dedup is using a lot of memory; for very large corpora use --dedup bloom.",
    "[i] 输出: {} ({} MB)": "[i] Output: {} ({} MB)",
    "... 已保留 {} 条": "... kept {} records",
    # ---------- prepare_data ----------
    "[i] 词表 {} → 存储 dtype {}": "[i] Vocab {} -> storage dtype {}",
    "[i] 语料: {} ({} MB)": "[i] Corpus: {} ({} MB)",
    "读取行数 : {}": "Lines read       : {}",
    "打包样本数 : {}": "Packed samples   : {}",
    "训练集 token : {}": "Train tokens     : {}",
    "验证集 token : {} ({} 条)": "Val tokens       : {} ({} records)",
    "JSON 解析失败 : {}": "JSON parse fails : {}",
    "text 为空 : {}": "Empty text       : {}",
    "token 数不足丢弃: {}": "Too few tokens   : {}",
    "[i] 耗时 {}s，{} 行/秒": "[i] Elapsed {}s, {} lines/s",
    "[!] 分词器缺少 bos/eos，无法标记文档边界":
        "[!] Tokenizer lacks bos/eos; document boundaries cannot be marked",
    "[!] token 总量仅 {}M。2B 模型通常需要 100B+ token 才能学到基础常识，":
        "[!] Token total is very small. A 2B model usually needs 100B+ tokens to learn basic knowledge;",
    "当前语料只够验证链路跑通，正式预训练前需要大幅补充数据。":
        "this corpus is only enough for a smoke test. Add much more data before real pretraining.",
    "请依次运行 clean_data.py 与 train_tokenizer.py":
        "Run clean_data.py and train_tokenizer.py first",
    "... 已处理 {} 条 / {} token": "... processed {} records / {} tokens",
    "[i] 跑满 1 epoch 约需 {}":
        "[i] One full epoch takes about {}",
    # ---------- mix_tokens ----------
    "目标总量 {} token 交错粒度 {} dtype {}":
        "Target {} tokens, interleave granularity {}, dtype {}",
    "实际混合配比：": "Actual mix ratios:",
    "[i] 交错块数 {}，开始写出…": "[i] {} interleaved blocks, writing...",
    "[i] 耗时 {}s": "[i] Elapsed {}s",
    "[i] ✓ 写出量与计划一致": "[i] OK: written amount matches the plan",
    "[!] 配比里有未提供数据的类别：{}": "[!] Ratios reference categories with no data: {}",
    "[i] 配比之和 {} ≠ 1，自动归一化": "[i] Ratios sum to {} (not 1); normalizing automatically",
    "[!] 各类 dtype 不一致：{}，无法混合。请用同一分词器打包。":
        "[!] dtype mismatch across sources: {}; cannot mix. Pack them with the same tokenizer.",
    "[!] 各类 vocab_size 不一致：{}，必须用同一分词器。":
        "[!] vocab_size mismatch across sources: {}; the same tokenizer is required.",
    "[!] 以下类别供给不足：": "[!] These categories are short on supply:",
    "处置：补下载该类语料，或降低其配比，":
        "Options: fetch more of that corpus, or lower its ratio,",
    "或加 --allow-insufficient 按实际供给混合（总量会低于目标）。":
        "or pass --allow-insufficient to mix with what exists (total will be below target).",
    "[i] --dry-run：仅报告，未写出任何文件": "[i] --dry-run: report only, nothing written",
    "[!] 非 dry-run 模式必须指定 --out-dir": "[!] --out-dir is required unless --dry-run is set",
    "[!] ★写出 {} 与计划 {} 不符，请检查": "[!] Written {} does not match planned {}; please check",
    "[!] 总供给 {} < 目标 {}，按实际供给混合（总量 {}）":
        "[!] Total supply {} < target {}; mixing with available supply (total {})",
    "[!] --source 格式应为 NAME=DIR，收到：{}": "[!] --source must be NAME=DIR, got: {}",
    "[!] --ratio 格式应为 name=frac，收到：{}": "[!] --ratio must be name=frac, got: {}",
    "{}: 需 {}，仅有 {}（缺 {}）": "{}: need {}, have {} (short {})",
    # ---------- train_tokenizer ----------
    "[i] 临时语料目录 {}": "[i] Temp corpus dir {}",
    "[i] 语料总行数 {}，本次参与训练 {} 行（{} MB）":
        "[i] Corpus has {} lines; {} lines used for training ({} MB)",
    "[i] 目标词表 {}，特殊符 {} 个": "[i] Target vocab {}, {} special tokens",
    "[i] BPE 训练耗时 {}s": "[i] BPE training took {}s",
    # ---------- train_tokenizer：词表类型/自定义标记/四阶段进度 ----------
    # ★这条的值是中文词而非数字，_values() 取不到，不能用 {} 模板；
    #   两种取值各写一条整句，才能真的译出来。
    "[i] 词表类型：普通文本 LLM": "[i] Vocab type: plain-text LLM",
    # ---------- train_model：续训随机状态 ----------
    "[i] 随机状态已恢复，续训数据顺序与暂停前一致":
        "[i] RNG state restored; data order after resuming matches the pre-pause order",
    "[!] 随机状态恢复失败（{}），本轮顺序将从头开始":
        "[!] Could not restore RNG state ({}); this run starts the order from scratch",
    "[i] 该检查点无随机状态文件（外部导入的权重属正常），数据顺序按种子重新开始":
        "[i] No RNG state file in this checkpoint (normal for imported weights); data order restarts from the seed",
    "[!] 随机状态保存失败（{}），续训顺序可能不同":
        "[!] Could not save RNG state ({}); the order after resuming may differ",
    # ---------- train_model：本轮审计修复新增 ----------
    "[!] 训练块只有 {} 个，不足一个微批（batch-size={}），无法产出任何训练批次。请减小 --batch-size 或增加语料":
        "[!] Only {} training blocks, fewer than one micro-batch (batch-size={}); no batch can be produced. Lower --batch-size or add corpus",
    "[!] 预估 {} GB 超出当前剩余显存 {} GB，很可能 OOM。仍将继续尝试——是否值得由你决定。":
        "[!] Estimated {} GB exceeds currently free VRAM {} GB; OOM is likely. Continuing anyway — your call.",
    "[!] 预估 {} GB 超出总显存 {} GB，很可能 OOM。仍将继续尝试——是否值得由你决定。":
        "[!] Estimated {} GB exceeds total VRAM {} GB; OOM is likely. Continuing anyway — your call.",
    "[i] 该目录无 trainer_state.json（外部权重属正常），步数从 0 计":
        "[i] No trainer_state.json in this folder (normal for external weights); step count starts at 0",
    "[!] trainer_state.json 损坏，按从头计步继续":
        "[!] trainer_state.json is corrupted; continuing with step count from 0",
    # ---------- train_tokenizer：NFKC 归一化 ----------
    "[i] 已启用 NFKC 归一化（全角/兼容字符统一）；该词表与未归一化的旧词表不兼容，请勿混用":
        "[i] NFKC normalization enabled (full-width and compatibility forms unified); "
        "this vocab is incompatible with older non-normalized vocabs — do not mix them",
    # ---------- prepare_data：词表口径与编号越界校验 ----------
    "[i] 词表含额外标记：基础 {} + 附加 {} = {}":
        "[i] Vocab includes added tokens: base {} + added {} = {}",
    "[!] 有 {} 条样本的 token 编号超出词表范围（最大 {} ≥ 词表 {}）":
        "[!] {} samples have token ids beyond the vocab range (max {} >= vocab {})",
    "原因通常是：词表与语料不是同一套，或导入的词表缺少附加标记。":
        "Usually the tokenizer and the corpus are not the same set, or the imported tokenizer lacks added tokens.",
    "请用与语料匹配的词表重新打包。":
        "Re-pack using a tokenizer that matches the corpus.",
    "[i] 编号校验通过：最大 token id {} < 词表 {}":
        "[i] Id check passed: max token id {} < vocab {}",
    "[i] 词表类型：含预设扩展控制符":
        "[i] Vocab type: with preset extension control tokens",
    "[i] 自定义特殊标记 {} 个：{}": "[i] Custom special tokens ({}): {}",
    "[progress] 5% 准备训练语料": "[progress] 5% Preparing training corpus",
    "[progress] 25% 语料已就绪，开始训练 BPE": "[progress] 25% Corpus ready; starting BPE training",
    "[progress] {}% 抽样语料 {} 行": "[progress] {}% Sampling corpus, {} lines read",
    "[progress] {}% BPE 训练中 · 已耗时 {}": "[progress] {}% BPE training · elapsed {}",
    "[progress] 80% BPE 训练完成，正在保存与校验": "[progress] 80% BPE training done; saving and verifying",
    "[progress] 95% 校验完成": "[progress] 95% Verification complete",
    "[i] 特殊标记校验：完好 {} / 拆碎 {}": "[i] Special token check: intact {} / split {}",
    "这些标记必须是单 token 才能作为控制符使用，请检查拼写后重训。":
        "These markers must each be a single token to work as control symbols; check the spelling and retrain.",
    # ---------- test_model：标记校验 ----------
    "预设扩展控制符: {}/{} 个保持单 token":
        "Preset extension control tokens: {}/{} remain single tokens",
    "预设扩展控制符: 未注册（标准文本模型，属正常）":
        "Preset extension control tokens: not registered (normal for a plain-text model)",
    "自定义特殊标记: {}/{} 个保持单 token":
        "Custom special tokens: {}/{} remain single tokens",
    "★被拆碎（名称, encode长度）: {}": "★Split apart (name, encode length): {}",
    "★被拆碎: {}": "★Split apart: {}",
    "这些标记必须是单 token 才能作为控制符使用，请检查后重训分词器。":
        "These markers must each be a single token to work as control symbols; check them and retrain the tokenizer.",
    "✓ 全部完好": "✓ All intact",
    "[i] 已保存：{}": "[i] Saved: {}",
    "[i] 回读词表大小：{}": "[i] Vocab size on reload: {}",
    "[i] 特殊符 id：": "[i] Special token ids:",
    "[i] 中文压缩率：{} token/字（已剔除 ByteLevel 前导空格）":
        "[i] Chinese compression: {} tokens/char (ByteLevel leading space excluded)",
    "[!] 找不到清洗后的语料：{}": "[!] Cleaned corpus not found: {}",
    "请先运行 clean_data.py 生成 data/cleaned_corpus.jsonl":
        "Run clean_data.py first to produce data/cleaned_corpus.jsonl",
    "[!] 实际词表 {} 远低于目标 {}（仅 {}）":
        "[!] Actual vocab {} is far below target {} (only {})",
    "原因：BPE 的 merge 数量受语料多样性上限约束，":
        "Reason: the number of BPE merges is capped by corpus diversity;",
    "语料太少或重复度高时无法凑够目标词表。":
        "too little or too repetitive data cannot reach the target vocab.",
    "处理：补充语料后重训，或把 --vocab-size 降到接近实际值。":
        "Fix: add corpus and retrain, or lower --vocab-size close to the actual value.",
    "注意：词表偏小会让中文被拆成更多字节，序列变长、训练变慢。":
        "Note: a small vocab splits Chinese into more bytes, making sequences longer and training slower.",
    "[i] 多模态标记校验：完好 {} / 拆碎 {}":
        "[i] Multimodal token check: intact {} / split {}",
    "文本: {}": "Text: {}",
    "还原: {} {}": "Decoded: {} {}",
    "★偏高。当前词表 {} 对中文太小，": "Too high. The current vocab {} is too small for Chinese;",
    "2B 级预训练建议 --vocab-size 32000 以上，否则序列变长、成本上升。":
        "for 2B-scale pretraining use --vocab-size 32000 or more, otherwise sequences grow and cost rises.",
    "★被拆碎（名称, encode长度）：{}": "Split tokens (name, encoded length): {}",
    "这些标记是第二阶段多模态训练必需的，请检查 mm_tokens 与重训。":
        "These tokens are required for stage-2 multimodal training; check mm_tokens and retrain.",
    "处于可用区间。词表 {}，正式训练可考虑更大词表。":
        "Usable range. Vocab {}; consider a larger vocab for real training.",
    "良好。词表 {} 对中文压缩充分。": "Good. Vocab {} compresses Chinese well.",
    # ---------- test_model ----------
    "模型目录: {}": "Model dir : {}",
    "架构 : {}": "Architecture : {}",
    "参数量 : {} = {}B": "Parameters   : {} = {}B",
    "设备 : {}": "Device       : {}",
    "上下文 : {}": "Context      : {}",
    "词表 : {}": "Vocab        : {}",
    "评测语料: {}": "Eval corpus: {}",
    "[!] 找不到模型。请先运行 train_model.py，或用 --model-dir 指定路径":
        "[!] Model not found. Run train_model.py first, or point --model-dir at it",
    "已尝试：{} 下的 final / best / checkpoint-*": "Tried: final / best / checkpoint-* under {}",
    "[!] {} 下没有 config.json，不是有效的模型目录":
        "[!] No config.json under {}; not a valid model directory",
    "语料困惑度: loss {} | ppl {} | 基于 {} 条 / {} token":
        "Corpus perplexity: loss {} | ppl {} | over {} records / {} tokens",
    "语料困惑度: loss {} | ppl {} | 基于 {} 条 {} {} token":
        "Corpus perplexity: loss {} | ppl {} | over {} records {} {} tokens",
    "语料困惑度: 跳过（未找到 data/cleaned_corpus.jsonl 或 --eval-lines 0）":
        "Corpus perplexity: skipped (data/cleaned_corpus.jsonl missing or --eval-lines 0)",
    "提示: {}": "Prompt: {}",
    "贪婪: {}": "Greedy: {}",
    "采样(T={}): {}": "Sampled(T={}): {}",
    "多模态控制符: {}/{} 个保持单 token": "Multimodal tokens: {}/{} stay single-token",
    "多模态控制符: 未注册（当前为纯文本模型，属正常）":
        "Multimodal tokens: not registered (normal for a text-only model)",
    "→ 困惑度极高，模型基本没学到东西（可能只训了很少步数）":
        "-> Perplexity is very high; the model has learned little (perhaps only a few steps were trained)",
    "★被拆碎（索引, encode长度）: {}": "Split tokens (index, encoded length): {}",
    "进入音频→谱面阶段前，这些标记必须是单 token，请重训分词器。":
        "Before the audio-to-chart stage these must be single tokens; retrain the tokenizer.",
    "✓ 全部完好，可进入第二阶段多模态训练": "OK: all intact, ready for stage-2 multimodal training",
    "→ 模型在学习但仍处早期，2B 级预训练完成后通常应低于 20":
        "-> The model is learning but still early; a finished 2B-scale pretrain is usually below 20",
    "→ 困惑度处于合理区间": "-> Perplexity is in a reasonable range",
    # ---------- adapt_corpus ----------
    "源类型: {} 文件数: {}": "Source kind: {}  files: {}",
    "读取记录 : {}": "Records read     : {}",
    "写出记录 : {}": "Records written  : {}",
    "坏记录 : {}": "Bad records      : {}",
    "提取为空 : {}": "Empty extraction : {}",
    "过短丢弃 : {}": "Too short        : {}",
    "文件级错误 : {}": "File-level errors: {}",
    "文件: {} ({} MB)": "File: {} ({} MB)",
    "[!] 没有匹配到任何输入文件：{}": "[!] No input files matched: {}",
    "{} 读{} → 写{}": "{} read {} -> wrote {}",
    "[!] ★有 {} 条未能写出（占 {}）": "[!] {} records were not written ({} of input)",
    "若 empty_extract 占多数，说明 --kind 选错或字段名不符，":
        "If empty_extract dominates, --kind is wrong or the field names differ;",
    "请用 --probe 查看真实字段后重跑。": "use --probe to inspect the real fields, then rerun.",
    "[i] ✓ 全部记录成功转换，无静默丢失": "[i] OK: every record converted, nothing silently lost",
    "[!] 未读到任何记录": "[!] No records were read",
    "字段: {}": "Fields: {}",
    "提取长度: {} 字符": "Extracted length: {} chars",
    "预览: {}": "Preview: {}",
    "[读取失败] {}: {}": "[read failed] {}: {}",
    "[坏行]": "[bad line]",
    "[!] {} 读取中断：{}: {}": "[!] {} read aborted: {}: {}",
    "... 已写出 {} 条": "... wrote {} records",
    "[i] 已处理 {} 条": "[i] Processed {} records",
}

# ★路径/文件名先整体保护起来：里面的数字（checkpoint-1108、v0.1.1）
#   绝不能被当成占位符，否则整句匹配失败、译文里路径也会被改坏。
_PATH = re.compile(
    r"(?:[A-Za-z]:[\\/]|\\\\|\./)"           # 盘符 / UNC / 相对路径开头
    r"[^\s\u4e00-\u9fff：，。（）()\"']*"      # 直到空白或中文标点
    r"|(?<![\w/])/(?:[\w.\-]+/)+[\w.\-]*"    # 以 / 开头的多段绝对路径
)
_TOKENFILE = re.compile(r"[\w.\-]+\.(?:py|json|jsonl|bin|pt|safetensors|csv|txt|md)\b")

# 数字（含千分位、小数、科学计数）→ 占位符
# ★关键：不能吃掉 bf16 / 2B / v0.1.1 / int8 这类词内部的数字，
#   否则骨架与译表键对不上，整句都译不出来。
#   因此要求数字左右都不是单词字符（字母/数字/下划线）。
_NUM = re.compile(
    r"(?<![\w.])"
    r"(?:\d[\d,]*(?:\.\d+)?(?:[eE][-+]?\d+)?)"
    r"(?![\w.])"
)
_CJK = re.compile(r"[\u4e00-\u9fff]")



# ★匹配策略：只保留中文与标点作为键，数字/路径/英文技术词全部剔除。
#   这样 bf16、2B、0.073B、checkpoint-1108 之类都不会影响匹配，
#   而中文句式本身足以唯一确定一条日志。
_CJK_PUNCT = re.compile(r"[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]+")


def _key(text: str) -> str:
    """取中文骨架：连续中文与中文标点，忽略数字与英文。

    ★先把路径整体挖掉再取骨架：项目名可能含中文（例如任意中文项目名），
      不挖掉就会把项目名混进键里，导致同一条日志因项目名不同而匹配不上。
    """
    masked = re.sub(
        r"(?:[A-Za-z]:[\\/]|\\\\|\./)[^\s：，。（）()\"']*", "\x01", text)
    return "|".join(_CJK_PUNCT.findall(masked))


def _fill(en: str, vals: list[str]) -> str:
    """把运行时抽出的值填进英文模板。

    支持 {} 按序填充，以及 {n} 指定用第 n 个值（中文里有多余数字时用得上）。
    """
    idx = [0]

    def _sub(m):
        g = m.group(1)
        if g:
            i = int(g)
            return vals[i] if i < len(vals) else m.group(0)
        i = idx[0]
        idx[0] += 1
        return vals[i] if i < len(vals) else "{}"

    return re.sub(r"\{(\d*)\}", _sub, en)


# 中文骨架 → 英文模板（由 MAP 在导入时构建）
_BY_KEY: dict[str, str] = {}
# ★短模板（≤2 个变量）另建「模板正则」：骨架会抹掉 fp32/bf16 这类英文值，
#   让两条不同日志撞键互相覆盖。短模板整句正则匹配、按组取值，可靠；
#   长模板（含路径/多变量）仍走骨架，保住跨路径匹配能力。


def _norm_ws(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


# 全文匹配表：(模板正则, 英文模板)。模板里的 {} 编译成捕获组，
# 运行时整句匹配、按组取值——比骨架键可靠，专治撞键与丢值。
_FULL_RE: list = []


def _build() -> None:
    _BY_KEY.clear()
    _FULL_RE.clear()
    for zh, en in MAP.items():
        _BY_KEY.setdefault(_key(zh), en)
        if zh.count("{}") <= 2:
            # 空白归一后编译：字面量转义，{} 变捕获组。
            # 末组贪婪到行尾，中间组非贪婪；字面量间的空白用 \s+ 兼容双空格。
            parts = [p.strip() for p in _norm_ws(zh).split("{}")]
            pat = ""
            for i, lit in enumerate(parts):
                if i:
                    last = i == len(parts) - 1
                    pat += r"\s+(.+)" if last else r"\s+(.+?)"
                if lit:
                    if i and not pat.endswith(r"\s+"):
                        pat += r"\s+"   # 变量与后随字面量之间的空白
                    # 字面量首尾空白已剥离，内部空白放宽为 \s+，兼容单/双空格
                    pat += re.escape(lit).replace(r"\ ", r"\s+")
            _FULL_RE.append((re.compile("^" + pat + "$"), en))


_build()

# 运行时从原句中抽取的值。
# ★顺序很重要：先整体吃掉「路径」和「字母数字混合的技术词」，
#   再抽纯数字。否则 bf16 会被抽成 16、--tier 3b 会被抽成 3，
#   填回英文模板时就把这些词写坏了。
_VAL = re.compile(
    # 路径整体：允许内含中文（项目名可能是中文），直到空白或中文标点
    r"(?:[A-Za-z]:[\\/]|\\\\|\./)[^\s：，。（）()\"']*"
    r"|\d[\d,]*(?:\.\d+)?[eE][-+]?\d+"                               # 科学计数 2e+06
    # ★小数优先于「字母开头技术词」：否则算力 8.9 / 耗时 3.5 会被
    #   [A-Za-z_][\w.\-]*\d[\w.\-]* 从数字位吞掉，译文丢值。
    #   要求小数点后不紧跟字母，v0.1.1 这类仍归技术词。
    r"|\d[\d,]*\.\d+(?![A-Za-z])"                                    # 8.9 / 3.5 / 24.0
    r"|\d+[A-Za-z]+\+?"                                              # 2B / 100B+ / 12M / 50x
    r"|[A-Za-z_][\w.\-]*\d[\w.\-]*"                                  # bf16 / v0.1.1
    r"|\d[\d,]*(?:\.\d+)?"                                           # 纯数字
)
# 档位名等纯英文单词不是变量，不参与取值；但 tiny/3b 这类档位需要保留在译文里
_TIER_WORD = re.compile(r"\b(tiny|small|base|mid|large|xl|2b|3b|7b)\b")


def _values(text: str) -> list[str]:
    """只取真正要填进英文模板的值：路径与纯数字，技术词跳过。

    ★例外：checkpoint-1108 / step-500 这类「词-数字」里的数字是真变量，
      必须取出来，否则英文模板的 {} 填不上。
    """
    # ★GPU 型号是含空格的英文名（NVIDIA GeForce RTX 4090），逐词抽会被
    #   「含字母即技术词」规则丢光。整行作为单变量保留（模板也是单变量），
    #   变量里的中文单位就地译掉，避免英文日志夹中文。
    if text.startswith("[i] GPU:"):
        v = text[len("[i] GPU:"):].strip()
        return [v.replace("算力", "compute")]
    # epoch 估算：数值短语整段保留避免拆值错位，中文单位/说明就地译掉
    em = re.search(r"约需\s*(.+)$", text)
    if em and "epoch" in text:
        v = em.group(1).strip()
        v = (v.replace("小时", "hours").replace("按", "at")
              .replace("估算", "estimated").replace("实际以", "actual depends on")
              .replace("和显卡为准", "and GPU"))
        return [v]
    out = []
    for m in _VAL.finditer(text):
        s = m.group(0)
        if re.match(r"^(?:[A-Za-z]:[\\/]|\\\\|\./)", s):
            out.append(s)                 # 路径整体
            continue
        mh = re.match(r"^[A-Za-z_][\w.]*-(\d+)$", s)
        if mh:
            out.append(mh.group(1))       # checkpoint-1108 → 1108
            continue
        if re.fullmatch(r"\d[\d,]*(?:\.\d+)?[eE][-+]?\d+", s):
            out.append(s)                 # 2e+06 整体保留
            continue
        # 倍数写法 50x / 3x：数字是变量，x 是固定后缀
        mx = re.fullmatch(r"(\d+(?:\.\d+)?)x", s)
        if mx:
            out.append(mx.group(1))
            continue
        # ★数字紧跟时间单位（12s / 8.4s / 3ms / 5h）：数字是变量，单位是固定后缀。
        #   不加这条会被下面的「含字母即技术词」规则吃掉，
        #   于是「耗时 12s」在英文里变成 Elapsed {}s（整数秒必现，小数秒才侥幸正常）。
        mu = re.fullmatch(r"(\d[\d,]*(?:\.\d+)?)(ms|s|h|min)", s)
        if mu:
            out.append(mu.group(1))
            continue
        if re.search(r"[A-Za-z]", s):
            continue                      # bf16 / 2B / v0.1.1 等固定技术词
        out.append(s)
    # 档位名是变量：出现在「档位 xxx：」里时要取出来
    mt = re.search(r"档位\s+(\w+)[：:]", text)
    if mt:
        out.insert(0, mt.group(1))
    # --tier xxx 的档位也是变量（下一步提示等），3b 会被抽成 3，这里补回原词
    tt = re.search(r"--tier\s+(\w+)", text)
    if tt:
        out.append(tt.group(1))
    return out


_UNIT_MAP = [("算力", "compute"), ("小时", "hours"), ("估算", "estimated"),
             ("实际以", "actual depends on"), ("和显卡为准", "and GPU"),
             ("按", "at"), ("（", " ("), ("）", ")"), ("，", ", ")]


def _localize_units(v: str) -> str:
    """整句模板的捕获组可能带中文单位（GPU 行/epoch 短语），就地译掉。"""
    for a, b in _UNIT_MAP:
        v = v.replace(a, b)
    return v


def translate(text: str) -> str:
    """中文 → 英文。zh 模式原样返回；未收录则保留中文，绝不丢日志。"""
    if not EN or not text or not _CJK.search(text):
        return text
    # ★@@WS 标记行是给工坊调度器解析的结构化数据（进度/统计），
    #   不是给人看的文案，任何语言下都必须原样透传，否则英文模式下
    #   进度与清洗告警会因解析不到而静默失效。
    if text.lstrip().startswith("@@WS"):
        return text
    nt = _norm_ws(text)
    for rx, en in _FULL_RE:            # 短模板整句优先，避免骨架撞键
        m = rx.match(nt)
        if m:
            vals = [_localize_units(v) for v in m.groups()]
            return _fill(en, vals)
    en = _BY_KEY.get(_key(text))
    if en is None:
        return text
    return _fill(en, _values(text))


_ORIG_PRINT = builtins.print
_installed = False


def _bi_print(*args, **kwargs):
    if EN and args:
        args = tuple(translate(a) if isinstance(a, str) else a for a in args)
    return _ORIG_PRINT(*args, **kwargs)


def install() -> str:
    """把 print 换成双语版。zh 模式下行为与原来完全一致。"""
    global _installed
    if not _installed:
        builtins.print = _bi_print
        _installed = True
    return "en" if EN else "zh"
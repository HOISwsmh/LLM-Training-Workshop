# -*- coding: utf-8 -*-
"""clean_data.py —— 面向 2B 级中文预训练语料的清洗脚本

目标场景：先训一个具备基础常识的中文 LLM（约 2B），后续扩展为
「音频 → 4K 音游谱面」的多模态模型（约 3B）。本脚本只负责文本预训练
语料的清洗，但为后面的多模态数据留出兼容位。

本脚本的设计要点：
    1. 流式读写 + 可选多进程，支撑 GB 级语料，内存不随语料量线性膨胀
    2. 去重只存 8 字节 blake2b 摘要（exact），或布隆位图（bloom）
    3. 控制字符 / 零宽 / 双向控制符 / 替换符统一剔除，NFKC 归一化全半角
    4. json.loads(strict=False) + 非 JSON 行降级为纯文本，脏行不再整条丢弃
    5. 保留段落换行，只压缩空白；CJK 之间的空格可选压掉
    6. 长度、符号比、数字比、字符重复率、4-gram 重复率等质量过滤
    7. 无 text 字段的记录（未来的音频/谱面样本）原样透传，额外字段全部保留
    8. 读取用 utf-8-sig + errors="replace"，坏字节不会中断整轮清洗
    9. 结束打印丢弃原因分布与 CJK 占比直方图，便于回调阈值

运行方式：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/clean_data.py
    python engine/clean_data.py --workers 8 --dedup bloom

说明：2B 预训练通常需要上亿条样本。exact 去重每条约占 60~100 字节内存，
超过 5000 万条时请改用 --dedup bloom（近似去重，恒定内存）。
若要进一步提升语料质量，可在此之后再做 MinHash/SimHash 近似去重与
困惑度过滤，本脚本只负责规则清洗这一层。
"""
from __future__ import annotations

import os
import argparse
import html
import json
import re
import sys
import time
import unicodedata
from collections import Counter
from hashlib import blake2b
from multiprocessing import Pool
from pathlib import Path

# 日志语言：默认中文，原样输出；仅当 LLM_LOG_LANG=en 时译为英文。
# ★不改动任何既有中文语句，查不到译文会退回中文，绝不丢日志。
try:
    from log_i18n import install as _install_log_lang
    _install_log_lang()
except Exception:
    pass

ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent)          # .
SRC = ROOT / "data" / "raw_corpus.jsonl"
DST = ROOT / "data" / "cleaned_corpus.jsonl"

# ---------------------------------------------------------------- 正则与常量

# CJK（含扩展 A、兼容表意、CJK 标点、全角形式、假名）
CJK_CLASS = (
    "\u2e80-\u2eff\u3000-\u303f\u3040-\u30ff\u3100-\u312f"
    "\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\uff00-\uffef"
)
CJK_RE = re.compile(f"[{CJK_CLASS}]")
# CJK 与 CJK 之间的空格（中文不需要词间空格，压掉可省词表）
CJK_GAP_RE = re.compile(f"(?<=[{CJK_CLASS}])[ \t]+(?=[{CJK_CLASS}])")
# 不可见字符：C0/C1 控制符、软连字符、零宽、双向控制、BOM、特殊占位、替换符
# 注意 \t \n \r 由换行处理逻辑单独负责，不在这里删
INVISIBLE_RE = re.compile(
    "[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f"
    "\u00ad\u034f\u061c\u180e"
    "\u200b-\u200f\u2028\u2029\u202a-\u202e\u2060-\u2064\u2066-\u2069"
    "\ufeff\ufffc\ufffd\U000e0000-\U000e007f]"
)
HTML_TAG_RE = re.compile(r"<\s*/?\s*[a-zA-Z!][^>]{0,300}>")
URL_RE = re.compile(r"(?:https?://|www\.)[^\s<>\"')\]}，。；！？]+", re.I)
EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
WS_RE = re.compile(r"[ \t\u00a0\u1680\u2000-\u200a\u202f\u205f\u3000]+")
NONWORD_RE = re.compile(r"[^\w\s]", re.UNICODE)
DIGIT_RE = re.compile(r"\d", re.UNICODE)
WHITESPACE_RE = re.compile(r"\s+")

REPEAT_SAMPLE = 20000        # 重复率只在开头采样，避免超长行拖慢
CJK_BUCKETS = (0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9, 1.0001)


# ---------------------------------------------------------------- 布隆过滤器


class BloomFilter:
    """无第三方依赖的布隆位图，用于内存放不下全量摘要时的近似去重。

    Kirsch-Mitzenmacher 双哈希：g_i = (h1 + i*h2) mod bits
    """

    __slots__ = ("buf", "bits", "k")

    def __init__(self, bits: int, k: int) -> None:
        self.bits = max(bits, 8)
        self.k = max(k, 1)
        self.buf = bytearray((self.bits + 7) // 8)

    def add_if_absent(self, key: bytes) -> bool:
        """未见过则写入并返回 True；判定为已存在则返回 False（可能有极低误判）。"""
        digest = blake2b(key, digest_size=16).digest()
        h1 = int.from_bytes(digest[:8], "big")
        h2 = int.from_bytes(digest[8:], "big") or 0x9E3779B97F4A7C15
        idx = [(h1 + i * h2) % self.bits for i in range(self.k)]

        missing = False
        for j in idx:
            byte, bit = divmod(j, 8)
            if not (self.buf[byte] >> bit) & 1:
                missing = True
                break
        if not missing:
            return False
        for j in idx:
            byte, bit = divmod(j, 8)
            self.buf[byte] |= 1 << bit
        return True


# ---------------------------------------------------------------- 文本清洗


def clean_text(text: str, cfg, stat: Counter) -> tuple[str, str, float]:
    """清洗单条文本。返回 (清洗后文本或 "", 原因, CJK 占比)。"""
    if cfg.nfkc:
        text = unicodedata.normalize("NFKC", text)

    invisible = len(INVISIBLE_RE.findall(text))
    if invisible:
        stat["invisible_chars"] += invisible
    text = INVISIBLE_RE.sub("", text)

    if cfg.strip_html:
        text = HTML_TAG_RE.sub("", text)
        text = html.unescape(text)                # &nbsp; &amp; &#x4e2d; 等
        text = HTML_TAG_RE.sub("", text)          # 反转义后又露出的标签
    # ★代码语料保护：strip_html=False 时上面三步全跳过。旧实现无条件
    #   html.unescape + 二次去标签，会把 <stdio.h>、vector<int>、JSX 当标签
    #   删掉、把 &amp; 等实体改坏（审计指出）。代码预设关闭 strip_html。

    if cfg.strip_urls:
        text, n_url = URL_RE.subn("", text)
        text, n_mail = EMAIL_RE.subn("", text)
        if n_url or n_mail:
            stat["links_removed"] += n_url + n_mail

    out_lines = []
    for raw_line in text.split("\n"):
        line = WS_RE.sub(" ", raw_line)
        if cfg.compact_cjk:
            line = CJK_GAP_RE.sub("", line)
        line = line.strip()
        if line:
            out_lines.append(line)

    cleaned = "\n".join(out_lines)
    if not cleaned:
        return "", "empty_after_clean", 0.0

    body = WHITESPACE_RE.sub("", cleaned)
    n = len(body)
    if n == 0:
        return "", "empty_after_clean", 0.0
    cjk_ratio = len(CJK_RE.findall(body)) / n

    # ---- 长度
    if len(cleaned) < cfg.min_chars:
        return "", "too_short", cjk_ratio
    if len(cleaned) > cfg.max_chars:
        # ★返回清洗后的文本而非空串：开启 split_long 时批处理要靠它切分保留；
        #   关闭切分时批处理见 too_long 仍丢弃，行为不变。
        return cleaned, "too_long", cjk_ratio

    # ---- 语言占比（默认关闭，跑完看直方图再定阈值）
    if cfg.min_cjk_ratio > 0 and cjk_ratio < cfg.min_cjk_ratio:
        return "", "low_cjk_ratio", cjk_ratio

    # ---- 符号 / 数字占比 / 重复度（样本太短时这些比值没有统计意义）
    if n >= 12:
        word_chars = len(NONWORD_RE.sub("", body))
        if (n - word_chars) / n > cfg.max_symbol_ratio:
            return "", "high_symbol_ratio", cjk_ratio
        digit_chars = len(DIGIT_RE.findall(body))
        if digit_chars / n > cfg.max_digit_ratio:
            return "", "high_digit_ratio", cjk_ratio

        sample = body[:REPEAT_SAMPLE]
        m = len(sample)
        if m >= 16:
            top = Counter(sample).most_common(1)[0][1]
            if top / m > cfg.max_top_char_ratio:
                return "", "char_repetition", cjk_ratio
            grams = [sample[i:i + 4] for i in range(m - 3)]
            if (1.0 - len(set(grams)) / len(grams)) > cfg.max_repeat_ratio:
                return "", "ngram_repetition", cjk_ratio

    return cleaned, "ok", cjk_ratio


def process_batch(lines: list[str], cfg) -> tuple[list, Counter]:
    """处理一批原始行。

    返回 (records, stat)：
      records = [(kind, payload, reason, cjk_ratio)]，kind 为 text/pass/drop
      stat    = 本批的计数器，主进程负责累加（多进程下也能正确汇总）
    """
    stat: Counter = Counter()
    out = []

    for raw in lines:
        line = raw.strip()
        if not line:
            stat["blank_lines"] += 1
            continue
        stat["read"] += 1

        obj = None
        parse_failed = False
        try:
            # strict=False：容忍行内的裸制表符等控制字符，不再整行丢弃
            obj = json.loads(line, strict=False)
        except (json.JSONDecodeError, ValueError):
            parse_failed = True

        text = None
        extra: dict = {}

        if isinstance(obj, dict):
            if "text" not in obj:
                # 没有 text 字段：视为未来的音频/谱面等多模态样本，原样透传
                if cfg.keep_non_text:
                    stat["non_text_kept"] += 1
                    out.append(("pass", obj, "non_text_passthrough", -1.0))
                else:
                    out.append(("drop", None, "no_text_field", -1.0))
                continue
            t = obj.get("text")
            if not isinstance(t, str):
                out.append(("drop", None, "bad_text_field", -1.0))
                continue
            text = t
            extra = {k: v for k, v in obj.items() if k != "text"}
        elif isinstance(obj, str):
            text = obj                             # 整行就是一个 JSON 字符串
        elif parse_failed:
            # 以 { 或 [ 开头却解析失败 = 结构损坏，救回来只会引入脏数据
            if cfg.salvage_plain and line[:1] not in ("{", "["):
                text = line
                stat["salvaged_plain"] += 1
            else:
                out.append(("drop", None, "json_parse_error", -1.0))
                continue
        else:
            out.append(("drop", None, "not_a_text_object", -1.0))
            continue

        cleaned, reason, ratio = clean_text(text, cfg, stat)
        # ★too_long 且开启切分时不在此丢弃，交给下面的切分逻辑保留；
        #   其余非 ok 原因（太短/低中文/高重复等）仍丢弃。
        if reason != "ok" and not (reason == "too_long" and getattr(cfg, "split_long", True)):
            out.append(("drop", None, reason, ratio))
            continue

        # ★长文档切分：超 max_chars 的文档不再整条丢弃，按段落边界切成多段保留
        #   （审计指出旧实现直接丢长文）。切分后每段都 ≤max_chars；开关默认开。
        if getattr(cfg, "split_long", True) and len(cleaned) > cfg.max_chars:
            for seg in _split_long(cleaned, cfg.max_chars):
                if len(seg) >= cfg.min_chars:
                    rec = {"text": seg}
                    rec.update(extra)
                    out.append(("text", rec, "ok", ratio))
            stat["long_split"] += 1
            continue

        record = {"text": cleaned}
        record.update(extra)                       # 保留来源等额外字段
        out.append(("text", record, "ok", ratio))

    return out, stat


def _split_long(text: str, max_chars: int) -> list[str]:
    """把超长文本按段落（换行）边界切成 ≤max_chars 的段，尽量不切断段落。

    单个段落本身超长时按 max_chars 硬切（保证不丢内容）。
    """
    paras = text.split("\n")
    segs, cur = [], ""
    for p in paras:
        if len(p) > max_chars:
            if cur:
                segs.append(cur)
                cur = ""
            for i in range(0, len(p), max_chars):
                segs.append(p[i:i + max_chars])
            continue
        if cur and len(cur) + 1 + len(p) > max_chars:
            segs.append(cur)
            cur = p
        else:
            cur = cur + "\n" + p if cur else p
    if cur:
        segs.append(cur)
    return segs


# ---------------------------------------------------------------- 写出与主流程

_WORKER_CFG = None


def _init_worker(cfg) -> None:
    global _WORKER_CFG
    _WORKER_CFG = cfg


def _clean_batch_mp(lines: list[str]) -> tuple[list, Counter]:
    return process_batch(lines, _WORKER_CFG)


class ShardWriter:
    """按行数分片的流式写出器。shard_lines=0 时只写单个文件。"""

    def __init__(self, dst: Path, shard_lines: int) -> None:
        self.dst = dst
        self.shard_lines = shard_lines
        self.paths: list[Path] = []
        self._fh = None
        self._idx = 0
        self._in_shard = 0

    def _next_path(self) -> Path:
        """计算下一个分片的路径（不创建文件，避免产生空分片）。"""
        if self.shard_lines > 0:
            self._idx += 1
            return self.dst.with_name(
                f"{self.dst.stem}-{self._idx:05d}{self.dst.suffix}")
        return self.dst

    def _open(self) -> None:
        """惰性打开：只有真要写第一条时才建文件。"""
        if self._fh:
            self._fh.close()
        path = self._next_path()
        self.dst.parent.mkdir(parents=True, exist_ok=True)
        self.paths.append(path)
        self._fh = path.open("w", encoding="utf-8", newline="\n")
        self._in_shard = 0

    def write(self, record: dict) -> None:
        if self._fh is None:
            self._open()
        self._fh.write(json.dumps(record, ensure_ascii=False) + "\n")
        self._in_shard += 1
        if self.shard_lines and self._in_shard >= self.shard_lines:
            self._fh.close()
            self._fh = None        # 写满即关闭，下一批再惰性新建

    def close(self) -> None:
        if self._fh:
            self._fh.close()
            self._fh = None
        if not self.paths:         # 一条都没写出时，仍生成一个空文件占位
            self.dst.parent.mkdir(parents=True, exist_ok=True)
            self.dst.touch()
            self.paths.append(self.dst)


def iter_batches(fh, size: int, limit: int):
    """按 size 行切批；limit>0 时最多产出 limit 行。"""
    batch, produced = [], 0
    for line in fh:
        batch.append(line)
        if len(batch) >= size:
            if limit and produced + len(batch) > limit:
                batch = batch[:limit - produced]
            yield batch
            produced += len(batch)
            batch = []
            if limit and produced >= limit:
                return
    if batch:
        if limit and produced + len(batch) > limit:
            batch = batch[:limit - produced]
        if batch:
            yield batch


def parse_args(argv=None) -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="2B 级中文预训练语料清洗（clean_data.py）",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument("--src", default=str(SRC), help="输入 jsonl")
    ap.add_argument("--dst", default=str(DST), help="输出 jsonl")
    ap.add_argument("--min-chars", type=int, default=8, help="清洗后最短字符数")
    ap.add_argument("--max-chars", type=int, default=50000, help="单条最长字符数")
    ap.add_argument("--min-cjk-ratio", type=float, default=0.0,
                    help="CJK 占比下限，0 表示不按语言过滤")
    ap.add_argument("--max-symbol-ratio", type=float, default=0.30)
    ap.add_argument("--max-digit-ratio", type=float, default=0.60)
    ap.add_argument("--max-top-char-ratio", type=float, default=0.35,
                    help="单一字符占比上限，拦「哈哈哈哈…」")
    ap.add_argument("--max-repeat-ratio", type=float, default=0.50,
                    help="4-gram 重复率上限，拦复制粘贴段落")
    ap.add_argument("--workers", type=int, default=1, help="清洗进程数，1 为单进程")
    ap.add_argument("--chunk-size", type=int, default=2000, help="每批行数")
    ap.add_argument("--dedup", choices=("exact", "bloom", "none"), default="exact")
    ap.add_argument("--bloom-mbytes", type=int, default=512, help="布隆位图大小(MB)")
    ap.add_argument("--bloom-hashes", type=int, default=7)
    ap.add_argument("--shard-lines", type=int, default=0,
                    help="每个输出分片的行数，0 表示输出单个文件")
    ap.add_argument("--limit", type=int, default=0, help="只处理前 N 行，0 为全量")
    ap.add_argument("--progress-every", type=int, default=200000,
                    help="每保留多少条打印一次进度，0 关闭")
    # 开关项（--xxx / --no-xxx）
    ap.add_argument("--nfkc", action=argparse.BooleanOptionalAction, default=True,
                    help="NFKC 归一化，全角转半角")
    ap.add_argument("--compact-cjk", action=argparse.BooleanOptionalAction, default=True,
                    help="压掉 CJK 字符之间的空格")
    ap.add_argument("--strip-html", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--strip-urls", action=argparse.BooleanOptionalAction, default=True,
                    help="删除 URL 与邮箱，省词表")
    ap.add_argument("--salvage-plain", action=argparse.BooleanOptionalAction, default=True,
                    help="非 JSON 的纯文本行降级为语料而非丢弃")
    ap.add_argument("--keep-non-text", action=argparse.BooleanOptionalAction, default=True,
                    help="无 text 字段的记录原样透传（为多模态数据留位）")
    ap.add_argument("--split-long", action=argparse.BooleanOptionalAction, default=True,
                    help="超长文档按段落切分保留（关闭则整条丢弃）")
    ap.add_argument("--near-dup", action=argparse.BooleanOptionalAction, default=False,
                    help="MinHash 近重复检测（抓改几个字的转载/抄袭，默认关）")
    ap.add_argument("--near-dup-threshold", type=float, default=0.8,
                    help="近重复 Jaccard 相似度阈值")
    ap.add_argument("--pii", action=argparse.BooleanOptionalAction, default=False,
                    help="PII/密钥脱敏（手机号/身份证/银行卡/邮箱/key，默认关）")
    return ap.parse_args(argv)


def run(cfg) -> tuple[int, ShardWriter, Counter, Counter, Counter]:
    src, dst = Path(cfg.src), Path(cfg.dst)
    if not src.exists():
        print(f"[!] 找不到原始语料：{src}")
        print("    请先生成 data/raw_corpus.jsonl（每行一条 JSON），再运行本脚本")
        raise SystemExit(1)
    dst.parent.mkdir(parents=True, exist_ok=True)

    # ---- 去重结构
    seen: set[bytes] = set()
    bloom = None
    if cfg.dedup == "bloom":
        bloom = BloomFilter(cfg.bloom_mbytes * 8 * 1024 * 1024, cfg.bloom_hashes)
        print(f"[i] 布隆去重：{cfg.bloom_mbytes} MB / {cfg.bloom_hashes} 哈希，"
              f"恒定内存，存在极低误判率")

    def is_dup(key: bytes) -> bool:
        if cfg.dedup == "none":
            return False
        if bloom is not None:
            return not bloom.add_if_absent(key)
        if key in seen:
            return True
        seen.add(key)
        return False

    reasons: Counter = Counter()
    cjk_hist: Counter = Counter()
    total_stat: Counter = Counter()
    writer = ShardWriter(dst, cfg.shard_lines)
    kept = 0

    # ★编码自动探测：GBK/GB18030 语料不再被 replace 静默变乱码后整批误杀。
    from textio import open_text
    with open_text(src) as fh_in:
        batches = iter_batches(fh_in, cfg.chunk_size, cfg.limit)
        if cfg.workers > 1:
            with Pool(cfg.workers, initializer=_init_worker,
                      initargs=(cfg,)) as pool:
                results = pool.imap(_clean_batch_mp, batches, chunksize=1)
                kept = _consume(results, cfg, reasons, cjk_hist, total_stat,
                                writer, is_dup)
        else:
            results = (process_batch(b, cfg) for b in batches)
            kept = _consume(results, cfg, reasons, cjk_hist, total_stat,
                            writer, is_dup)

    writer.close()
    return kept, writer, reasons, cjk_hist, total_stat


def _consume(results, cfg, reasons, cjk_hist, total_stat, writer, is_dup) -> int:
    """主进程侧：汇总统计、去重（精确+可选近重复）、脱敏、写出。"""
    from textquality import MinHashLSH, redact_pii
    near = MinHashLSH(threshold=getattr(cfg, "near_dup_threshold", 0.8)) \
        if getattr(cfg, "near_dup", False) else None
    do_pii = getattr(cfg, "pii", False)
    kept = 0
    for records, stat in results:
        total_stat.update(stat)
        for kind, payload, reason, ratio in records:
            reasons[reason] += 1
            if kind == "drop":
                continue
            if kind == "text":
                # ★PII/密钥脱敏（可选开关）：在去重前替换，避免隐私进模型
                if do_pii:
                    payload["text"], n_pii = redact_pii(payload["text"])
                    if n_pii:
                        total_stat["pii_redacted"] += n_pii
                key_src = payload["text"]
            else:
                key_src = json.dumps(payload, sort_keys=True, ensure_ascii=False)
            key = blake2b(key_src.encode("utf-8"), digest_size=8).digest()
            if is_dup(key):
                reasons["duplicate"] += 1
                continue
            # ★MinHash 近重复（可选）：抓改几个字的转载/抄袭，精确去重抓不到
            if near is not None and kind == "text":
                if near.is_near_dup(key.hex(), payload["text"]):
                    reasons["near_duplicate"] += 1
                    continue
            # 直方图只统计真正保留的样本，与"保留"计数口径一致
            if ratio >= 0:
                for i in range(len(CJK_BUCKETS) - 1):
                    if CJK_BUCKETS[i] <= ratio < CJK_BUCKETS[i + 1]:
                        cjk_hist[i] += 1
                        break
            writer.write(payload)
            kept += 1
            if cfg.progress_every and kept % cfg.progress_every == 0:
                print(f"    ... 已保留 {kept} 条")
                # 语言无关标记：工坊进度条只认这行，不受日志语言影响
                print(f"@@WS kept {kept}", flush=True)
    return kept


def report(kept, writer, reasons, cjk_hist, total_stat, cfg, elapsed) -> None:
    total = total_stat["read"]
    pct = lambda c: (c / total * 100) if total else 0.0

    print("\n" + "=" * 64)
    print(f"输入行数         : {total}")
    print(f"保留             : {kept}  ({pct(kept):.2f}%)")
    # 语言无关标记：保留率告警只认这行，英文日志下同样生效
    print(f"@@WS input {total}", flush=True)
    print(f"@@WS kept_total {kept}", flush=True)
    print(f"空行             : {total_stat['blank_lines']}")
    print(f"救回的纯文本行   : {total_stat['salvaged_plain']}")
    print(f"非文本记录透传   : {total_stat['non_text_kept']}")
    print(f"删除的链接数     : {total_stat['links_removed']}")
    print(f"剔除的不可见字符 : {total_stat['invisible_chars']}")
    print("-" * 64)
    print("丢弃原因分布：")
    for reason, cnt in reasons.most_common():
        if reason == "ok":
            continue
        print(f"    {reason:<22} {cnt:>10}  ({pct(cnt):5.2f}%)")
    print("-" * 64)
    print("保留样本的 CJK 占比直方图（用于决定 --min-cjk-ratio）：")
    for i in range(len(CJK_BUCKETS) - 1):
        cnt = cjk_hist[i]
        bar = "#" * int(cnt / kept * 40) if kept else ""
        label = f"[{CJK_BUCKETS[i]:.1f}, {min(CJK_BUCKETS[i + 1], 1.0):.1f})"
        print(f"    {label:<12} {cnt:>10}  {bar}")
    print("-" * 64)
    if cfg.min_cjk_ratio == 0:
        print("[i] 当前未按语言过滤。若做纯中文预训练，可依据上面的直方图设置")
        print("    --min-cjk-ratio 0.3 左右，滤掉纯符号/纯外文噪声。")
    if cfg.dedup == "exact" and kept > 50_000_000:
        print("[i] exact 去重内存占用已较大，超大语料建议改用 --dedup bloom。")
    for p in writer.paths:
        size_mb = p.stat().st_size / 1024 / 1024
        print(f"[i] 输出: {p}  ({size_mb:.2f} MB)")
    speed = total / elapsed if elapsed > 0 else 0.0
    print(f"[i] 耗时 {elapsed:.1f}s，{speed:,.0f} 行/秒，workers={cfg.workers}")
    print("=" * 64)


def main(argv=None) -> int:
    cfg = parse_args(argv)
    t0 = time.time()
    kept, writer, reasons, cjk_hist, total_stat = run(cfg)
    report(kept, writer, reasons, cjk_hist, total_stat, cfg, time.time() - t0)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""mix_tokens.py —— 按 token 配比混合多类已打包语料

★为什么不能按文件体积配比：
    各类的压缩率与字节密度都不同（中文 3 字节/字符、代码约 1.05；
    实测压缩率 网页 0.588 / 百科 0.714 / 代码 0.659 / 问答 0.712）。
    按体积 50:20:15:15 混合，得到的 token 配比会严重偏离目标。
    本脚本一律以【token 数】为准。

★为什么要交错而不是首尾拼接：
    简单 concatenation 会让模型先学完一类再学下一类，破坏 i.i.d. 假设，
    造成灾难性遗忘。本脚本按 block 粒度轮转来源，保证局部多样性。

输入：各类 prepare_data.py 产出的 tokens_*.bin + data_meta.json
输出：混合后的 tokens_train.bin / tokens_val.bin / data_meta.json

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/mix_tokens.py \
        --source web=data\\mix\\web \
        --source wiki=data\\mix\\wiki \
        --source code=data\\mix\\code \
        --source qa=data\\mix\\qa \
        --ratio web=0.55,wiki=0.13,code=0.20,qa=0.12 \
        --target-tokens 60e9 --out-dir data\\final
    # 先看各类供给与缺口，不写出：
    python ... --dry-run
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
from pathlib import Path

import numpy as np

# 日志语言：默认中文，原样输出；仅当 LLM_LOG_LANG=en 时译为英文。
# ★不改动任何既有中文语句，查不到译文会退回中文，绝不丢日志。
try:
    from log_i18n import install as _install_log_lang
    _install_log_lang()
except Exception:
    pass


def parse_size(s: str) -> int:
    """支持 60e9 / 60B / 2.5e9 / 1000000 等写法。"""
    s = s.strip().upper().replace("_", "")
    mult = 1.0
    if s.endswith("T"):
        mult, s = 1e12, s[:-1]
    elif s.endswith("B"):
        mult, s = 1e9, s[:-1]
    elif s.endswith("M"):
        mult, s = 1e6, s[:-1]
    elif s.endswith("K"):
        mult, s = 1e3, s[:-1]
    return int(float(s) * mult)


def parse_args(argv=None):
    ap = argparse.ArgumentParser(
        description="按 token 配比交错混合多类已打包语料",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--source", action="append", required=True, metavar="NAME=DIR",
                    help="类别名=数据目录（含 tokens_train.bin 与 data_meta.json），可多次")
    ap.add_argument("--ratio", required=True,
                    help="目标配比，如 web=0.55,wiki=0.13,code=0.20,qa=0.12")
    ap.add_argument("--target-tokens", default="60e9",
                    help="混合后训练集总 token 目标，支持 60e9/60B 写法")
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--block-size", type=int, default=1024,
                    help="交错粒度：每多少个 token 轮换一次来源")
    ap.add_argument("--val-tokens", type=int, default=2_000_000,
                    help="验证集总 token 目标，按同一配比从各类 val 取")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--dry-run", action="store_true", help="只报告供给与缺口，不写出")
    ap.add_argument("--allow-insufficient", action="store_true",
                    help="某类不足时按实际量混合并重新归一化配比，而非报错")
    ap.add_argument("--no-cross-dedup", action="store_true",
                    help="关闭跨来源块级精确去重（默认开，重复块跳过）")
    return ap.parse_args(argv)


def load_source(name: str, d: Path) -> dict:
    meta_p = d / "data_meta.json"
    train_p = d / "tokens_train.bin"
    if not meta_p.exists() or not train_p.exists():
        raise FileNotFoundError(f"{name}: {d} 下缺 data_meta.json 或 tokens_train.bin")
    meta = json.loads(meta_p.read_text(encoding="utf-8"))
    dtype = np.dtype(meta["dtype"])
    train = np.memmap(str(train_p), dtype=dtype, mode="r")
    val_p = d / "tokens_val.bin"
    val = np.memmap(str(val_p), dtype=dtype, mode="r") if val_p.exists() else None
    return {"name": name, "dir": d, "meta": meta, "dtype": dtype,
            "train": train, "val": val,
            "n_train": len(train), "n_val": len(val) if val is not None else 0}


def plan_sources(sources: dict, ratio: dict, target: int, allow_short: bool):
    """计算各类应取多少 token，处理供给不足。"""
    plan = {}
    short = {}
    for name, r in ratio.items():
        want = int(target * r)
        have = sources[name]["n_train"]
        take = min(want, have)
        plan[name] = take
        if take < want:
            short[name] = (want, have)

    if short and not allow_short:
        return plan, short, False

    if short and allow_short:
        # ★保持配比、不静默重分配（用户拍板）：某类不足时只取该类实际量，
        #   缺口不补给其它类——那会悄悄改变数据分布。明确告警并报实际产量，
        #   由用户决定是否调整配比或补语料。
        total_have = sum(plan.values())
        print(f"[!] 以下类别供给不足，按实际量取用（配比不变，总量会低于目标）：")
        for name, (want, have) in short.items():
            print(f"    {name}: 需 {want:,}，仅有 {have:,}（缺 {want - have:,}）")
        print(f"    实际总产量 {total_have:,} / 目标 {target:,}"
              f"（{total_have / max(target, 1):.1%}）")
    return plan, short, True


def interleave_iter(plan: dict, block: int):
    """流式生成 (来源名, 起始偏移, 长度) 的交错序列。

    ★改为生成器：旧实现把全部块存成 Python 列表，60B token/块长1024
      约 5860 万条、占 7-8GB 内存，大目标直接 OOM（审计指出）。
      现在边算边吐，内存恒定 O(类别数)，与总量无关。
    ★信用累积改增量维护：旧实现每轮对每个来源重算 remain 之和，
      复杂度 O(块数×类别数)；现在用 running total + 增量信用，O(块数)。
      交错顺序与旧实现完全一致（最大余额法），不改变混合分布。
    """
    remain = {k: v for k, v in plan.items() if v > 0}
    offsets = {k: 0 for k in remain}
    total = sum(remain.values())
    if total == 0:
        return
    credit = {k: 0.0 for k in remain}
    while remain:
        for k in remain:
            credit[k] += block * remain[k] / total
        k = max(credit, key=lambda x: credit[x])
        n = min(block, remain[k])
        yield (k, offsets[k], n)
        offsets[k] += n
        remain[k] -= n
        credit[k] -= n
        total -= n
        if remain[k] <= 0:
            del remain[k]
            del credit[k]


def write_mix(sources: dict, seq, out_path: Path, dtype,
              total_hint: int = 0, progress_every: int = 5_000_000,
              dedup: bool = False, block: int = 0):
    """按交错序列流式写出混合 bin，带进度标记。返回 (written, dup_skipped)。

    ★写盘阶段可达数十分钟，旧实现无任何输出，界面进度条冻结像卡死。
      现在每写 progress_every 个 token 打一条 @@WS 标记（语言无关）。
    ★跨源去重（dedup=True）：按整块 token 序列的 blake2b 哈希跨来源精确去重，
      重复块跳过（审计指出旧实现只类内去重、类间重复会重复训练）。
      只存 16 字节摘要/块，内存远小于存全部块；非整块尾段不参与去重。
    """
    import hashlib
    written = 0
    dup = 0
    seen: set = set()
    next_mark = progress_every
    with out_path.open("wb") as fh:
        for name, off, n in seq:
            arr = np.asarray(sources[name]["train"][off:off + n], dtype=dtype)
            if dedup and block and n == block:
                h = hashlib.blake2b(arr.tobytes(), digest_size=16).digest()
                if h in seen:
                    dup += n
                    continue
                seen.add(h)
            fh.write(arr.tobytes())
            written += n
            if progress_every and written >= next_mark:
                pct = (written / total_hint * 100) if total_hint else 0
                print(f"@@WS mix_written {written} {pct:.1f}", flush=True)
                next_mark += progress_every
    return written, dup


def _tok_fp(d: Path) -> str | None:
    """打包数据所用分词器的内容指纹（与 imports.tokenizer_fingerprint 同口径）。

    ★只比 vocab_size 不够：两套词表大小相同但 token→id 映射不同时，
      混出来的数据 embedding 全部错位，模型静默变废（审计指出）。
      指纹覆盖 vocab/merges/added_tokens/normalizer/pre_tokenizer。
    """
    f = Path(d) / "tokenizer.json"
    if not f.exists():
        return None
    try:
        tj = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    model = tj.get("model") or {}
    vocab = model.get("vocab")
    if isinstance(vocab, dict):
        payload = json.dumps(sorted(vocab.items(), key=lambda kv: kv[0]),
                             ensure_ascii=False, separators=(",", ":"))
    elif isinstance(vocab, list):
        payload = json.dumps(vocab, ensure_ascii=False, separators=(",", ":"))
    else:
        try:
            return hashlib.sha256(f.read_bytes()).hexdigest()[:16]
        except OSError:
            return None
    payload += "|" + json.dumps(model.get("merges") or [],
                                ensure_ascii=False, separators=(",", ":"))
    for key in ("added_tokens", "normalizer", "pre_tokenizer", "post_processor", "decoder"):
        payload += "|" + json.dumps(tj.get(key), ensure_ascii=False,
                                    separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def main(argv=None) -> int:
    args = parse_args(argv)
    target = parse_size(args.target_tokens)

    sources = {}
    for item in args.source:
        if "=" not in item:
            print(f"[!] --source 格式应为 NAME=DIR，收到：{item}")
            return 1
        name, d = item.split("=", 1)
        sources[name.strip()] = load_source(name.strip(), Path(d.strip()))

    ratio = {}
    for kv in args.ratio.split(","):
        if "=" not in kv:
            print(f"[!] --ratio 格式应为 name=frac，收到：{kv}")
            return 1
        k, v = kv.split("=", 1)
        ratio[k.strip()] = float(v)

    missing = set(ratio) - set(sources)
    if missing:
        print(f"[!] 配比里有未提供数据的类别：{sorted(missing)}")
        return 1
    s = sum(ratio.values())
    if abs(s - 1.0) > 1e-6:
        print(f"[i] 配比之和 {s:.6f} ≠ 1，自动归一化")
        ratio = {k: v / s for k, v in ratio.items()}

    # dtype 一致性检查
    dtypes = {v["dtype"].name for v in sources.values()}
    if len(dtypes) > 1:
        print(f"[!] 各类 dtype 不一致：{dtypes}，无法混合。请用同一分词器打包。")
        return 1
    dtype = next(iter(sources.values()))["dtype"]
    vocabs = {v["meta"].get("vocab_size") for v in sources.values()}
    if len(vocabs) > 1:
        print(f"[!] 各类 vocab_size 不一致：{vocabs}，必须用同一分词器。")
        return 1
    # ★词表内容指纹一致性：大小相同但映射不同的两套词表混在一起，
    #   token 编号会错位、模型静默变废。meta 里带指纹时逐类比对。
    fps = {v["meta"].get("tokenizer_fp") for v in sources.values()
           if v["meta"].get("tokenizer_fp")}
    if len(fps) > 1:
        print(f"[!] 各类分词器内容指纹不一致：{fps}。"
              "词表大小相同不代表编号映射相同，必须用同一分词器打包。")
        return 1

    print("=" * 74)
    print(f"目标总量 {target:,} token   交错粒度 {args.block_size}   dtype {dtype.name}")
    print("-" * 74)
    print(f"{'类别':<10}{'目标占比':>9}{'目标token':>15}{'实际供给':>15}{'可取':>15}{'状态':>8}")

    plan, short, ok = plan_sources(sources, ratio, target, args.allow_insufficient)
    for name, r in ratio.items():
        want = int(target * r)
        have = sources[name]["n_train"]
        take = plan[name]
        flag = "OK" if take >= want else "不足"
        print(f"{name:<10}{r:>8.1%}{want:>15,}{have:>15,}{take:>15,}{flag:>8}")

    if short and not ok:
        print("-" * 74)
        print("[!] 以下类别供给不足：")
        for name, (want, have) in short.items():
            print(f"    {name}: 需 {want:,}，仅有 {have:,}（缺 {want - have:,}）")
        print("\n    处置：补下载该类语料，或降低其配比，")
        print("    或加 --allow-insufficient 按实际供给混合（总量会低于目标）。")
        print("=" * 74)
        return 2

    actual_total = sum(plan.values())
    print("-" * 74)
    print(f"{'合计':<10}{'100.0%':>9}{target:>15,}"
          f"{sum(v['n_train'] for v in sources.values()):>15,}{actual_total:>15,}")
    print("\n实际混合配比：")
    for name in ratio:
        print(f"    {name:<10} {plan[name] / max(actual_total, 1):>7.2%}  "
              f"({plan[name]:,} token)")

    if args.dry_run:
        print("\n[i] --dry-run：仅报告，未写出任何文件")
        print("=" * 74)
        return 0

    if not args.out_dir:
        print("[!] 非 dry-run 模式必须指定 --out-dir")
        return 1
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ★磁盘预检：混合产物≈实际总量×itemsize，不够就提前报错，
    #   而不是写到一半磁盘满留下半成品（审计指出）。
    need = actual_total * dtype.itemsize + 64 * 1024 ** 2
    try:
        free = shutil.disk_usage(str(out_dir)).free
        if free < need:
            print(f"[!] 磁盘空间不足：约需 {need / 1024 ** 3:.1f}GB，"
                  f"剩余 {free / 1024 ** 3:.1f}GB")
            return 1
    except OSError:
        pass

    t0 = time.time()
    # ★原子产物：先写临时目录，全部落盘且校验一致后再整体切换。
    #   旧实现先截断 bin、最后写 meta，中途失败留下「旧 meta+残缺 bin」，
    #   训练会读越界或静默用坏数据（审计指出）。
    tmp = out_dir / f".mix_tmp_{os.getpid()}"
    if tmp.exists():
        shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)

    n_blocks_est = (actual_total + args.block_size - 1) // args.block_size
    print(f"\n[i] 预计交错块数 {n_blocks_est:,}，开始流式写出…")
    train_tmp = tmp / "tokens_train.bin"
    written, dup = write_mix(sources, interleave_iter(plan, args.block_size),
                             train_tmp, dtype, total_hint=actual_total,
                             dedup=not args.no_cross_dedup, block=args.block_size)
    if dup:
        print(f"[i] 跨源去重：跳过重复块 {dup:,} token（实际写出 {written:,}）")

    # 验证集：按同配比从各类 val 取，同样流式交错
    val_plan = {}
    for name, r in ratio.items():
        want = int(args.val_tokens * r)
        val_plan[name] = min(want, sources[name]["n_val"])
    val_tmp = tmp / "tokens_val.bin"
    val_written = 0
    with val_tmp.open("wb") as fh:
        for name, off, n in interleave_iter(val_plan, args.block_size):
            arr = sources[name]["val"][off:off + n]
            fh.write(np.asarray(arr, dtype=dtype).tobytes())
            val_written += n

    # 去重会合法地减少写出量，故核对「写出+去重=计划」而非仅写出=计划
    if written + dup != actual_total:
        print(f"[!] ★写出 {written:,}+去重 {dup:,} 与计划 {actual_total:,} 不符，保留临时目录供排查")
        return 1

    meta = {
        "dtype": dtype.name,
        "itemsize": dtype.itemsize,
        "vocab_size": next(iter(sources.values()))["meta"].get("vocab_size"),
        "tokenizer_fp": next(iter(sources.values()))["meta"].get("tokenizer_fp"),
        "train_tokens": int(written),
        "val_tokens": int(val_written),
        "target_tokens": int(target),
        "block_size": args.block_size,
        "ratio_target": ratio,
        "ratio_actual": {k: plan[k] / max(actual_total, 1) for k in ratio},
        "per_source_tokens": {k: int(v) for k, v in plan.items()},
        "sources": {k: str(v["dir"]) for k, v in sources.items()},
        "seed": args.seed,
        "short": {k: {"want": w, "have": h} for k, (w, h) in short.items()},
    }
    (tmp / "data_meta.json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    # 原子切换：临时目录里的三个文件逐个 replace 到正式位置。
    # replace 是同盘原子操作；meta 最后落，确保「meta 存在即数据完整」。
    for fn in ("tokens_train.bin", "tokens_val.bin"):
        (tmp / fn).replace(out_dir / fn)
    (tmp / "data_meta.json").replace(out_dir / "data_meta.json")
    shutil.rmtree(tmp, ignore_errors=True)
    train_path = out_dir / "tokens_train.bin"
    val_path = out_dir / "tokens_val.bin"

    el = time.time() - t0
    print("-" * 74)
    print(f"[i] {train_path}  ({train_path.stat().st_size / 1024 ** 3:.2f} GB, {written:,} token)")
    print(f"[i] {val_path}  ({val_path.stat().st_size / 1024 ** 2:.1f} MB, {val_written:,} token)")
    print(f"[i] 耗时 {el:.1f}s")
    print("[i] ✓ 写出量与计划一致")
    if short:
        print(f"[!] 注意：{len(short)} 类供给不足，实际产量 {written:,} 低于目标 {target:,}，"
              "配比未变。如需达标请补语料或调整配比。")
    print("=" * 74)
    return 0


if __name__ == "__main__":
    sys.exit(main())

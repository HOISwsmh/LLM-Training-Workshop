# -*- coding: utf-8 -*-
"""文本质量增强：MinHash 近重复检测、PII/密钥脱敏、文档稳定 hash。

零第三方依赖。供 clean_data / prepare_data 调用。
- MinHashLSH：字符 n-gram 的 MinHash 签名 +  banding LSH，识别「高度相似」
  文档（转载/改几个字的抄袭），弥补精确去重只认完全相同的不足。
- 文档 hash：blake2b(归一化文本)，用于 train/val 按文档划分防泄漏。
- PII/密钥脱敏：手机号/身份证/银行卡/邮箱/API key 等正则替换为占位符。
"""
from __future__ import annotations

import re
from hashlib import blake2b

# ---------------------------------------------------------------- 文档 hash


def doc_hash(text: str) -> str:
    """归一化（去空白）后的稳定文档指纹，用于划分 train/val 防泄漏。"""
    norm = re.sub(r"\s+", "", text)
    return blake2b(norm.encode("utf-8"), digest_size=16).hexdigest()


def split_by_hash(text: str, val_ratio: float = 0.005) -> str:
    """按文档 hash 决定 train/val：同一文档（及完全相同副本）必落同一侧。

    用 hash 前 8 位映射到 [0,1)，小于 val_ratio 进 val。确定性、可复现，
    不依赖样本顺序，避免等距抽样把同文档拆到两侧造成泄漏。
    """
    h = doc_hash(text)
    frac = int(h[:8], 16) / 0xFFFFFFFF
    return "val" if frac < val_ratio else "train"


# ---------------------------------------------------------------- MinHash LSH


def _shingles(text: str, n: int = 5) -> set:
    norm = re.sub(r"\s+", "", text)
    if len(norm) < n:
        return {norm} if norm else set()
    return {norm[i:i + n] for i in range(len(norm) - n + 1)}


class MinHashLSH:
    """字符 n-gram MinHash + banding LSH 近重复索引。

    num_perm 个哈希函数（双哈希派生），bands×rows=num_perm。
    两文档 Jaccard 相似度高于阈值时大概率落入同一桶被判近重复。
    内存 O(文档数×bands)，远小于存全文。
    """

    def __init__(self, num_perm: int = 64, bands: int = 16, threshold: float = 0.8):
        self.num_perm = num_perm
        self.bands = bands
        self.rows = max(1, num_perm // bands)
        self.threshold = threshold
        self._buckets: list = [{} for _ in range(bands)]
        self._sigs: dict = {}

    def _signature(self, text: str):
        sh = _shingles(text)
        if not sh:
            return None
        hs = [int.from_bytes(blake2b(s.encode("utf-8"), digest_size=8).digest(), "big")
              for s in sh]
        sig = []
        for i in range(self.num_perm):
            # 双哈希派生第 i 个置换：(a*h+b) mod 大素数
            a = (i * 2 + 1) & 0xFFFFFFFFFFFFFFFF
            b = (i * 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
            sig.append(min(((a * h + b) & 0xFFFFFFFFFFFFFFFF) for h in hs))
        return sig

    def is_near_dup(self, key: str, text: str) -> bool:
        """判定 text 是否与已索引文档近重复；不重复则索引它。"""
        sig = self._signature(text)
        if sig is None:
            return False
        # 先查 LSH 桶候选
        cand = set()
        for bi in range(self.bands):
            band = tuple(sig[bi * self.rows:(bi + 1) * self.rows])
            bucket = self._buckets[bi].get(band)
            if bucket:
                cand.update(bucket)
        for ck in cand:
            other = self._sigs.get(ck)
            if other is None:
                continue
            agree = sum(1 for x, y in zip(sig, other) if x == y)
            if agree / self.num_perm >= self.threshold:
                return True
        # 不重复：索引
        self._sigs[key] = sig
        for bi in range(self.bands):
            band = tuple(sig[bi * self.rows:(bi + 1) * self.rows])
            self._buckets[bi].setdefault(band, []).append(key)
        return False


# ---------------------------------------------------------------- PII 脱敏

_PII_PATTERNS = [
    (re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)"), "[手机号]"),
    (re.compile(r"(?<!\d)\d{17}[\dXx](?!\d)"), "[身份证]"),
    (re.compile(r"(?<!\d)\d{16,19}(?!\d)"), "[银行卡]"),
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+"), "[邮箱]"),
    (re.compile(r"(?i)(?:api[_-]?key|secret[_-]?key|access[_-]?key|token)\s*[:=]\s*['\"]?[\w\-\.]{16,}"), "[密钥]"),
    (re.compile(r"(?i)(?:sk|ak|pk)-[A-Za-z0-9]{20,}"), "[密钥]"),
    (re.compile(r"eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}"), "[JWT]"),
]


def redact_pii(text: str) -> tuple[str, int]:
    """替换 PII/密钥为占位符，返回 (脱敏文本, 命中数)。"""
    n = 0
    for pat, repl in _PII_PATTERNS:
        text, c = pat.subn(repl, text)
        n += c
    return text, n

# -*- coding: utf-8 -*-
"""文本读取编码探测：避免 GBK/GB18030 语料被 errors=replace 静默替换成乱码。

★旧实现全链 utf-8-sig + errors=replace，非 UTF-8 语料（常见 GBK 小说/论坛存档）
  会变成 U+FFFD，再被低中文比例规则整批误杀，用户只看到「清洗后只剩几条」却不知
  原因（审计指出）。这里先采样探测编码：能严格 UTF-8 解码就用 UTF-8；否则尝试
  GB18030（GBK 超集），成功则用之；都不行才回退 replace 并计数告警。
"""
from __future__ import annotations

import gzip
from pathlib import Path

_SAMPLE = 256 * 1024


def detect_encoding(path: Path) -> str:
    """采样探测文件编码，返回可直接用于 open 的 encoding 名。"""
    opener = gzip.open if path.suffix == ".gz" else open
    try:
        with opener(path, "rb") as fh:
            sample = fh.read(_SAMPLE)
    except OSError:
        return "utf-8-sig"
    if not sample:
        return "utf-8-sig"
    # 先试严格 UTF-8（兼容 BOM）：成功即 UTF-8
    try:
        sample.decode("utf-8-sig")
        return "utf-8-sig"
    except UnicodeDecodeError:
        pass
    # 再试 GB18030（GBK/GB2312 超集）：中文旧存档最常见
    try:
        sample.decode("gb18030")
        return "gb18030"
    except UnicodeDecodeError:
        pass
    return "utf-8-sig"   # 回退：配合 errors=replace，坏字节计数告警


def open_text(path: Path, mode: str = "rt"):
    """按探测编码打开文本文件；非 UTF-8 时打印一次提示。"""
    enc = detect_encoding(path)
    if enc != "utf-8-sig":
        print(f"[i] 检测到非 UTF-8 编码（{enc}），已自动转码读取：{Path(path).name}")
    opener = gzip.open if Path(path).suffix == ".gz" else open
    return opener(path, mode, encoding=enc, errors="replace")

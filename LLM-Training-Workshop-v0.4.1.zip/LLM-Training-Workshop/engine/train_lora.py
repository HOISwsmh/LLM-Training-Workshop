# -*- coding: utf-8 -*-
"""train_lora.py —— LoRA 低秩适配微调：冻结主权重，只训低秩适配器。

显存省（不存主权重优化器态/梯度），可叠加多个适配器。零第三方依赖：
自研 LoRA 层包裹 nn.Linear（q/k/v/o/gate/up/down），r 默认 16。
复用 train_model 断点/暂停/尖刺组件；断点只存适配器权重+优化器态。

运行：
    python engine/train_lora.py --base-dir output/3b_model/final \
        --data data/sft.jsonl --out-dir output/lora --r 16 --max-steps 2000
合并导出：--merge 把适配器并入主权重存完整 HF 模型（供 GGUF 转换）。
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from pathlib import Path

import torch
import torch.nn as nn
from transformers import AutoTokenizer, AutoModelForCausalLM, Adafactor

sys.path.insert(0, str(Path(__file__).resolve().parent))
import train_model as TM
import train_sft as SFT

try:
    from log_i18n import install as _install_log_lang
    _install_log_lang()
except Exception:
    pass


class LoRALinear(nn.Module):
    """包裹 nn.Linear：output = base(x) + (x @ A^T @ B^T) * scale。

    base 冻结；A/B 可训。A 高斯初始化、B 零初始化 → 初始等价 base。
    """

    def __init__(self, base: nn.Linear, r: int, alpha: float):
        super().__init__()
        self.base = base
        for p in self.base.parameters():
            p.requires_grad = False
        self.r = r
        self.scale = alpha / r
        self.lora_A = nn.Parameter(torch.zeros(r, base.in_features))
        self.lora_B = nn.Parameter(torch.zeros(base.out_features, r))
        nn.init.kaiming_uniform_(self.lora_A, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B)

    def forward(self, x):
        out = self.base(x)
        lora = (x @ self.lora_A.t() @ self.lora_B.t()) * self.scale
        return out + lora.to(out.dtype)


TARGET_MODULES = ("q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj")


def inject_lora(model, r: int, alpha: float) -> int:
    n = 0
    for name, module in list(model.named_modules()):
        for child_name, child in list(module.named_children()):
            if child_name in TARGET_MODULES and isinstance(child, nn.Linear):
                setattr(module, child_name, LoRALinear(child, r, alpha))
                n += 1
    return n


def lora_state_dict(model) -> dict:
    return {k: v for k, v in model.state_dict().items() if "lora_" in k}


def load_lora_state(model, state: dict):
    model.load_state_dict(state, strict=False)


def merge_lora(model):
    """把适配器并入 base 权重，移除 LoRA 包裹（导出完整模型用）。"""
    for name, module in list(model.named_modules()):
        for child_name, child in list(module.named_children()):
            if isinstance(child, LoRALinear):
                w = child.base.weight
                delta = (child.lora_B @ child.lora_A) * child.scale
                w.data += delta.to(w.dtype)
                for p in child.base.parameters():
                    p.requires_grad = True
                setattr(module, child_name, child.base)


def parse_args():
    ap = argparse.ArgumentParser(description="LoRA 低秩适配微调")
    ap.add_argument("--base-dir", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--r", type=int, default=16)
    ap.add_argument("--alpha", type=float, default=32)
    ap.add_argument("--block-size", type=int, default=2048)
    ap.add_argument("--batch-size", type=int, default=4)
    ap.add_argument("--grad-accum", type=int, default=4)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--max-steps", type=int, default=2000)
    ap.add_argument("--warmup-steps", type=int, default=100)
    ap.add_argument("--save-every", type=int, default=200)
    ap.add_argument("--log-every", type=int, default=10)
    ap.add_argument("--keep-checkpoints", type=int, default=3)
    ap.add_argument("--master-dtype", choices=("fp32", "bf16"), default="bf16")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--merge", action="store_true", help="训练后合并适配器导出完整HF模型")
    ap.add_argument("--no-spike-guard", action="store_true")
    ap.add_argument("--spike-abs", type=float, default=20.0)
    ap.add_argument("--spike-ratio", type=float, default=3.0)
    ap.add_argument("--spike-window", type=int, default=50)
    ap.add_argument("--spike-rollback-after", type=int, default=5)
    ap.add_argument("--spike-lr-decay", type=float, default=0.5)
    ap.add_argument("--spike-max-rollbacks", type=int, default=3)
    ap.add_argument("--backup-dir", default=None)
    ap.add_argument("--backup-every", type=int, default=0)
    ap.add_argument("--keep-backups", type=int, default=3)
    ap.add_argument("--optimizer", default="adafactor")
    ap.add_argument("--weight-decay", type=float, default=0.0)
    ap.add_argument("--grad-clip", type=float, default=1.0)
    ap.add_argument("--min-lr-ratio", type=float, default=0.1)
    ap.add_argument("--decay-steps", type=int, default=0)
    ap.add_argument("--log-csv", default=None)
    ap.add_argument("--num-workers", type=int, default=0)
    ap.add_argument("--no-checkpointing", action="store_true")
    ap.add_argument("--tier", default="lora")
    return ap.parse_args()


def save_lora_checkpoint(model, tokenizer, optimizer, step, out_dir, args,
                         best=False, final=False, extra_state=None):
    name = "best" if best else ("final" if final else f"checkpoint-{step}")
    target = out_dir / name
    tmp = TM._atomic_dir(target)
    torch.save(lora_state_dict(model), tmp / "adapter.pt")
    torch.save(optimizer.state_dict(), tmp / "optimizer.pt")
    tokenizer.save_pretrained(str(tmp))
    (tmp / "trainer_state.json").write_text(json.dumps(
        {"global_step": step, "r": args.r, "alpha": args.alpha, "tier": args.tier,
         # ★续训保全字段：缺了它们续训会复原 LR、绕过止损计数
         **(extra_state or {})},
        ensure_ascii=False, indent=2), encoding="utf-8")
    (tmp / "lora_config.json").write_text(json.dumps(
        {"r": args.r, "alpha": args.alpha, "base": args.base_dir},
        ensure_ascii=False, indent=2), encoding="utf-8")
    TM._commit_dir(tmp, target)
    print(f"    [保存] {target}")


def load_latest_lora_checkpoint(out_dir: Path):
    """取最新的【完整】LoRA 编号断点（adapter.pt + trainer_state.json 齐全）。

    ★TM.checkpoint_complete 查的是 base 模型权重文件，LoRA 断点只有 adapter.pt，
      不能复用；这里按 LoRA 自己的产物验完整性，残缺的跳过。
    """
    cks = sorted(out_dir.glob("checkpoint-*"),
                 key=lambda p: int(p.name.split("-")[1]) if p.name.split("-")[1].isdigit() else -1)
    for c in reversed(cks):
        ap = c / "adapter.pt"
        if ap.exists() and ap.stat().st_size > 0 and (c / "trainer_state.json").exists():
            return c
        print(f"[!] LoRA 断点 {c.name} 不完整（可能写入中断），已跳过")
    return None


def main() -> int:
    args = parse_args()
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    master_dtype = torch.float32 if args.master_dtype == "fp32" else torch.bfloat16

    tokenizer = AutoTokenizer.from_pretrained(args.base_dir)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    missing = [t for t in (SFT.USER_START, SFT.ASSISTANT_START, SFT.TURN_END)
               if t not in tokenizer.get_vocab()]
    if missing:
        tokenizer.add_special_tokens({"additional_special_tokens": missing})

    dialogs = SFT.load_dialogs(Path(args.data))
    if not dialogs:
        print("[!] 没有可用对话样本")
        return 1
    print(f"[i] LoRA 样本 {len(dialogs)} 条，r={args.r}")

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ★续训接线：旧实现 --resume 只续 CSV 日志，适配器/优化器/步数全从 0 开始。
    #   现在从最新完整 LoRA 断点恢复适配器权重+优化器+步数+lr_scale/止损计数。
    resume_from = None
    if args.resume:
        resume_from = load_latest_lora_checkpoint(out_dir)
        if resume_from is None:
            print(f"[i] {out_dir} 下没有完整 LoRA checkpoint-*，将从头开始")

    model = AutoModelForCausalLM.from_pretrained(args.base_dir, dtype=master_dtype)
    if missing:
        model.resize_token_embeddings(len(tokenizer))
    n_lora = inject_lora(model, args.r, args.alpha)
    # ★先注入 LoRA 再恢复适配器权重：state_dict 的键含 lora_ 包裹层，
    #   必须在注入后加载才对得上。
    if resume_from is not None:
        try:
            adapter = torch.load(resume_from / "adapter.pt", map_location="cpu", weights_only=True)
            load_lora_state(model, adapter)
            print(f"[i] LoRA 从检查点续训：{resume_from}（适配器已恢复）")
        except (OSError, RuntimeError, ValueError) as e:
            print(f"[!] 适配器恢复失败（{type(e).__name__}），按新适配器继续")
            resume_from = None
    model = model.to(device)
    # 只训 LoRA 参数
    trainable = [p for p in model.parameters() if p.requires_grad]
    print(f"[i] 注入 LoRA 层 {n_lora} 个，可训参数 {sum(p.numel() for p in trainable):,}")
    if not args.no_checkpointing:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        model.config.use_cache = False

    stop_flag = out_dir / "STOP_REQUESTED"
    if stop_flag.exists():
        stop_flag.unlink()

    optimizer = Adafactor(trainable, lr=args.lr, scale_parameter=False,
                          relative_step=False, warmup_init=False,
                          weight_decay=args.weight_decay, clip_threshold=1.0,
                          decay_rate=-0.8, beta1=None)

    step = micro_step = 0
    tokens_seen = tokens_at_log = 0
    running = running_micro = 0.0
    lr_scale = 1.0
    best_val = float("inf")
    rollbacks = 0
    if resume_from is not None:
        opt_p = resume_from / "optimizer.pt"
        if opt_p.exists():
            try:
                optimizer.load_state_dict(torch.load(opt_p, map_location=device, weights_only=True))
            except (OSError, RuntimeError, ValueError) as e:
                print(f"[!] 优化器状态恢复失败（{type(e).__name__}），按新优化器继续")
        st_p = resume_from / "trainer_state.json"
        if st_p.exists():
            try:
                st = json.loads(st_p.read_text(encoding="utf-8"))
                step = int(st.get("global_step", 0))
                best_val = float(st.get("best_val", float("inf")))
                lr_scale = float(st.get("lr_scale", 1.0))
                rollbacks = int(st.get("rollbacks", 0))
                print(f"[i] 已恢复步数 {step}，lr_scale={lr_scale}")
            except (OSError, ValueError):
                print("[!] trainer_state.json 损坏，步数从 0 计")

    logger = TM.CsvLogger(Path(args.log_csv) if args.log_csv else out_dir / "train_log.csv",
                          resume=(resume_from is not None))
    guard = TM.SpikeGuard(args)
    guard.rollbacks = rollbacks

    t0 = time.time()
    import random
    rng = random.Random(args.seed)

    try:
        while step < args.max_steps:
            rng.shuffle(dialogs)
            for i in range(0, len(dialogs), args.batch_size):
                if step >= args.max_steps:
                    break
                batch = dialogs[i:i + args.batch_size]
                x, y = SFT.build_sft_batch(batch, tokenizer, args.block_size, device)
                lr = TM.lr_at(step, args) * lr_scale
                for g in optimizer.param_groups:
                    g["lr"] = lr
                with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
                    loss = model(x, labels=y).loss
                real_loss = loss.item()
                if guard.check(real_loss) is not None:
                    optimizer.zero_grad(set_to_none=True)
                    micro_step = 0
                    running = running_micro = 0.0
                    logger.log("event", step=step, loss=real_loss, note="spike_skip")
                    continue
                (loss / args.grad_accum).backward()
                running += real_loss
                running_micro += 1
                tokens_seen += int((y != -100).sum().item())
                micro_step += 1
                if micro_step % args.grad_accum == 0:
                    if args.grad_clip > 0:
                        torch.nn.utils.clip_grad_norm_(trainable, args.grad_clip)
                    optimizer.step()
                    optimizer.zero_grad(set_to_none=True)
                    step += 1
                    if step % args.log_every == 0:
                        avg = running / max(running_micro, 1)
                        el = time.time() - t0
                        tps = (tokens_seen - tokens_at_log) / el if el > 0 else 0
                        print(f"step {step:>7,}/{args.max_steps:,} | loss {avg:.4f} "
                              f"| lr {lr:.2e} | {tps:,.0f} tok/s")
                        logger.log("train", step=step, tokens_seen=tokens_seen,
                                   loss=round(avg, 6), lr=lr, tok_s=round(tps, 1),
                                   elapsed_s=round(el, 3))
                        running = running_micro = 0.0
                        tokens_at_log = tokens_seen
                        t0 = time.time()
                    if step % args.save_every == 0:
                        save_lora_checkpoint(model, tokenizer, optimizer, step, out_dir, args,
                                             extra_state={"best_val": best_val, "lr_scale": lr_scale,
                                                          "rollbacks": guard.rollbacks})
                        TM.prune_checkpoints(out_dir, args.keep_checkpoints)
                    if stop_flag.exists():
                        raise TM.StopRequested()
                    if step >= args.max_steps:
                        break
    except TM.StopRequested:
        save_lora_checkpoint(model, tokenizer, optimizer, step, out_dir, args,
                             extra_state={"best_val": best_val, "lr_scale": lr_scale,
                                          "rollbacks": guard.rollbacks})
        if stop_flag.exists():
            stop_flag.unlink()
        logger.log("event", step=step, note="paused_by_request")
        logger.close()
        print(f"[i] LoRA 已暂停并保存断点 checkpoint-{step}")
        return 131
    except torch.cuda.OutOfMemoryError:
        print("[!] 显存不足（CUDA OOM），LoRA 中止。减小 batch-size/r 后从断点续训。")
        logger.log("event", step=step, note="cuda_oom")
        logger.close()
        return 5

    save_lora_checkpoint(model, tokenizer, optimizer, step, out_dir, args, final=True,
                         extra_state={"best_val": best_val, "lr_scale": lr_scale,
                                      "rollbacks": guard.rollbacks})
    if args.merge:
        merge_lora(model)
        merged = out_dir / "merged"
        model.save_pretrained(str(merged), max_shard_size="5GB")
        tokenizer.save_pretrained(str(merged))
        print(f"[i] 已合并适配器导出完整模型：{merged}")
    logger.log("event", step=step, note="done")
    logger.close()
    print(f"[i] LoRA 完成：{step} 步，适配器保存到 {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

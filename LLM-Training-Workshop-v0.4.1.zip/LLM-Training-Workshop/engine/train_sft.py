# -*- coding: utf-8 -*-
"""train_sft.py —— 指令微调（SFT）：教 base 模型按问答格式回应。

与预训练的本质区别：**只监督回答段**（prompt 与 padding 置 -100 不计损失）。
复用 train_model 的断点原子写/暂停/尖刺防护/CSV 日志组件，不另起一套。

输入：jsonl 对话，支持 messages / instruction-output / prompt-completion 三种格式。
产出：标准 HF base+chat 权重（可再转 GGUF）。

运行：
    python engine/train_sft.py --base-dir output/3b_model/final \
        --data data/sft.jsonl --out-dir output/sft --max-steps 2000
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from pathlib import Path

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, Adafactor

sys.path.insert(0, str(Path(__file__).resolve().parent))
import train_model as TM  # 复用断点/日志/尖刺组件

try:
    from log_i18n import install as _install_log_lang
    _install_log_lang()
except Exception:
    pass

ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent)

# 对话模板标记（与 mm_tokens 口径一致，用拼接避免同形字符损坏）
USER_START = "<" + "|user|" + ">"
ASSISTANT_START = "<" + "|assistant|" + ">"
TURN_END = "<" + "|turn_end|" + ">"


def parse_args():
    ap = argparse.ArgumentParser(description="指令微调（SFT）")
    ap.add_argument("--base-dir", required=True, help="base 模型目录（预训练 final/best）")
    ap.add_argument("--data", required=True, help="对话 jsonl")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--block-size", type=int, default=2048)
    ap.add_argument("--batch-size", type=int, default=2)
    ap.add_argument("--grad-accum", type=int, default=8)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--max-steps", type=int, default=2000)
    ap.add_argument("--warmup-steps", type=int, default=100)
    ap.add_argument("--save-every", type=int, default=200)
    ap.add_argument("--eval-every", type=int, default=200)
    ap.add_argument("--log-every", type=int, default=10)
    ap.add_argument("--keep-checkpoints", type=int, default=3)
    ap.add_argument("--master-dtype", choices=("fp32", "bf16"), default="bf16")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--no-spike-guard", action="store_true")
    ap.add_argument("--spike-abs", type=float, default=20.0)
    ap.add_argument("--spike-ratio", type=float, default=3.0)
    ap.add_argument("--spike-window", type=int, default=50)
    ap.add_argument("--spike-rollback-after", type=int, default=5)
    ap.add_argument("--spike-lr-decay", type=float, default=0.5)
    ap.add_argument("--spike-max-rollbacks", type=int, default=3)
    ap.add_argument("--backup-dir", default=None)
    ap.add_argument("--backup-every", type=int, default=0)
    ap.add_argument("--keep-backups", type=int, default=3)
    ap.add_argument("--optimizer", default="adafactor")
    ap.add_argument("--weight-decay", type=float, default=0.0)
    ap.add_argument("--grad-clip", type=float, default=1.0)
    ap.add_argument("--min-lr-ratio", type=float, default=0.1)
    ap.add_argument("--decay-steps", type=int, default=0)
    ap.add_argument("--log-csv", default=None)
    ap.add_argument("--num-workers", type=int, default=0)
    ap.add_argument("--no-checkpointing", action="store_true")
    ap.add_argument("--tier", default="sft")
    return ap.parse_args()


def load_dialogs(path: Path) -> list:
    """读对话 jsonl，归一化为 [(prompt, response)]。"""
    out = []
    with open(path, "r", encoding="utf-8-sig", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                o = json.loads(line)
            except ValueError:
                continue
            if not isinstance(o, dict):
                continue
            if "messages" in o and isinstance(o["messages"], list):
                # 多轮：把历史 user/assistant 拼成 prompt，最后 assistant 为 response
                msgs = o["messages"]
                prompt_parts, resp = [], ""
                for m in msgs:
                    role, content = m.get("role", ""), m.get("content", "")
                    if role == "assistant":
                        resp = content
                    else:
                        prompt_parts.append(f"{USER_START}{content}{TURN_END}")
                if resp:
                    out.append(("".join(prompt_parts) + ASSISTANT_START, resp + TURN_END))
            elif "instruction" in o:
                inp = o.get("input", "")
                q = o["instruction"] + ("\n" + inp if inp else "")
                out.append((USER_START + q + TURN_END + ASSISTANT_START,
                            o.get("output", "") + TURN_END))
            elif "prompt" in o:
                out.append((USER_START + o["prompt"] + TURN_END + ASSISTANT_START,
                            o.get("completion", "") + TURN_END))
    return out


def build_sft_batch(dialogs, tokenizer, block_size, device):
    """变长打包：prompt+response 拼接，labels 仅 response 段非 -100。"""
    ids_list, labels_list = [], []
    for prompt, resp in dialogs:
        p_ids = tokenizer(prompt, add_special_tokens=False)["input_ids"]
        r_ids = tokenizer(resp, add_special_tokens=False)["input_ids"]
        ids = (p_ids + r_ids)[:block_size]
        labels = ([-100] * len(p_ids) + r_ids)[:block_size]
        # pad 到 block_size
        pad = block_size - len(ids)
        if pad > 0:
            ids = ids + [tokenizer.pad_token_id or 0] * pad
            labels = labels + [-100] * pad
        ids_list.append(ids)
        labels_list.append(labels)
    x = torch.tensor(ids_list, dtype=torch.long, device=device)
    y = torch.tensor(labels_list, dtype=torch.long, device=device)
    return x, y


def main() -> int:
    args = parse_args()
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    master_dtype = torch.float32 if args.master_dtype == "fp32" else torch.bfloat16

    tokenizer = AutoTokenizer.from_pretrained(args.base_dir)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    # 注册对话标记（若 base 词表没有则追加，保证单 token）
    special = [USER_START, ASSISTANT_START, TURN_END]
    missing = [t for t in special if t not in tokenizer.get_vocab()]
    if missing:
        tokenizer.add_special_tokens({"additional_special_tokens": missing})

    dialogs = load_dialogs(Path(args.data))
    if not dialogs:
        print("[!] 没有可用对话样本（需 messages/instruction-output/prompt-completion 格式）")
        return 1
    print(f"[i] SFT 样本 {len(dialogs)} 条")

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ★续训接线：旧实现 --resume 只续 CSV 日志，模型/优化器/步数全从 0 开始，
    #   长时间微调停止后等于白跑。现在从最新完整断点恢复权重+优化器+步数+
    #   best_val/lr_scale/止损计数，与主训练引擎口径一致。
    resume_from = None
    if args.resume:
        resume_from = TM.load_latest_checkpoint(out_dir)
        if resume_from is None:
            print(f"[i] {out_dir} 下没有完整 checkpoint-*，SFT 将从头开始")
    load_dir = str(resume_from) if resume_from is not None else args.base_dir
    if resume_from is not None:
        print(f"[i] SFT 从检查点续训：{resume_from}")

    model = AutoModelForCausalLM.from_pretrained(load_dir, dtype=master_dtype)
    if missing:
        model.resize_token_embeddings(len(tokenizer))
    model = model.to(device)
    if not args.no_checkpointing:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        model.config.use_cache = False

    stop_flag = out_dir / "STOP_REQUESTED"
    if stop_flag.exists():
        stop_flag.unlink()

    n_params = sum(p.numel() for p in model.parameters())
    optimizer = Adafactor(model.parameters(), lr=args.lr, scale_parameter=False,
                          relative_step=False, warmup_init=False,
                          weight_decay=args.weight_decay, clip_threshold=1.0,
                          decay_rate=-0.8, beta1=None)

    step = 0
    tokens_seen = 0
    micro_step = 0
    best_val = float("inf")
    lr_scale = 1.0
    rollbacks = 0
    if resume_from is not None:
        opt_p = resume_from / "optimizer.pt"
        if opt_p.exists():
            try:
                optimizer.load_state_dict(torch.load(opt_p, map_location=device, weights_only=True))
            except (OSError, RuntimeError, ValueError) as e:
                print(f"[!] 优化器状态恢复失败（{type(e).__name__}），按新优化器继续")
        st_p = resume_from / "trainer_state.json"
        if st_p.exists():
            try:
                st = json.loads(st_p.read_text(encoding="utf-8"))
                step = int(st.get("global_step", 0))
                best_val = float(st.get("best_val", float("inf")))
                lr_scale = float(st.get("lr_scale", 1.0))
                rollbacks = int(st.get("rollbacks", 0))
                print(f"[i] 已恢复步数 {step}，best_val={best_val:.4f}，lr_scale={lr_scale}")
            except (OSError, ValueError):
                print("[!] trainer_state.json 损坏，步数从 0 计")

    logger = TM.CsvLogger(Path(args.log_csv) if args.log_csv else out_dir / "train_log.csv",
                          resume=(resume_from is not None))
    guard = TM.SpikeGuard(args)
    guard.rollbacks = rollbacks

    t0 = time.time()
    tokens_at_log = 0
    running = running_micro = 0.0
    import random
    rng = random.Random(args.seed)

    try:
        while step < args.max_steps:
            rng.shuffle(dialogs)
            for i in range(0, len(dialogs), args.batch_size):
                if step >= args.max_steps:
                    break
                batch = dialogs[i:i + args.batch_size]
                x, y = build_sft_batch(batch, tokenizer, args.block_size, device)
                lr = TM.lr_at(step, args) * lr_scale
                for g in optimizer.param_groups:
                    g["lr"] = lr
                with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
                    loss = model(x, labels=y).loss
                real_loss = loss.item()
                reason = guard.check(real_loss)
                if reason is not None:
                    optimizer.zero_grad(set_to_none=True)
                    micro_step = 0
                    running = running_micro = 0.0
                    logger.log("event", step=step, loss=real_loss, note=f"spike_skip {reason}")
                    continue
                (loss / args.grad_accum).backward()
                running += real_loss
                running_micro += 1
                tokens_seen += int((y != -100).sum().item())
                micro_step += 1
                if micro_step % args.grad_accum == 0:
                    if args.grad_clip > 0:
                        torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
                    optimizer.step()
                    optimizer.zero_grad(set_to_none=True)
                    step += 1
                    if step % args.log_every == 0:
                        avg = running / max(running_micro, 1)
                        el = time.time() - t0
                        tps = (tokens_seen - tokens_at_log) / el if el > 0 else 0
                        print(f"step {step:>7,}/{args.max_steps:,} | loss {avg:.4f} "
                              f"| lr {lr:.2e} | {tps:,.0f} tok/s")
                        logger.log("train", step=step, tokens_seen=tokens_seen,
                                   loss=round(avg, 6), lr=lr, tok_s=round(tps, 1),
                                   elapsed_s=round(el, 3))
                        running = running_micro = 0.0
                        tokens_at_log = tokens_seen
                        t0 = time.time()
                    if step % args.save_every == 0:
                        TM.save_checkpoint(model, tokenizer, optimizer, step, out_dir,
                                           args, n_params, best=False,
                                           extra_state={"best_val": best_val, "lr_scale": lr_scale,
                                                        "rollbacks": guard.rollbacks})
                        TM.prune_checkpoints(out_dir, args.keep_checkpoints)
                    if stop_flag.exists():
                        raise TM.StopRequested()
                    if step >= args.max_steps:
                        break
    except TM.StopRequested:
        TM.save_checkpoint(model, tokenizer, optimizer, step, out_dir, args, n_params,
                           best=False, extra_state={"best_val": best_val, "lr_scale": lr_scale,
                                                    "rollbacks": guard.rollbacks})
        if stop_flag.exists():
            stop_flag.unlink()
        logger.log("event", step=step, note="paused_by_request")
        logger.close()
        print(f"[i] SFT 已暂停并保存断点 checkpoint-{step}")
        return 131
    except torch.cuda.OutOfMemoryError:
        print("[!] 显存不足（CUDA OOM），SFT 中止。减小 batch-size/block-size 后从断点续训。")
        logger.log("event", step=step, note="cuda_oom")
        logger.close()
        return 5

    TM.save_checkpoint(model, tokenizer, optimizer, step, out_dir, args, n_params,
                       final=True, extra_state={"best_val": best_val, "lr_scale": lr_scale,
                                                "rollbacks": guard.rollbacks})
    logger.log("event", step=step, note="done")
    logger.close()
    print(f"[i] SFT 完成：{step} 步，模型保存到 {out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

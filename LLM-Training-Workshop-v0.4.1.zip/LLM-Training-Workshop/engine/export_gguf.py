# -*- coding: utf-8 -*-
"""export_gguf.py —— 导出：精简 HF 推理包 + GGUF 转换 + 量化 + 加载自检。

- 精简 HF 包：只含 config/weights/tokenizer/generation_config，去掉优化器/
  训练态，附 model card。可直接给 transformers/vLLM 用。
- GGUF：调用 llama.cpp convert_hf_to_gguf.py 转 F16，再 llama-quantize 量化
  （Q4_K_M 等）。转换后做加载+生成自检，失败即报错不产出坏包。
- 依赖 llama.cpp 可执行文件/脚本（用户自备，--llama-cpp 指定目录）；
  未提供时只做精简 HF 导出并提示。

运行：
    python engine/export_gguf.py --model-dir output/sft/final --out-dir export \
        --quant Q4_K_M --llama-cpp D:/llama.cpp
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

try:
    from log_i18n import install as _install_log_lang
    _install_log_lang()
except Exception:
    pass

HF_KEEP = ("config.json", "generation_config.json", "tokenizer.json",
           "tokenizer_config.json", "special_tokens_map.json", "added_tokens.json")


def parse_args():
    ap = argparse.ArgumentParser(description="导出精简HF包+GGUF+量化+自检")
    ap.add_argument("--model-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--quant", default="Q4_K_M", help="量化类型 Q4_K_M/Q5_K_M/Q8_0 等")
    ap.add_argument("--llama-cpp", default=None, help="llama.cpp 目录（含convert脚本/quantize可执行）")
    ap.add_argument("--no-gguf", action="store_true", help="只导出精简HF包，不转GGUF")
    ap.add_argument("--model-name", default="model")
    # ★自定义量化调参（llama-quantize 真实支持的选项，见其官方 README）
    ap.add_argument("--imatrix", default=None, help="重要性矩阵文件，提升量化精度")
    ap.add_argument("--pure", action="store_true", help="关闭k-quant混合，所有张量同类型")
    ap.add_argument("--leave-output", action="store_true", help="输出层不量化，体积略增质量略升")
    ap.add_argument("--allow-requantize", action="store_true", help="允许对已量化张量再量化")
    ap.add_argument("--output-tensor-type", default=None, help="输出层单独量化类型，如 q6_k")
    ap.add_argument("--token-embedding-type", default=None, help="词嵌入层单独量化类型")
    ap.add_argument("--tensor-type", action="append", default=None,
                    help="逐张量自定义，格式 正则=类型，可多次")
    ap.add_argument("--threads", type=int, default=0, help="量化线程数，0=默认")
    ap.add_argument("--quant-args", default=None, help="额外原始参数（按shell词法拆分）")
    return ap.parse_args()


def build_quant_opts(args) -> list:
    """把自定义调参组装成 llama-quantize 选项列表（全部来自官方文档）。"""
    opts = []
    if args.imatrix:
        opts += ["--imatrix", args.imatrix]
    if args.pure:
        opts.append("--pure")
    if args.leave_output:
        opts.append("--leave-output-tensor")
    if args.allow_requantize:
        opts.append("--allow-requantize")
    if args.output_tensor_type:
        opts += ["--output-tensor-type", args.output_tensor_type]
    if args.token_embedding_type:
        opts += ["--token-embedding-type", args.token_embedding_type]
    for tt in (args.tensor_type or []):
        opts += ["--tensor-type", tt]
    if args.quant_args:
        import shlex
        opts += shlex.split(args.quant_args)
    return opts


def export_hf(model_dir: Path, out_dir: Path, model_name: str) -> Path:
    """精简 HF 推理包：去优化器/训练态，附 model card。"""
    hf = out_dir / "hf"
    hf.mkdir(parents=True, exist_ok=True)
    copied = []
    for fn in HF_KEEP:
        src = model_dir / fn
        if src.exists():
            shutil.copy2(src, hf / fn)
            copied.append(fn)
    # 权重分片 + index
    for f in sorted(model_dir.glob("*.safetensors")):
        shutil.copy2(f, hf / f.name)
        copied.append(f.name)
    idx = model_dir / "model.safetensors.index.json"
    if idx.exists():
        shutil.copy2(idx, hf / idx.name)
    if not any(n.endswith(".safetensors") for n in copied):
        pb = model_dir / "pytorch_model.bin"
        if pb.exists():
            shutil.copy2(pb, hf / pb.name)
    # model card
    cfg = {}
    try:
        cfg = json.loads((model_dir / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    card = f"""---
license: other
base_model: {model_dir.name}
---
# {model_name}

由 LLM 训练工坊导出。架构 {cfg.get('model_type', 'llama')}，
参数量级见 config.json。本包为精简推理权重（不含优化器/训练态）。

- 训练数据与许可见项目 data_card.json（发布前请自行确认合规）。
- base 模型不会对话；如需对话请先 SFT。
"""
    (hf / "README.md").write_text(card, encoding="utf-8")
    print(f"[i] 精简 HF 包已导出：{hf}（{len(copied)} 个文件）")
    return hf


def convert_gguf(hf: Path, out_dir: Path, quant: str, llama_cpp: Path, model_name: str,
                 opts: list | None = None, threads: int = 0) -> Path:
    convert = llama_cpp / "convert_hf_to_gguf.py"
    if not convert.exists():
        raise FileNotFoundError(f"找不到 convert_hf_to_gguf.py：{convert}")
    f16 = out_dir / f"{model_name}-f16.gguf"
    subprocess.run([sys.executable, str(convert), str(hf), "--outfile", str(f16),
                    "--outtype", "f16"], check=True)
    # 量化
    quantize = None
    for cand in ("llama-quantize", "llama-quantize.exe", "quantize", "quantize.exe"):
        p = llama_cpp / cand
        if p.exists():
            quantize = p
            break
        p2 = llama_cpp / "build" / "bin" / cand
        if p2.exists():
            quantize = p2
            break
    if quantize is None:
        print("[!] 找不到 llama-quantize，保留 F16 GGUF")
        return f16
    qout = out_dir / f"{model_name}-{quant}.gguf"
    cmd = [str(quantize)] + (opts or []) + [str(f16), str(qout), quant]
    if threads and threads > 0:
        cmd.append(str(threads))
    if opts:
        print(f"[i] 自定义量化选项：{' '.join(opts)}")
    subprocess.run(cmd, check=True)
    print(f"[i] GGUF 量化完成：{qout}")
    return qout


def self_check_gguf(gguf: Path, llama_cpp: Path) -> bool:
    """加载+生成自检：用 llama-cli/main 跑一句，确认能加载能生成。"""
    cli = None
    for cand in ("llama-cli", "llama-cli.exe", "main", "main.exe"):
        for base in (llama_cpp, llama_cpp / "build" / "bin"):
            p = base / cand
            if p.exists():
                cli = p
                break
        if cli:
            break
    if cli is None:
        print("[!] 找不到 llama-cli，跳过生成自检（GGUF 已产出）")
        return True
    r = subprocess.run([str(cli), "-m", str(gguf), "-p", "你好", "-n", "16",
                        "--no-warmup"], capture_output=True, text=True, timeout=300)
    ok = r.returncode == 0 and len(r.stdout.strip()) > 0
    print(f"[i] GGUF 自检：{'通过' if ok else '失败'}")
    return ok


def main() -> int:
    args = parse_args()
    model_dir = Path(args.model_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if not (model_dir / "config.json").exists():
        print(f"[!] 模型目录无 config.json：{model_dir}")
        return 1
    hf = export_hf(model_dir, out_dir, args.model_name)
    if args.no_gguf or not args.llama_cpp:
        if not args.no_gguf:
            print("[i] 未提供 --llama-cpp，仅导出精简 HF 包。如需 GGUF 请指定 llama.cpp 目录。")
        return 0
    llama_cpp = Path(args.llama_cpp)
    try:
        gguf = convert_gguf(hf, out_dir, args.quant, llama_cpp, args.model_name,
                            build_quant_opts(args), args.threads)
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"[!] GGUF 转换失败：{e}")
        return 1
    if not self_check_gguf(gguf, llama_cpp):
        print("[!] GGUF 自检失败，产物可能不可用")
        return 1
    print(f"[i] 导出完成：{out_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# 兼容矩阵（v0.4.1）

本工坊为**实验性单卡工具**，界面/后端零第三方依赖（Python 标准库），
训练引擎依赖见 `requirements.txt` / `requirements.lock.txt`。

## 已实测通过

| 项 | 版本/平台 | 说明 |
|---|---|---|
| Python | 3.10 | 开发/验证环境 |
| torch | 2.14.1+cu132 | CUDA 可用，单卡 |
| transformers | 5.20.2 | 必须 5.x（dtype= / rope_parameters） |
| 操作系统 | Windows 11 | 启动器 exe + 便携打包 |
| 全链路 | nano 端到端 | 识别→清洗→词表→打包→整合→训练→验证→SFT/LoRA/导出 |

## 关键约束（踩坑记录，勿退回旧写法）

- **transformers 5.x 硬要求**：4.x 不报错但静默回落 rope_theta=10000、
  dtype 不生效（3B 全 fp32），训出来不对且难排查。
- **lm-eval / 评估**：CMMLU 在 datasets 5.x 必失败；lm-eval 硬依赖 accelerate。
  评估走工坊内置 test_model（困惑度+生成），不依赖 lm-eval。
- **rope_theta 跨版本**：不同 transformers 版本对 rope 配置读取方式不同，
  统一走 rope_parameters，避免静默回落。

## 未验证 / 待补

| 项 | 状态 |
|---|---|
| Linux / macOS | 未验证；路径探测与启动器需补齐跨平台分支 |
| 多卡 / 分布式 | 不在范围（单卡定位） |
| 多模态训练 | 边界外（v0.4.0 到通用预训练 + SFT/LoRA + 导出） |
| Python 3.11/3.12 | 未实测；理论兼容，建议先用 3.10 |

## 复现建议

需要完全一致的训练结果时，用 `requirements.lock.txt` 的精确版本，
并固定随机种子与语料顺序（工坊混料/打包已做确定性处理）。

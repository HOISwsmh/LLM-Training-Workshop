"""外部训练监控（严格只读）。

用途：监控**不由本工具启动**的训练，例如用户自己在命令行跑的长任务。

★安全边界（硬性）：
  1. 本模块只读文件，绝不在被监控目录里创建/修改/删除任何东西
  2. 绝不终止、暂停或以任何方式干预训练进程
  3. 注册信息只写在本程序自己的目录里
  4. 判断"是否还在跑"依据日志写入时间，不依据进程存活
     （踩坑教训：体积不变可能只是没到写盘点，进程活着也可能已卡死）
"""
from __future__ import annotations

import csv
import json
import re
import time
from pathlib import Path

from . import paths as PA

WATCH_FILE = "watched_trainings.json"

# 训练脚本写日志的默认间隔未知时，用这个宽限判断是否停滞
STALL_MULTIPLIER = 6
DEFAULT_LOG_EVERY = 20
DEFAULT_STEP_SEC = 24.0


# ---------------- 注册表（写在本程序目录，不碰被监控目录） ----------------
def _load() -> list[dict]:
    p = PA.app_root() / WATCH_FILE
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save(items: list[dict]) -> None:
    p = PA.app_root() / WATCH_FILE
    try:
        p.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def list_watched() -> list[dict]:
    return _load()


def add(name: str, out_dir: str, total_tokens: float = 0,
        total_steps: int = 0, log_file: str = "") -> dict:
    """注册一个外部训练目录。只校验可读性，不写入该目录。"""
    name = (name or "").strip()
    if not name:
        raise ValueError("请填写监控名称")
    if len(name) > 50:
        raise ValueError("名称过长（最多 50 字）")
    d = Path((out_dir or "").strip().strip('"'))
    if not d.exists() or not d.is_dir():
        raise ValueError(f"目录不存在：{out_dir}")
    csv_p = d / "train_log.csv"
    if not csv_p.exists():
        raise ValueError(f"该目录下没有 train_log.csv：{d}")
    try:
        with csv_p.open(encoding="utf-8") as f:
            f.readline()
    except OSError as e:
        raise ValueError(f"无法读取日志：{e}") from e

    items = _load()
    if any(x["name"] == name for x in items):
        raise ValueError(f"名称「{name}」已存在")
    if any(Path(x["out_dir"]) == d for x in items):
        raise ValueError("该目录已在监控列表中")

    # 自动推断总步数/总token（从日志的 start 事件里取）
    info = _peek_totals(csv_p)
    item = {
        "name": name,
        "out_dir": str(d),
        "total_tokens": float(total_tokens or info.get("total_tokens") or 0),
        "total_steps": int(total_steps or info.get("total_steps") or 0),
        "log_file": (log_file or "").strip().strip('"'),
        "added_at": time.time(),
    }
    items.append(item)
    _save(items)
    return item


def remove(name: str) -> None:
    items = _load()
    kept = [x for x in items if x["name"] != name]
    if len(kept) == len(items):
        raise ValueError(f"未找到监控项「{name}」")
    _save(kept)


def _peek_totals(csv_p: Path) -> dict:
    """从 start 事件与 step 分母推断总量。只读。"""
    out = {}
    try:
        with csv_p.open(encoding="utf-8", newline="") as f:
            for r in csv.DictReader(f):
                note = r.get("note") or ""
                if r.get("phase") == "event" and "start" in note:
                    m = re.search(r"tokens=([\d.eE+]+)", note)
                    if m:
                        try:
                            out["total_tokens"] = float(m.group(1))
                        except ValueError:
                            pass
                    break
    except (OSError, ValueError):
        pass
    return out


# ---------------- 读取训练数据（只读） ----------------
def read_log(out_dir: str, limit: int = 1500) -> dict:
    d = Path(out_dir)
    p = d / "train_log.csv"
    points, evals, events = [], [], []
    start_note = ""
    try:
        with p.open(encoding="utf-8", newline="") as f:
            for r in csv.DictReader(f):
                ph = r.get("phase")
                if ph == "train":
                    points.append({
                        "step": int(r.get("step") or 0),
                        "loss": _f(r.get("loss")),
                        "ppl": _f(r.get("ppl")),
                        "lr": _f(r.get("lr")),
                        "tok_s": _f(r.get("tok_s")),
                        "vram": _f(r.get("vram_gb")),
                        "tokens": int(r.get("tokens_seen") or 0),
                        "spikes": int(r.get("skipped_spikes") or 0),
                        "rollbacks": int(r.get("rollbacks") or 0),
                        "elapsed": _f(r.get("elapsed_s")),
                        "time": r.get("wall_time", ""),
                    })
                elif ph == "eval":
                    evals.append({"step": int(r.get("step") or 0),
                                  "loss": _f(r.get("loss")), "ppl": _f(r.get("ppl"))})
                elif ph == "event":
                    note = r.get("note", "")
                    if "start" in note and not start_note:
                        start_note = note
                    events.append({"step": int(r.get("step") or 0),
                                   "note": note, "time": r.get("wall_time", "")})
    except (OSError, ValueError):
        return {"points": [], "evals": [], "events": [], "latest": None,
                "start_note": "", "mtime": None, "error": "日志不可读"}

    mtime = None
    try:
        mtime = p.stat().st_mtime
    except OSError:
        pass

    full_n = len(points)
    if full_n > limit:
        stride = full_n // limit + 1
        points = points[::stride]
        if full_n and points and points[-1]["step"] != full_n:
            pass
    return {"points": points, "evals": evals, "events": events[-25:],
            "latest": points[-1] if points else None,
            "start_note": start_note, "mtime": mtime, "count": full_n}


def _f(v):
    try:
        return float(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def checkpoints(out_dir: str) -> list[dict]:
    d = Path(out_dir)
    items = []
    if not d.exists():
        return items
    try:
        for c in sorted(d.iterdir()):
            if not c.is_dir():
                continue
            if not (c.name.startswith("checkpoint-") or c.name in ("best", "final")):
                continue
            size = 0
            try:
                size = sum(f.stat().st_size for f in c.rglob("*") if f.is_file())
            except OSError:
                pass
            step = None
            st = c / "trainer_state.json"
            if st.exists():
                try:
                    step = json.loads(st.read_text(encoding="utf-8")).get("global_step")
                except (OSError, ValueError):
                    pass
            try:
                mt = c.stat().st_mtime
            except OSError:
                mt = 0
            items.append({"name": c.name, "step": step,
                          "size_gb": round(size / 1024 ** 3, 2), "mtime": mt})
    except OSError:
        pass
    return items


def tail(path: str, lines: int = 60) -> str:
    if not path:
        return ""
    p = Path(path)
    if not p.exists() or not p.is_file():
        return ""
    try:
        with p.open(encoding="utf-8", errors="replace") as f:
            return "".join(f.readlines()[-lines:])
    except OSError:
        return ""


def supports_pause(out_dir: str) -> dict:
    """判断某个外部训练能否被安全暂停。

    ★只有引擎支持 STOP_REQUESTED 标记的训练才能暂停。
      判断依据：该输出目录旁的引擎脚本是否含标记机制 —— 但外部训练用的引擎
      路径未知，因此改为保守策略：默认不支持，除非用户显式确认过。
    """
    d = Path(out_dir)
    flag = d / "STOP_REQUESTED"
    return {
        "can_pause": False,
        "reason": ("该训练不由本工具启动，无法确认它的引擎是否支持暂停标记。"
                   "贸然写入标记可能被忽略（无效），也可能被误当成其他文件。"
                   "请用它自己的启动方式停止，或把训练迁移到本工具管理。"),
        "flag_path": str(flag),
        "flag_exists": flag.exists(),
    }


def snapshot(item: dict) -> dict:
    """汇总一个被监控训练的当前状态。全程只读。"""
    d = item["out_dir"]
    log = read_log(d)
    L = log["latest"]
    cks = checkpoints(d)

    total_tokens = float(item.get("total_tokens") or 0)
    total_steps = int(item.get("total_steps") or 0)

    # 从日志 step 行推断总步数：训练脚本打印 step N/TOTAL，但CSV没有分母，
    # 所以优先用用户填的；否则用 tokens 比例估算
    pct = None
    if L and total_tokens > 0:
        pct = min(100.0, L["tokens"] / total_tokens * 100)
    elif L and total_steps > 0:
        pct = min(100.0, L["step"] / total_steps * 100)

    eta = None
    if L and L.get("tok_s") and total_tokens > 0:
        left = total_tokens - L["tokens"]
        if left > 0:
            eta = left / L["tok_s"]

    # 活性判断：按日志写入时间，不看进程
    age = (time.time() - log["mtime"]) if log.get("mtime") else None
    # 用最近若干步的实际耗时估一个日志间隔
    step_sec = DEFAULT_STEP_SEC
    pts = log["points"]
    if len(pts) >= 2 and pts[-1].get("elapsed") and pts[0].get("elapsed"):
        ds = pts[-1]["step"] - pts[0]["step"]
        dt = pts[-1]["elapsed"] - pts[0]["elapsed"]
        if ds > 0 and dt > 0:
            step_sec = dt / ds
    gap = DEFAULT_LOG_EVERY * step_sec
    if len(pts) >= 2:
        gap = max(gap, (pts[-1]["step"] - pts[-2]["step"]) * step_sec)
    threshold = max(120.0, gap * STALL_MULTIPLIER)

    if age is None:
        state = "unknown"
    elif age <= threshold:
        state = "running"
    else:
        state = "stalled"

    done = any(c["name"] == "final" for c in cks)
    if done:
        state = "finished"

    return {
        "name": item["name"], "out_dir": d,
        "log": log, "checkpoints": cks,
        "total_tokens": total_tokens, "total_steps": total_steps,
        "percent": pct, "eta_sec": eta,
        "log_age_sec": age, "stall_threshold_sec": threshold,
        "step_sec_est": round(step_sec, 2),
        "state": state,
        "log_file": item.get("log_file") or "",
    }

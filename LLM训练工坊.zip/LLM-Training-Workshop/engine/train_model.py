# -*- coding: utf-8 -*-
"""train_model.py —— 2-3B 中文 LLM 预训练（含断点续训）

★两个关键架构决策，都是被硬件条件决定的：

1. 用 LLaMA 而不是 GPT-2
   GPT-2 的绝对位置编码、LayerNorm、带 bias 的注意力和 MLP、gelu，
   在 2-3B 规模上都不如 LLaMA 的 RoPE + RMSNorm + SwiGLU + 无 bias。
   同等参数量下 LLaMA 收敛更快、效果更好，且 RoPE 便于后续扩长上下文。
   还用了 GQA（num_key_value_heads < num_attention_heads）省 KV 缓存。

2. 用 Adafactor 而不是 AdamW
   实测 3B 模型 AdamW 的优化器状态需要 33.5 GB，超过单卡 31.8 GB 显存，
   而 Adafactor 的状态只要 0.09 GB（0.031 B/param vs AdamW 的 12 B/param）。
   代价是 Adafactor 收敛略慢、对学习率更敏感，所以默认学习率调高到 1e-2
   （AdamW 量级是 3e-4），并配 warmup + cosine 衰减。
   若装 bitsandbytes，可换 8-bit AdamW 折中。

显存策略：模型权重与梯度全程 bf16（3B 各占 6 GB），配非重入梯度检查点。
已实测 bf16 + Adafactor + gradient_checkpointing + generate 四者可共存。

注意：环境未安装 accelerate，transformers 的 Trainer 不可用
（实测直接 ImportError），因此本脚本自己实现训练循环。

档位（meta 设备实测参数量，tie_word_embeddings=True）：
    tiny    14.9M   验证链路，几分钟跑完
    small   38.9M
    base   123.7M
    mid    345.3M
    large  747.6M
    xl       1.299B
    2b       1.985B  24GB 级显卡可训
    3b       2.978B  31.8GB 显卡靠 Adafactor 才可训

    档位名与实际参数量已逐项校准：名称里的数字就是 meta 设备上的真实
    参数量，不是估算值。改动 TIERS 后请用 build_config + meta 设备复核。

运行：
    # 先激活你自己的 Python 环境（venv / conda 均可）
    python engine/train_model.py --tier tiny --max-steps 200
    python engine/train_model.py --tier 2b --max-tokens 100e9
    python engine/train_model.py --resume   # 断点续训
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import shutil
import statistics
import sys
import time
from collections import deque
from pathlib import Path

import numpy as np
import torch
from transformers import AutoTokenizer, LlamaConfig, LlamaForCausalLM, Adafactor

ROOT = Path(os.environ.get("LLM_WORKSHOP_ROOT") or Path(__file__).resolve().parent.parent)
DATA_DIR = ROOT / "data"
TOK_DIR = ROOT / "tokenizer"
OUT_ROOT = ROOT / "output"

# name: (hidden_size, num_hidden_layers, intermediate_size, vocab_size)
# 词表需与 train_tokenizer.py 实际产出一致，脚本会自动校正
TIERS = {
    "tiny":  (384,  6,   1408,  8192),   # 14.9M   验证链路，几分钟跑完
    "small": (512,  8,   1408, 32000),   # 38.9M
    "base":  (768, 12,   2944, 32000),   # 123.7M
    "mid":   (1024, 16,  5504, 32000),   # 345.3M
    "large": (1536, 16,  8192, 32000),   # 747.6M
    "xl":    (2048, 24,  6656, 32000),   # 1.299B
    "2b":    (2560, 24,  8192, 32000),   # 1.985B  24GB 级显卡可训
    "3b":    (2560, 32,  9472, 49152),   # 2.978B  31.8GB 靠 Adafactor 才可训
    "7b":    (4096, 32, 11008, 32000),   # 5.802B(tie,32k词表) 约需27GB+激活；48GB级显存舒适
}
HEAD_DIM = 64           # 注意力头维度，业界常用 64/128
KV_GROUPS = 4           # GQA：每 4 个查询头共享 1 组 KV


# ---------------------------------------------------------------- 暂停控制


class StopRequested(Exception):
    """外部请求优雅暂停（通过 out_dir/STOP_REQUESTED 标记触发）。

    与控制台信号无关，因此后台无窗口启动的训练也能被安全暂停。
    """


# ---------------------------------------------------------------- 数据集


class PackedMemmapDataset:
    """把 memmap 的 token 流按 block_size+1 切成等长块。

    打包式训练不需要 padding：样本已在 prepare_data.py 阶段用
    BOS/EOS 分隔并首尾相接，这里按固定长度滑窗取块即可。
    内存占用恒定，与语料大小无关。
    """

    def __init__(self, path: Path, dtype_str: str, block_size: int) -> None:
        self.data = np.memmap(str(path), dtype=np.dtype(dtype_str), mode="r")
        self.block_size = block_size
        self.n_blocks = max(0, (len(self.data) - 1) // (block_size + 1))

    def __len__(self) -> int:
        return self.n_blocks

    def __getitem__(self, idx) -> tuple[torch.Tensor, torch.Tensor]:
        i = int(idx) * (self.block_size + 1)
        chunk = np.asarray(self.data[i:i + self.block_size + 1], dtype=np.int64)
        x = torch.from_numpy(chunk[:-1])
        y = torch.from_numpy(chunk[1:])
        return x, y


def collate(batch: list[tuple[torch.Tensor, torch.Tensor]]):
    xs = torch.stack([b[0] for b in batch])
    ys = torch.stack([b[1] for b in batch])
    return xs, ys


# ---------------------------------------------------------------- 配置


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="2-3B 中文 LLM 预训练",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--tier", choices=sorted(TIERS), default="tiny")
    ap.add_argument("--arch", default=None,
                    help="自定义架构 JSON，未填项沿用档位预设。可含 hidden_size / "
                         "num_hidden_layers / intermediate_size / num_attention_heads / "
                         "num_key_value_heads / head_dim / tie_embeddings")
    ap.add_argument("--out-dir", default=None, help="默认 output/<tier>_model")
    ap.add_argument("--data-dir", default=str(DATA_DIR))
    ap.add_argument("--tokenizer", default=str(TOK_DIR))
    ap.add_argument("--block-size", type=int, default=1024, help="上下文长度")
    ap.add_argument("--batch-size", type=int, default=4, help="每步微批大小")
    ap.add_argument("--grad-accum", type=int, default=8, help="梯度累积步数")
    ap.add_argument("--lr", type=float, default=1e-2, help="Adafactor 学习率，比 AdamW 高约 30 倍")
    ap.add_argument("--min-lr-ratio", type=float, default=0.1, help="cosine 衰减下限比例")
    ap.add_argument("--warmup-steps", type=int, default=500)
    ap.add_argument("--decay-steps", type=int, default=0, help="0 表示用 max-steps")
    ap.add_argument("--max-steps", type=int, default=1000)
    ap.add_argument("--max-tokens", type=float, default=0,
                    help="按 token 预算训练，>0 时覆盖 max-steps")
    ap.add_argument("--weight-decay", type=float, default=0.0)
    ap.add_argument("--grad-clip", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--log-every", type=int, default=10)
    ap.add_argument("--eval-every", type=int, default=200)
    ap.add_argument("--eval-batches", type=int, default=20)
    ap.add_argument("--save-every", type=int, default=200)
    ap.add_argument("--keep-checkpoints", type=int, default=3)
    ap.add_argument("--resume", action="store_true", help="从 out-dir 最新检查点续训")
    ap.add_argument("--resume-from", default=None,
                    help="从指定目录续训（可为别处的检查点，或含 config.json 的模型目录）。"
                         "优先级高于 --resume；目录内无 optimizer.pt 时按仅继承权重处理")
    ap.add_argument("--optimizer", choices=("adafactor", "adamw"), default="adafactor",
                    help="adamw 仅适用于 ≤750M 档位，3B 会 OOM")
    ap.add_argument("--no-checkpointing", action="store_true",
                    help="关闭梯度检查点（显存充裕时可提速约 25%%）")
    ap.add_argument("--compile", action="store_true", help="torch.compile 加速")
    ap.add_argument("--num-workers", type=int, default=4, help="DataLoader 进程数")
    ap.add_argument("--master-dtype", choices=("fp32", "bf16"), default="fp32",
                    help="主权重精度。fp32=主权重fp32+autocast bf16计算（推荐，避免小更新被舍入吞掉）；"
                         "bf16=权重与梯度全bf16（省显存但大模型易震荡）")
    # ---- C.3 训练日志持久化（CSV，零第三方依赖）
    ap.add_argument("--log-csv", default=None,
                    help="训练日志 CSV 路径，缺省为 out-dir/train_log.csv；传 none 关闭")
    # ---- C.2 loss 尖刺处理
    ap.add_argument("--spike-abs", type=float, default=20.0,
                    help="loss 绝对上限，超过即判为尖刺并跳过该 micro-batch")
    ap.add_argument("--spike-ratio", type=float, default=3.0,
                    help="相对近期中位数的倍数上限，0 表示关闭相对判据")
    ap.add_argument("--spike-window", type=int, default=50,
                    help="相对判据的滑动窗口长度（micro-batch 数）")
    ap.add_argument("--spike-rollback-after", type=int, default=5,
                    help="连续尖刺达到此数则回滚到最近检查点并降 lr，0 表示关闭回滚")
    ap.add_argument("--spike-lr-decay", type=float, default=0.5,
                    help="回滚时学习率乘以此系数")
    ap.add_argument("--spike-max-rollbacks", type=int, default=3,
                    help="累计回滚达到此数仍未恢复则止损退出，0 表示不限制")
    ap.add_argument("--no-spike-guard", action="store_true", help="完全关闭尖刺防护")
    # ---- D.1 检查点异盘备份
    ap.add_argument("--backup-dir", default=None,
                    help="检查点备份目录，应位于另一块物理盘；缺省不备份")
    ap.add_argument("--backup-every", type=int, default=0,
                    help="每多少个编号检查点备份一次，0 表示 save-every 的 5 倍；best/final 始终备份")
    ap.add_argument("--keep-backups", type=int, default=3,
                    help="备份目录保留的编号检查点个数，best/final 不受影响")
    return ap.parse_args()


def lr_at(step: int, args) -> float:
    """线性 warmup + cosine 衰减到 lr * min_lr_ratio。"""
    if step < args.warmup_steps:
        return args.lr * (step + 1) / max(1, args.warmup_steps)
    total = args.decay_steps or args.max_steps
    prog = min(1.0, (step - args.warmup_steps) / max(1, total - args.warmup_steps))
    cos = 0.5 * (1 + math.cos(math.pi * prog))
    return args.lr * (args.min_lr_ratio + (1 - args.min_lr_ratio) * cos)


def build_config(tier: str, vocab_size: int, block_size: int, pad_id, bos_id, eos_id,
                 arch: dict | None = None) -> LlamaConfig:
    """构建模型配置。arch 非空时用自定义架构覆盖档位预设。

    arch 可含：hidden_size / num_hidden_layers / intermediate_size /
               num_attention_heads / num_key_value_heads / head_dim / tie_embeddings
    ★词表始终以实际分词器为准，不受 arch 影响（否则 embedding 与数据会错位）。
    """
    hidden, layers, inter, tier_vocab = TIERS[tier]
    if vocab_size != tier_vocab:
        print(f"[i] 词表校正：档位默认 {tier_vocab:,} → 实际分词器 {vocab_size:,}")

    a = arch or {}
    if a:
        hidden = int(a.get("hidden_size") or hidden)
        layers = int(a.get("num_hidden_layers") or layers)
        inter = int(a.get("intermediate_size") or inter)
        print(f"[i] 自定义架构：hidden={hidden} layers={layers} inter={inter}")

    head_dim = int(a.get("head_dim") or HEAD_DIM)
    if a.get("num_attention_heads"):
        heads = int(a["num_attention_heads"])
    else:
        heads = max(hidden // head_dim, 1)
    if a.get("num_key_value_heads"):
        kv_heads = int(a["num_key_value_heads"])
    else:
        kv_heads = max(heads // KV_GROUPS, 1)
    # 合法性约束：查询头数须能被 KV 头数整除，hidden 须与 heads*head_dim 一致
    kv_heads = max(1, min(kv_heads, heads))
    while heads % kv_heads != 0 and kv_heads > 1:
        kv_heads -= 1
    tie = bool(a.get("tie_embeddings", True))
    # transformers 5.x 把 rope_theta 放进了 rope_parameters
    return LlamaConfig(
        vocab_size=vocab_size,
        hidden_size=hidden,
        intermediate_size=inter,
        num_hidden_layers=layers,
        num_attention_heads=heads,
        num_key_value_heads=kv_heads,
        head_dim=head_dim,
        max_position_embeddings=block_size,
        hidden_act="silu",
        rms_norm_eps=1e-5,
        rope_parameters={"rope_type": "default", "rope_theta": 500000.0},
        attention_bias=False,
        mlp_bias=False,
        tie_word_embeddings=tie,      # 共享输入输出 embedding，中小模型可省数亿参数
        initializer_range=0.02,
        bos_token_id=bos_id,
        eos_token_id=eos_id,
        pad_token_id=pad_id,
        use_cache=False,
    )


def count_params(model) -> int:
    return sum(p.numel() for p in model.parameters())


# ---------------------------------------------------------------- C.3 日志持久化


class CsvLogger:
    """训练日志持久化。只用标准库 csv，每行 flush，断电不丢已写部分。

    设计要点：
      - 追加模式打开，resume 时不覆盖历史
      - 每写一行立即 flush + os.fsync 不做（fsync 太慢），flush 已足够对抗进程退出
      - train / eval / event 三类记录同表，用 phase 列区分，便于事后统一分析
    """

    FIELDS = ["wall_time", "phase", "step", "micro_step", "tokens_seen",
              "loss", "ppl", "lr", "tok_s", "vram_gb", "elapsed_s",
              "skipped_spikes", "rollbacks", "note"]

    def __init__(self, path: Path | None, resume: bool = False) -> None:
        self.fh = None
        self.writer = None
        self.path = path
        if path is None:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        is_new = not path.exists() or path.stat().st_size == 0
        self.fh = path.open("a", encoding="utf-8", newline="")
        self.writer = csv.DictWriter(self.fh, fieldnames=self.FIELDS, extrasaction="ignore")
        if is_new:
            self.writer.writeheader()
            self.fh.flush()
        if resume:
            self.log("event", note="resume")

    def log(self, phase: str, **kw) -> None:
        if self.writer is None:
            return
        row = {"wall_time": time.strftime("%Y-%m-%d %H:%M:%S"), "phase": phase}
        row.update(kw)
        try:
            self.writer.writerow(row)
            self.fh.flush()          # ★长跑必须每行落盘
        except (OSError, ValueError):
            pass                     # 日志失败绝不中断训练

    def close(self) -> None:
        if self.fh is not None:
            try:
                self.fh.close()
            except OSError:
                pass
            self.fh = None


# ---------------------------------------------------------------- C.2 尖刺防护


class SpikeGuard:
    """loss 尖刺检测：NaN/Inf、绝对阈值、相对滑动中位数三条判据。

    只用 collections.deque + statistics.median，零第三方依赖。
    注意：传入的必须是【未除以 grad_accum 的真实 loss】，否则阈值会被
    同步缩小 grad_accum 倍，防护形同虚设（本项目踩过的坑）。
    """

    def __init__(self, args) -> None:
        self.enabled = not args.no_spike_guard
        self.abs_max = args.spike_abs
        self.ratio = args.spike_ratio
        self.hist: deque[float] = deque(maxlen=max(2, args.spike_window))
        self.consecutive = 0
        self.skipped = 0
        self.rollbacks = 0

    def check(self, real_loss: float) -> str | None:
        """返回 None 表示正常；否则返回尖刺原因字符串。"""
        if not self.enabled:
            self.hist.append(real_loss)
            return None
        if not math.isfinite(real_loss):
            self.consecutive += 1
            self.skipped += 1
            return "non_finite"
        if self.abs_max > 0 and real_loss > self.abs_max:
            self.consecutive += 1
            self.skipped += 1
            return f"abs>{self.abs_max:g}"
        if self.ratio > 0 and len(self.hist) >= 8:
            med = statistics.median(self.hist)
            if med > 0 and real_loss > self.ratio * med:
                self.consecutive += 1
                self.skipped += 1
                return f"ratio>{self.ratio:g}x(med={med:.3f})"
        self.hist.append(real_loss)
        self.consecutive = 0
        return None

    def should_rollback(self, limit: int) -> bool:
        return limit > 0 and self.consecutive >= limit

    def reset_streak(self) -> None:
        self.consecutive = 0


def estimate_memory(n_params: int, optimizer: str, checkpointing: bool,
                    master_dtype: str = "fp32") -> dict:
    """粗估显存（GB）。用于开训前拦截必然 OOM 的配置。"""
    wbytes = 4 if master_dtype == "fp32" else 2
    weights = n_params * wbytes / 1024 ** 3      # 主权重
    grads = n_params * wbytes / 1024 ** 3        # 梯度与主权重同 dtype
    if optimizer == "adamw":
        opt_state = n_params * (4 + 4) / 1024 ** 3   # m + v（主权重已单列）
    else:
        opt_state = n_params * 0.031 / 1024 ** 3
    act = 2.0 if checkpointing else 8.0
    return {"weights": weights, "grads": grads, "opt": opt_state,
            "act": act, "total": weights + grads + opt_state + act}


# ---------------------------------------------------------------- 训练


@torch.no_grad()
def evaluate(model, loader, device, max_batches: int, block_size: int) -> tuple[float, float]:
    model.eval()
    total_loss, total_tokens, n = 0.0, 0, 0
    for x, y in loader:
        x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
            loss = model(x, labels=y).loss
        total_loss += loss.item() * x.numel()
        total_tokens += x.numel()
        n += 1
        if n >= max_batches:
            break
    model.train()
    if total_tokens == 0:
        return float("nan"), float("nan")
    avg = total_loss / total_tokens
    return avg, math.exp(min(avg, 20))     # 困惑度，截断避免溢出


def load_latest_checkpoint(out_dir: Path):
    cks = sorted(out_dir.glob("checkpoint-*"), key=lambda p: int(p.name.split("-")[1]))
    return cks[-1] if cks else None


def main() -> int:
    args = parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type != "cuda":
        print("[!] 未检测到 CUDA。2B 以上在 CPU 上无法完成预训练，"
              "仅可用于 --tier tiny 的链路验证。")
    else:
        p = torch.cuda.get_device_properties(0)
        print(f"[i] GPU: {p.name}  {p.total_memory / 1024 ** 3:.1f} GB  算力 {p.major}.{p.minor}")
        if not torch.cuda.is_bf16_supported():
            print("[!] 该显卡不支持 bf16，训练将无法进行")
            return 1

    data_dir, tok_dir = Path(args.data_dir), Path(args.tokenizer)
    train_bin, val_bin = data_dir / "tokens_train.bin", data_dir / "tokens_val.bin"
    meta_path = data_dir / "data_meta.json"
    for label, p in (("分词器", tok_dir), ("训练数据", train_bin), ("数据元信息", meta_path)):
        if not p.exists():
            print(f"[!] 找不到{label}：{p}")
            print("    请依次运行 clean_data.py → train_tokenizer.py → prepare_data.py")
            return 1

    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    dtype_str = meta["dtype"]
    vocab_size = meta["vocab_size"]

    tokenizer = AutoTokenizer.from_pretrained(str(tok_dir))
    pad_id = tokenizer.pad_token_id
    bos_id = tokenizer.bos_token_id
    eos_id = tokenizer.eos_token_id

    train_ds = PackedMemmapDataset(train_bin, dtype_str, args.block_size)
    if len(train_ds) == 0:
        print(f"[!] {train_bin} 太小，切不出一个 {args.block_size} 长度的块。"
              f"请增加语料或减小 --block-size")
        return 1
    print(f"[i] 训练块 {len(train_ds):,} × {args.block_size} token "
          f"（共 {train_ds.data.shape[0]:,} token）")

    has_val = val_bin.exists() and val_bin.stat().st_size > 0
    val_ds = PackedMemmapDataset(val_bin, dtype_str, args.block_size) if has_val else None
    if val_ds is not None and len(val_ds) == 0:
        val_ds = None
    print(f"[i] 验证集：{len(val_ds):,} 块" if val_ds else "[i] 验证集：无（跳过评估）")

    arch = None
    if args.arch:
        try:
            arch = json.loads(args.arch)
            if not isinstance(arch, dict):
                arch = None
        except ValueError as e:
            print(f"[!] --arch 不是合法 JSON，忽略：{e}")
    config = build_config(args.tier, vocab_size, args.block_size, pad_id, bos_id, eos_id,
                          arch=arch)
    n_params = None
    with torch.device("meta"):
        n_params = count_params(LlamaForCausalLM(config))

    mem = estimate_memory(n_params, args.optimizer, not args.no_checkpointing,
                          args.master_dtype)
    print(f"[i] 档位 {args.tier}：{n_params:,} 参数 = {n_params / 1e9:.3f}B")
    print(f"[i] 预估显存：权重 {mem['weights']:.2f} + 梯度 {mem['grads']:.2f} "
          f"+ 优化器 {mem['opt']:.2f} + 激活 {mem['act']:.1f} ≈ {mem['total']:.2f} GB")

    if device.type == "cuda":
        vram = torch.cuda.get_device_properties(0).total_memory / 1024 ** 3
        if mem["total"] > vram:
            print(f"\n[!] 预估 {mem['total']:.1f} GB 超出显存 {vram:.1f} GB，几乎必然 OOM。")
            if args.optimizer == "adamw":
                print("    → 改用 --optimizer adafactor（优化器状态从 "
                      f"{mem['opt']:.1f} GB 降到 {n_params * 0.031 / 1024 ** 3:.2f} GB）")
            print("    → 或降档：--tier 小一档；或减小 --batch-size / --block-size")
            print("    → 或开启梯度检查点（去掉 --no-checkpointing）\n")
            return 1

    # ---- 加载或新建模型
    out_dir = Path(args.out_dir) if args.out_dir else OUT_ROOT / f"{args.tier}_model"
    out_dir.mkdir(parents=True, exist_ok=True)
    start_step = 0

    resume_from = None
    if args.resume_from:
        # 导入外部已有模型/检查点：允许指向别处，不要求在本项目输出目录内。
        rp = Path(args.resume_from)
        if not rp.is_dir():
            print(f"[!] 指定的续训目录不存在：{rp}")
            return 1
        if (rp / "config.json").exists():
            resume_from = rp                       # 直接就是模型/检查点目录
        else:
            resume_from = load_latest_checkpoint(rp)  # 是包含多个 checkpoint-* 的父目录
            if resume_from is None:
                print(f"[!] {rp} 内既无 config.json 也无 checkpoint-*，无法续训")
                return 1
    elif args.resume:
        resume_from = load_latest_checkpoint(out_dir)
        if resume_from is None:
            print(f"[!] {out_dir} 下没有 checkpoint-*，将从头开始训练")

    # ★主权重精度：bf16 只有 8 位尾数，权重 0.02 减 1e-5 会被舍入吞掉
    #   （实测 bf16 下结果反而变大），导致大模型训练震荡。
    #   fp32 主权重 + autocast bf16 计算是标准做法，显存代价约 +5.5GB。
    master_dtype = torch.float32 if args.master_dtype == "fp32" else torch.bfloat16

    if resume_from is not None:
        print(f"[i] 从检查点续训：{resume_from}")
        model = LlamaForCausalLM.from_pretrained(str(resume_from), dtype=master_dtype)
        state = json.loads((resume_from / "trainer_state.json").read_text(encoding="utf-8"))
        start_step = state.get("global_step", 0)
    else:
        model = LlamaForCausalLM(config)
        model = model.to(device, dtype=master_dtype)
    model = model.to(device)
    print(f"[i] 主权重精度：{args.master_dtype}（计算 autocast bf16）")

    if not args.no_checkpointing:
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        model.config.use_cache = False

    if args.optimizer == "adafactor":
        optimizer = Adafactor(
            model.parameters(), lr=args.lr, scale_parameter=False,
            relative_step=False, warmup_init=False,
            weight_decay=args.weight_decay, clip_threshold=1.0,
            decay_rate=-0.8, beta1=None,
        )
    else:
        optimizer = torch.optim.AdamW(
            model.parameters(), lr=args.lr, betas=(0.9, 0.95),
            weight_decay=args.weight_decay, eps=1e-8, fused=(device.type == "cuda"),
        )

    if resume_from is not None:
        opt_state = resume_from / "optimizer.pt"
        if opt_state.exists():
            optimizer.load_state_dict(torch.load(opt_state, map_location=device, weights_only=True))
            print("[i] 优化器状态已恢复")

    if args.compile:
        print("[i] 正在 torch.compile（首次编译较慢）…")
        model = torch.compile(model)

    # ---- 步数预算
    tokens_per_step = args.batch_size * args.grad_accum * args.block_size
    if args.max_tokens > 0:
        args.max_steps = max(1, int(args.max_tokens / tokens_per_step))
        print(f"[i] 按 token 预算 {args.max_tokens:.3g} → {args.max_steps:,} 步")
    print(f"[i] 每步消耗 {tokens_per_step:,} token "
          f"（batch {args.batch_size} × accum {args.grad_accum} × block {args.block_size}）")

    train_loader = torch.utils.data.DataLoader(
        train_ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers,
        collate_fn=collate, pin_memory=(device.type == "cuda"),
        drop_last=True, persistent_workers=args.num_workers > 0)
    val_loader = torch.utils.data.DataLoader(
        val_ds, batch_size=args.batch_size, shuffle=False, num_workers=0,
        collate_fn=collate, drop_last=True) if val_ds else None

    model.train()
    step = start_step          # 优化器步数：只有真正 optimizer.step() 之后才自增
    micro_step = 0             # micro-batch 计数：只用来控制梯度累积节奏
    running = 0.0              # 累计未缩放的真实 loss，供日志统计
    running_micro = 0          # 本日志区间实际参与的 micro-batch 数
    tokens_seen = step * tokens_per_step
    tokens_at_log = tokens_seen
    t0 = time.time()
    best_val = float("inf")

    # ---- C.3 日志：默认写到 out_dir/train_log.csv，传 --log-csv none 关闭
    log_path = None
    if args.log_csv and args.log_csv.lower() != "none":
        log_path = Path(args.log_csv)
    elif not args.log_csv:
        log_path = out_dir / "train_log.csv"
    logger = CsvLogger(log_path, resume=(resume_from is not None))
    if log_path:
        print(f"[i] 训练日志：{log_path}")
    guard = SpikeGuard(args)
    if guard.enabled:
        print(f"[i] 尖刺防护：abs>{args.spike_abs:g} / ratio>{args.spike_ratio:g}x "
              f"/ 窗口{args.spike_window} / 连续{args.spike_rollback_after}次回滚")
    if args.backup_dir:
        every = args.backup_every or (args.save_every * 5)
        print(f"[i] 检查点备份：{args.backup_dir}（每 {every} 步 + best/final）")
    logger.log("event", step=step, tokens_seen=tokens_seen, lr=args.lr,
               note=f"start tier={args.tier} params={n_params} "
                    f"batch={args.batch_size} accum={args.grad_accum} block={args.block_size}")

    lr_scale = 1.0             # 尖刺回滚时下调，乘在 lr_at 之上

    # ★优雅暂停：外部程序（如工坊界面）在 out_dir 放一个停止标记文件，
    #   训练在步边界检测到后保存断点再退出。
    #   为什么不用控制台 Ctrl+C 信号：后台启动的训练没有可见控制台，
    #   跨进程附着控制台不可靠；文件标记与控制台无关，跨进程稳定可用。
    stop_flag = out_dir / "STOP_REQUESTED"
    if stop_flag.exists():          # 清掉上次遗留的标记，避免刚启动就退出
        try:
            stop_flag.unlink()
            print("[i] 已清除上次遗留的停止标记")
        except OSError:
            pass

    try:
        while step < args.max_steps:
            for x, y in train_loader:
                if step >= args.max_steps:
                    break
                if stop_flag.exists():
                    raise StopRequested()
                x = x.to(device, non_blocking=True)
                y = y.to(device, non_blocking=True)
                lr = lr_at(step, args) * lr_scale
                for g in optimizer.param_groups:
                    g["lr"] = lr

                with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
                    raw_loss = model(x, labels=y).loss
                real_loss = raw_loss.item()

                # ---- C.2 尖刺检测：必须在 backward 之前，且用未缩放真值
                reason = guard.check(real_loss)
                if reason is not None:
                    print(f"    [尖刺] micro_step {micro_step} loss={real_loss:.4g} "
                          f"原因={reason} → 跳过该 batch")
                    optimizer.zero_grad(set_to_none=True)
                    logger.log("event", step=step, micro_step=micro_step,
                               tokens_seen=tokens_seen, loss=real_loss, lr=lr,
                               skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                               note=f"spike_skip {reason}")
                    micro_step += 1
                    if guard.should_rollback(args.spike_rollback_after):
                        # ★优先回滚到 best（验证 loss 最优，权重已知良好）；
                        #   最新的编号检查点可能是崩坏后保存的坏权重，回滚回去仍会崩。
                        ck = None
                        best_dir = out_dir / "best"
                        if (best_dir / "config.json").exists():
                            ck = best_dir
                        else:
                            ck = load_latest_checkpoint(out_dir)
                        if ck is None:
                            # 无任何检查点可回滚（开局即崩）：继续跑只会无限空转
                            print(f"\n[!] 连续 {guard.consecutive} 次尖刺，且尚无任何检查点可回滚。")
                            print("    这通常意味着学习率过高或数据/配置有问题，继续训练只会空转。")
                            print("    建议：降低 --lr（如降到当前值的 1/3～1/10）、"
                                  "延长 --warmup-steps，或检查语料是否异常。")
                            logger.log("event", step=step, micro_step=micro_step,
                                       tokens_seen=tokens_seen, lr=lr,
                                       skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                                       note="abort: consecutive spikes with no checkpoint")
                            logger.close()
                            return 2

                        guard.rollbacks += 1
                        # ★回滚次数上限：反复回滚仍崩说明权重或配置已不可救，止损退出
                        if (args.spike_max_rollbacks > 0
                                and guard.rollbacks > args.spike_max_rollbacks):
                            print(f"\n[!] 已回滚 {guard.rollbacks - 1} 次仍持续尖刺，判定无法自动恢复。")
                            print("    请人工介入：降低 --lr、检查语料，或从更早的健康检查点重启。")
                            logger.log("event", step=step, micro_step=micro_step,
                                       tokens_seen=tokens_seen, lr=lr,
                                       skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                                       note="abort: max rollbacks exceeded")
                            logger.close()
                            return 3

                        lr_scale *= args.spike_lr_decay
                        print(f"    [回滚] 连续 {guard.consecutive} 次尖刺 → "
                              f"载入 {ck.name}，lr 系数降至 {lr_scale:.3g}")
                        raw = model._orig_mod if hasattr(model, "_orig_mod") else model
                        src = LlamaForCausalLM.from_pretrained(str(ck), dtype=master_dtype)
                        raw.load_state_dict(src.state_dict())
                        del src
                        opt_f = ck / "optimizer.pt"
                        if opt_f.exists():
                            optimizer.load_state_dict(
                                torch.load(opt_f, map_location=device, weights_only=True))
                        optimizer.zero_grad(set_to_none=True)
                        # ★回到检查点的步数，避免用崩坏进度继续推进调度器
                        st_f = ck / "trainer_state.json"
                        if st_f.exists():
                            try:
                                ck_step = json.loads(st_f.read_text(encoding="utf-8")).get("global_step")
                                if isinstance(ck_step, int) and ck_step < step:
                                    step = ck_step
                                    tokens_seen = step * tokens_per_step
                                    tokens_at_log = tokens_seen
                            except (OSError, ValueError):
                                pass
                        guard.reset_streak()
                        guard.hist.clear()
                        running, running_micro = 0.0, 0
                        logger.log("event", step=step, micro_step=micro_step,
                                   tokens_seen=tokens_seen, lr=lr,
                                   skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                                   note=f"rollback to {ck.name} lr_scale={lr_scale:.4g}")
                    continue

                (raw_loss / args.grad_accum).backward()

                # 日志必须用未缩放的真实 loss：raw_loss 若直接除以 grad_accum 再累加，
                # 会让打印值偏小 grad_accum 倍，且与 val_loss 量纲不一致。
                running += real_loss
                running_micro += 1
                tokens_seen += x.numel()

                micro_step += 1
                if micro_step % args.grad_accum == 0:
                    if args.grad_clip > 0:
                        torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
                    optimizer.step()
                    optimizer.zero_grad(set_to_none=True)
                    step += 1

                    if step % args.log_every == 0:
                        avg = running / max(running_micro, 1)
                        elapsed = time.time() - t0
                        # 用真实 token 增量计时：每个 micro-batch 只消耗
                        # batch_size × block_size，乘 tokens_per_step 会虚高 grad_accum 倍。
                        tps = (tokens_seen - tokens_at_log) / elapsed if elapsed > 0 else 0
                        eta = (args.max_steps - step) / max(tps / tokens_per_step, 1e-6) / 3600
                        vram = (torch.cuda.max_memory_allocated() / 1024 ** 3
                                if device.type == "cuda" else 0.0)
                        print(f"step {step:>8,}/{args.max_steps:,} | loss {avg:.4f} "
                              f"| ppl {math.exp(min(avg, 20)):7.2f} | lr {lr:.2e} "
                              f"| {tps:,.0f} tok/s | {tokens_seen / 1e9:.3f}B tok "
                              f"| ETA {eta:.1f}h")
                        logger.log("train", step=step, micro_step=micro_step,
                                   tokens_seen=tokens_seen, loss=round(avg, 6),
                                   ppl=round(math.exp(min(avg, 20)), 3), lr=lr,
                                   tok_s=round(tps, 1), vram_gb=round(vram, 3),
                                   elapsed_s=round(elapsed, 3),
                                   skipped_spikes=guard.skipped, rollbacks=guard.rollbacks)
                        running, running_micro = 0.0, 0
                        tokens_at_log = tokens_seen
                        t0 = time.time()

                    if val_loader and step % args.eval_every == 0:
                        vl, vp = evaluate(model, val_loader, device, args.eval_batches, args.block_size)
                        print(f"    [eval] step {step:,} | val_loss {vl:.4f} | val_ppl {vp:.2f}")
                        logger.log("eval", step=step, micro_step=micro_step,
                                   tokens_seen=tokens_seen, loss=round(vl, 6),
                                   ppl=round(vp, 3), lr=lr,
                                   skipped_spikes=guard.skipped, rollbacks=guard.rollbacks)
                        if vl == vl and vl < best_val:      # NaN 安全比较
                            # ★别让崩坏权重占据 best：best 是尖刺回滚的首选目标，
                            #   若被坏权重污染，回滚回去仍会崩，形成无限循环。
                            polluted = (guard.enabled and args.spike_abs > 0
                                        and vl > args.spike_abs)
                            if polluted:
                                print(f"    [!] val_loss {vl:.4f} 超过尖刺阈值 "
                                      f"{args.spike_abs:g}，跳过 best 保存以免污染回滚目标")
                                logger.log("event", step=step, tokens_seen=tokens_seen,
                                           loss=round(vl, 6),
                                           note="skip best save: val_loss above spike threshold")
                            else:
                                best_val = vl
                                save_checkpoint(model, tokenizer, optimizer, step, out_dir,
                                                args, n_params, best=True)

                    if step % args.save_every == 0:
                        save_checkpoint(model, tokenizer, optimizer, step, out_dir,
                                        args, n_params, best=False)
                        prune_checkpoints(out_dir, args.keep_checkpoints)

                    if step >= args.max_steps:
                        break
    except StopRequested:
        print(f"\n[!] 收到暂停请求，保存当前进度（step {step}）…")
        save_checkpoint(model, tokenizer, optimizer, step, out_dir, args, n_params, best=False)
        backup_checkpoint(out_dir / f"checkpoint-{step}", f"checkpoint-{step}", step, args)
        try:
            stop_flag.unlink()      # 消费掉标记，便于下次直接续训
        except OSError:
            pass
        logger.log("event", step=step, micro_step=micro_step, tokens_seen=tokens_seen,
                   skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                   note="paused_by_request")
        logger.close()
        print(f"[i] 已暂停并保存断点 checkpoint-{step}，可续训")
        return 131

    except KeyboardInterrupt:
        print(f"\n[!] 收到中断，保存当前进度（step {step}）…")
        save_checkpoint(model, tokenizer, optimizer, step, out_dir, args, n_params, best=False)
        logger.log("event", step=step, micro_step=micro_step, tokens_seen=tokens_seen,
                   skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
                   note="keyboard_interrupt")
        logger.close()
        return 130

    save_checkpoint(model, tokenizer, optimizer, step, out_dir, args, n_params, best=False,
                    final=True)
    logger.log("event", step=step, micro_step=micro_step, tokens_seen=tokens_seen,
               skipped_spikes=guard.skipped, rollbacks=guard.rollbacks,
               note=f"done best_val={best_val:.6f}")
    logger.close()
    print(f"\n[i] 训练完成：{step:,} 步，{tokens_seen / 1e9:.3f}B token")
    print(f"[i] 模型已保存到 {out_dir}")
    if val_loader:
        print(f"[i] 最佳验证 loss：{best_val:.4f}")
    if guard.enabled and (guard.skipped or guard.rollbacks):
        print(f"[i] 尖刺统计：跳过 {guard.skipped} 个 micro-batch，回滚 {guard.rollbacks} 次")
    if log_path:
        print(f"[i] 训练日志：{log_path}")
    print(f"[i] 下一步：python scripts/test_model.py --tier {args.tier}")
    return 0


def save_checkpoint(model, tokenizer, optimizer, step, out_dir: Path,
                    args, n_params: int, best: bool = False, final: bool = False) -> None:
    """保存完整检查点：模型 + 优化器 + 训练状态，支持断点续训。"""
    name = "best" if best else ("final" if final else f"checkpoint-{step}")
    target = out_dir / name
    target.mkdir(parents=True, exist_ok=True)

    # torch.compile 后真实模型在 _orig_mod 下
    raw = model._orig_mod if hasattr(model, "_orig_mod") else model
    raw.save_pretrained(str(target))
    tokenizer.save_pretrained(str(target))
    torch.save(optimizer.state_dict(), target / "optimizer.pt")
    (target / "trainer_state.json").write_text(json.dumps({
        "global_step": step,
        "tier": args.tier,
        "n_params": n_params,
        "block_size": args.block_size,
        "batch_size": args.batch_size,
        "grad_accum": args.grad_accum,
        "optimizer": args.optimizer,
        "lr": args.lr,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"    [保存] {target}")
    backup_checkpoint(target, name, step, args, best=best, final=final)


def backup_checkpoint(target: Path, name: str, step: int, args,
                      best: bool = False, final: bool = False) -> None:
    """D.1 检查点异盘备份。

    ★备份失败绝不中断训练：整段 try/except，只打警告。
    ★best/final 始终备份；编号检查点按 backup-every 抽样，避免频繁写大盘。
    """
    if not args.backup_dir:
        return
    every = args.backup_every or (args.save_every * 5)
    if not (best or final) and (every <= 0 or step % every != 0):
        return

    root = Path(args.backup_dir)
    dest = root / target.parent.name / name
    try:
        dest.mkdir(parents=True, exist_ok=True)
        # 只复制续训必需的文件，跳过无关产物
        wanted = ("model.safetensors", "config.json", "generation_config.json",
                  "trainer_state.json", "optimizer.pt",
                  "tokenizer.json", "tokenizer_config.json")
        copied = 0
        for fn in wanted:
            src = target / fn
            if src.exists():
                shutil.copy2(src, dest / fn)
                copied += 1
        print(f"    [备份] {dest}  ({copied} 个文件)")
        if not (best or final):
            prune_backups(dest.parent, args.keep_backups)
    except Exception as e:                      # noqa: BLE001 备份不能拖垮训练
        print(f"    [!] 备份失败（训练继续）：{type(e).__name__}: {e}")


def prune_backups(root: Path, keep: int) -> None:
    """备份目录同样做保留个数清理，best/final 不动。"""
    if keep <= 0 or not root.exists():
        return
    cks = sorted(root.glob("checkpoint-*"), key=lambda p: int(p.name.split("-")[1]))
    for old in cks[:-keep]:
        try:
            for f in old.iterdir():
                f.unlink(missing_ok=True)
            old.rmdir()
        except OSError:
            pass


def prune_checkpoints(out_dir: Path, keep: int) -> None:
    """只保留最近 keep 个编号检查点，避免磁盘被占满（best/final 不动）。"""
    if keep <= 0:
        return
    cks = sorted(out_dir.glob("checkpoint-*"), key=lambda p: int(p.name.split("-")[1]))
    for old in cks[:-keep]:
        for f in old.iterdir():
            f.unlink(missing_ok=True)
        old.rmdir()


if __name__ == "__main__":
    sys.exit(main())

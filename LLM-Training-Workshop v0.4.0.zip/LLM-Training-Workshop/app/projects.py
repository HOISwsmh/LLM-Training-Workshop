"""项目管理：每个训练项目一个独立目录，配置与产物都在其中。

目录结构（用户项目）：
  projects/<项目名>/
    config.json      用户选择的配置
    state.json       流水线各工位状态
    corpus/          下载的原始语料
    data/            清洗/打包/混合产物
    tokenizer/       训练出的词表
    output/          模型与检查点
    logs/            各工位日志
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from pathlib import Path

from .paths import projects_dir

# ★状态写并发锁：训练线程与 HTTP 请求线程都会 read-modify-write state.json，
#   旧实现固定 .tmp 名 + 无锁，并发时临时文件互踩、更新丢失（审计指出）。
#   每项目一把锁串行化写入，临时名带 pid+线程 id 保证唯一。
_STATE_LOCKS: dict = {}
_STATE_LOCKS_GUARD = threading.Lock()


def _state_lock(name: str) -> threading.Lock:
    with _STATE_LOCKS_GUARD:
        lk = _STATE_LOCKS.get(name)
        if lk is None:
            lk = threading.Lock()
            _STATE_LOCKS[name] = lk
        return lk

# ★项目目录必须走 paths.projects_dir()：它面向 exe 冻结场景返回 exe 同级目录。
#   旧实现用 __file__ 自建，一旦 PyInstaller onefile 打包，projects 会落到
#   _MEI 临时解包目录，退出即丢用户数据（审计指出）。源码运行时两者等价。
ROOT = projects_dir().parent
PROJECTS_DIR = projects_dir()

# 工位：预训练七步 + 微调/导出三步（v0.4.0 扩展，边界到通用预训练+SFT/LoRA）
STAGES = [
    ("adapt", "识别字段", "统一字段结构，认出正文列"),
    ("clean", "清洗", "按语料类型去噪、去重、过滤"),
    ("tokenizer", "训练词表", "学习分词器"),
    ("pack", "打包", "转成 token 流"),
    ("mix", "整合", "按配比混合成最终训练集"),
    ("train", "训练", "预训练模型"),
    ("test", "验证", "困惑度与生成测试"),
    ("sft", "指令微调", "SFT 教模型按问答格式回应"),
    ("lora", "LoRA微调", "低秩适配微调，省显存可叠加"),
    ("export", "量化导出", "精简HF包+GGUF量化+自检"),
]

DEFAULT_CONFIG = {
    "tier": "base",
    "arch": None,               # 自定义架构；None = 用档位预设
    # ★默认上下文 2048：社区主预训练普遍 4096（Qwen2.5 主阶段即 4096），
    #   1024 偏短。单卡显存有限取 2048 折中；冒烟档可在界面调小。
    #   只影响新建项目，已有项目配置不变。
    "block_size": 2048,
    "batch_size": 4,
    "grad_accum": 4,
    "lr": None,                 # None = 按档位自动
    "master_dtype": "bf16",
    "max_tokens": 0,            # 0 = 按语料实际供给
    # ★全混合（用户要求）：True = 按各类实际 token 量成比例、用完全部数据，
    #   忽略 weight/percent/max_tokens；False = 按权重/百分比（旧行为）。
    "mix_all": False,
    "warmup_steps": 500,
    "vocab_size": 32000,
    # 词表类型：False（默认）= 普通文本 LLM，只注册 5 个基础标记；
    # True = 额外注册音频/谱面控制符，供第二阶段多模态训练。
    # ★发布版默认纯文本，用户拿到就能训出干净的普通 LLM。
    "multimodal_tokens": False,
    # 用户自定义特殊标记：逗号/换行分隔的字符串，任意领域可用。
    # 留空 = 只用 5 个基础标记（+ 可选预设扩展）。
    "extra_special": "",
    # 语料条目：每条一个本地路径 + 类型 + 可选权重
    # [{"path": "D:/语料/wiki", "kind": "wiki", "weight": 1.0}, ...]
    "corpus": [],
    "clean_level": "standard",  # loose / standard / strict
    # ★全局强度微调（用户要求把全局数值改成可调）：比率=偏移量、
    #   min_chars_scale=倍数、max_chars=绝对上限，叠在「类型预设×档位」上，
    #   各类按自身基线联动。必须在 DEFAULT_CONFIG 里，否则 save_config 的
    #   allowed 过滤会丢弃它，前端填的微调存不进 config.json。
    "clean_level_adjust": {},
    # 旧版全局绝对值覆盖：保留键以兼容旧 config.json，新界面不再写入；
    # 清洗工位已改用 clean_level_adjust，此键不再参与计算。
    "clean_overrides": {},
    # ★数据质量增强开关（默认关，不改变旧行为）
    "near_dup": False,          # MinHash 近重复检测
    "near_dup_threshold": 0.8,
    "pii": False,               # PII/密钥脱敏
    "val_by_hash": False,       # 按文档hash划分train/val防泄漏
    # 模型输出目录：留空 = 项目内 output/model；也可指定任意位置
    "output_dir": "",
    "save_every": 500,
    "keep_checkpoints": 3,
    "backup_dir": "",
    "backup_every": 500,
    "keep_backups": 10,
    "eval_every": 500,
    "log_every": 20,
    "num_workers": 0,
    "spike_guard": True,
    # 日志语言：zh（默认，保持既有中文输出不变）/ en
    # ★与界面语言独立：界面切英文不会改动已有项目的日志语言
    "log_lang": "zh",
    # 每个工位的来源：{"tokenizer": {"mode": "import", "path": "..."}}
    # mode: "auto"（自己生成，默认） / "import"（用已有文件）
    # 语料类工位可按条覆盖：corpus[i]["clean_import"] 指向已清洗文件
    "sources": {},
    # ★微调/导出配置（v0.4.0）
    "sft_data": "",            # 对话 jsonl 路径（空=用项目内 data/sft.jsonl）
    "sft_lr": 2e-5,
    "sft_steps": 2000,
    "sft_batch": 2,
    "sft_accum": 8,
    "lora_r": 16,
    "lora_alpha": 32,
    "lora_lr": 1e-4,
    "lora_steps": 2000,
    "lora_merge": True,        # LoRA 训练后合并导出完整模型
    "export_quant": "Q4_K_M",
    "llama_cpp": "",           # llama.cpp 目录（GGUF 转换用，空=只导HF）
    # ★自定义量化调参（llama-quantize 真实选项，空/False=默认行为）
    "quant_imatrix": "",       # 重要性矩阵文件路径
    "quant_pure": False,       # 关闭 k-quant 混合
    "quant_leave_output": False,  # 输出层不量化
    "quant_allow_requantize": False,
    "quant_output_type": "",   # 输出层单独类型，如 q6_k
    "quant_embed_type": "",    # 词嵌入层单独类型
    "quant_tensor_types": "",  # 逐张量自定义，每行 正则=类型
    "quant_threads": 0,        # 0=默认线程
    "quant_extra_args": "",    # 额外原始参数
}

_NAME_RE = re.compile(r"^[\w\u4e00-\u9fff][\w\u4e00-\u9fff .-]{0,48}$")


def output_dir(name: str, cfg: dict | None = None) -> Path:
    """模型输出目录。留空用项目内 output/model；否则用用户指定位置。

    ★所有读写输出的地方都必须走这个函数，避免"训练写到A、界面读B"的口径分裂。
    """
    if cfg is None:
        try:
            cfg = load(name)["config"]
        except (ValueError, OSError):
            cfg = {}
    raw = (cfg.get("output_dir") or "").strip().strip('"')
    if raw:
        return Path(raw)
    return project_dir(name) / "output" / "model"


def safe_name(name: str) -> str:
    """校验项目名，阻断路径穿越。"""
    name = (name or "").strip()
    if not _NAME_RE.match(name) or ".." in name or name in (".", ".."):
        raise ValueError("项目名只能包含中英文、数字、空格、点、下划线和连字符，且不超过 50 字")
    return name


def project_dir(name: str) -> Path:
    return PROJECTS_DIR / safe_name(name)


def _read_json(p: Path, default):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write_json(p: Path, data) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    # ★唯一临时名（pid+线程id）：固定 .tmp 名在并发写下会互踩（审计指出）。
    tmp = p.with_suffix(f"{p.suffix}.tmp-{os.getpid()}-{threading.get_ident()}")
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(p)      # 原子替换，避免断电写坏配置
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def new_state() -> dict:
    return {
        "stages": {k: {"status": "pending", "progress": 0.0, "message": "",
                       "started_at": None, "finished_at": None}
                   for k, _n, _d in STAGES},
        "running": False,
        "current": None,
        "created_at": time.time(),
        "error": None,
    }


def create(name: str, config: dict | None = None) -> dict:
    d = project_dir(name)
    if d.exists():
        raise ValueError(f"项目「{name}」已存在")
    for sub in ("corpus", "data", "tokenizer", "output", "logs"):
        (d / sub).mkdir(parents=True, exist_ok=True)
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(config or {})
    cfg["name"] = name
    _write_json(d / "config.json", cfg)
    _write_json(d / "state.json", new_state())
    return {"name": name, "config": cfg, "state": new_state()}


def list_all() -> list[dict]:
    if not PROJECTS_DIR.exists():
        return []
    out = []
    for d in sorted(PROJECTS_DIR.iterdir()):
        if not d.is_dir() or d.name.startswith("_"):
            continue
        cfg = _read_json(d / "config.json", None)
        if cfg is None:
            continue
        st = _read_json(d / "state.json", new_state())
        done = sum(1 for s in st["stages"].values() if s["status"] == "done")
        out.append({
            "name": d.name,
            "tier": cfg.get("tier"),
            "block_size": cfg.get("block_size"),
            "running": st.get("running", False),
            "current": st.get("current"),
            "stages_done": done,
            "stages_total": len(STAGES),
            "created_at": st.get("created_at"),
        })
    return out


def load(name: str) -> dict:
    d = project_dir(name)
    cfg = _read_json(d / "config.json", None)
    if cfg is None:
        raise ValueError(f"项目「{name}」不存在")
    return {"name": name, "config": cfg,
            "state": _read_json(d / "state.json", new_state())}


def save_config(name: str, patch: dict, internal: bool = False) -> dict:
    d = project_dir(name)
    # ★整段读-改-写入每项目锁：用户保存与流水线内部写回（internal）可能
    #   并发，旧实现无锁，两份 cfg 交错互覆会丢更新。锁内再调 save_state
    #   会重入，故状态写直接走 _write_json（同一把锁已持有）。
    with _state_lock(name):
        cfg = _read_json(d / "config.json", None)
        if cfg is None:
            raise ValueError(f"项目「{name}」不存在")
        st = _read_json(d / "state.json", new_state())
        # ★internal=True：流水线运行中写回自己的结果（如识别工位把 auto 判出的
        #   语料类型写回 corpus）。这是运行的一部分，不是用户改参，不受运行锁限制，
        #   也不触发下游失效。旧实现一律拒绝，导致识别跑到一半自抛
        #   「项目正在运行，请先停止再修改配置」，整个工位 failed（用户实测）。
        if st.get("running") and not internal:
            raise ValueError("项目正在运行，请先停止再修改配置")
        allowed = set(DEFAULT_CONFIG) | {"name"}
        # ★改参失效下游：先记下真正变化的「内容级」字段，保存后把受影响的
        #   已完成工位标 pending。旧实现改 vocab/档位/上下文后下游仍 done，
        #   一键跑静默用旧词表/旧数据（三份审计一致指出的最高危项）。
        from .pipeline import CONFIG_STAGE_KEYS  # noqa: PLC0415  延迟导入避免循环
        affected = set()
        for k, v in patch.items():
            if k in allowed and k != "name":
                if k in CONFIG_STAGE_KEYS and cfg.get(k) != v:
                    affected.update(CONFIG_STAGE_KEYS[k])
                cfg[k] = v
        _write_json(d / "config.json", cfg)
        # ★内部写回不动工位状态：运行中 state.json 由流水线线程独占刷新，
        #   这里改了也会被覆盖；下游失效已由 reset/start 的 invalidate_downstream 处理
        if affected and not internal:
            for k in affected:
                if k in st.get("stages", {}) and st["stages"][k]["status"] == "done":
                    st["stages"][k] = {"status": "pending", "progress": 0.0,
                                       "message": "配置已修改，需重跑",
                                       "started_at": None, "finished_at": None}
            _write_json(d / "state.json", st)
        return cfg


def save_state(name: str, state: dict) -> None:
    with _state_lock(name):
        _write_json(project_dir(name) / "state.json", state)


def predict_rerun(name: str, patch: dict) -> dict:
    """配置编辑的下游重跑预测：改这些字段会让哪些已完成工位失效。

    只读不写，供界面在保存前展示「改了 X → 这几步要重跑」，改前心里有数。
    """
    d = project_dir(name)
    cfg = _read_json(d / "config.json", None)
    if cfg is None:
        raise ValueError(f"项目「{name}」不存在")
    st = _read_json(d / "state.json", new_state())
    from .pipeline import CONFIG_STAGE_KEYS  # noqa: PLC0415
    changed, affected = [], set()
    for k, v in patch.items():
        if k in CONFIG_STAGE_KEYS and cfg.get(k) != v:
            changed.append(k)
            affected.update(CONFIG_STAGE_KEYS[k])
    rerun = [k for k in affected
             if k in st.get("stages", {}) and st["stages"][k]["status"] == "done"]
    return {"changed": changed, "rerun": sorted(rerun, key=lambda x: [s[0] for s in STAGES].index(x))}


def delete(name: str) -> None:
    """删除项目：仅允许删本项目目录内的内容，且需调用方确认。"""
    import shutil  # noqa: PLC0415

    d = project_dir(name)
    if not d.exists():
        raise ValueError(f"项目「{name}」不存在")
    st = _read_json(d / "state.json", new_state())
    # ★双校验：state.json 损坏时兜底 new_state() 的 running=False，
    #   只看文件会把运行中项目删掉；再查运行器实时状态兜底
    from .pipeline import RUNNER  # noqa: PLC0415  延迟导入避免循环
    if st.get("running") or (RUNNER.is_running() and RUNNER.active == name):
        raise ValueError("项目正在运行，请先停止")
    # 双保险：确认路径确实在 projects 目录之下
    if PROJECTS_DIR.resolve() not in d.resolve().parents:
        raise ValueError("路径校验失败，拒绝删除")
    shutil.rmtree(d)

/* LLM Training Workshop — front-end logic.
   Zero dependencies; charts drawn on native canvas. Bilingual via i18n.js. */
'use strict';

const $ = (s) => document.querySelector(s);
const $$ = (s) => Array.from(document.querySelectorAll(s));

const S = {
  meta: null, hw: null, rec: null,
  projects: [], current: null, proj: null, runner: null, env: null,
  form: { tier: null, clean: 'standard', save: 500, spike: true, corpus: [],
          arch: {}, archOpen: false, archOn: false, tie: true, logLang: 'zh' },
  timer: null, dataLogStage: 'clean', trainLogStage: 'train',
  watchName: null, watchSnap: null, lastDone: false,
};

const DATA_STAGES = ['adapt', 'clean', 'tokenizer', 'pack', 'mix'];
const MIX_COLORS = ['#22d3ee', '#a78bfa', '#34d399', '#fbbf24', '#f87171', '#60a5fa', '#f472b6', '#4ade80'];

/* ---------------- net & ui helpers ---------------- */
async function api(path, body) {
  const opt = body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {};
  const r = await fetch(path, opt);
  const j = await r.json();
  if (!j.ok) throw new Error(j.error || 'request failed');
  return j.data;
}

function toast(msg, kind) {
  const el = document.createElement('div');
  el.className = 'toast ' + (kind || '');
  el.textContent = msg;
  $('#toast').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, 4600);
}

function confirmBox(title, text, extraHTML) {
  return new Promise((res) => {
    $('#mTitle').textContent = title;
    $('#mText').textContent = text;
    $('#mExtra').innerHTML = extraHTML || '';
    $('#modal').classList.add('on');
    const done = (v) => { $('#modal').classList.remove('on'); $('#mOk').onclick = null; $('#mCancel').onclick = null; res(v); };
    $('#mOk').onclick = () => done(true);
    $('#mCancel').onclick = () => done(false);
  });
}

const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const fmt = {
  n: (v) => (v == null ? '—' : Number(v).toLocaleString('en-US')),
  f: (v, d = 2) => (v == null ? '—' : Number(v).toFixed(d)),
  tok: (v) => {
    if (v == null) return '—';
    if (v >= 1e9) return (v / 1e9).toFixed(2) + 'B';
    if (v >= 1e6) return (v / 1e6).toFixed(1) + 'M';
    if (v >= 1e3) return (v / 1e3).toFixed(1) + 'K';
    return String(v);
  },
  eta: (sec) => {
    if (!sec || sec < 0 || !isFinite(sec)) return '—';
    if (sec < 3600) return Math.round(sec / 60) + ' ' + t('unit.min');
    if (sec < 86400) return (sec / 3600).toFixed(1) + ' ' + t('unit.hour');
    return (sec / 86400).toFixed(1) + ' ' + t('unit.day');
  },
  dur: (sec) => {
    if (!sec || sec < 0) return '—';
    if (sec < 60) return Math.round(sec) + ' ' + t('unit.sec');
    if (sec < 3600) return (sec / 60).toFixed(1) + ' ' + t('unit.min');
    if (sec < 86400) return (sec / 3600).toFixed(1) + ' ' + t('unit.hour');
    return (sec / 86400).toFixed(1) + ' ' + t('unit.day');
  },
};

const stageName = (k) => t('stage.' + k);
const kindName = (k) => t('kind.' + k);
const levelName = (k) => t('level.' + k);
const groupName = (k) => t('group.' + k);

/* ---------------- 后端直出文案的翻译 ----------------
   后端返回的描述/提示/工位消息是中文。中文界面原样显示；
   英文界面查表翻译，查不到就保留中文（绝不显示空白或键名）。 */
const SV = {
  // 语料类型描述
  '新闻、博客、论坛等长文本': 'Long-form news, blogs and forums',
  '维基百科、百度百科等结构化词条': 'Structured encyclopedia entries',
  '知乎、问答社区、指令数据': 'Q&A communities and instruction data',
  '维基文库、电子书、长篇文章': 'Wikisource, ebooks and long articles',
  '公版古籍，段落短、文言密度高': 'Public-domain classics; short paragraphs',
  '源码文件，中文占比为 0 属正常': 'Source code; zero CJK ratio is normal',
  '结构不确定的语料，按通用规则处理': 'Unknown structure; generic rules applied',
  // 分组描述
  '识别字段 + 清洗': 'Map fields + clean',
  '训词表 + 打包 + 混合': 'Tokenizer + pack + mix',
  '从原始语料到可训练数据': 'Raw corpus to trainable data',
  '用已有训练集开始/继续训练': 'Start or resume with an existing dataset',
  '对已训好的模型做生成与困惑度测试': 'Generation and perplexity test on a trained model',
  '一条流水线跑到底': 'Run the whole pipeline end to end',
  // 清洗强度描述
  '保留更多，噪声也更多': 'Keeps more, including more noise',
  '推荐，按类型适配': 'Recommended; per-type presets',
  '只留高质量，可能损失较多': 'High quality only; may drop a lot',
  // 清洗字段名
  '中文字符占比下限': 'Min CJK ratio',
  '重复率上限': 'Max repeat ratio',
  '符号占比上限': 'Max symbol ratio',
  '最短字符数': 'Min characters',
  '最长字符数': 'Max characters',
  '数字占比上限': 'Max digit ratio',
  '单字最高占比': 'Max single-char ratio',
  // 清洗字段提示
  '低于此值的样本丢弃。代码类应设 0': 'Drop samples below this. Use 0 for code',
  '4-gram 重复率超过此值丢弃。代码类建议 ≥0.8': 'Drop above this 4-gram repeat rate. Use >=0.8 for code',
  '标点符号过多视为噪声': 'Too much punctuation counts as noise',
  '短于此值丢弃。古籍段落短，建议 8': 'Drop shorter samples. Classics are short; 8 works',
  '超长样本截断或丢弃，留空用默认': 'Trim or drop overlong samples; empty = default',
  '纯数字表格类内容的过滤，留空用默认': 'Filters numeric tables; empty = default',
  '某个字反复出现的刷屏文本，留空用默认': 'Catches spam repeating one character; empty = default',
  // 架构字段名
  '隐层宽度': 'Hidden size',
  '层数': 'Layers',
  '前馈中间维度': 'FFN intermediate size',
  '每头维度': 'Head dimension',
  '注意力头数': 'Attention heads',
  'KV 头数（GQA）': 'KV heads (GQA)',
  // 导入规格
  '已识别的语料': 'Mapped corpus',
  '已清洗的语料': 'Cleaned corpus',
  '已有词表': 'Existing tokenizer',
  '已打包的 token 流': 'Packed token stream',
  '已整合的训练集': 'Mixed dataset',
  '已有模型/断点': 'Existing model / checkpoint',
  '待验证的模型': 'Model to evaluate',
  '已统一字段的 jsonl（每行含 text 字段）': 'jsonl with unified fields (text per line)',
  '清洗好的 jsonl，可跳过识别与清洗': 'Cleaned jsonl; skips mapping and cleaning',
  '含 tokenizer.json 的目录（会复制到项目内）': 'Folder with tokenizer.json (copied into the project)',
  '含 tokens_train.bin 与 data_meta.json 的目录（直接引用，不复制）':
    'Folder with tokens_train.bin and data_meta.json (referenced, not copied)',
  '检查点目录，或含 config.json 的模型目录；有 optimizer.pt 则连优化器状态一起接上':
    'A checkpoint folder, or a model folder with config.json; optimizer state is restored if optimizer.pt exists',
  '含 config.json 与权重的模型目录': 'Model folder with config.json and weights',
  // 常见工位消息
  '训练中…': 'Training...',
  '训练完成': 'Training finished',
  '词表已生成': 'Tokenizer created',
  '清洗完成': 'Cleaning finished',
  '用户停止': 'Stopped by user',
  '已暂停并保存断点，可点「继续训练」接着跑':
    'Paused and checkpoint saved; click Resume to continue',
  // 硬件警告与档位理由（后端直出）
  '需要 CUDA 显卡': 'A CUDA GPU is required',
  '未检测到可用的 NVIDIA 显卡，将使用 CPU 模式（极慢，仅供体验 15M 档）。':
    'No usable NVIDIA GPU detected; falling back to CPU mode (very slow, only fit for the 15M tier).',
  '显卡算力过低（需 RTX 20 系及以上），可能无法运行 GPU 训练。':
    'GPU compute capability is too low (RTX 20 series or newer required); GPU training may not run.',
  '内存检测不可用': 'Memory detection unavailable',
  // 配置校验：上下文与模型规模
  '上下文长度必须是正整数': 'Context length must be a positive integer',
  '显存较紧张，建议关闭其他占用显存的程序。':
    'VRAM is tight; consider closing other programs that use the GPU.',
  '未检测到可用显卡，将走 CPU，速度会非常慢（建议仅用小档位体验流程）。':
    'No usable GPU detected; CPU mode will be very slow (use a small tier just to try the workflow).',
  '长上下文会增加显存与耗时（实测 4096 比 1024 慢约 15%）。':
    'Longer context costs more VRAM and time (measured: 4096 is about 15% slower than 1024).',
  // 导入校验
  '请填写路径': 'Enter a path',
  '这里需要填一个文件，而不是文件夹': 'A file is required here, not a folder',
  '这里需要填一个文件夹，而不是文件': 'A folder is required here, not a file',
  '文件是空的': 'The file is empty',
  '首行不是 JSON 对象': 'The first line is not a JSON object',
  '首行没有 text 字段，可能不是已统一字段的语料':
    'The first line has no text field; this may not be a mapped corpus',
  '无法按 jsonl 读取首行，文件可能损坏或不是文本':
    'Could not read the first line as jsonl; the file may be corrupt or not text',
  '目录内既没有 config.json，也没有可用的 checkpoint-*':
    'The folder has neither config.json nor a usable checkpoint-*',
  '没有验证集 tokens_val.bin，训练中的困惑度评估会被跳过':
    'No tokens_val.bin; perplexity evaluation during training will be skipped',
  'tokenizer.json 无法解析出词表大小': 'Could not read the vocab size from tokenizer.json',
  'config.json 无法解析': 'Could not parse config.json',
  '目录里没有模型权重（model.safetensors 或 pytorch_model.bin）':
    'No model weights in the folder (model.safetensors or pytorch_model.bin)',
  '没有 optimizer.pt：只继承权重，优化器从零开始，学习率预热会重来，loss 可能短暂上跳':
    'No optimizer.pt: only weights are inherited, the optimizer starts fresh and warmup restarts, so loss may briefly jump',
  'data_meta.json 里训练 token 数为 0': 'data_meta.json reports zero training tokens',
  // 架构字段提示（界面通常走 i18n 键，这里兜底覆盖后端直出的情况）
  '模型主干维度，越大越强也越吃显存。不限上限':
    'Backbone width; larger is stronger and costs more VRAM. No upper limit.',
  'Transformer 块数量，决定深度。不限上限': 'Number of transformer blocks. No upper limit.',
  'SwiGLU 内部维度，通常约为隐层的 2.7–4 倍。不限上限':
    'SwiGLU inner dimension, usually 2.7-4x the hidden size. No upper limit.',
  '常用 64 或 128。不限上限': 'Commonly 64 or 128. No upper limit.',
  '留空则自动 = 隐层宽度 ÷ 每头维度。不限上限':
    'Leave empty to use hidden size / head dimension. No upper limit.',
  '留空自动取头数的 1/4；不能整除时自动下调':
    'Leave empty to use a quarter of the heads; lowered automatically if it does not divide evenly.',
  // 清洗风险提示
  '中文门槛过高，混合中英文的语料可能被大量丢弃':
    'The CJK threshold is high; mixed Chinese/English text may be dropped in bulk.',
  '代码的 4-gram 重复率中位数约 0.52，阈值低于此值会误杀约一半样本':
    'Code has a median 4-gram repeat rate near 0.52; a lower threshold would discard about half the samples.',
  '代码语料的中文占比通常为 0，中文门槛大于 0.05 可能滤掉绝大部分代码':
    'Code usually has zero CJK ratio; a threshold above 0.05 may filter out most of it.',
  '古籍段落中位数约 34 字，最短门槛过高会滤掉大量正常段落':
    'Classical paragraphs average about 34 characters; a high minimum would drop many valid ones.',
  '符号率上限过低，含公式或代码片段的文本容易被丢弃':
    'The symbol-ratio cap is low; text with formulas or code snippets is easily dropped.',
  '最短字数不小于最长字数，会导致所有样本被丢弃':
    'The minimum length is not below the maximum, so every sample would be dropped.',
  '隐层宽度/层数/中间维度取值很小，模型容量会非常有限':
    'Hidden size / layers / intermediate size are very small; model capacity will be limited.',
  // 硬件与内存
  '内存信息读取失败，不影响训练；显存与磁盘数据仍准确。':
    'Could not read memory info; training is unaffected and VRAM/disk figures are still accurate.',
  // 项目与运行状态
  '名称过长（最多 50 字）': 'Name is too long (50 characters max)',
  '项目名只能包含中英文、数字、空格、点、下划线和连字符，且不超过 50 字':
    'Project names may contain letters, Chinese characters, digits, spaces, dots, underscores and hyphens, up to 50 characters.',
  '项目正在运行，请先停止': 'The project is running; stop it first',
  '项目正在运行，请先停止再修改配置': 'The project is running; stop it before changing the configuration',
  '训练输出目录尚未创建，请稍等再试': 'The training output folder does not exist yet; try again shortly',
  '路径校验失败，拒绝删除': 'Path validation failed; deletion refused',
  '路径不存在': 'Path does not exist',
  '未找到该监控项': 'Monitor entry not found',
  '该目录已在监控列表中': 'This folder is already being monitored',
  '该路径下没有 jsonl/json/parquet/gz 文件': 'No jsonl/json/parquet/gz files under this path',
  '请填写监控名称': 'Enter a monitor name',
  '请填写 python.exe 的完整路径': 'Enter the full path to python.exe',
  '路径不存在或不是 python 可执行文件': 'The path does not exist or is not a python executable',
  '该环境缺少训练依赖（需要 torch/transformers/tokenizers/numpy），请先在其中安装后重试':
    'This environment lacks training dependencies (torch/transformers/tokenizers/numpy); install them and retry',
  '已请求暂停。训练会在当前步结束后保存断点再退出，请稍候。':
    'Pause requested. Training will save a checkpoint after the current step and then exit; please wait.',
  '本工具为单卡训练设计，不支持多卡/多机并行（多张卡只用第一张，不合并显存）。模型规模、上下文长度与显存需求**不设强制上限**：超出参考范围时只提示风险，是否尝试由你决定。它是面向个人开发者的实验性工具，请自行核对数据与许可。':
    'Built for single-GPU training; no multi-GPU or multi-node support (only the first GPU is used, VRAM is not pooled). Model size, context length and VRAM needs have no hard limits: going beyond the reference range only raises a warning, and the choice is yours. This is an experimental tool for individual developers; verify your data and licences yourself.',
};

// 后端消息里的中文工位名 → 工位 key，便于在英文提示中显示为英文工位名
const STAGE_BY_ZH = {
  '识别字段': 'adapt', '清洗': 'clean', '训练词表': 'tokenizer',
  '打包': 'pack', '整合': 'mix', '训练': 'train', '验证': 'test',
};

// 档位标签：后端返回中文，界面按当前语言取对应文案
const tierLabel = (k, fallback) => {
  const key = 'tierLabel.' + k;
  const v = t(key);
  return v === key ? (fallback || k) : v;
};

// 中文界面直接返回；英文界面查表，未收录保留中文
const sv = (s) => {
  if (!s) return s;
  if (PREF.lang !== 'en') return s;
  if (SV[s] != null) return SV[s];
  // 带变量的消息：按中文句式匹配后回填数字
  const patterns = [
    // 显卡被其他程序占用
    [/^显卡已被其他程序占用约 ([\d.]+)GB（可能是本地模型、游戏或另一个训练任务）。推荐规模已按剩余显存计算。$/,
      (m) => `About ${m[1]}GB of VRAM is in use by other programs (a local model, a game, or another training job). The recommendation is based on what is left.`],
    // 多卡提示
    [/^检测到 (\d+) 张显卡，但本工具只使用第 1 张，不会合并多卡显存。$/,
      (m) => `${m[1]} GPUs detected, but this tool only uses the first one; VRAM is not pooled.`],
    // 档位显存不足理由
    [/^约需 ([\d.]+)GB 显存，当前可用 ([\d.]+)GB$/,
      (m) => `Needs about ${m[1]}GB VRAM; ${m[2]}GB available`],
    // 架构预估超限
    [/^预计需要约 ([\d.]+)GB 显存，当前可用约 ([\d.]+)GB，\*\*可能 OOM\*\*。$/,
      (m) => `Estimated ${m[1]}GB VRAM needed vs about ${m[2]}GB available — OOM is likely.`],
    [/^未检测到可用显卡，将走 CPU，速度会非常慢（建议仅用小档位体验流程）。$/,
      () => 'No usable GPU detected; CPU mode will be very slow (use a small tier just to try the workflow).'],
    // 配置校验：未知档位 / 上下文过短或超范围
    [/^未知的模型规模：(.+)$/, (m) => `Unknown model tier: ${m[1]}`],
    [/^上下文 (\d+) 很短，样本会被切得很碎，通常建议 ≥256$/,
      (m) => `A context of ${m[1]} is very short and will chop samples finely; 256 or more is usually better`],
    [/^上下文 (\d+) 超出已验证范围（(\d+)）。本工具未内置 FlashAttention 与序列并行，注意力显存随长度平方增长，可能非常慢或直接 OOM。可以尝试，风险自负。$/,
      (m) => `A context of ${m[1]} is beyond the verified range (${m[2]}). There is no FlashAttention or sequence parallelism here, and attention memory grows with the square of length, so it may be very slow or OOM. You can still try, at your own risk.`],
    // 自定义架构摘要
    [/^自定义架构：(\d+) 宽 × (\d+) 层，(\d+) 头（KV (\d+)），约 ([\d.]+)B 参数$/,
      (m) => `Custom architecture: ${m[1]} wide x ${m[2]} layers, ${m[3]} heads (KV ${m[4]}), about ${m[5]}B params`],
    // 模型超舒适区
    [/^模型约 ([\d.]+)B，超出单卡舒适区参考值 ([\d.]+)B。本工具不做模型切分，参数必须完整放进一张卡。可以尝试，风险自负。$/,
      (m) => `The model is about ${m[1]}B, above the single-GPU comfort reference of ${m[2]}B. There is no model sharding here, so all parameters must fit on one card. You can still try, at your own risk.`],
    // 显存不足补充建议
    [/^可先退出占显存的程序（本地模型\/游戏）、减小批大小或上下文；也可以直接尝试——是否启动由你决定。$/,
      () => 'You can close programs using VRAM (a local model or a game), lower the batch size or context, or just go ahead — starting is your call.'],
    // ★后端会把「可能 OOM」和上面那条建议拼成一句返回，需整句匹配
    [/^预计需要约 ([\d.]+)GB 显存，当前可用约 ([\d.]+)GB，\*\*可能 OOM\*\*。可先退出占显存的程序（本地模型\/游戏）、减小批大小或上下文；也可以直接尝试——是否启动由你决定。$/,
      (m) => `Estimated ${m[1]}GB VRAM needed vs about ${m[2]}GB available — OOM is likely. You can close programs using VRAM (a local model or a game), lower the batch size or context, or just go ahead — starting is your call.`],
    // 导入自动选断点
    [/^已自动选用最新断点 (.+)$/, (m) => `Automatically picked the latest checkpoint: ${m[1]}`],
    // 缺少必需文件 / 路径不存在
    [/^缺少必需文件：(.+)$/, (m) => `Missing required file: ${m[1]}`],
    [/^路径不存在：(.+)$/, (m) => `Path does not exist: ${m[1]}`],
    [/^只支持 (.+) 文件$/, (m) => `Only ${m[1]} files are supported`],
    // 项目名相关（含中文书名号包裹的名字）
    [/^项目「(.+)」不存在$/, (m) => `Project "${m[1]}" does not exist`],
    [/^项目「(.+)」已存在$/, (m) => `Project "${m[1]}" already exists`],
    [/^名称「(.+)」已存在$/, (m) => `The name "${m[1]}" already exists`],
    [/^项目「(.+)」当前没有正在运行的任务$/, (m) => `Project "${m[1]}" has no running task right now`],
    [/^已有项目「(.+)」在运行。本工具为单卡设计，一次只能训练一个项目。$/,
      (m) => `Project "${m[1]}" is already running. This tool is single-GPU, so only one project can train at a time.`],
    [/^当前在「(.+)」步骤，只有训练步骤支持暂停$/,
      (m) => `Currently at the "${stageName(STAGE_BY_ZH[m[1]] || m[1])}" stage; only the training stage can be paused`],
    [/^未找到监控项「(.+)」$/, (m) => `Monitor entry "${m[1]}" not found`],
    [/^未知工位：(.+)$/, (m) => `Unknown stage: ${m[1]}`],
    [/^未知步骤分组：(.+)$/, (m) => `Unknown step group: ${m[1]}`],
    [/^目录不存在：(.+)$/, (m) => `Folder does not exist: ${m[1]}`],
    [/^该目录下没有 train_log.csv：(.+)$/, (m) => `No train_log.csv in this folder: ${m[1]}`],
    [/^无法写入暂停标记：(.+)$/, (m) => `Could not write the pause flag: ${m[1]}`],
    [/^无法读取日志：(.+)$/, (m) => `Could not read the log: ${m[1]}`],
    [/^无法创建输出目录 (.+)：(.+)$/, (m) => `Could not create output folder ${m[1]}: ${m[2]}`],
    // 架构合法性提示
    [/^查询头数 (\d+) 不能被 KV 头数 (\d+) 整除，已自动下调为 (\d+)$/,
      (m) => `${m[1]} query heads are not divisible by ${m[2]} KV heads; lowered automatically to ${m[3]}`],
    [/^隐层宽度 (\d+) 不是每头维度 (\d+) 的整数倍，实际头数会取整为 (\d+)（可改用 (\d+) 更整齐）$/,
      (m) => `Hidden size ${m[1]} is not a multiple of head dimension ${m[2]}; head count rounds to ${m[3]} (using ${m[4]} would divide evenly)`],
    // 语料探测与导入结果
    [/^(.+) (\d+)MB\(导入\)$/, (m) => `${m[1]} ${m[2]}MB (imported)`],
    [/^第(\d+)类将用已清洗文件$/, (m) => `Entry ${m[1]} will use the cleaned file`],
    // 磁盘与引用
    [/^磁盘空间不足：约需 ([\d.]+)GB，剩余 ([\d.]+)GB$/,
      (m) => `Not enough disk space: about ${m[1]}GB needed, ${m[2]}GB free`],
    [/^已引用 (.+)（目录联接，未复制）$/, (m) => `Referencing ${m[1]} (directory junction, not copied)`],
    [/^已引用 (.+)（符号链接，未复制）$/, (m) => `Referencing ${m[1]} (symlink, not copied)`],
    [/^已复制 ([\d.]+)GB（系统不支持目录引用）$/, (m) => `Copied ${m[1]}GB (the system does not support directory references)`],
    [/^已指向该目录$/, () => 'Already pointing at this folder'],
    // 词表不一致（严重错误，必须让用户看懂）
    [/^词表内容不一致：要接续的模型用的是另一套分词器。直接续训会让所有 token 编号错位、模型权重作废。请把「训练词表」这一步改为导入该模型自带的词表：(.+)$/,
      (m) => `Tokenizer mismatch: the model you are resuming uses a different tokenizer. Continuing would misalign every token id and ruin the weights. Set the Tokenizer stage to import the model's own tokenizer: ${m[1]}`],
    [/^导入数据的词表大小是 (\d+)，但配置里填的是 (\d+)。两者必须一致，否则 token 编号错位、训练结果无意义。请把词表大小改成 (\d+)$/,
      (m) => `The imported data uses a vocab of ${m[1]} but the configuration says ${m[2]}. They must match, otherwise token ids are misaligned and training is meaningless. Set the vocab size to ${m[3]}`],
    [/^(\d+) 类语料共产出 ([\d.]+)MB$/, (m) => `${m[1]} corpus type(s), ${m[2]}MB produced`],
    [/^打包完成，合计约 ([\d,]+) token$/, (m) => `Packed about ${m[1]} tokens in total`],
    [/^训练集 ([\d,]+) token$/, (m) => `Dataset: ${m[1]} tokens`],
    [/^(\d+) 类已整合，训练集 ([\d,]+) token$/, (m) => `${m[1]} sources mixed, ${m[2]} tokens`],
    [/^就绪 ([\d,]+) token$/, (m) => `Ready: ${m[1]} tokens`],
    [/^沿用已导入的训练集，([\d,]+) token$/, (m) => `Using imported dataset, ${m[1]} tokens`],
    [/^沿用导入数据 ([\d,]+) token$/, (m) => `Using imported data: ${m[1]} tokens`],
    [/^第 ([\d,]+)\/([\d,]+) 步$/, (m) => `Step ${m[1]}/${m[2]}`],
    [/^(\d+)\/(\d+) 类已识别$/, (m) => `${m[1]}/${m[2]} types mapped`],
    [/^(\d+)\/(\d+) 类已清洗$/, (m) => `${m[1]}/${m[2]} types cleaned`],
    [/^(\d+)\/(\d+) 类已打包$/, (m) => `${m[1]}/${m[2]} types packed`],
    [/^验证完成（(.+)）$/, (m) => `Evaluation finished (${m[1]})`],
    [/^验证完成$/, () => 'Evaluation finished'],
    [/^已导入词表（(\d+) 个文件）$/, (m) => `Tokenizer imported (${m[1]} files)`],
    [/^已导入清洗语料：(.+)$/, (m) => `Cleaned corpus imported: ${m[1]}`],
    [/^已导入：(.+)$/, (m) => `Imported: ${m[1]}`],
    [/^已选用已有模型，从第 ([\d,]+) 步接上$/, (m) => `Existing model selected, resuming at step ${m[1]}`],
    [/^已选用已有模型$/, () => 'Existing model selected'],
    [/^全部语料已导入$/, () => 'All corpus entries imported'],
    [/^风险提示：(.+)$/, (m) => `Risk notice: ${m[1]}`],
  ];
  for (const [re, fn] of patterns) {
    const m = String(s).match(re);
    if (m) return fn(m);
  }
  return s;
};

/* ---------------- app ---------------- */
const App = {
  // 进入数据/训练页时若没选项目，自动挑一个：优先正在跑的，其次最近创建的
  async ensureCurrent() {
    if (S.current) return S.current;
    try {
      const d = await api('/api/projects');
      S.projects = d.projects; S.runner = d.runner;
      const list = d.projects || [];
      if (!list.length) return null;
      const running = (d.runner && d.runner.active)
        ? list.find((x) => x.name === d.runner.active) : null;
      const pick = running || list.find((x) => x.running)
        || list.slice().sort((a, b) => (b.created_at || 0) - (a.created_at || 0))[0];
      if (pick) { S.current = pick.name; S.lastDone = false; }
    } catch (e) { /* 拿不到列表就保持未选中，由各页显示空态 */ }
    return S.current;
  },

  // 点项目卡片时按进度决定去哪一页
  landingView(st) {
    if (!st || !st.stages) return 'data';
    if (st.running && st.current === 'train') return 'train';
    const s = st.stages;
    if (s.train && ['running', 'paused', 'done'].includes(s.train.status)) return 'train';
    if (s.mix && s.mix.status === 'done') return 'train';   // 数据就绪，具备训练条件
    return 'data';
  },

  async go(v) {
    $$('nav button').forEach((b) => b.classList.toggle('on', b.dataset.view === v));
    $$('.view').forEach((s) => s.classList.toggle('on', s.id === 'v-' + v));
    if (v === 'home') App.loadProjects();
    if (v === 'data') { await App.ensureCurrent(); App.renderPicker('data'); App.refreshData(); }
    if (v === 'train') { await App.ensureCurrent(); App.renderPicker('train'); App.refreshTrain(); }
    if (v === 'watch') App.refreshWatch();
    if (v === 'env') App.refreshEnv();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    // 视图刚显示，此刻才量得到画布尺寸 → 补画之前跳过的图
    requestAnimationFrame(() => Chart.flush());
  },

  // 页内项目下拉：随时切换，标注正在运行的那个
  renderPicker(which) {
    const box = $(which === 'train' ? '#trainPicker' : '#dataPicker');
    if (!box) return;
    const list = S.projects || [];
    if (!list.length) { box.innerHTML = ''; return; }
    const act = S.runner && S.runner.active;
    box.innerHTML = `<label>${t('pick.label')}</label>
      <select data-pick="${which}">${list.map((p) => {
        const run = p.name === act || p.running;
        return `<option value="${esc(p.name)}" ${p.name === S.current ? 'selected' : ''}>`
          + `${esc(p.name)}${run ? ' · ' + t('pick.running') : ''}</option>`;
      }).join('')}</select>`;
    const sel = box.querySelector('select');
    if (sel) {
      sel.onchange = async () => {
        S.current = sel.value; S.lastDone = false;
        if (which === 'train') await App.refreshTrain(); else await App.refreshData();
        requestAnimationFrame(() => Chart.flush());
      };
    }
  },

  rerenderAll() {
    applyLang();
    if (S.meta) {
      $('#limitNotice').innerHTML = '<b>' + t('about.limits') + '：</b>' + esc(sv(S.meta.limits.notice));
      App.renderLimits(); App.renderAboutText(); App.renderCleanLevels();
      App.renderCorpus(); App.renderMixPreview(); App.renderArch(); App.renderImports();
    }
    if (S.rec) { App.renderTiers(); App.renderHwDetail(); }
    // ★顶部硬件条必须一起重绘：否则切换语言后它仍显示旧语言，
    //   直到 30 秒后定时刷新才变过来，看起来就是"一会中文一会英文"。
    App.paintHwChip();
    App.loadProjects();
    const cur = $$('nav button').find((b) => b.classList.contains('on'));
    const v = cur ? cur.dataset.view : 'home';
    if (v === 'data') App.refreshData();
    if (v === 'train') App.refreshTrain();
    if (v === 'watch') App.refreshWatch();
    if (v === 'env') App.refreshEnv();
    updateSaveHint(); updateTokensHint();
  },

  async loadMeta() {
    S.meta = await api('/api/meta');
    $('#limitNotice').innerHTML = '<b>' + t('about.limits') + '：</b>' + esc(sv(S.meta.limits.notice));
    App.renderLimits(); App.renderAboutText(); App.renderCleanLevels();
    if (!S.form.corpus.length) App.addCorpus();
    App.renderImports();
  },

  renderLimits() {
    const L = S.meta.limits;
    $('#aboutLimits').innerHTML = `<table><tbody>
      <tr><td style="width:190px;color:var(--txt3)">${t('about.multiGpu')}</td>
        <td><span class="tag fail">${t('about.notSupported')}</span> ${t('about.multiGpuVal')}</td></tr>
      <tr><td style="color:var(--txt3)">${t('about.modelSize')}</td>
        <td><span class="tag idle">${t('about.advisory')}</span> ${t('about.modelSizeVal', { v: L.advisory_model_b })}</td></tr>
      <tr><td style="color:var(--txt3)">${t('about.ctx')}</td>
        <td><span class="tag idle">${t('about.advisory')}</span> ${t('about.ctxVal', { v: L.advisory_context })}</td></tr>
      <tr><td style="color:var(--txt3)">${t('about.vramGuard')}</td>
        <td><span class="tag idle">${t('about.advisory')}</span> ${t('about.vramGuardVal')}</td></tr>
      <tr><td style="color:var(--txt3)">${t('about.position')}</td><td>${t('about.positionVal')}</td></tr>
    </tbody></table>
    <div class="banner" style="margin:18px 0 0"><span class="bi">⚠</span><div>${esc(sv(L.notice))}</div></div>`;
  },

  renderAboutText() {
    $('#aboutText').innerHTML = ['p1', 'p2', 'p3', 'p4', 'p5']
      .map((k) => '<p>· ' + t('about.' + k) + '</p>').join('');
  },

  // 顶部硬件条单独成函数，语言切换与定时刷新都走它，保证文案始终跟随当前语言
  paintHwChip() {
    const chip = $('#hwChip');
    if (!chip) return;
    const h = S.hw;
    if (!h) {
      chip.innerHTML = `<span class="dot off"></span><span>${t('hw.detecting')}</span>`;
      return;
    }
    if (h.cuda_available) {
      chip.innerHTML = `<span class="dot ${h.vram_free_gb < 4 ? 'warn' : ''}"></span>
        <span>${esc(h.gpu.replace('NVIDIA ', ''))}</span>
        <span>${t('hw.available')} <b>${fmt.f(h.vram_free_gb, 1)}</b> / ${fmt.f(h.vram_total_gb, 1)} GB</span>`;
    } else {
      chip.innerHTML = `<span class="dot off"></span><span>${t('hw.cpuMode')}</span>`;
    }
  },

  async loadHardware() {
    const d = await api('/api/hardware');
    S.hw = d.hardware; S.rec = d.recommend;
    App.paintHwChip();
    App.renderHwDetail(); App.renderTiers();
  },

  renderHwDetail() {
    if (!S.hw) return;
    const h = S.hw;
    $('#hwDetail').innerHTML = `
      <div class="metrics">
        <div class="metric c1"><div class="mk">${t('home.gpu')}</div>
          <div class="mv" style="font-size:15px">${h.gpu ? esc(h.gpu.replace('NVIDIA ', '')) : t('common.none')}</div></div>
        <div class="metric c2"><div class="mk">${t('home.vram')}</div>
          <div class="mv">${fmt.f(h.vram_free_gb, 1)}<span class="mu">GB</span></div></div>
        <div class="metric c3"><div class="mk">${t('home.ram')}</div>
          <div class="mv">${fmt.f(h.ram_free_gb, 1)}<span class="mu">GB</span></div></div>
        <div class="metric c4"><div class="mk">${t('home.rec')}</div>
          <div class="mv" style="font-size:17px">${S.rec.recommended ? esc(tierLabel(S.rec.recommended, S.meta.tier_labels[S.rec.recommended])) : t('home.cpuOnly')}</div></div>
      </div>
      ${(h.warnings || []).map((w) => `<div class="banner" style="margin:16px 0 0"><span class="bi">⚠</span><div>${esc(sv(w))}</div></div>`).join('')}
      <div class="hint" style="margin-top:14px">${t('home.disk')}: ${h.disks.map((d) => `${d.drive} ${d.free_gb}GB`).join(' | ')}
        　${t('home.cpuCores')} ${h.cpu_count}${h.driver ? '　' + t('home.driver') + ' ' + esc(h.driver) : ''}</div>`;
  },

  renderTiers() {
    if (!S.rec) return;
    $('#tierList').innerHTML = S.rec.tiers.map((x) => {
      const on = S.form.tier === x.tier;
      const isRec = S.rec.recommended === x.tier;
      return `<div class="tier ${on ? 'on' : ''} ${x.fits ? '' : 'risk'}" data-tier="${x.tier}">
        <div class="tn">${esc(tierLabel(x.tier, x.label))}</div>
        <div class="tp">${x.params_b < 1 ? (x.params_b * 1000).toFixed(0) + 'M' : x.params_b + 'B'}</div>
        <div class="tv">~${x.vram_need_gb} GB</div>
        <span class="badge ${x.fits ? (isRec ? 'rec' : 'ok') : 'no'}">
          ${x.fits ? (isRec ? t('tier.rec') : t('tier.ok')) : t('tier.risk')}</span>
      </div>`;
    }).join('');
    $$('#tierList .tier').forEach((el) => {
      el.onclick = () => {
        const x = S.rec.tiers.find((y) => y.tier === el.dataset.tier);
        S.form.tier = el.dataset.tier;
        if (x && !x.fits) toast(t('tier.riskToast', { r: sv(x.reason) || t('tier.risk') }), 'err');
        App.renderTiers(); App.renderArch();
        $('#tierWarn').textContent = '';
      };
    });
    if (!S.form.tier && S.rec.recommended) { S.form.tier = S.rec.recommended; App.renderTiers(); }
    $('#tierWarn').innerHTML = S.rec.cpu_only ? t('tier.cpuWarn') : '';
  },

  /* ---------------- custom architecture ---------------- */
  archBase() {
    const k = S.form.tier || 'base';
    return (S.meta.tier_arch || {})[k] || { hidden_size: 768, num_hidden_layers: 12, intermediate_size: 2944 };
  },

  archEffective() {
    const base = App.archBase(), a = {};
    ['hidden_size', 'num_hidden_layers', 'intermediate_size', 'head_dim',
      'num_attention_heads', 'num_key_value_heads'].forEach((k) => {
      const v = S.form.arch[k];
      a[k] = (v == null || v === '') ? base[k] : v;
    });
    a.tie_embeddings = S.form.tie;
    return a;
  },

  archEstimate() {
    const a = App.archEffective();
    const h = +a.hidden_size || 768, L = +a.num_hidden_layers || 12;
    const inter = +a.intermediate_size || 2944, hd = +a.head_dim || 64;
    const heads = +a.num_attention_heads || Math.max(Math.floor(h / hd), 1);
    let kv = +a.num_key_value_heads || Math.max(Math.floor(heads / 4), 1);
    const kvRaw = kv;
    kv = Math.max(1, Math.min(kv, heads));
    while (heads % kv !== 0 && kv > 1) kv -= 1;
    const vocab = parseInt($('#fVocab').value, 10) || 32000;
    const attn = h * heads * hd + 2 * h * kv * hd + heads * hd * h;
    const total = vocab * h * (a.tie_embeddings ? 1 : 2) + L * (attn + h * inter * 3 + 2 * h) + h;
    const probs = [];
    if (!a.num_attention_heads && h % hd !== 0) probs.push(`${h} % ${hd} != 0 → heads=${heads}`);
    if (a.num_key_value_heads && heads % kvRaw !== 0) probs.push(`heads ${heads} % kv ${kvRaw} != 0 → kv=${kv}`);
    const vram = (total * 2 / 1024 ** 3) * 2 + total * 0.031 / 1024 ** 3 + 2.0;
    return { params: total, b: total / 1e9, heads, kv, vram: +vram.toFixed(2), probs };
  },

  renderArch() {
    const box = $('#archPanel'), tgl = $('#btnArchToggle');
    if (!S.meta) return;
    tgl.classList.toggle('on', S.form.archOpen);
    tgl.innerHTML = (S.form.archOpen ? '▾ ' : '▸ ') + t('create.archToggle')
      + (S.form.archOn ? ` <span class="tag run">${t('create.archEnabled')}</span>` : '');
    if (!S.form.archOpen) { box.innerHTML = ''; return; }

    const est = App.archEstimate(), base = App.archBase();
    const fields = S.meta.arch_fields.map((f) => {
      const custom = S.form.arch[f.key] != null && S.form.arch[f.key] !== '';
      const val = custom ? S.form.arch[f.key] : (base[f.key] != null ? base[f.key] : '');
      const ph = f.key === 'num_attention_heads' ? est.heads : (f.key === 'num_key_value_heads' ? est.kv : (f.key === 'head_dim' ? 64 : ''));
      return `<div class="cf">
        <div class="cf-head"><label>${t('arch.' + f.key)}</label>
          ${custom ? `<button class="cf-reset" data-archreset="${f.key}">${t('common.reset')}</button>` : `<span class="cf-auto">${t('common.preset')}</span>`}
        </div>
        <div class="cf-row"><input type="number" data-arch="${f.key}" value="${val === '' ? '' : val}"
          min="${f.min}" step="${f.step}" placeholder="${ph}"></div>
        <div class="cf-hint">${t('arch.hint.' + f.key)}</div>
      </div>`;
    }).join('');

    const budget = S.rec ? S.rec.budget_gb : 0;
    const over = est.vram > budget;
    box.innerHTML = `<div class="clean-adv">
      <div class="ca-title">${t('create.archTitle')}<span>${t('create.archSub')}</span></div>
      <label class="sw" style="margin-bottom:13px">
        <input type="checkbox" id="archEnable" ${S.form.archOn ? 'checked' : ''}>
        <span><b>${t('create.archEnable')}</b></span></label>
      <div class="metrics" style="margin-bottom:14px">
        <div class="metric c2"><div class="mk">${t('create.archParams')}</div>
          <div class="mv">${est.b < 1 ? (est.b * 1000).toFixed(0) : est.b.toFixed(2)}<span class="mu">${est.b < 1 ? 'M' : 'B'}</span></div></div>
        <div class="metric ${over ? 'c4' : 'c3'}"><div class="mk">${t('create.archVram')}</div>
          <div class="mv">${est.vram}<span class="mu">GB</span></div></div>
        <div class="metric c1"><div class="mk">${t('create.archHeads')}</div>
          <div class="mv" style="font-size:19px">${est.heads} / KV ${est.kv}</div></div>
      </div>
      ${over ? `<div class="ca-warn">⚠ ${t('create.archOver', { a: est.vram, b: budget })}</div>` : ''}
      ${est.probs.length ? `<div class="ca-warn">${est.probs.map((p) => '⚠ ' + esc(p)).join('<br>')}</div>` : ''}
      <div class="cf-grid">${fields}</div>
      <div class="ca-switches"><label class="sw"><input type="checkbox" id="archTie" ${S.form.tie ? 'checked' : ''}>
        <span>${t('create.archTie')}</span></label></div>
      <div class="btn-row" style="margin-top:12px"><button class="btn sm" id="archClear">${t('create.archClear')}</button></div>
    </div>`;

    $('#archEnable').onchange = (e) => { S.form.archOn = e.target.checked; App.renderArch(); };
    $('#archTie').onchange = (e) => { S.form.tie = e.target.checked; App.renderArch(); };
    $('#archClear').onclick = () => { S.form.arch = {}; S.form.tie = true; toast(t('clean.restored'), 'ok'); App.renderArch(); };
    $$('#archPanel [data-arch]').forEach((el) => {
      el.onchange = () => {
        const k = el.dataset.arch, raw = el.value.trim();
        if (raw === '') delete S.form.arch[k];
        else {
          const f = S.meta.arch_fields.find((x) => x.key === k);
          const v = parseInt(raw, 10);
          if (isFinite(v)) S.form.arch[k] = Math.max(f.min || 1, v);
        }
        App.renderArch();
      };
    });
    $$('#archPanel [data-archreset]').forEach((el) => {
      el.onclick = () => { delete S.form.arch[el.dataset.archreset]; App.renderArch(); };
    });
  },

  /* ---------------- corpus ---------------- */
  addCorpus() {
    S.form.corpus.push({ path: '', kind: 'auto', percent: null, info: null,
      clean_level: '', clean_custom: {}, dedup: 'bloom', strip_urls: true, nfkc: true, open: false });
    App.renderCorpus(); App.renderMixPreview();
  },

  shares() {
    const list = S.form.corpus;
    const vals = list.map((c) => {
      const v = parseFloat(c.percent);
      return isFinite(v) && v > 0 ? v : 0;
    });
    let sum = vals.reduce((a, b) => a + b, 0);
    if (sum <= 0) return list.map(() => list.length ? 100 / list.length : 0);
    return vals.map((v) => (v / sum) * 100);
  },

  renderMixPreview() {
    const box = $('#mixPreview');
    if (!box || !S.meta) return;
    const list = S.form.corpus;
    if (!list.length) { box.innerHTML = ''; return; }
    const sh = App.shares();
    box.innerHTML = `<div class="ca-title" style="margin-bottom:6px">${t('create.mixPreview')}</div>
      <div class="mix-bar">${sh.map((p, i) =>
        `<div class="mix-seg" style="width:${p}%;background:${MIX_COLORS[i % MIX_COLORS.length]}"></div>`).join('')}</div>
      <div class="mix-legend">${list.map((c, i) =>
        `<span><i style="background:${MIX_COLORS[i % MIX_COLORS.length]}"></i>${t('create.corpusN')} ${i + 1} · ${kindName(c.kind)} ${sh[i].toFixed(1)}%</span>`).join('')}</div>
      <div class="hint" style="margin-top:8px">${t('create.mixNote')}</div>`;
  },

  cleanPanel(c, i) {
    const cp = App.cleanParams(c.kind, c.clean_level || S.form.clean, c.clean_custom);
    const fields = S.meta.clean_fields.map((f) => {
      const b = S.meta.clean_bounds[f.key] || [0, 1];
      const overridden = c.clean_custom[f.key] != null && c.clean_custom[f.key] !== '';
      const val = overridden ? c.clean_custom[f.key] : cp[f.key];
      const isInt = f.step >= 1;
      const shown = val == null ? '' : (isInt ? Math.round(val) : (+val).toFixed(2));
      return `<div class="cf">
        <div class="cf-head"><label>${t('clean.' + f.key)}</label>
          ${overridden ? `<button class="cf-reset" data-reset="${i}" data-f="${f.key}">${t('common.reset')}</button>` : `<span class="cf-auto">${t('common.preset')}</span>`}
        </div>
        <div class="cf-row">
          <input type="range" data-cust="${i}" data-f="${f.key}" data-int="${isInt ? 1 : 0}"
            min="${b[0]}" max="${b[1]}" step="${f.step}" value="${val == null ? b[0] : val}" class="${overridden ? 'on' : ''}">
          <input type="number" data-custn="${i}" data-f="${f.key}" min="${b[0]}" max="${b[1]}" step="${f.step}"
            value="${shown}" placeholder="${cp[f.key] == null ? '' : cp[f.key]}">
        </div>
        <div class="cf-hint">${t('clean.hint.' + f.key)}</div>
      </div>`;
    }).join('');
    const warns = App.cleanWarns(c.kind, cp);
    return `<div class="clean-adv">
      <div class="ca-title">${t('clean.customTitle')}<span>${t('clean.customSub')}</span></div>
      ${warns.length ? `<div class="ca-warn">${warns.map((w) => '⚠ ' + w).join('<br>')}</div>` : ''}
      <div class="cf-grid">${fields}</div>
      <div class="ca-switches">
        <label class="sw"><input type="checkbox" data-sw="${i}" data-k="strip_urls" ${c.strip_urls !== false ? 'checked' : ''}><span>${t('clean.stripUrls')}</span></label>
        <label class="sw"><input type="checkbox" data-sw="${i}" data-k="nfkc" ${c.nfkc !== false ? 'checked' : ''}><span>${t('clean.nfkc')}</span></label>
        <div class="sw-select"><label>${t('clean.dedup')}</label>
          <select data-dedup="${i}">
            <option value="bloom" ${c.dedup !== 'exact' && c.dedup !== 'none' ? 'selected' : ''}>${t('clean.dedup.bloom')}</option>
            <option value="exact" ${c.dedup === 'exact' ? 'selected' : ''}>${t('clean.dedup.exact')}</option>
            <option value="none" ${c.dedup === 'none' ? 'selected' : ''}>${t('clean.dedup.none')}</option>
          </select></div>
      </div>
      <div class="btn-row" style="margin-top:12px"><button class="btn sm" data-clearcust="${i}">${t('common.resetAll')}</button></div>
    </div>`;
  },

  cleanWarns(kind, p) {
    const w = [];
    if (kind === 'code' && p.min_cjk_ratio > 0.05) w.push(t('clean.warn.code_cjk'));
    if (kind === 'code' && p.max_repeat_ratio < 0.52) w.push(t('clean.warn.code_rep'));
    if (kind === 'guji' && p.min_chars > 20) w.push(t('clean.warn.guji_len'));
    if (p.min_cjk_ratio > 0.8) w.push(t('clean.warn.cjk_high'));
    if (p.max_symbol_ratio < 0.1) w.push(t('clean.warn.sym_low'));
    if (p.max_chars && p.min_chars >= p.max_chars) w.push(t('clean.warn.len_conflict'));
    return w;
  },

  renderCorpus() {
    const box = $('#corpusList');
    if (!S.meta) return;
    if (!S.form.corpus.length) { box.innerHTML = `<div class="hint">${t('create.corpusEmpty')}</div>`; return; }
    const sh = App.shares();
    box.innerHTML = S.form.corpus.map((c, i) => {
      const kinds = S.meta.kinds.map((k) =>
        `<button class="kind-btn ${c.kind === k.key ? 'on' : ''}" data-i="${i}" data-k="${k.key}" title="${esc(sv(k.desc))}">${kindName(k.key)}</button>`).join('');
      const lv = c.clean_level || S.form.clean;
      const cp = App.cleanParams(c.kind, lv, c.clean_custom);
      const nCustom = Object.keys(c.clean_custom || {}).filter((k) => c.clean_custom[k] != null && c.clean_custom[k] !== '').length;
      const lvBtns = [`<button data-lv="${i}" data-v="" class="${!c.clean_level ? 'on' : ''}">${t('create.levelInherit')}</button>`]
        .concat(S.meta.levels.map((l) => `<button data-lv="${i}" data-v="${l.key}" class="${c.clean_level === l.key ? 'on' : ''}">${levelName(l.key)}</button>`)).join('');
      return `<div class="corpus-item">
        <div class="ci-head">
          <div class="ci-idx" style="background:${MIX_COLORS[i % MIX_COLORS.length]}">${i + 1}</div>
          <div class="ci-title">${t('create.corpusN')} ${i + 1}${nCustom ? ` <span class="tag run">${nCustom} ${t('common.custom_n')}</span>` : ''}</div>
          ${S.form.corpus.length > 1 ? `<button class="ci-del" data-del="${i}" title="✕">✕</button>` : ''}
        </div>
        <div class="field" style="margin-bottom:12px">
          <label>${t('create.path')}</label>
          <div style="display:flex;gap:8px">
            <input type="text" data-path="${i}" value="${esc(c.path)}" placeholder="${t('create.pathPh')}">
            <button class="btn sm" data-probe="${i}" style="flex:none">${t('common.detect')}</button>
          </div>
          <div class="hint">${c.info ? esc(sv(c.info)) : t('create.pathHint')}</div>
        </div>
        <div class="field" style="margin-bottom:12px"><label>${t('create.kind')}</label><div class="kind-grid">${kinds}</div></div>
        <div class="row" style="align-items:flex-end">
          <div class="field" style="margin:0;flex:2">
            <label>${t('create.level')}</label>
            <div class="seg mini">${lvBtns}</div>
          </div>
          <div class="field" style="margin:0;max-width:190px">
            <label>${t('create.percent')}</label>
            <input type="number" data-pct="${i}" value="${c.percent == null ? '' : c.percent}" min="0" step="0.1"
              placeholder="${sh[i].toFixed(1)}">
          </div>
        </div>
        <div class="ci-meta" style="margin-top:10px">
          <b>${t('create.actualThreshold')}：</b>${t('create.cjkMin')} ${cp.min_cjk_ratio}　${t('create.repMax')} ${cp.max_repeat_ratio}<br>
          ${t('create.symMax')} ${cp.max_symbol_ratio}　${t('create.minChars')} ${cp.min_chars} ${t('create.chars')}${cp.max_chars ? '　' + t('create.maxChars') + ' ' + cp.max_chars : ''}
        </div>
        <button class="ci-toggle ${c.impOpen ? 'on' : ''}" data-imptoggle="${i}">${c.impOpen ? '▾' : '▸'} ${t('import.corpusToggle')}${c.clean_import ? ` <span class="tag done">${t('import.on')}</span>` : ''}</button>
        ${c.impOpen ? `<div class="ci-imp">
          <label>${t('import.cleanedFile')}</label>
          <input type="text" data-cimp="${i}" value="${esc(c.clean_import || '')}" placeholder="${t('import.filePh')}">
          <div class="hint">${t('import.cleanedHint')}</div>
        </div>` : ''}
        <button class="ci-toggle ${c.open ? 'on' : ''}" data-toggle="${i}">${c.open ? '▾' : '▸'} ${t('create.customClean')}</button>
        ${c.open ? App.cleanPanel(c, i) : ''}
      </div>`;
    }).join('');

    $$('#corpusList [data-cimp]').forEach((el) => {
      el.oninput = () => { S.form.corpus[+el.dataset.cimp].clean_import = el.value; };
    });
    $$('#corpusList [data-imptoggle]').forEach((el) => {
      el.onclick = () => { const c = S.form.corpus[+el.dataset.imptoggle]; c.impOpen = !c.impOpen; App.renderCorpus(); };
    });
    $$('#corpusList [data-path]').forEach((el) => { el.oninput = () => { S.form.corpus[+el.dataset.path].path = el.value; }; });
    $$('#corpusList [data-pct]').forEach((el) => {
      el.oninput = () => {
        const v = el.value.trim();
        S.form.corpus[+el.dataset.pct].percent = v === '' ? null : (parseFloat(v) || 0);
        App.renderMixPreview();
      };
    });
    $$('#corpusList [data-lv]').forEach((el) => {
      el.onclick = () => { S.form.corpus[+el.dataset.lv].clean_level = el.dataset.v; App.renderCorpus(); };
    });
    $$('#corpusList .kind-btn').forEach((el) => {
      el.onclick = () => { S.form.corpus[+el.dataset.i].kind = el.dataset.k; App.renderCorpus(); App.renderMixPreview(); };
    });
    $$('#corpusList [data-del]').forEach((el) => {
      el.onclick = () => { S.form.corpus.splice(+el.dataset.del, 1); App.renderCorpus(); App.renderMixPreview(); };
    });
    $$('#corpusList [data-probe]').forEach((el) => {
      el.onclick = async () => {
        const i = +el.dataset.probe, p = S.form.corpus[i].path.trim();
        if (!p) { toast(t('create.needCorpus'), 'err'); return; }
        el.textContent = t('common.detecting');
        try {
          const r = await api('/api/probe?path=' + encodeURIComponent(p));
          S.form.corpus[i].info = `${r.files} files · ${r.size_gb} GB (${r.sample.join(', ')})`;
        } catch (e) { S.form.corpus[i].info = '✕ ' + e.message; toast(e.message, 'err'); }
        App.renderCorpus();
      };
    });
    $$('#corpusList [data-toggle]').forEach((el) => {
      el.onclick = () => { const i = +el.dataset.toggle; S.form.corpus[i].open = !S.form.corpus[i].open; App.renderCorpus(); };
    });
    $$('#corpusList [data-cust]').forEach((el) => {
      el.oninput = () => {
        const i = +el.dataset.cust, f = el.dataset.f, isInt = el.dataset.int === '1';
        const v = isInt ? parseInt(el.value, 10) : parseFloat(el.value);
        S.form.corpus[i].clean_custom[f] = v;
        const n = $(`#corpusList [data-custn="${i}"][data-f="${f}"]`);
        if (n) n.value = isInt ? v : v.toFixed(2);
        el.classList.add('on');
        App.updateCorpusMeta(i);
      };
      el.onchange = () => App.renderCorpus();
    });
    $$('#corpusList [data-custn]').forEach((el) => {
      el.onchange = () => {
        const i = +el.dataset.custn, f = el.dataset.f, raw = el.value.trim();
        if (raw === '') delete S.form.corpus[i].clean_custom[f];
        else {
          const b = S.meta.clean_bounds[f] || [0, 1];
          const v = parseFloat(raw);
          if (isFinite(v)) S.form.corpus[i].clean_custom[f] = b[1] > 5 ? Math.round(Math.max(b[0], Math.min(b[1], v))) : +Math.max(b[0], Math.min(b[1], v)).toFixed(3);
        }
        App.renderCorpus();
      };
    });
    $$('#corpusList [data-reset]').forEach((el) => {
      el.onclick = () => { delete S.form.corpus[+el.dataset.reset].clean_custom[el.dataset.f]; App.renderCorpus(); };
    });
    $$('#corpusList [data-clearcust]').forEach((el) => {
      el.onclick = () => {
        const i = +el.dataset.clearcust;
        Object.assign(S.form.corpus[i], { clean_custom: {}, dedup: 'bloom', strip_urls: true, nfkc: true });
        toast(t('clean.restored'), 'ok'); App.renderCorpus();
      };
    });
    $$('#corpusList [data-sw]').forEach((el) => { el.onchange = () => { S.form.corpus[+el.dataset.sw][el.dataset.k] = el.checked; }; });
    $$('#corpusList [data-dedup]').forEach((el) => { el.onchange = () => { S.form.corpus[+el.dataset.dedup].dedup = el.value; }; });
  },

  updateCorpusMeta(i) {
    const c = S.form.corpus[i];
    const cp = App.cleanParams(c.kind, c.clean_level || S.form.clean, c.clean_custom);
    const item = $$('#corpusList .corpus-item')[i];
    if (!item) return;
    const meta = item.querySelector('.ci-meta');
    if (meta) meta.innerHTML = `<b>${t('create.actualThreshold')}：</b>${t('create.cjkMin')} ${cp.min_cjk_ratio}　${t('create.repMax')} ${cp.max_repeat_ratio}<br>
      ${t('create.symMax')} ${cp.max_symbol_ratio}　${t('create.minChars')} ${cp.min_chars} ${t('create.chars')}${cp.max_chars ? '　' + t('create.maxChars') + ' ' + cp.max_chars : ''}`;
    const warns = App.cleanWarns(c.kind, cp);
    let w = item.querySelector('.ca-warn');
    if (warns.length) {
      if (!w) { w = document.createElement('div'); w.className = 'ca-warn'; const g = item.querySelector('.cf-grid'); if (g) g.parentNode.insertBefore(w, g); }
      w.innerHTML = warns.map((x) => '⚠ ' + x).join('<br>');
    } else if (w) w.remove();
  },

  cleanParams(kind, level, custom) {
    const k = (S.meta.kinds.find((x) => x.key === kind) || S.meta.kinds.find((x) => x.key === 'auto')).clean;
    const d = { loose: [-0.15, 0.15, 0.15, 0.5], standard: [0, 0, 0, 1], strict: [0.15, -0.10, -0.10, 1.5] }[level] || [0, 0, 0, 1];
    const cl = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
    const out = {
      min_cjk_ratio: +cl(k.min_cjk_ratio + d[0], 0, 0.95).toFixed(2),
      max_repeat_ratio: +cl(k.max_repeat_ratio + d[1], 0.1, 0.95).toFixed(2),
      max_symbol_ratio: +cl(k.max_symbol_ratio + d[2], 0.05, 0.9).toFixed(2),
      min_chars: Math.max(4, Math.round(k.min_chars * d[3])),
    };
    const bounds = S.meta.clean_bounds || {};
    Object.entries(custom || {}).forEach(([key, v]) => {
      if (v == null || v === '' || !bounds[key]) return;
      const n = parseFloat(v);
      if (!isFinite(n)) return;
      const [lo, hi] = bounds[key], c = cl(n, lo, hi);
      out[key] = hi > 5 ? Math.round(c) : +c.toFixed(3);
    });
    return out;
  },

  renderCleanLevels() {
    $('#segClean') && ($('#segClean').innerHTML = S.meta.levels.map((l) =>
      `<button data-v="${l.key}" class="${S.form.clean === l.key ? 'on' : ''}">${levelName(l.key)}</button>`).join(''));
    $$('#segClean button').forEach((b) => {
      b.onclick = () => { S.form.clean = b.dataset.v; App.renderCleanLevels(); App.renderCorpus(); };
    });
  },

  /* ---------------- projects ---------------- */
  async loadProjects() {
    const d = await api('/api/projects');
    S.projects = d.projects; S.runner = d.runner;
    const box = $('#projectList');
    if (!d.projects.length) {
      box.innerHTML = `<div class="empty"><div class="ei">◇</div><p>${t('home.empty')}</p>
        <button class="btn primary" onclick="App.go('create')">${t('home.emptyBtn')}</button></div>`;
      return;
    }
    box.innerHTML = '<div class="pcards">' + d.projects.map((p) => {
      const pct = Math.round((p.stages_done / p.stages_total) * 100);
      const tag = p.running ? `<span class="tag run">${t('home.running')}</span>`
        : (p.stages_done === p.stages_total ? `<span class="tag done">${t('home.done')}</span>` : `<span class="tag idle">${t('home.pending')}</span>`);
      return `<div class="pcard" data-n="${esc(p.name)}">
        <div class="pcn">${esc(p.name)} ${tag}</div>
        <div class="pcm">${esc(tierLabel(p.tier, S.meta.tier_labels[p.tier]))} | ctx ${p.block_size}</div>
        <div class="pcp"><div class="big-prog" style="margin:0"><div class="fill" style="width:${pct}%"></div></div>
        <div class="hint" style="margin-top:6px">${p.stages_done}/${p.stages_total} ${t('home.stagesDone')}${p.current ? ' | ' + t('home.current') + ': ' + stageName(p.current) : ''}</div></div>
      </div>`;
    }).join('') + '</div>';
    $$('#projectList .pcard').forEach((el) => {
      el.onclick = async () => {
        S.current = el.dataset.n; S.lastDone = false;
        // 按项目进度决定落在哪一页：具备训练条件就去训练中心
        let view = 'data';
        try {
          const p = await api('/api/project?name=' + encodeURIComponent(S.current));
          S.proj = p; view = App.landingView(p.state);
        } catch (e) { /* 读不到状态就退回数据处理 */ }
        App.go(view);
      };
    });
  },

  readForm() {
    const num = (id, d) => { const v = parseFloat($(id).value); return isFinite(v) ? v : d; };
    const lrRaw = $('#fLr').value.trim();
    const arch = {};
    if (S.form.archOn) {
      Object.entries(S.form.arch).forEach(([k, v]) => { if (v != null && v !== '') arch[k] = v; });
      arch.tie_embeddings = S.form.tie;
    }
    const sh = App.shares();
    return {
      tier: S.form.tier || 'base',
      arch: S.form.archOn ? arch : null,
      block_size: Math.round(num('#fCtx', 1024)),
      max_tokens: Math.round(num('#fTokens', 0) * 1e9),
      clean_level: S.form.clean,
      vocab_size: Math.round(num('#fVocab', 32000)),
      lr: lrRaw ? parseFloat(lrRaw) : null,
      batch_size: Math.round(num('#fBatch', 4)),
      grad_accum: Math.round(num('#fAccum', 4)),
      save_every: Math.round(num('#fSave', 500)),
      keep_checkpoints: Math.round(num('#fKeep', 3)),
      warmup_steps: Math.round(num('#fWarm', 500)),
      eval_every: Math.round(num('#fEval', 500)),
      log_every: Math.round(num('#fLog', 20)),
      master_dtype: $('#fDtype').value,
      num_workers: Math.round(num('#fWorkers', 0)),
      output_dir: $('#fOutDir').value.trim(),
      backup_dir: $('#fBackup').value.trim(),
      backup_every: Math.round(num('#fBackupEvery', 500)),
      keep_backups: Math.round(num('#fKeepBk', 10)),
      spike_guard: S.form.spike,
      log_lang: S.form.logLang === 'en' ? 'en' : 'zh',
      corpus: S.form.corpus.filter((c) => c.path.trim() || (c.clean_import || '').trim()).map((c) => {
        const cc = {};
        Object.entries(c.clean_custom || {}).forEach(([k, v]) => { if (v != null && v !== '') cc[k] = v; });
        const realIdx = S.form.corpus.indexOf(c);
        return { path: c.path.trim(), kind: c.kind, percent: +sh[realIdx].toFixed(4),
          clean_level: c.clean_level || '', clean_custom: cc, dedup: c.dedup || 'bloom',
          strip_urls: c.strip_urls !== false, nfkc: c.nfkc !== false,
          clean_import: (c.clean_import || '').trim() };
      }),
      // 各工位来源：只提交真正选了「使用已有」且填了路径的项
      sources: (() => {
        const out = {};
        Object.entries(S.form.sources || {}).forEach(([k, v]) => {
          if (v && v.mode === 'import' && (v.path || '').trim()) {
            out[k] = { mode: 'import', path: v.path.trim() };
          }
        });
        return out;
      })(),
    };
  },

  // ---------------- 使用已有文件 ----------------
  renderImports() {
    const box = $('#importList');
    if (!box || !S.meta || !S.meta.import_specs) return;
    S.form.sources = S.form.sources || {};
    const specs = S.meta.import_specs;
    box.innerHTML = S.meta.stages.map((s) => {
      const spec = specs[s.key];
      if (!spec) return '';
      const cur = S.form.sources[s.key] || { mode: 'auto', path: '' };
      const on = cur.mode === 'import';
      return `<div class="imp-row" data-k="${s.key}">
        <div class="imp-head">
          <span class="imp-name">${stageName(s.key)}</span>
          <div class="seg sm">
            <button class="imp-mode ${!on ? 'on' : ''}" data-k="${s.key}" data-m="auto">${t('import.auto')}</button>
            <button class="imp-mode ${on ? 'on' : ''}" data-k="${s.key}" data-m="import">${t('import.use')}</button>
          </div>
        </div>
        ${on ? `<div class="imp-body">
          <div class="imp-input">
            <input type="text" class="imp-path" data-k="${s.key}" value="${esc(cur.path || '')}"
              placeholder="${spec.accept === 'dir' ? t('import.dirPh') : t('import.filePh')}">
            <button class="btn sm imp-check" data-k="${s.key}">${t('import.check')}</button>
          </div>
          <div class="hint">${esc(sv(spec.hint))}</div>
          <div class="imp-result" data-res="${s.key}"></div>
        </div>` : `<div class="hint imp-autohint">${t('import.autoHint', { s: stageName(s.key) })}</div>`}
      </div>`;
    }).join('');

    $$('#importList .imp-mode').forEach((el) => {
      el.onclick = () => {
        const k = el.dataset.k;
        S.form.sources[k] = S.form.sources[k] || { mode: 'auto', path: '' };
        if (S.form.sources[k].mode === el.dataset.m) return;
        S.form.sources[k].mode = el.dataset.m;
        App.renderImports();
        // 切到「使用已有」且已填过路径时，直接把上次结果显示出来
        if (el.dataset.m === 'import') {
          App.paintImportResult(k);
          if ((S.form.sources[k].path || '').trim()) App.checkImport(k, true);
        }
      };
    });
    $$('#importList .imp-path').forEach((el) => {
      // ★只更新数据与结果区，绝不重建整个列表：
      //   重建会销毁正在输入的 input，导致焦点丢失、输入被打断。
      el.oninput = () => {
        const k = el.dataset.k;
        S.form.sources[k] = S.form.sources[k] || { mode: 'import', path: '' };
        S.form.sources[k].path = el.value;
        if (S.form.importState) delete S.form.importState[k];
        App.paintImportResult(k);
        clearTimeout(App._impTimer && App._impTimer[k]);
        App._impTimer = App._impTimer || {};
        // 停止输入 600ms 后自动校验，省掉手动点按钮
        App._impTimer[k] = setTimeout(() => {
          if (el.value.trim()) App.checkImport(k, true);
        }, 600);
      };
      el.onblur = () => { if (el.value.trim()) App.checkImport(el.dataset.k, true); };
      el.onkeydown = (ev) => {
        if (ev.key === 'Enter') { ev.preventDefault(); App.checkImport(el.dataset.k); }
      };
    });
    $$('#importList .imp-check').forEach((el) => {
      el.onclick = () => App.checkImport(el.dataset.k);
    });
    Object.keys(S.form.importState || {}).forEach((k) => App.paintImportResult(k));
  },

  // 只刷新某一行的结果区，不动输入框
  paintImportResult(k) {
    const box = $(`#importList [data-res="${k}"]`);
    if (!box) return;
    const st = (S.form.importState || {})[k];
    if (!st) { box.innerHTML = ''; return; }
    if (st.checking) { box.innerHTML = `<div class="hint">${t('common.detecting')}</div>`; return; }
    if (st.ok) {
      const bits = [];
      const i = st.info || {};
      if (i.train_tokens) bits.push(`${fmt(i.train_tokens)} token`);
      if (i.vocab_size) bits.push(`vocab ${i.vocab_size}`);
      if (i.global_step != null) bits.push(t('import.step', { n: fmt(i.global_step) }));
      if (i.size_gb) bits.push(`${i.size_gb} GB`);
      if (i.size_mb) bits.push(`${i.size_mb} MB`);
      if (i.has_optimizer === false) bits.push(t('import.weightsOnly'));
      let h = `<div class="imp-ok">✓ ${t('import.usable')}${bits.length ? ' · ' + bits.join(' · ') : ''}</div>`;
      (st.warnings || []).forEach((w) => { h += `<div class="imp-warn">⚠ ${esc(sv(w))}</div>`; });
      box.innerHTML = h;
    } else {
      box.innerHTML = `<div class="imp-bad">✕ ${esc((st.problems || []).map(sv).join(PREF.lang === 'en' ? '; ' : '；'))}</div>`;
    }
  },

  async checkImport(k, quiet) {
    const cur = (S.form.sources || {})[k] || {};
    const p = (cur.path || '').trim();
    if (!p) { if (!quiet) toast(t('import.needPath'), 'err'); return; }
    S.form.importState = S.form.importState || {};
    // 同一路径正在校验或已校验过就不重复请求
    if (S.form.importState[k] && S.form.importState[k]._p === p
        && !S.form.importState[k].checking) {
      App.paintImportResult(k); return;
    }
    S.form.importState[k] = { checking: true, _p: p };
    App.paintImportResult(k);
    try {
      const r = await api('/api/import/check', { stage: k, path: p });
      // 请求期间用户可能又改了路径，过期结果直接丢弃
      const now = ((S.form.sources || {})[k] || {}).path || '';
      if (now.trim() !== p) return;
      r._p = p;
      S.form.importState[k] = r;
      App.paintImportResult(k);
      if (!r.ok && !quiet) toast(t('import.bad'), 'err');
    } catch (e) {
      S.form.importState[k] = { ok: false, problems: [e.message], _p: p };
      App.paintImportResult(k);
    }
  },

  async check() {
    const c = App.readForm();
    const r = await api('/api/check', { tier: c.tier, block_size: c.block_size, arch: c.arch, vocab_size: c.vocab_size });
    const box = $('#checkResult');
    const warns = r.warnings || [];
    if (!r.ok) {
      box.innerHTML = `<div class="banner err"><span class="bi">✕</span><div><b>${t('create.checkBad')}</b><br>${r.problems.map((x) => esc(sv(x))).join('<br>')}</div></div>`;
    } else if (warns.length) {
      box.innerHTML = `<div class="banner"><span class="bi">⚠</span><div><b>${t('create.checkWarn')}</b>　${t('create.vramNeed', { v: r.vram_need_gb })}<br>${warns.map((x) => esc(sv(x))).join('<br>')}
        ${(r.notes || []).length ? '<br>' + r.notes.map((x) => esc(sv(x))).join(' ') : ''}</div></div>`;
    } else {
      box.innerHTML = `<div class="banner ok"><span class="bi">✓</span><div><b>${t('create.checkOk')}</b>　${t('create.vramNeed', { v: r.vram_need_gb })}
        ${(r.notes || []).map((x) => esc(sv(x))).join(' ')}</div></div>`;
    }
    return r.ok;
  },

  async create() {
    const name = $('#fName').value.trim();
    if (!name) { toast(t('create.needName'), 'err'); return; }
    const cfg = App.readForm();
    if (!cfg.corpus.length) { toast(t('create.needCorpus'), 'err'); return; }
    if (!(await App.check())) { toast(t('create.checkBad'), 'err'); return; }
    try {
      await api('/api/projects/create', { name, config: cfg });
      toast(t('create.created') + name, 'ok');
      S.current = name; S.lastDone = false; $('#fName').value = '';
      App.go('data');
    } catch (e) { toast(e.message, 'err'); }
  },

  /* ---------------- data page ---------------- */
  async refreshData() {
    if (!S.current) { $('#dataEmpty').style.display = ''; $('#dataBody').style.display = 'none'; return; }
    $('#dataEmpty').style.display = 'none'; $('#dataBody').style.display = '';
    try {
      const p = await api('/api/project?name=' + encodeURIComponent(S.current));
      S.proj = p;
      $('#dataName').textContent = p.name;
      const c = p.config;
      $('#dataCfg').textContent = `${(c.corpus || []).length} × ${t('create.corpusN')} | ${levelName(c.clean_level)} | vocab ${c.vocab_size}`;
      $('#btnDataStop').disabled = !p.state.running;
      App.renderDataPipe(p.state); App.renderGroups(p.state); App.renderDataCorpus(c);
      $('#dataError').innerHTML = p.state.error
        ? `<div class="banner err" style="margin:16px 0 0"><span class="bi">✕</span><div>${esc(p.state.error)}</div></div>` : '';
      await App.refreshDataLog();
    } catch (e) { toast(e.message, 'err'); }
  },

  renderDataPipe(st) {
    const stages = S.meta.stages.filter((s) => DATA_STAGES.includes(s.key));
    $('#dataPipe').innerHTML = stages.map((s) => {
      const x = st.stages[s.key] || { status: 'pending', progress: 0 };
      const pct = x.status === 'done' ? 100 : Math.round((x.progress || 0) * 100);
      return `<div class="pstage ${x.status}" data-k="${s.key}">
        <div class="pbar"><div class="pfill" style="width:${pct}%"></div></div>
        <div class="pn">${stageName(s.key)}</div>
        <div class="ps">${x.status === 'running' ? pct + '%' : (x.status === 'done' ? '✓' : '')}</div></div>`;
    }).join('');
    $$('#dataPipe .pstage').forEach((el) => { el.onclick = () => { S.dataLogStage = el.dataset.k; App.refreshDataLog(); }; });
  },

  renderGroups(st) {
    const running = st.running;
    const ready = { prepare: true, build: st.stages.clean.status === 'done', all_data: true,
      train: st.stages.mix.status === 'done', test: st.stages.train.status === 'done', full: true };
    $('#groupList').innerHTML = S.meta.groups.map((g) => {
      const ok = ready[g.key];
      const allDone = g.stages.every((k) => st.stages[k].status === 'done');
      const names = g.stages.map(stageName).join(' → ');
      return `<div class="group ${(!ok || running) ? 'dis' : ''}" data-g="${g.key}">
        <div class="gn">${groupName(g.key)}${allDone ? ` <span class="tag done">${t('data.allDone')}</span>` : ''}</div>
        <div class="gd">${esc(sv(g.desc))}</div><div class="gs">${esc(names)}</div>
        <span class="gready ${ok ? 'yes' : 'no'}">${ok ? (allDone ? t('data.rerun') : t('data.ready')) : t('data.needPrev')}</span>
      </div>`;
    }).join('');
    $$('#groupList .group').forEach((el) => {
      el.onclick = async () => {
        if (el.classList.contains('dis')) { toast(running ? t('data.running') : t('data.needPrevToast'), 'err'); return; }
        const g = S.meta.groups.find((x) => x.key === el.dataset.g);
        if (g.stages.every((k) => st.stages[k].status === 'done')) {
          if (!(await confirmBox(t('data.rerunTitle'), t('data.rerunText', { g: groupName(g.key) })))) return;
          await api('/api/run/reset', { name: S.current, stages: g.stages });
        }
        try {
          await api('/api/run/start', { name: S.current, group: g.key });
          toast(t('data.started') + groupName(g.key), 'ok');
          if (g.key === 'train') App.go('train');
          App.refreshData();
        } catch (e) { toast(e.message, 'err'); }
      };
    });
  },

  renderDataCorpus(cfg) {
    const list = cfg.corpus || [];
    if (!list.length) { $('#dataCorpus').innerHTML = `<div class="hint">${t('data.noCorpus')}</div>`; return; }
    const vals = list.map((c) => (c.percent != null ? +c.percent : (c.weight || 1)));
    const sum = vals.reduce((a, b) => a + b, 0) || 1;
    $('#dataCorpus').innerHTML = `<table class="tbl-sm"><thead><tr>
      <th>#</th><th>${t('data.colPath')}</th><th>${t('data.colKind')}</th><th>${t('data.colLevel')}</th>
      <th>${t('data.colPct')}</th><th>${t('create.cjkMin')}</th><th>${t('create.repMax')}</th>
      <th>${t('create.symMax')}</th><th>${t('create.minChars')}</th><th>${t('data.colDedup')}</th><th>${t('data.colCustom')}</th>
      </tr></thead><tbody>` + list.map((c, i) => {
        const lv = c.clean_level || cfg.clean_level;
        const cp = App.cleanParams(c.kind, lv, c.clean_custom);
        const nc = Object.keys(c.clean_custom || {}).length;
        const dm = t('clean.dedup.' + (c.dedup || 'bloom'));
        const warns = App.cleanWarns(c.kind, cp);
        return `<tr><td>${i + 1}</td>
          <td style="max-width:230px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(c.path)}">${esc(c.path)}</td>
          <td>${kindName(c.kind)}</td><td>${levelName(lv)}</td>
          <td class="mono">${((vals[i] / sum) * 100).toFixed(1)}%</td>
          <td class="mono">${cp.min_cjk_ratio}</td><td class="mono">${cp.max_repeat_ratio}</td>
          <td class="mono">${cp.max_symbol_ratio}</td><td class="mono">${cp.min_chars}</td>
          <td>${dm}</td>
          <td>${nc ? `<span class="tag run">${nc}</span>` : `<span style="color:var(--txt3)">${t('common.preset')}</span>`}
            ${warns.length ? `<span title="${esc(warns.join('; '))}" style="color:var(--amber);cursor:help"> ⚠</span>` : ''}</td></tr>`;
      }).join('') + '</tbody></table>' + `<div class="hint" style="margin-top:10px">${t('data.tableHint')}</div>`;
  },

  async refreshDataLog() {
    const stages = S.meta.stages.filter((s) => DATA_STAGES.includes(s.key));
    $('#dataLogTabs').innerHTML = stages.map((s) =>
      `<button data-s="${s.key}" class="${S.dataLogStage === s.key ? 'on' : ''}">${stageName(s.key)}</button>`).join('');
    $$('#dataLogTabs button').forEach((b) => { b.onclick = () => { S.dataLogStage = b.dataset.s; App.refreshDataLog(); }; });
    const cur = stages.find((s) => s.key === S.dataLogStage);
    $('#dataLogName').textContent = cur ? stageName(cur.key) + ' · ' + cur.desc : '';
    try {
      const d = await api(`/api/log?name=${encodeURIComponent(S.current)}&stage=${S.dataLogStage}`);
      const box = $('#dataLogBox');
      const bottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
      box.textContent = d.text || '—';
      if (bottom) box.scrollTop = box.scrollHeight;
    } catch (e) { /* ignore */ }
  },

  /* ---------------- training ---------------- */
  async refreshTrain() {
    if (!S.current) { $('#trainEmpty').style.display = ''; $('#trainBody').style.display = 'none'; return; }
    $('#trainEmpty').style.display = 'none'; $('#trainBody').style.display = '';
    try {
      const p = await api('/api/project?name=' + encodeURIComponent(S.current));
      S.proj = p;
      try { S.runner = (await api('/api/projects')).runner; } catch (e) { /* ignore */ }
      const c = p.config, st = p.state, ts = st.stages.train;
      $('#trainName').textContent = p.name;
      const archTxt = c.arch ? `${c.arch.hidden_size || '?'}×${c.arch.num_hidden_layers || '?'}` : tierLabel(c.tier, S.meta.tier_labels[c.tier]);
      $('#trainCfg').textContent = `${archTxt} | ctx ${c.block_size} | ${c.batch_size}×${c.grad_accum} | ckpt/${c.save_every}`
        + (p.output_dir ? ` | ${t('train.outAt')} ${p.output_dir}` : '');
      const dataReady = st.stages.mix.status === 'done';
      const isTrainRunning = st.running && st.current === 'train';
      const pausing = !!(S.runner && S.runner.pausing);
      $('#btnTrainStart').disabled = st.running || !dataReady;
      $('#btnTrainStop').disabled = !st.running;
      $('#btnTrainPause').disabled = !isTrainRunning || pausing;
      $('#btnTrainPause').innerHTML = pausing ? `<span class="spin"></span> ${t('train.pausing')}` : t('train.pause');
      $('#btnTest').disabled = st.running || ts.status !== 'done';
      $('#btnTrainStart').textContent = ts.status === 'done' ? t('train.restart')
        : (['paused', 'failed', 'stopped'].includes(ts.status) ? t('train.resume') : t('train.start'));
      $('#btnTrainStart').title = dataReady ? '' : t('train.needData');
      const tagMap = { done: 'done', running: 'run', paused: 'idle', failed: 'fail', stopped: 'idle', pending: 'idle' };
      const lblMap = { done: 'stDone', running: 'stRunning', paused: 'stPaused', failed: 'stFailed', stopped: 'stStopped', pending: 'stPending' };
      $('#trainStatusTag').innerHTML = `<span class="tag ${tagMap[ts.status] || 'idle'}">${t('train.' + (lblMap[ts.status] || 'stPending'))}</span>`;
      $('#trainError').innerHTML = st.error
        ? `<div class="banner err" style="margin:16px 0 0"><span class="bi">✕</span><div>${esc(st.error)}</div></div>`
        : (!dataReady ? `<div class="banner" style="margin:16px 0 0"><span class="bi">⚠</span><div>${t('train.dataNotReady')}</div></div>` : '');
      await Promise.all([App.refreshMetrics(), App.refreshCk(), App.refreshTrainLog()]);
      App.renderDoneBanner(p);
    } catch (e) { toast(e.message, 'err'); }
  },

  renderDoneBanner(p) {
    const ts = p.state.stages.train, box = $('#doneBanner');
    if (ts.status !== 'done') { box.innerHTML = ''; S.lastDone = false; return; }
    const dur = (ts.finished_at && ts.started_at) ? ts.finished_at - ts.started_at : null;
    const tested = p.state.stages.test.status === 'done';
    box.innerHTML = `<div class="done-banner">
      <div class="db-ic">✓</div>
      <div style="flex:1;min-width:220px">
        <div class="db-t">${t('train.doneTitle')}</div>
        <div class="db-s">${dur ? t('train.doneTime') + ' ' + fmt.dur(dur) + '　' : ''}${t('train.doneSaved')}${p.config.backup_dir ? ' ' + t('train.doneBackup') + ' ' + esc(p.config.backup_dir) : ''}.
          ${tested ? t('train.doneTested') : t('train.doneSuggest')}</div>
      </div></div>`;
    if (!S.lastDone) { S.lastDone = true; toast(t('train.doneToast'), 'ok'); }
  },

  async refreshMetrics() {
    const d = await api('/api/trainlog?name=' + encodeURIComponent(S.current));
    const pts = d.points || [], last = d.latest, cfg = S.proj.config;
    const budget = cfg.max_tokens > 0 ? cfg.max_tokens : (S.proj.total_tokens || null);
    let eta = null, pct = 0;
    if (last) {
      if (last.tok_s && budget) eta = Math.max(0, (budget - last.tokens) / last.tok_s);
      if (budget) pct = Math.min(100, (last.tokens / budget) * 100);
    }
    const ts = S.proj.state.stages.train;
    if (ts.status === 'done') pct = 100;
    $('#trainFill').style.width = pct.toFixed(2) + '%';
    $('#trainProgPct').textContent = pct.toFixed(2) + '%';
    $('#trainProgText').textContent = ts.status === 'running' ? (sv(ts.message) || t('train.stRunning'))
      : (ts.status === 'done' ? t('train.doneTitle') : (sv(ts.message) || t('train.waiting')));
    $('#metricRow').innerHTML = `
      <div class="metric c1"><div class="mk">${t('train.mStep')}</div><div class="mv">${last ? fmt.n(last.step) : '—'}</div></div>
      <div class="metric c2"><div class="mk">${t('train.mLoss')}</div><div class="mv">${last ? fmt.f(last.loss, 3) : '—'}</div></div>
      <div class="metric c3"><div class="mk">${t('train.mTokens')}</div><div class="mv">${last ? fmt.tok(last.tokens) : '—'}</div></div>
      <div class="metric c1"><div class="mk">${t('train.mSpeed')}</div><div class="mv">${last ? fmt.n(Math.round(last.tok_s)) : '—'}<span class="mu">tok/s</span></div></div>
      <div class="metric c4"><div class="mk">${t('train.mVram')}</div><div class="mv">${last ? fmt.f(last.vram, 1) : '—'}<span class="mu">GB</span></div></div>
      <div class="metric c2"><div class="mk">${t('train.mEta')}</div><div class="mv" style="font-size:18px">${ts.status === 'done' ? t('train.finished') : fmt.eta(eta)}</div></div>
      <div class="metric ${last && last.spikes > 0 ? 'c4' : 'c3'}"><div class="mk">${t('train.mSpike')}</div><div class="mv">${last ? last.spikes + ' / ' + last.rollbacks : '—'}</div></div>`;
    $('#lossEmpty').style.display = pts.length ? 'none' : '';
    $('#perfEmpty').style.display = pts.length ? 'none' : '';
    if (pts.length) { Chart.loss($('#lossChart'), pts, d.evals || []); Chart.perf($('#perfChart'), pts); }
  },

  async refreshCk() {
    const d = await api('/api/checkpoints?name=' + encodeURIComponent(S.current));
    const c = S.proj.config;
    $('#ckSummary').textContent = t('train.ckSummary', { a: c.save_every, b: c.keep_checkpoints })
      + (c.backup_dir ? t('train.ckBackup', { c: c.backup_every, d: c.backup_dir, e: c.keep_backups }) : t('train.ckNoBackup'))
      + t('train.ckNever');
    const box = $('#ckList');
    if (!d.checkpoints.length) { box.innerHTML = `<div class="hint">${t('train.noCk')}</div>`; return; }
    box.innerHTML = `<table class="tbl-sm"><thead><tr><th>${t('train.ckName')}</th><th>${t('train.ckStep')}</th>
      <th>${t('train.ckSize')}</th><th>${t('train.ckTime')}</th><th style="text-align:right">${t('train.ckAction')}</th></tr></thead><tbody>`
      + d.checkpoints.map((x) => `<tr>
        <td><b>${esc(x.name)}</b>${/best|final/.test(x.name) ? ` <span class="tag done">${t('train.ckProtected')}</span>` : ''}</td>
        <td class="mono">${x.step != null ? fmt.n(x.step) : '—'}</td><td class="mono">${x.size_gb} GB</td>
        <td class="mono" style="color:var(--txt3)">${new Date(x.mtime * 1000).toLocaleString()}</td>
        <td style="text-align:right">${/^checkpoint-/.test(x.name) ? `<button class="btn sm" data-resume="${esc(x.name)}">${t('train.ckResume')}</button>` : ''}</td>
      </tr>`).join('') + '</tbody></table>'
      + (d.backup_dir ? `<div class="hint" style="margin-top:12px">${t('train.ckDir')} ${esc(d.backup_dir)}: ${d.backups.length ? d.backups.map(esc).join(', ') : t('train.ckNone')}</div>` : '');
    $$('#ckList [data-resume]').forEach((b) => {
      b.onclick = async () => {
        if (!(await confirmBox(t('train.resumeTitle'), t('train.resumeText', { c: b.dataset.resume })))) return;
        try { await api('/api/run/start', { name: S.current, group: 'train' }); toast(t('train.resumed'), 'ok'); App.refreshTrain(); }
        catch (e) { toast(e.message, 'err'); }
      };
    });
  },

  async editCkPolicy() {
    const c = S.proj.config;
    const html = `<div class="row">
      <div class="field"><label>${t('create.saveEvery')}</label><input type="number" id="eSave" value="${c.save_every}" min="1"></div>
      <div class="field"><label>${t('create.keep')}</label><input type="number" id="eKeep" value="${c.keep_checkpoints}" min="1"></div>
    </div><div class="row">
      <div class="field"><label>${t('create.backupDir')}</label><input type="text" id="eBdir" value="${esc(c.backup_dir)}"></div>
      <div class="field"><label>${t('create.keepBackup')}</label><input type="number" id="eKeepBk" value="${c.keep_backups}" min="1"></div>
    </div>`;
    if (!(await confirmBox(t('train.policyTitle'), t('train.policyText'), html))) return;
    try {
      await api('/api/projects/config', { name: S.current, config: {
        save_every: parseInt($('#eSave').value, 10) || 500,
        keep_checkpoints: parseInt($('#eKeep').value, 10) || 3,
        backup_dir: $('#eBdir').value.trim(),
        backup_every: parseInt($('#eSave').value, 10) || 500,
        keep_backups: parseInt($('#eKeepBk').value, 10) || 10 } });
      toast(t('train.policySaved'), 'ok'); App.refreshTrain();
    } catch (e) { toast(e.message, 'err'); }
  },

  async refreshTrainLog() {
    $$('#trainLogTabs button').forEach((b) => {
      b.classList.toggle('on', b.dataset.s === S.trainLogStage);
      b.onclick = () => { S.trainLogStage = b.dataset.s; App.refreshTrainLog(); };
    });
    try {
      const d = await api(`/api/log?name=${encodeURIComponent(S.current)}&stage=${S.trainLogStage}`);
      const box = $('#trainLogBox');
      const bottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
      box.textContent = d.text || '—';
      if (bottom) box.scrollTop = box.scrollHeight;
    } catch (e) { /* ignore */ }
  },

  async startTrain() {
    const ts = S.proj.state.stages.train;
    if (ts.status === 'done') {
      if (!(await confirmBox(t('train.restartTitle'), t('train.restartText')))) return;
      await api('/api/run/reset', { name: S.current, stages: ['train', 'test'] });
    }
    try {
      await api('/api/run/start', { name: S.current, group: 'train' });
      toast(ts.status === 'paused' ? t('train.resumed') : t('train.started'), 'ok');
      S.lastDone = false; App.refreshTrain();
    } catch (e) { toast(e.message, 'err'); }
  },

  async pauseTrain() {
    if (!(await confirmBox(t('train.pauseTitle'), t('train.pauseText')))) return;
    try {
      const r = await api('/api/run/pause', { name: S.current });
      S.runner = { ...(S.runner || {}), pausing: true };
      toast(r.message || t('train.pauseRequested'), 'ok');
      App.refreshTrain();
    } catch (e) { toast(e.message, 'err'); }
  },

  async stop() {
    if (!(await confirmBox(t('train.stopTitle'), t('train.stopText')))) return;
    try { await api('/api/run/stop', {}); toast(t('train.stopped'), 'ok'); App.refreshTrain(); App.refreshData(); }
    catch (e) { toast(e.message, 'err'); }
  },

  async runTest() {
    try {
      await api('/api/run/start', { name: S.current, group: 'test' });
      S.trainLogStage = 'test'; toast(t('train.testStarted'), 'ok'); App.refreshTrain();
    } catch (e) { toast(e.message, 'err'); }
  },

  /* ---------------- external monitor ---------------- */
  async refreshWatch() {
    if (S.watchName) return App.refreshWatchOne();
    $('#watchDetail').style.display = 'none';
    try {
      const d = await api('/api/watch/list');
      const box = $('#watchList');
      if (!d.items.length) { box.innerHTML = `<div class="empty" style="padding:34px 20px"><div class="ei">◎</div><p>${t('watch.empty')}</p></div>`; return; }
      const tag = { running: 'run', stalled: 'fail', finished: 'done', unknown: 'idle' };
      const lbl = { running: 'stRunning', stalled: 'stStalled', finished: 'stFinished', unknown: 'stUnknown' };
      box.innerHTML = '<div class="pcards">' + d.items.map((s) => {
        const L = s.log.latest, pct = s.percent != null ? s.percent : 0;
        return `<div class="pcard" data-w="${esc(s.name)}">
          <div class="pcn">${esc(s.name)} <span class="tag ${tag[s.state] || 'idle'}">${t('watch.' + (lbl[s.state] || 'stUnknown'))}</span></div>
          <div class="pcm">${L ? `${t('train.mStep')} ${fmt.n(L.step)} | loss ${fmt.f(L.loss, 3)}` : '—'}</div>
          <div class="pcp"><div class="big-prog" style="margin:0"><div class="fill" style="width:${pct.toFixed(2)}%"></div></div>
          <div class="hint" style="margin-top:6px">${s.percent != null ? pct.toFixed(3) + '%' : t('watch.noTotalPct')}${L ? ' | ' + fmt.tok(L.tokens) : ''}</div></div>
        </div>`;
      }).join('') + '</div>';
      $$('#watchList .pcard').forEach((el) => { el.onclick = () => { S.watchName = el.dataset.w; App.refreshWatchOne(); }; });
    } catch (e) { toast(e.message, 'err'); }
  },

  async refreshWatchOne() {
    if (!S.watchName) return;
    try {
      const s = await api('/api/watch/one?name=' + encodeURIComponent(S.watchName));
      S.watchSnap = s;
      $('#watchDetail').style.display = '';
      $('#wTitle').textContent = s.name;
      $('#wPath').textContent = s.out_dir;
      const tag = { running: 'run', stalled: 'fail', finished: 'done', unknown: 'idle' };
      const lbl = { running: 'stRunning', stalled: 'stStalled', finished: 'stFinished', unknown: 'stUnknown' };
      $('#wStateTag').innerHTML = `<span class="tag ${tag[s.state] || 'idle'}">${t('watch.' + (lbl[s.state] || 'stUnknown'))}</span>`;
      const L = s.log.latest, pct = s.percent != null ? s.percent : 0;
      $('#wFill').style.width = pct.toFixed(2) + '%';
      $('#wProgPct').textContent = s.percent != null ? pct.toFixed(3) + '%' : '—';
      $('#wProgText').textContent = L ? `${t('train.mStep')} ${fmt.n(L.step)} | ${fmt.tok(L.tokens)}${s.total_tokens ? ' / ' + fmt.tok(s.total_tokens) : ''}` : '—';
      let notice = '';
      if (s.state === 'stalled') notice = `<div class="banner" style="margin:16px 0 0"><span class="bi">⚠</span><div>${t('watch.stalled', { a: fmt.dur(s.log_age_sec), b: fmt.dur(s.stall_threshold_sec) })}</div></div>`;
      else if (s.state === 'running') notice = `<div class="hint" style="margin-top:12px">${t('watch.alive', { a: fmt.dur(s.log_age_sec), b: s.step_sec_est })}</div>`;
      if (!s.total_tokens && !s.total_steps) notice += `<div class="hint" style="margin-top:8px">${t('watch.noTotal')}</div>`;
      $('#wNotice').innerHTML = notice;
      $('#wMetrics').innerHTML = `
        <div class="metric c1"><div class="mk">${t('train.mStep')}</div><div class="mv">${L ? fmt.n(L.step) : '—'}</div></div>
        <div class="metric c2"><div class="mk">${t('train.mLoss')}</div><div class="mv">${L ? fmt.f(L.loss, 3) : '—'}</div></div>
        <div class="metric c3"><div class="mk">${t('train.mTokens')}</div><div class="mv">${L ? fmt.tok(L.tokens) : '—'}</div></div>
        <div class="metric c1"><div class="mk">${t('train.mSpeed')}</div><div class="mv">${L ? fmt.n(Math.round(L.tok_s)) : '—'}<span class="mu">tok/s</span></div></div>
        <div class="metric c4"><div class="mk">${t('train.mVram')}</div><div class="mv">${L ? fmt.f(L.vram, 1) : '—'}<span class="mu">GB</span></div></div>
        <div class="metric c2"><div class="mk">${t('train.mEta')}</div><div class="mv" style="font-size:18px">${s.state === 'finished' ? t('train.finished') : fmt.eta(s.eta_sec)}</div></div>
        <div class="metric ${L && L.spikes > 0 ? 'c4' : 'c3'}"><div class="mk">${t('train.mSpike')}</div><div class="mv">${L ? L.spikes + ' / ' + L.rollbacks : '—'}</div></div>`;
      const pts = s.log.points || [];
      $('#wLossEmpty').style.display = pts.length ? 'none' : '';
      $('#wPerfEmpty').style.display = pts.length ? 'none' : '';
      if (pts.length) { Chart.loss($('#wLossChart'), pts, s.log.evals || []); Chart.perf($('#wPerfChart'), pts); }
      const cks = s.checkpoints || [];
      $('#wCkList').innerHTML = cks.length
        ? `<table class="tbl-sm"><thead><tr><th>${t('train.ckName')}</th><th>${t('train.ckStep')}</th><th>${t('train.ckSize')}</th><th>${t('train.ckTime')}</th></tr></thead><tbody>`
          + cks.map((c) => `<tr><td><b>${esc(c.name)}</b>${/best|final/.test(c.name) ? ` <span class="tag done">${t('train.ckProtected')}</span>` : ''}</td>
            <td class="mono">${c.step != null ? fmt.n(c.step) : '—'}</td><td class="mono">${c.size_gb} GB</td>
            <td class="mono" style="color:var(--txt3)">${new Date(c.mtime * 1000).toLocaleString()}</td></tr>`).join('') + '</tbody></table>'
        : `<div class="hint">${t('train.noCk')}</div>`;
      const box = $('#wLogBox');
      const bottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
      box.textContent = s.tail || (s.log_file ? t('watch.logEmpty') : t('watch.noLog'));
      if (bottom) box.scrollTop = box.scrollHeight;
    } catch (e) { toast(e.message, 'err'); }
  },

  async watchAdd() {
    const name = $('#wName').value.trim(), dir = $('#wDir').value.trim();
    if (!name || !dir) { toast(t('watch.needFields'), 'err'); return; }
    const raw = $('#wTokens').value.trim();
    let total = 0;
    if (raw) {
      const v = Number(raw);
      if (!isFinite(v) || v < 0) { toast(t('watch.badTotal'), 'err'); return; }
      total = v * 1e9;
    }
    try {
      await api('/api/watch/add', { name, out_dir: dir, total_tokens: total,
        total_steps: parseInt($('#wSteps').value, 10) || 0, log_file: $('#wLog').value.trim() });
      toast(t('watch.added'), 'ok');
      ['#wName', '#wDir', '#wTokens', '#wSteps', '#wLog'].forEach((s) => { $(s).value = ''; });
      S.watchName = name; await App.refreshWatchOne();
    } catch (e) { toast(e.message, 'err'); }
  },

  async watchRemove() {
    if (!(await confirmBox(t('watch.removeTitle'), t('watch.removeText')))) return;
    try {
      await api('/api/watch/remove', { name: S.watchName });
      toast(t('watch.removed'), 'ok'); S.watchName = null; App.refreshWatch();
    } catch (e) { toast(e.message, 'err'); }
  },

  /* ---------------- environment ---------------- */
  async refreshEnv(force) {
    try {
      const d = await api('/api/env' + (force ? '?force=1' : ''));
      S.env = d.env;
      const e = d.env, rt = d.runtime, box = $('#envStatus');
      if (e.ready) {
        const i = e.info;
        const missing = Object.entries(i.mods).filter(([, v]) => !v).map(([k]) => k);
        box.innerHTML = `<div class="done-banner" style="margin:0"><div class="db-ic">✓</div>
          <div style="flex:1"><div class="db-t">${t('env.ready')}</div>
          <div class="db-s">Python ${esc(i.ver)}　PyTorch ${esc(i.torch || '—')}　CUDA ${i.cuda ? t('env.cudaOk') + ' (' + esc(i.cuda_ver || '') + ')' : t('env.cudaNo')}</div></div></div>
          <div class="ci-meta" style="margin-top:14px"><b>${t('env.interpreter')}:</b> ${esc(i.exe)}<br>
          <b>${t('env.deps')}:</b> ${Object.entries(i.mods).map(([k, v]) => `<span style="color:${v ? 'var(--green)' : 'var(--txt3)'}">${v ? '✓' : '○'} ${esc(k)}</span>`).join('　')}</div>
          ${missing.length ? `<div class="hint" style="margin-top:10px">${t('env.optionalMissing', { d: missing.join(', ') })}</div>` : ''}`;
        $('#fPython').value = i.exe;
      } else {
        box.innerHTML = `<div class="banner err" style="margin:0"><span class="bi">✕</span>
          <div><b>${t('env.notReady')}</b><br>${t('env.notReadyText', { d: (e.required || []).join(', ') })}</div></div>
          ${e.tried && e.tried.length ? `<div class="hint" style="margin-top:12px">${t('env.tried', { n: e.tried.length })}</div>` : ''}`;
      }
      const steps = e.howto || [];
      $('#envHowto').innerHTML = `<div class="logbox" style="max-height:none">${steps.map((s, n) => `${n + 1}. ${esc(s)}`).join('\n')}</div>
        <div class="hint" style="margin-top:12px">${t('env.howtoNote')}</div>`;
      $('#envRuntime').innerHTML = `<table class="tbl-sm"><tbody>
        <tr><td style="width:160px;color:var(--txt3)">${t('env.mode')}</td><td>${rt.frozen ? t('env.modeFrozen') : t('env.modeSource')}</td></tr>
        <tr><td style="color:var(--txt3)">${t('env.appRoot')}</td><td class="mono">${esc(rt.app_root)}</td></tr>
        <tr><td style="color:var(--txt3)">${t('env.webRoot')}</td><td class="mono">${esc(rt.resource_root)}</td></tr>
        <tr><td style="color:var(--txt3)">${t('env.engineDir')}</td><td class="mono">${esc(rt.engine_dir)}</td></tr>
        <tr><td style="color:var(--txt3)">${t('env.enginePy')}</td><td class="mono">${esc(rt.engine_python || t('env.notReadyShort'))}</td></tr>
      </tbody></table>`;
    } catch (e) { toast(e.message, 'err'); }
  },

  async setEnv() {
    const p = $('#fPython').value.trim();
    if (!p) { toast(t('env.needPath'), 'err'); return; }
    const b = $('#btnEnvSet');
    b.disabled = true; b.textContent = t('env.checking');
    try {
      await api('/api/env/set', { python: p });
      toast(t('env.switched'), 'ok');
      await App.refreshEnv(true); await App.loadHardware();
    } catch (e) { toast(e.message, 'err'); }
    b.disabled = false; b.textContent = t('env.use');
  },

  tick() {
    if (S.timer) clearInterval(S.timer);
    S.timer = setInterval(() => {
      if ($('#v-train').classList.contains('on') && S.current) App.refreshTrain();
      else if ($('#v-data').classList.contains('on') && S.current) App.refreshData();
      else if ($('#v-watch').classList.contains('on')) App.refreshWatch();
      else if ($('#v-home').classList.contains('on')) App.loadProjects();
    }, 4000);
  },
};

/* ---------------- charts ---------------- */
const Chart = {
  css(name, fallback) {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  },
  // ★画布在隐藏的视图里 getBoundingClientRect() 全为 0，
  //   旧实现用 Math.max(1,…) 兜底 → 画布被设成 1×1，之后即使显示出来也是空白。
  //   现在：量不到尺寸就直接返回 null（调用方跳过绘制，保留上一次画面），
  //   并记下待重绘标记，等视图可见或窗口变化时补画。
  prep(cv) {
    if (!cv) return null;
    let r = cv.getBoundingClientRect();
    if ((!r.width || !r.height) && cv.parentElement) {
      const pr = cv.parentElement.getBoundingClientRect();
      r = { width: pr.width, height: pr.height };
    }
    if (!r.width || !r.height) {
      Chart.pending.add(cv);
      return null;
    }
    Chart.pending.delete(cv);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const W = Math.max(1, Math.round(r.width * dpr));
    const H = Math.max(1, Math.round(r.height * dpr));
    // 只在尺寸真的变了才重设，避免每 4 秒刷新都清空画布造成闪烁
    if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
    const g = cv.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, r.width, r.height);
    return { g, w: r.width, h: r.height };
  },
  pending: new Set(),
  // 视图切换 / 窗口缩放后补画之前量不到尺寸的图
  flush() {
    if (!Chart.pending.size) return;
    Array.from(Chart.pending).forEach((cv) => {
      const fn = Chart.redraw.get(cv);
      if (fn) fn();
    });
  },
  redraw: new Map(),
  frame(g, w, h, pad, ymin, ymax, ylab) {
    const grid = Chart.css('--grid', 'rgba(120,140,200,.14)');
    const txt3 = Chart.css('--txt3', '#7d89a8');
    g.strokeStyle = grid; g.fillStyle = txt3;
    g.font = '11px Consolas, monospace'; g.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = pad.t + (h - pad.t - pad.b) * i / 4;
      g.beginPath(); g.moveTo(pad.l, y); g.lineTo(w - pad.r, y); g.stroke();
      const v = ymax - (ymax - ymin) * i / 4;
      g.textAlign = 'right';
      g.fillText(v.toFixed(ymax - ymin < 5 ? 2 : 0), pad.l - 7, y + 3);
    }
    if (ylab) { g.textAlign = 'left'; g.fillText(ylab, pad.l, 12); }
  },
  line(g, pts, color, width, fill) {
    if (pts.length < 2) return;
    g.beginPath();
    pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]));
    g.strokeStyle = color; g.lineWidth = width || 2;
    g.lineJoin = 'round'; g.lineCap = 'round'; g.stroke();
    if (fill) {
      g.lineTo(pts[pts.length - 1][0], fill.base); g.lineTo(pts[0][0], fill.base); g.closePath();
      const gr = g.createLinearGradient(0, fill.top, 0, fill.base);
      gr.addColorStop(0, fill.c0); gr.addColorStop(1, fill.c1);
      g.fillStyle = gr; g.fill();
    }
  },
  hexA(hex, a) {
    const h = hex.replace('#', '');
    if (h.length !== 6) return hex;
    const n = parseInt(h, 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  },
  loss(cv, pts, evals) {
    if (!cv) return;
    Chart.redraw.set(cv, () => Chart.loss(cv, pts, evals));
    const prep = Chart.prep(cv);
    if (!prep) return;                      // 视图不可见：保留原画面，等可见再画
    const { g, w, h } = prep;
    const pad = { l: 46, r: 16, t: 20, b: 26 };
    const cy = Chart.css('--cyan', '#22d3ee'), vi = Chart.css('--violet', '#a78bfa'), txt3 = Chart.css('--txt3', '#7d89a8');
    const vals = pts.map((p) => p.loss).filter((v) => v != null);
    if (!vals.length) return;
    let ymin = Math.min(...vals), ymax = Math.max(...vals);
    const m = (ymax - ymin) * 0.12 || 0.5;
    ymin = Math.max(0, ymin - m); ymax += m;
    const x0 = pts[0].step, x1 = pts[pts.length - 1].step || 1;
    const X = (s) => pad.l + (w - pad.l - pad.r) * ((s - x0) / Math.max(x1 - x0, 1));
    const Y = (v) => pad.t + (h - pad.t - pad.b) * (1 - (v - ymin) / (ymax - ymin));
    Chart.frame(g, w, h, pad, ymin, ymax, 'loss');
    const tp = pts.filter((p) => p.loss != null).map((p) => [X(p.step), Y(p.loss)]);
    Chart.line(g, tp, cy, 2, { base: h - pad.b, top: pad.t, c0: Chart.hexA(cy, .22), c1: Chart.hexA(cy, 0) });
    if (evals && evals.length) {
      const ep = evals.filter((e) => e.loss != null).map((e) => [X(e.step), Y(e.loss)]);
      Chart.line(g, ep, vi, 1.7);
      g.fillStyle = vi; ep.forEach((p) => { g.beginPath(); g.arc(p[0], p[1], 3, 0, 7); g.fill(); });
    }
    g.fillStyle = txt3; g.textAlign = 'left'; g.fillText(x0, pad.l, h - 8);
    g.textAlign = 'right'; g.fillText(x1, w - pad.r, h - 8);
    g.fillStyle = cy; g.fillText('— ' + t('train.chartTrain'), w - pad.r - 58, 12);
    g.fillStyle = vi; g.fillText('— ' + t('train.chartVal'), w - pad.r, 12);
  },
  perf(cv, pts) {
    if (!cv) return;
    Chart.redraw.set(cv, () => Chart.perf(cv, pts));
    const prep = Chart.prep(cv);
    if (!prep) return;
    const { g, w, h } = prep;
    const pad = { l: 50, r: 44, t: 20, b: 26 };
    const gr = Chart.css('--green', '#34d399'), am = Chart.css('--amber', '#fbbf24'), txt3 = Chart.css('--txt3', '#7d89a8');
    const sp = pts.filter((p) => p.tok_s != null), vr = pts.filter((p) => p.vram != null);
    if (!sp.length) return;
    const smax = Math.max(...sp.map((p) => p.tok_s)) * 1.15 || 1;
    const vmax = Math.max(...vr.map((p) => p.vram), 1) * 1.25;
    const x0 = pts[0].step, x1 = pts[pts.length - 1].step || 1;
    const X = (s) => pad.l + (w - pad.l - pad.r) * ((s - x0) / Math.max(x1 - x0, 1));
    const YS = (v) => pad.t + (h - pad.t - pad.b) * (1 - v / smax);
    const YV = (v) => pad.t + (h - pad.t - pad.b) * (1 - v / vmax);
    Chart.frame(g, w, h, pad, 0, smax, 'tok/s');
    Chart.line(g, sp.map((p) => [X(p.step), YS(p.tok_s)]), gr, 2,
      { base: h - pad.b, top: pad.t, c0: Chart.hexA(gr, .18), c1: Chart.hexA(gr, 0) });
    if (vr.length) Chart.line(g, vr.map((p) => [X(p.step), YV(p.vram)]), am, 1.7);
    g.fillStyle = am; g.textAlign = 'left'; g.font = '11px Consolas, monospace';
    for (let i = 0; i <= 4; i++) {
      const y = pad.t + (h - pad.t - pad.b) * i / 4;
      g.fillText((vmax - vmax * i / 4).toFixed(0) + 'G', w - pad.r + 6, y + 3);
    }
    g.fillStyle = txt3; g.textAlign = 'left'; g.fillText(x0, pad.l, h - 8);
    g.textAlign = 'right'; g.fillStyle = gr; g.fillText('— ' + t('train.chartSpeed'), w - pad.r - 56, 12);
    g.fillStyle = am; g.fillText('— ' + t('train.chartVram'), w - pad.r, 12);
  },
};

/* ---------------- hints ---------------- */
function updateSaveHint() {
  const el = $('#saveHint'); if (!el) return;
  const v = parseInt($('#fSave').value, 10) || 500;
  const ctx = parseInt($('#fCtx').value, 10) || 1024;
  const bs = parseInt($('#fBatch').value, 10) || 4;
  const ga = parseInt($('#fAccum').value, 10) || 4;
  el.textContent = t('create.saveHint', { v, t: fmt.tok(v * ctx * bs * ga) });
}

function updateTokensHint() {
  const el = $('#tokensHint'); if (!el) return;
  const b = parseFloat($('#fTokens').value);
  const v = isFinite(b) ? b : 0;
  el.textContent = t('create.tokensHint', { b: v.toFixed(3), n: fmt.n(Math.round(v * 1e9)) });
}

/* ---------------- init ---------------- */
(async function init() {
  applyTheme(); applyLang();

  $('#btnTheme').onclick = () => {
    PREF.theme = PREF.theme === 'dark' ? 'light' : 'dark';
    applyTheme();
    if (S.current && $('#v-train').classList.contains('on')) App.refreshMetrics();
    if (S.watchName && $('#v-watch').classList.contains('on')) App.refreshWatchOne();
  };
  $('#btnLang').onclick = () => {
    PREF.lang = PREF.lang === 'zh' ? 'en' : 'zh';
    App.rerenderAll();
  };

  $$('nav button').forEach((b) => { b.onclick = () => App.go(b.dataset.view); });
  $('#btnAddCorpus').onclick = App.addCorpus;
  $('#btnMixEven').onclick = () => {
    S.form.corpus.forEach((c) => { c.percent = null; });
    App.renderCorpus(); App.renderMixPreview();
  };
  $('#btnCreate').onclick = App.create;
  $('#btnCheck').onclick = () => App.check().catch((e) => toast(e.message, 'err'));
  $('#btnDataStop').onclick = App.stop;
  $('#btnDataRefresh').onclick = App.refreshData;
  $('#btnTrainStart').onclick = App.startTrain;
  $('#btnTrainPause').onclick = App.pauseTrain;
  $('#btnTrainStop').onclick = App.stop;
  $('#btnTrainRefresh').onclick = App.refreshTrain;
  $('#btnTest').onclick = App.runTest;
  $('#btnEditCk').onclick = App.editCkPolicy;
  $('#btnWatchAdd').onclick = App.watchAdd;
  $('#btnWatchRefresh').onclick = App.refreshWatchOne;
  $('#btnWatchBack').onclick = () => { S.watchName = null; App.refreshWatch(); };
  $('#btnWatchRemove').onclick = App.watchRemove;
  $('#btnEnvRecheck').onclick = async () => {
    const b = $('#btnEnvRecheck');
    b.disabled = true; b.innerHTML = `<span class="spin"></span> ${t('common.detecting')}`;
    await App.refreshEnv(true); await App.loadHardware().catch(() => {});
    b.disabled = false; b.textContent = t('env.recheck');
  };
  $('#btnEnvSet').onclick = App.setEnv;
  $('#btnArchToggle').onclick = () => { S.form.archOpen = !S.form.archOpen; App.renderArch(); };

  $$('#segSave button').forEach((b) => {
    b.onclick = () => {
      $$('#segSave button').forEach((x) => x.classList.remove('on'));
      b.classList.add('on');
      if (b.dataset.v !== 'custom') $('#fSave').value = b.dataset.v;
      else { $('#fSave').focus(); $('#fSave').select(); }
      updateSaveHint();
    };
  });
  ['#fSave', '#fCtx', '#fBatch', '#fAccum'].forEach((id) => $(id).addEventListener('input', updateSaveHint));
  $('#fTokens').addEventListener('input', updateTokensHint);
  $('#fVocab').addEventListener('change', () => { if (S.form.archOpen) App.renderArch(); });
  $$('#segSpike button').forEach((b) => {
    b.onclick = () => {
      $$('#segSpike button').forEach((x) => x.classList.remove('on'));
      b.classList.add('on'); S.form.spike = b.dataset.v === '1';
    };
  });

  $$('#segLogLang button').forEach((b) => {
    b.onclick = () => {
      $$('#segLogLang button').forEach((x) => x.classList.remove('on'));
      b.classList.add('on'); S.form.logLang = b.dataset.v === 'en' ? 'en' : 'zh';
    };
  });

  let rz;
  window.addEventListener('resize', () => {
    clearTimeout(rz);
    rz = setTimeout(() => {
      if ($('#v-train').classList.contains('on') && S.current) App.refreshMetrics();
      if ($('#v-watch').classList.contains('on') && S.watchName) App.refreshWatchOne();
      Chart.flush();          // 尺寸变了，补画之前量不到尺寸的图
    }, 200);
  });

  try {
    await App.loadMeta();
    await App.loadHardware();
    await App.loadProjects();
    updateSaveHint(); updateTokensHint();
    App.tick();
    const d = await api('/api/env');
    S.env = d.env;
    if (!d.env.ready) { toast(t('env.toastNoEnv'), 'err'); App.go('env'); await App.refreshEnv(); }
  } catch (e) { toast(e.message, 'err'); }
  setInterval(() => App.loadHardware().catch(() => {}), 30000);
})();

window.App = App;
